var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// server/lextel-parse.ts
function nextReconnectDelay(current, reason) {
  if (reason === "drop") return Math.max(current, RECONNECT_AFTER_DROP_MS);
  const base2 = Math.max(current, 600);
  return Math.min(RECONNECT_CAP_MS, Math.round(base2 * 1.5));
}
function captureStreamStalled(now, updatedAt2, attachedAt2, stallMs = CAPTURE_STALL_MS) {
  if (!updatedAt2 || !attachedAt2) return false;
  if (now - attachedAt2 < stallMs) return false;
  return now - updatedAt2 >= stallMs;
}
function pushCaptureRing(ring, chunk, max = CAPTURE_RING_MAX) {
  if (!chunk.length) return ring;
  const next = Buffer.concat([ring, chunk]);
  if (next.length <= max) return next;
  return Buffer.from(next.subarray(next.length - max));
}
function round(n, d) {
  const p = 10 ** d;
  return Math.round(n * p) / p;
}
function alarmsOf(r, flags = 0) {
  const alarms = {
    vLow: r.vdc > 0 && r.vdc < 10.5,
    vHigh: r.vdc > 28,
    swrHigh: r.swr >= 2,
    antFault: r.swr >= 3 || Boolean(flags & 8),
    pwrHigh: r.pep > 2e3 || Boolean(flags & 16)
  };
  if (flags & 1) alarms.vHigh = true;
  if (flags & 2) alarms.vLow = true;
  if (flags & 4) alarms.swrHigh = true;
  const labels = [];
  if (alarms.vHigh) labels.push("vHigh");
  if (alarms.vLow) labels.push("vLow");
  if (alarms.swrHigh) labels.push("swrHigh");
  if (alarms.antFault) labels.push("antFault");
  if (alarms.pwrHigh) labels.push("pwrHigh");
  return { alarms, labels };
}
function finish(partial, flags = 0) {
  const base2 = {
    pep: round(Math.max(0, partial.pep ?? 0), 3),
    avg: round(Math.max(0, partial.avg ?? 0), 3),
    ref: round(Math.max(0, partial.ref ?? 0), 3),
    swr: round(Math.min(9.9, Math.max(1, partial.swr ?? 1)), 2),
    vdc: round(Math.max(0, partial.vdc ?? 0), 2),
    z: round(Math.max(0, partial.z ?? 0), 1),
    mod: round(Math.min(150, Math.max(0, partial.mod ?? 0)), 1)
  };
  return { ...base2, ...alarmsOf(base2, flags) };
}
function plausible(r, idleOk = true) {
  let s = 0;
  if (r.vdc >= 10 && r.vdc <= 30) s += 3;
  else if (r.vdc === 0 && idleOk) s += 0;
  if (r.z >= 5 && r.z <= 500) s += 2;
  if (r.swr >= 1 && r.swr <= 9.9) s += 2;
  if (r.pep >= 0 && r.pep <= 2400) s += 1;
  if (r.avg >= 0 && r.avg <= 2400 && r.avg <= r.pep + 80) s += 1;
  if (r.ref >= 0 && r.ref <= 2400 && r.ref <= r.pep + 80) s += 1;
  if (r.mod >= 0 && r.mod <= 150) s += 1;
  return s;
}
function num(v) {
  if (v == null || v === "") return void 0;
  const n = Number(v.replace(",", "."));
  return Number.isFinite(n) ? n : void 0;
}
function wattsField(n) {
  if (n == null || !Number.isFinite(n)) return 0;
  return n / 1e3;
}
function readingFromLetters(L) {
  if (L.A == null && L.E == null) return null;
  if (L.D == null && L.E == null && L.A == null) return null;
  const f = L.F;
  return finish({
    pep: wattsField(L.A),
    avg: wattsField(L.B),
    ref: wattsField(L.C),
    swr: L.D ?? 1,
    vdc: L.E ?? 0,
    // F on the MS-2000 is band in MHz (7 = 40 m), not Z and not AM %.
    z: f != null && f > 150 && f <= 500 ? f : 0,
    mod: 0
  });
}
function parseLetterBlock(text) {
  const L = {};
  const re = /(?:^|\r?\n)([A-F]):\s*([\d.,]+)/gi;
  let m;
  let last = null;
  while (m = re.exec(text)) {
    L[m[1].toUpperCase()] = Number(m[2].replace(",", "."));
    if (L.A != null && L.D != null && L.E != null && L.F != null) {
      last = readingFromLetters(L);
    }
  }
  return last ?? readingFromLetters(L);
}
function parseAsciiLine(line) {
  const t = line.trim();
  if (!t) return null;
  const letter = t.match(/^([A-F]):\s*([\d.,]+)$/i);
  if (letter) {
    const one = { [letter[1].toUpperCase()]: Number(letter[2].replace(",", ".")) };
    const fromOne = readingFromLetters(one);
    if (fromOne && letter[1].toUpperCase() === "E") return fromOne;
  }
  if (t.startsWith("{") && t.endsWith("}")) {
    try {
      const j = JSON.parse(t);
      const pick = (...keys) => {
        for (const k of keys) {
          const v = j[k];
          if (typeof v === "number" && Number.isFinite(v)) return v;
          if (typeof v === "string") {
            const n = Number(v);
            if (Number.isFinite(n)) return n;
          }
        }
        return void 0;
      };
      const pep = pick("pep", "PEP", "p", "fwd", "peak");
      if (pep == null && pick("v", "vdc", "volt", "voltage") == null) return null;
      return finish({
        pep,
        avg: pick("avg", "average", "rms", "pavg", "media"),
        ref: pick("ref", "refl", "pr", "reflected"),
        swr: pick("swr", "roe", "vswr"),
        vdc: pick("vdc", "volt", "voltage", "v", "psu"),
        z: pick("z", "ohm", "r", "zant"),
        mod: pick("mod", "am", "modulation")
      });
    } catch {
    }
  }
  const kv = {};
  const re = /(PEP|PEAK|AVG|MEDIA|MÉDIA|SWR|ROE|VSWR|VDC|VOLT|V|REF|REFL|MOD|AM|Z|OHM|RANT)\s*[:=]\s*([\d.,]+)/gi;
  let m;
  while (m = re.exec(t)) {
    kv[m[1].toUpperCase()] = Number(m[2].replace(",", "."));
  }
  if (kv.PEP != null || kv.PEAK != null || kv.SWR != null || kv.ROE != null || kv.VDC != null) {
    return finish({
      pep: kv.PEP ?? kv.PEAK,
      avg: kv.AVG ?? kv.MEDIA ?? kv.M\u00C9DIA,
      ref: kv.REF ?? kv.REFL,
      swr: kv.SWR ?? kv.ROE ?? kv.VSWR,
      vdc: kv.VDC ?? kv.VOLT ?? kv.V,
      z: kv.Z ?? kv.OHM ?? kv.RANT,
      mod: kv.MOD ?? kv.AM
    });
  }
  const parts = t.split(/[;,\s]+/).map((x) => x.trim()).filter(Boolean);
  const nums = parts.map((p) => num(p)).filter((n) => n != null);
  if (nums.length >= 5 && nums.length <= 10) {
    const cand = finish({
      pep: nums[0],
      avg: nums[1],
      ref: nums[2],
      swr: nums[3] < 20 ? nums[3] : nums[3] / 10,
      vdc: nums[4] > 30 ? nums[4] / 10 : nums[4],
      z: nums[5],
      mod: nums[6]
    });
    if (plausible(cand) >= 6) return cand;
  }
  return null;
}
function uInt(buf, off, size, le) {
  if (size === 1) return buf[off] ?? 0;
  if (off + 1 >= buf.length) return 0;
  return le ? buf.readUInt16LE(off) : buf.readUInt16BE(off);
}
function applyMap(frame, layout) {
  if (!layout.map) return null;
  const le = layout.endian !== "be";
  const get = (key, fallback = 0) => {
    const f = layout.map?.[key];
    if (!f) return fallback;
    return uInt(frame, f.off, f.size, le) * f.scale;
  };
  const flags = layout.map.flags ? uInt(frame, layout.map.flags.off, layout.map.flags.size, le) : 0;
  const pep = get("pep");
  const swrRaw = get("swr", 1);
  const vdcRaw = get("vdc");
  return finish(
    {
      pep,
      avg: get("avg"),
      ref: get("ref"),
      swr: swrRaw < 1 ? 1 : swrRaw > 20 ? swrRaw / (swrRaw > 200 ? 100 : 10) : swrRaw,
      vdc: vdcRaw > 40 ? vdcRaw / (vdcRaw > 400 ? 100 : 10) : vdcRaw,
      z: get("z"),
      mod: get("mod")
    },
    flags
  );
}
function tryBin16(frame, le) {
  if (frame.length < 14) return null;
  const g = (off) => le ? frame.readUInt16LE(off) : frame.readUInt16BE(off);
  const pep = g(0);
  const avg = g(2);
  const ref = g(4);
  let swr = g(6);
  let vdc = g(8);
  const z = g(10);
  const mod = frame[12] ?? 0;
  const flags = frame[13] ?? 0;
  if (swr > 20) swr = swr / (swr > 200 ? 100 : 10);
  if (vdc > 40) vdc = vdc / (vdc > 400 ? 100 : 10);
  const pepW = pep > 2400 ? pep / 10 : pep;
  const avgW = avg > 2400 ? avg / 10 : avg;
  const refW = ref > 2400 ? ref / 10 : ref;
  const cand = finish({ pep: pepW, avg: avgW, ref: refW, swr, vdc, z, mod }, flags);
  return plausible(cand) >= 7 ? cand : null;
}
function scaleFits(raw, min, max) {
  for (const s of [1, 0.1, 0.01]) {
    const v = raw * s;
    if (v >= min && v <= max) return s;
  }
  return null;
}
function learnLayout(buf) {
  if (buf.length < 64) return null;
  let best = null;
  for (let period = 8; period <= 32; period++) {
    const frames = [];
    for (let i = 0; i + period <= buf.length && frames.length < 12; i += period) {
      frames.push(buf.subarray(i, i + period));
    }
    if (frames.length < 5) continue;
    for (const endian of ["le", "be"]) {
      const le = endian === "le";
      const map = {};
      const assign = (key, min, max, prefer2 = true) => {
        let hit = null;
        let hitScore = 0;
        const maxOff = period - 1;
        for (let off = 0; off <= maxOff; off++) {
          for (const size of prefer2 ? [2, 1] : [1, 2]) {
            if (off + size > period) continue;
            const used = Object.values(map).some((f) => f && !(off + size <= f.off || f.off + f.size <= off));
            if (used) continue;
            const vals = frames.map((f) => uInt(f, off, size, le));
            const median = vals.slice().sort((a, b) => a - b)[Math.floor(vals.length / 2)] ?? 0;
            const scale = scaleFits(median, min, max);
            if (scale == null) continue;
            const stable = vals.filter((v) => {
              const x = v * scale;
              return x >= min * 0.5 && x <= max * 1.2;
            }).length;
            if (stable < frames.length - 1) continue;
            if (stable > hitScore) {
              hitScore = stable;
              hit = { off, size, scale };
            }
          }
        }
        if (hit) map[key] = hit;
      };
      assign("vdc", 10, 30);
      assign("z", 5, 500);
      assign("swr", 1, 9.9);
      assign("pep", 0, 2400);
      assign("avg", 0, 2400);
      assign("ref", 0, 2400);
      assign("mod", 0, 150, false);
      if (!map.vdc && !map.pep) continue;
      const layout = { kind: "learned", period, endian, map };
      const reading2 = applyMap(frames[frames.length - 1], layout);
      if (!reading2) continue;
      const score = plausible(reading2) + Object.keys(map).length;
      if (!best || score > best.score) best = { score, layout, reading: reading2 };
    }
  }
  if (best && best.score >= 8) return { layout: best.layout, reading: best.reading };
  return null;
}
function toHex(buf, max = 64) {
  const slice = buf.subarray(Math.max(0, buf.length - max));
  return Array.from(slice, (b) => b.toString(16).padStart(2, "0")).join(" ");
}
function guessPeriod(buf) {
  if (buf.length < 48) return null;
  let bestLag = 0;
  let best = 0;
  const n = Math.min(buf.length, 512);
  for (let lag = 8; lag <= 32; lag++) {
    let hit = 0;
    let tot = 0;
    for (let i = 0; i + lag < n; i++) {
      tot += 1;
      if (buf[i] === buf[i + lag]) hit += 1;
    }
    const score = tot ? hit / tot : 0;
    if (score > best) {
      best = score;
      bestLag = lag;
    }
  }
  return best >= 0.18 ? bestLag : null;
}
function inspectCapture(buf) {
  const printable = buf.reduce((n, b) => n + (b === 9 || b === 10 || b === 13 || b >= 32 && b < 127 ? 1 : 0), 0);
  const ratio = buf.length ? printable / buf.length : 0;
  let start = 0;
  while (start < buf.length && buf[start] === 0) start += 1;
  const slice = buf.subarray(start);
  const ascii = slice.toString("latin1").replace(/[^\t\r\n\x20-\x7e]/g, ".").slice(0, 480);
  const hexHead = toHex(buf.subarray(0, Math.min(buf.length, 96)), 96);
  const period = guessPeriod(buf);
  const dec2 = new LextelDecoder();
  const reading2 = buf.length ? dec2.push(buf) : null;
  let note = "aguardando bytes";
  if (!buf.length) note = "sem captura";
  else if (ratio > 0.75 || dec2.layout?.kind === "ascii") note = "ASCII A-F (PEP/AVG/REF mW /1000 = W, ROE, V, F)";
  else if (dec2.layout) note = `quadro ${dec2.layout.kind}${period ? ` \xB7 per\xEDodo ~${period} B` : ""}`;
  else if (period) note = `bin\xE1rio repetindo a cada ~${period} B \u2014 ainda mapeando campos`;
  else note = `${buf.length} B recebidos \xB7 ${Math.round(ratio * 100)}% imprim\xEDveis`;
  return {
    ascii,
    printable: ratio,
    period,
    hexHead,
    note,
    layout: dec2.layout,
    reading: reading2
  };
}
var MAX_BUF, CAPTURE_RING_MAX, CAPTURE_RESET_MS, CAPTURE_STALL_MS, RECONNECT_CAP_MS, RECONNECT_AFTER_DROP_MS, LextelDecoder;
var init_lextel_parse = __esm({
  "server/lextel-parse.ts"() {
    "use strict";
    MAX_BUF = 2048;
    CAPTURE_RING_MAX = 32 * 1024;
    CAPTURE_RESET_MS = 15e3;
    CAPTURE_STALL_MS = 8e3;
    RECONNECT_CAP_MS = 9e4;
    RECONNECT_AFTER_DROP_MS = 6e4;
    LextelDecoder = class {
      buf = Buffer.alloc(0);
      ascii = "";
      letters = {};
      layout = null;
      lastHex = "";
      bytes = 0;
      constructor(saved6) {
        this.layout = saved6 ?? null;
      }
      reset(saved6) {
        this.buf = Buffer.alloc(0);
        this.ascii = "";
        this.letters = {};
        this.layout = saved6 ?? null;
        this.lastHex = "";
        this.bytes = 0;
      }
      /** Esvazia a janela de montagem. O mapa já aprendido permanece, para a tela não zerar. */
      trimWindow() {
        this.buf = Buffer.alloc(0);
        this.ascii = "";
        this.letters = {};
        this.lastHex = "";
      }
      push(chunk) {
        if (!chunk.length) return null;
        this.bytes += chunk.length;
        this.buf = Buffer.concat([this.buf, chunk]);
        if (this.buf.length > MAX_BUF) this.buf = this.buf.subarray(this.buf.length - MAX_BUF);
        this.lastHex = toHex(this.buf);
        this.ascii += chunk.toString("latin1");
        if (this.ascii.length > MAX_BUF) this.ascii = this.ascii.slice(-MAX_BUF);
        const block = parseLetterBlock(this.ascii);
        if (block && (plausible(block) >= 4 || this.layout?.kind === "ascii" || block.vdc >= 10)) {
          this.layout = { kind: "ascii" };
          return block;
        }
        const nl = this.ascii.lastIndexOf("\n");
        const cr = this.ascii.lastIndexOf("\r");
        const cut = Math.max(nl, cr);
        if (cut > 0) {
          const lines = this.ascii.slice(0, cut).split(/\r\n|\n|\r/);
          this.ascii = this.ascii.slice(cut + 1);
          for (const line of lines) {
            const lettr = line.trim().match(/^([A-F]):\s*([\d.,]+)$/i);
            if (lettr) {
              this.letters[lettr[1].toUpperCase()] = Number(lettr[2].replace(",", "."));
              if (this.letters.A != null && this.letters.E != null) {
                const got = readingFromLetters(this.letters);
                if (got && (plausible(got) >= 4 || this.layout?.kind === "ascii" || got.vdc >= 10)) {
                  this.layout = { kind: "ascii" };
                  return got;
                }
              }
            }
          }
          for (let i = lines.length - 1; i >= 0; i--) {
            const got = parseAsciiLine(lines[i] ?? "");
            if (got && plausible(got) >= 5) {
              this.layout = { kind: lines[i]?.trim().startsWith("{") ? "json" : /[;,]/.test(lines[i] ?? "") ? "csv" : "ascii" };
              return got;
            }
          }
        }
        const aa = this.buf.lastIndexOf(170);
        if (aa >= 0 && aa + 1 < this.buf.length && this.buf[aa + 1] === 85 && aa + 16 <= this.buf.length) {
          const frame = this.buf.subarray(aa, aa + 16);
          const le = tryBin16(frame.subarray(2), true);
          const be = tryBin16(frame.subarray(2), false);
          const hit = (le && plausible(le) >= 7 ? le : null) || (be && plausible(be) >= 7 ? be : null);
          if (hit) {
            this.layout = { kind: "aa55", period: 16, endian: le && plausible(le) >= 7 ? "le" : "be" };
            return hit;
          }
        }
        const stx = this.buf.lastIndexOf(2);
        const etx = this.buf.lastIndexOf(3);
        if (stx >= 0 && etx > stx + 8 && etx - stx <= 40) {
          const frame = this.buf.subarray(stx + 1, etx);
          const hit = tryBin16(frame, true) || tryBin16(frame, false);
          if (hit) {
            this.layout = { kind: "stx", period: etx - stx + 1 };
            return hit;
          }
        }
        if (this.layout?.kind === "learned" || this.layout?.kind === "bin16") {
          const period = this.layout.period ?? 16;
          if (this.buf.length >= period) {
            const frame = this.buf.subarray(this.buf.length - period);
            const hit = this.layout.map ? applyMap(frame, this.layout) : tryBin16(frame, this.layout.endian !== "be");
            if (hit && plausible(hit) >= 5) return hit;
          }
        }
        if (this.buf.length >= 16) {
          const tail2 = this.buf.subarray(this.buf.length - 16);
          const hit = tryBin16(tail2, true) || tryBin16(tail2, false);
          if (hit) {
            this.layout = { kind: "bin16", period: 16, endian: tryBin16(tail2, true) ? "le" : "be" };
            return hit;
          }
        }
        if (!this.layout && this.buf.length >= 96) {
          const learned = learnLayout(this.buf);
          if (learned) {
            this.layout = learned.layout;
            return learned.reading;
          }
        }
        return null;
      }
    };
  }
});

// shared/const.ts
function asSer2netDevice(v) {
  if (v === SER2NET_RADIO_ID) return SER2NET_RADIO_ID;
  return SER2NET_ACC_IDS.includes(v) ? v : "";
}
var ONE_YEAR_MS, SERVICE_IDS, UPDATE_IDS, SER2NET_ACC_IDS, SER2NET_RADIO_ID, SER2NET_ACC_BAUD;
var init_const = __esm({
  "shared/const.ts"() {
    "use strict";
    ONE_YEAR_MS = 1e3 * 60 * 60 * 24 * 365;
    SERVICE_IDS = [
      "ser2net",
      "wavelog",
      "db",
      "wlg",
      "mmdvm",
      "radio",
      "hamlib",
      "spe",
      "hamplus",
      "palstar",
      "ldg",
      "lp100a",
      "acom",
      "lextel",
      "wifi",
      "bluetooth",
      "dhcp",
      "web"
    ];
    UPDATE_IDS = ["app", "os", "ser2net", "hamlib", "wavelog", "wlg"];
    SER2NET_ACC_IDS = ["spe", "hamplus", "palstar", "ldg", "lp100a", "acom"];
    SER2NET_RADIO_ID = "radio";
    SER2NET_ACC_BAUD = {
      spe: 115200,
      hamplus: 9600,
      palstar: 9600,
      ldg: 38400,
      lp100a: 115200,
      acom: 1200
    };
  }
});

// server/rfc2217.ts
function escapeIac(data) {
  let extra = 0;
  for (let i = 0; i < data.length; i++) if (data[i] === IAC) extra++;
  if (!extra) return data;
  const out = Buffer.alloc(data.length + extra);
  let j = 0;
  for (let i = 0; i < data.length; i++) {
    const b = data[i];
    out[j++] = b;
    if (b === IAC) out[j++] = IAC;
  }
  return out;
}
function feedTelnet(sock3, chunk, state) {
  state.buf = Buffer.concat([state.buf, chunk]);
  const app = [];
  const b = state.buf;
  let i = 0;
  while (i < b.length) {
    const c = b[i];
    if (c !== IAC) {
      app.push(c);
      i++;
      continue;
    }
    if (i + 1 >= b.length) break;
    const cmd = b[i + 1];
    if (cmd === IAC) {
      app.push(IAC);
      i += 2;
      continue;
    }
    if (cmd === SB) {
      let j = i + 2;
      let end = -1;
      while (j + 1 < b.length) {
        if (b[j] === IAC && b[j + 1] === SE) {
          end = j;
          break;
        }
        j++;
      }
      if (end < 0) break;
      i = end + 2;
      continue;
    }
    if (cmd === WILL || cmd === WONT || cmd === DO || cmd === DONT) {
      if (i + 2 >= b.length) break;
      const opt = b[i + 2];
      const accept = opt === BINARY || opt === SGA || opt === COM_PORT_OPTION;
      if (cmd === WILL) {
        sock3.write(Buffer.from([IAC, accept ? DO : DONT, opt]));
      } else if (cmd === DO) {
        sock3.write(Buffer.from([IAC, accept ? WILL : WONT, opt]));
      }
      i += 3;
      continue;
    }
    i += 2;
  }
  state.buf = i > 0 ? b.subarray(i) : b;
  return Buffer.from(app);
}
function attachRfc2217(sock3, onAppData) {
  const state = { buf: Buffer.alloc(0) };
  sock3.setNoDelay(true);
  sock3.write(Buffer.from([IAC, WILL, BINARY, IAC, DO, BINARY]));
  sock3.write(Buffer.from([IAC, WILL, SGA, IAC, DO, SGA]));
  sock3.write(Buffer.from([IAC, WILL, COM_PORT_OPTION, IAC, DO, COM_PORT_OPTION]));
  sock3.on("data", (chunk) => {
    const app = feedTelnet(sock3, chunk, state);
    if (app.length) onAppData(app);
  });
  const setControl = (value) => {
    try {
      sock3.write(Buffer.from([IAC, SB, COM_PORT_OPTION, SET_CONTROL, value & 255, IAC, SE]));
      return true;
    } catch {
      return false;
    }
  };
  const writeBinary = (buf) => {
    try {
      sock3.write(escapeIac(buf));
      return true;
    } catch {
      return false;
    }
  };
  const setDtr = (on) => setControl(on ? RFC2217_DTR_ON : RFC2217_DTR_OFF);
  const setRts = (on) => setControl(on ? RFC2217_RTS_ON : RFC2217_RTS_OFF);
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const pulseWake = async (holdMs = 1e3) => {
    setRts(false);
    setDtr(false);
    await sleep(holdMs);
    setRts(true);
    await sleep(50);
    setDtr(true);
  };
  return {
    sock: sock3,
    writeBinary,
    setControl,
    setDtr,
    setRts,
    pulseWake,
    destroy: () => {
      try {
        sock3.removeAllListeners();
        sock3.destroy();
      } catch {
      }
    }
  };
}
var IAC, WILL, WONT, DO, DONT, SB, SE, BINARY, SGA, COM_PORT_OPTION, SET_CONTROL, RFC2217_DTR_ON, RFC2217_DTR_OFF, RFC2217_RTS_ON, RFC2217_RTS_OFF;
var init_rfc2217 = __esm({
  "server/rfc2217.ts"() {
    "use strict";
    IAC = 255;
    WILL = 251;
    WONT = 252;
    DO = 253;
    DONT = 254;
    SB = 250;
    SE = 240;
    BINARY = 0;
    SGA = 3;
    COM_PORT_OPTION = 44;
    SET_CONTROL = 5;
    RFC2217_DTR_ON = 8;
    RFC2217_DTR_OFF = 9;
    RFC2217_RTS_ON = 10;
    RFC2217_RTS_OFF = 11;
  }
});

// shared/ser2net-bind.ts
function ser2netDialHost(bind2) {
  const host2 = bind2.trim();
  if (!host2 || host2 === "0.0.0.0" || host2 === "localhost") return "127.0.0.1";
  return host2;
}
var SER2NET_LISTEN;
var init_ser2net_bind = __esm({
  "shared/ser2net-bind.ts"() {
    "use strict";
    SER2NET_LISTEN = "0.0.0.0";
  }
});

// server/ser2net-store.ts
import { execFile } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from "node:fs";
import { Socket } from "node:net";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { promisify } from "node:util";
import { randomBytes } from "node:crypto";
function dataDir() {
  if (existsSync(OPT_DIR)) return OPT_DIR;
  const local = join(ROOT, "data", "ser2net");
  mkdirSync(local, { recursive: true });
  return local;
}
function paths() {
  const folder = dataDir();
  return {
    folder,
    jsonPath: join(folder, "services.json"),
    yamlPath: join(folder, "ser2net.yaml")
  };
}
function newId() {
  return randomBytes(4).toString("hex");
}
function slug(name, id, used) {
  let base2 = name.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "");
  if (!/^[a-z]/.test(base2)) base2 = `svc_${base2}`;
  if (!base2 || base2 === "svc_") base2 = `svc_${id.replace(/[^a-z0-9]/gi, "").slice(0, 8) || "x"}`;
  base2 = base2.slice(0, 28);
  let a = base2;
  let n = 2;
  while (used.has(a)) a = `${base2.slice(0, 24)}_${n++}`;
  used.add(a);
  return a;
}
function writeAtomic(file, body) {
  const tmp = `${file}.${process.pid}.tmp`;
  writeFileSync(tmp, body, { encoding: "utf8" });
  renameSync(tmp, file);
}
function accepterLine(bind2, port, device) {
  if (device === "spe") return `    accepter: telnet(rfc2217),tcp,${bind2},${port}`;
  return `    accepter: tcp,${bind2},${port}`;
}
function renderYaml(bind2, services) {
  const used = /* @__PURE__ */ new Set();
  const blocks = services.map((svc) => {
    const a = slug(svc.name, svc.id, used);
    const baud = BAUDS.has(svc.baud) ? svc.baud : 9600;
    return [
      `connection: &${a}`,
      accepterLine(bind2, svc.tcpPort, svc.device),
      `    enable: on`,
      `    options:`,
      `      kickolduser: true`,
      `    connector: serialdev,${svc.serial},${baud}n81,local`
    ].join("\n");
  });
  return [
    "%YAML 1.1",
    "---",
    GENERATED,
    "# ser2net 4 \u2014 \xFAnico processo na TTY. SPE usa telnet(rfc2217) (DTR/RTS); demais TCP raw.",
    `# Pasta: ${dataDir()}`,
    "",
    // ser2net 4 recusa documento só com comentários ("Unexpected scalar value") e o
    // systemd reiniciava a cada 2 s. `define` vazio é aceito e mantém o daemon de pé.
    ...blocks.length ? blocks : ["# (nenhum servi\xE7o cadastrado)", 'define: &hc_empty ""'],
    ""
  ].join("\n");
}
function parseYaml(text) {
  if (!text.includes("Ham Cockpit generated")) return null;
  const out = [];
  const re = /connection:\s*&(\S+)\s+accepter:\s*(?:telnet\(rfc2217\),)?tcp,([^,]+),(\d+)\s+enable:\s*on[\s\S]*?connector:\s*serialdev,([^,]+),(\d+)n81,local/g;
  let m;
  while (m = re.exec(text)) {
    const tcpPort = Number(m[3]);
    const baud = Number(m[5]);
    if (!tcpPort) continue;
    out.push({
      id: newId(),
      name: m[1].replace(/_/g, " "),
      serial: m[4].trim(),
      tcpPort,
      baud: BAUDS.has(baud) ? baud : 9600,
      device: ""
    });
  }
  return out;
}
function normalizeSvc(raw, seen) {
  if (!raw || typeof raw !== "object") return null;
  const r = raw;
  const name = String(r.name ?? "").trim();
  const serial = String(r.serial ?? "").trim();
  const tcpPort = Number(r.tcpPort);
  const baud = Number(r.baud);
  if (!name || name.length > 48 || /[\r\n]/.test(name)) return null;
  if (!serial || serial.length > 256 || /[\r\n,]/.test(serial)) return null;
  if (!Number.isInteger(tcpPort) || tcpPort < 1024 || tcpPort > 65535) return null;
  if (!BAUDS.has(baud)) return null;
  const key = name.toLowerCase();
  if (seen.name.has(key) || seen.port.has(tcpPort) || seen.serial.has(serial)) return null;
  seen.name.add(key);
  seen.port.add(tcpPort);
  seen.serial.add(serial);
  const id = String(r.id ?? "").replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 16) || newId();
  return { id, name, serial, tcpPort, baud, device: asSer2netDevice(r.device) };
}
function readJson(file) {
  try {
    const j = JSON.parse(readFileSync(file, "utf8"));
    return j && typeof j === "object" ? j : null;
  } catch {
    return null;
  }
}
async function daemonActive() {
  if (process.platform !== "linux") return false;
  try {
    const { stdout } = await execFileAsync("systemctl", ["is-active", "ser2net.service"], {
      timeout: 5e3,
      windowsHide: true
    });
    return stdout.trim() === "active";
  } catch {
    return false;
  }
}
async function probeHamlibNet(port = HAMLIB_NET_PORT, host2 = "127.0.0.1", timeoutMs = 900) {
  return new Promise((resolve) => {
    const sock3 = new Socket();
    let done = false;
    let timer;
    const finish2 = (ok) => {
      if (done) return;
      done = true;
      if (timer) clearTimeout(timer);
      try {
        sock3.destroy();
      } catch {
      }
      resolve(ok);
    };
    timer = setTimeout(() => finish2(false), timeoutMs);
    sock3.connect(port, host2, () => {
      finish2(true);
    });
    sock3.on("error", () => finish2(false));
    sock3.on("close", () => {
      if (!done) finish2(false);
    });
  });
}
async function openListenPorts() {
  if (process.platform !== "linux" || !existsSync(HELPER)) return;
  try {
    await execFileAsync("sudo", ["-n", HELPER, "open-ports"], { timeout: 15e3, windowsHide: true });
  } catch {
  }
}
async function reloadDaemon() {
  if (process.platform !== "linux") return false;
  try {
    if (existsSync(HELPER)) {
      await execFileAsync("sudo", ["-n", HELPER, "reload-or-restart"], { timeout: 15e3, windowsHide: true });
    } else {
      await execFileAsync("systemctl", ["reload-or-restart", "ser2net.service"], {
        timeout: 15e3,
        windowsHide: true
      });
    }
    return true;
  } catch {
    return false;
  }
}
async function hamlibCtl(action) {
  if (process.platform !== "linux") return false;
  const cmd = action === "start" ? "start-hamlib" : "stop-hamlib";
  try {
    if (existsSync(HELPER)) {
      await execFileAsync("sudo", ["-n", HELPER, cmd], { timeout: 2e4, windowsHide: true });
    } else {
      const unit = "rigctld@ic705.service";
      if (action === "start") {
        await execFileAsync("systemctl", ["restart", unit], { timeout: 15e3, windowsHide: true });
      } else {
        await execFileAsync("systemctl", ["stop", unit], { timeout: 15e3, windowsHide: true });
      }
    }
    return true;
  } catch {
    return false;
  }
}
async function loadSer2net() {
  const { folder, jsonPath: jsonPath9, yamlPath } = paths();
  let bind2 = SER2NET_LISTEN;
  let services = [];
  const json = existsSync(jsonPath9) ? readJson(jsonPath9) : null;
  if (json) {
    if (typeof json.bind === "string" && BIND_RE.test(json.bind.trim())) bind2 = json.bind.trim();
    const seen = { name: /* @__PURE__ */ new Set(), port: /* @__PURE__ */ new Set(), serial: /* @__PURE__ */ new Set() };
    if (Array.isArray(json.services)) {
      for (const row of json.services) {
        const svc = normalizeSvc(row, seen);
        if (svc) services.push(svc);
      }
    }
  } else if (existsSync(yamlPath)) {
    try {
      const parsed = parseYaml(readFileSync(yamlPath, "utf8"));
      if (parsed) services = parsed;
    } catch {
    }
  }
  const [running, hamlibRunning] = await Promise.all([daemonActive(), probeHamlibNet()]);
  return {
    ok: true,
    folder,
    bind: bind2,
    services,
    yamlPath,
    jsonPath: jsonPath9,
    running,
    hamlibRunning
  };
}
async function saveSer2net(input) {
  const current = await loadSer2net();
  const bind2 = typeof input.bind === "string" && BIND_RE.test(input.bind.trim()) ? input.bind.trim() : current.bind;
  if (!Array.isArray(input.services)) {
    return { ...current, ok: false, error: "services", hamlibRunning: current.hamlibRunning };
  }
  if (input.services.length > 32) {
    return { ...current, ok: false, error: "limit", hamlibRunning: current.hamlibRunning };
  }
  const seen = { name: /* @__PURE__ */ new Set(), port: /* @__PURE__ */ new Set(), serial: /* @__PURE__ */ new Set() };
  const services = [];
  for (const row of input.services) {
    const svc = normalizeSvc(row, seen);
    if (!svc) return { ...current, ok: false, error: "invalid", hamlibRunning: current.hamlibRunning };
    services.push(svc);
  }
  const taken = /* @__PURE__ */ new Set();
  for (const svc of services) {
    if (!svc.device) continue;
    if (taken.has(svc.device)) svc.device = "";
    else taken.add(svc.device);
  }
  const { folder, jsonPath: jsonPath9, yamlPath } = paths();
  mkdirSync(folder, { recursive: true });
  const payload = JSON.stringify({ bind: bind2, folder, services }, null, 2);
  writeAtomic(jsonPath9, `${payload}
`);
  writeAtomic(yamlPath, renderYaml(bind2, services));
  await reloadDaemon();
  await openListenPorts();
  const [running, hamlibRunning] = await Promise.all([daemonActive(), probeHamlibNet()]);
  return {
    ok: true,
    folder,
    bind: bind2,
    services,
    yamlPath,
    jsonPath: jsonPath9,
    running,
    hamlibRunning
  };
}
var execFileAsync, ROOT, OPT_DIR, HELPER, GENERATED, BAUDS, BIND_RE, HAMLIB_NET_PORT;
var init_ser2net_store = __esm({
  "server/ser2net-store.ts"() {
    "use strict";
    init_const();
    init_ser2net_bind();
    execFileAsync = promisify(execFile);
    ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
    OPT_DIR = "/opt/ser2net";
    HELPER = "/opt/ham-cockpit/bin/ser2net-ctl";
    GENERATED = "# Ham Cockpit generated \u2014 do not edit";
    BAUDS = /* @__PURE__ */ new Set([1200, 9600, 19200, 38400, 57600, 115200]);
    BIND_RE = /^(127\.0\.0\.1|0\.0\.0\.0|localhost|(\d{1,3}\.){3}\d{1,3})$/;
    HAMLIB_NET_PORT = 4532;
  }
});

// server/spe.ts
var spe_exports = {};
__export(spe_exports, {
  speCmd: () => speCmd,
  speConnect: () => speConnect,
  speDisconnect: () => speDisconnect,
  spePeek: () => spePeek,
  spePowerOn: () => spePowerOn,
  speSave: () => speSave,
  speStatus: () => speStatus
});
import { existsSync as existsSync2, mkdirSync as mkdirSync2, readFileSync as readFileSync2, renameSync as renameSync2, writeFileSync as writeFileSync2 } from "node:fs";
import { spawn } from "node:child_process";
import net from "node:net";
import { dirname as dirname2, join as join2 } from "node:path";
import { fileURLToPath as fileURLToPath2 } from "node:url";
function dataDir2() {
  if (existsSync2("/opt/ham-cockpit")) {
    mkdirSync2(OPT_DIR2, { recursive: true });
    return OPT_DIR2;
  }
  const local = join2(ROOT2, "data", "spe");
  mkdirSync2(local, { recursive: true });
  return local;
}
function jsonPath() {
  return join2(dataDir2(), "spe.json");
}
function writeAtomic2(file, body) {
  const tmp = `${file}.${process.pid}.tmp`;
  writeFileSync2(tmp, body, { encoding: "utf8" });
  renameSync2(tmp, file);
}
function loadSaved() {
  try {
    const raw = JSON.parse(readFileSync2(jsonPath(), "utf8"));
    return { autoConnect: raw.autoConnect !== false };
  } catch {
    return { autoConnect: true };
  }
}
function persist() {
  writeAtomic2(jsonPath(), `${JSON.stringify({ autoConnect: saved.autoConnect }, null, 2)}
`);
}
function hostPacket(data) {
  let chk = 0;
  for (let i = 0; i < data.length; i++) chk = chk + (data[i] || 0) & 255;
  const out = Buffer.alloc(4 + data.length + 1);
  out[0] = 85;
  out[1] = 85;
  out[2] = 85;
  out[3] = data.length;
  data.copy(out, 4);
  out[4 + data.length] = chk;
  return out;
}
function bandLabel(code) {
  const n = Number.parseInt(code, 10);
  if (!Number.isFinite(n) || n < 0 || n >= BANDS.length) return code || "\u2014";
  return BANDS[n];
}
function numField(s) {
  if (s == null) return NaN;
  return Number.parseFloat(String(s).replace(/^\s+/, "").trim());
}
function parseStatusCsv(payload) {
  const parts = payload.split(",");
  const f = parts[0] === "" ? parts.slice(1) : parts;
  if (f.length < 19) return false;
  const model = (f[0] || "").trim();
  if (!/^\d{2}K$/.test(model) && model !== "15K") return false;
  const state = (f[1] || "").trim().toUpperCase();
  const ptt = (f[2] || "").trim().toUpperCase();
  const bankRaw = (f[3] || "A").trim();
  const input = Number.parseInt(f[4] || "1", 10);
  const band = bandLabel((f[5] || "").trim());
  const txAnt = (f[6] || "1").trim();
  const ant = Number.parseInt(txAnt[0] || "1", 10) || 1;
  const pwrCh = (f[8] || "L").trim().toUpperCase();
  const pout = Number.parseInt((f[9] || "0").trim(), 10);
  const swrAtu = numField(f[10]);
  const swrAnt = numField(f[11]);
  const vpa = numField(f[12]);
  const ipa = numField(f[13]);
  const temp = Number.parseInt((f[14] || "0").trim(), 10);
  const warning = (f[17] || "N").trim().toUpperCase();
  const alarm = (f[18] || "N").trim().toUpperCase();
  live.model = model;
  live.operate = state === "O";
  live.tx = ptt === "T";
  live.bank = bankRaw === "B" ? "B" : bankRaw === "x" ? "x" : "A";
  live.input = input === 2 ? 2 : 1;
  live.band = band;
  live.ant = ant >= 1 && ant <= 6 ? ant : 1;
  live.pwr = pwrCh === "M" || pwrCh === "H" ? pwrCh : "L";
  live.pout = Number.isFinite(pout) && pout >= 0 ? pout : 0;
  live.swrAtu = Number.isFinite(swrAtu) && swrAtu > 0 ? Math.round(swrAtu * 100) / 100 : 1;
  live.swrAnt = Number.isFinite(swrAnt) && swrAnt > 0 ? Math.round(swrAnt * 100) / 100 : 1;
  live.vpa = Number.isFinite(vpa) ? Math.round(vpa * 10) / 10 : 0;
  live.ipa = Number.isFinite(ipa) ? Math.round(ipa * 10) / 10 : 0;
  live.temp = Number.isFinite(temp) ? temp : 0;
  live.warning = warning === "N" ? "" : warning;
  live.alarm = alarm === "N" ? "" : alarm;
  live.ledAl = Boolean(live.alarm);
  live.ledTune = /t/i.test(txAnt.slice(1));
  live.ledOn = true;
  live.hardware = true;
  heardHardware = true;
  wakeUntil = 0;
  live.phase = "ready";
  live.error = "";
  live.lastRx = payload.slice(0, 96);
  statusEpoch += 1;
  return true;
}
function consumeRx() {
  for (; ; ) {
    const sync = rx.indexOf(170);
    if (sync < 0) {
      if (rx.length > 512) rx = rx.subarray(rx.length - 16);
      return;
    }
    if (sync > 0) rx = rx.subarray(sync);
    if (rx.length < 4) return;
    if (rx[0] !== 170 || rx[1] !== 170 || rx[2] !== 170) {
      rx = rx.subarray(1);
      continue;
    }
    const cnt = rx[3];
    if (cnt === 67) {
      if (rx.length < 76) return;
      parseStatusCsv(rx.subarray(4, 4 + 67).toString("latin1"));
      rx = rx.subarray(76);
      continue;
    }
    if (cnt === 1) {
      if (rx.length < 6) return;
      rx = rx.subarray(6);
      continue;
    }
    const frameLen = 4 + cnt + 1;
    if (rx.length < frameLen) return;
    rx = rx.subarray(frameLen);
  }
}
function enqueue(fn) {
  const run6 = chain.then(fn, fn);
  chain = run6.then(
    () => void 0,
    () => void 0
  );
  return run6;
}
function snap() {
  return { ok: true, ...live, baud: BAUD, transport: "rfc2217", folder: dataDir2(), build: SPE_BUILD };
}
function clearReconnect() {
  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }
}
function scheduleReconnect() {
  if (!wantLink || reconnectTimer) return;
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    if (!wantLink) return;
    if (sock && !sock.destroyed && live.connected) {
      reconnectDelay = 800;
      return;
    }
    void speConnect().catch(() => void 0);
  }, reconnectDelay);
  reconnectTimer.unref?.();
  reconnectDelay = Math.min(8e3, Math.round(reconnectDelay * 1.5));
}
function clearSilence() {
  if (silenceTimer) {
    clearTimeout(silenceTimer);
    silenceTimer = null;
  }
}
function armSilence(ms = SILENCE_MS) {
  clearSilence();
  silenceTimer = setTimeout(onSilence, ms);
  silenceTimer.unref?.();
}
function noteRx() {
  lastRxAt = Date.now();
  if (sock && !sock.destroyed) armSilence(SILENCE_MS);
}
function settleDown(error3) {
  wantLink = false;
  clearReconnect();
  clearSilence();
  wakeUntil = 0;
  heardHardware = false;
  linkGen += 1;
  sessionGen += 1;
  dropSock();
  live.connected = false;
  live.hardware = false;
  live.phase = "idle";
  live.error = error3;
  live.tx = false;
  live.operate = false;
  live.pout = 0;
  live.ipa = 0;
  live.vpa = 0;
  live.swrAtu = 1;
  live.swrAnt = 1;
  live.ledOn = false;
  live.ledAl = false;
  live.ledTune = false;
  if (!error3) {
    live.lastTxHex = "";
    live.lastRx = "";
  }
}
function onSilence() {
  silenceTimer = null;
  if (!sock || sock.destroyed) return;
  const quietFor = Date.now() - lastRxAt;
  if (quietFor < SILENCE_MS) {
    armSilence(SILENCE_MS - quietFor);
    return;
  }
  if (Date.now() < wakeUntil && !heardHardware) {
    armSilence(Math.max(200, wakeUntil - Date.now()));
    return;
  }
  settleDown("nocomm");
}
function noteDown(msg) {
  live.connected = false;
  live.hardware = false;
  live.ledOn = false;
  if (msg) live.error = msg;
  linkGen += 1;
  if (wantLink) {
    live.phase = "connecting";
    scheduleReconnect();
    return;
  }
  if (live.phase !== "idle") live.phase = "error";
}
function onLinkLost() {
  linkGen += 1;
  live.connected = false;
  live.hardware = false;
  live.ledOn = false;
  live.tx = false;
  const booting = Date.now() < wakeUntil && !heardHardware && wantLink;
  if (booting) {
    live.phase = "connecting";
    live.error = "";
    clearSilence();
    scheduleReconnect();
    return;
  }
  wantLink = false;
  clearReconnect();
  clearSilence();
  wakeUntil = 0;
  heardHardware = false;
  live.phase = "idle";
  live.error = "nocomm";
  live.operate = false;
  live.pout = 0;
  live.ipa = 0;
  live.vpa = 0;
  live.swrAtu = 1;
  live.swrAnt = 1;
  live.ledAl = false;
  live.ledTune = false;
}
function stopPoll() {
  if (pollTimer) {
    clearInterval(pollTimer);
    pollTimer = null;
  }
}
function dropSock() {
  stopPoll();
  clearSilence();
  rx = Buffer.alloc(0);
  const r = rfc;
  rfc = null;
  sock = null;
  if (r) r.destroy();
}
async function resolveEndpoint() {
  const cfg = await loadSer2net();
  const svc = cfg.services.find((x) => x.device === "spe");
  if (!svc) return null;
  return { host: ser2netDialHost(cfg.bind), port: svc.tcpPort };
}
function sudoBounded(args, ms) {
  return new Promise((resolve) => {
    let settled = false;
    const finish2 = () => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve();
    };
    const child2 = spawn("sudo", ["-n", ...args], { detached: true, stdio: "ignore" });
    const timer = setTimeout(() => {
      const pid = child2.pid;
      if (pid) {
        try {
          process.kill(-pid, "SIGKILL");
        } catch {
        }
      }
      finish2();
    }, ms);
    child2.once("error", finish2);
    child2.once("close", finish2);
  });
}
async function ensureSpeRfc2217Yaml() {
  if (yamlEnsured) return;
  yamlEnsured = true;
  const cfg = await loadSer2net();
  const baud = SER2NET_ACC_BAUD.spe;
  const spe = cfg.services.find((s) => s.device === "spe");
  if (spe && spe.baud !== baud) live.error = "baud";
}
async function stopAmpctld() {
  if (process.platform !== "linux" || !existsSync2(SER2NET_CTL)) return;
  await sudoBounded([SER2NET_CTL, "quiet-amp"], 4e3);
}
function writePacket(data) {
  if (!rfc || !sock || sock.destroyed) return false;
  const pkt = hostPacket(data);
  live.lastTxHex = pkt.toString("hex");
  return rfc.writeBinary(pkt);
}
function requestStatus() {
  writePacket(Buffer.from([144]));
}
async function waitStatus(prevEpoch, ms = STATUS_WAIT_MS, gen = linkGen) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    if (linkGen !== gen) return false;
    if (!sock || sock.destroyed || !rfc) return false;
    if (statusEpoch !== prevEpoch && live.hardware) return true;
    await new Promise((r) => setTimeout(r, 80));
  }
  return linkGen === gen && statusEpoch !== prevEpoch && live.hardware;
}
function startPoll() {
  stopPoll();
  const tick = () => {
    if (!sock || sock.destroyed) return;
    requestStatus();
  };
  tick();
  pollTimer = setInterval(tick, POLL_MS);
  pollTimer.unref?.();
}
function attachSock(s, host2, port) {
  dropSock();
  sock = s;
  rx = Buffer.alloc(0);
  live.port = `${host2}:${port}`;
  live.connected = true;
  live.hardware = false;
  live.phase = "connecting";
  live.error = "";
  live.ledOn = false;
  heardHardware = false;
  lastRxAt = Date.now();
  rfc = attachRfc2217(s, (app) => {
    noteRx();
    rx = Buffer.concat([rx, app]);
    consumeRx();
  });
  s.on("error", () => {
    if (sock !== s) return;
    dropSock();
    onLinkLost();
  });
  s.on("close", () => {
    if (sock !== s) return;
    sock = null;
    rfc = null;
    stopPoll();
    clearSilence();
    onLinkLost();
  });
  armSilence(SILENCE_MS);
  rfc.setRts(true);
  rfc.setDtr(true);
  reconnectDelay = 800;
  clearReconnect();
  startPoll();
}
function speStatus() {
  return snap();
}
async function spePeek() {
  return snap();
}
async function speSave(body) {
  if (typeof body.autoConnect === "boolean") {
    saved.autoConnect = body.autoConnect;
    if (!body.autoConnect) {
      wantLink = false;
      clearReconnect();
    } else if (!sock || sock.destroyed) {
      wantLink = true;
      reconnectDelay = 800;
      scheduleReconnect();
    }
  }
  persist();
  live.autoConnect = saved.autoConnect;
  return snap();
}
async function connectInside() {
  wantLink = true;
  if (sock && !sock.destroyed && live.connected) {
    reconnectDelay = 800;
    clearReconnect();
    return snap();
  }
  if (sock) {
    dropSock();
    live.connected = false;
  }
  const gen = ++sessionGen;
  live.error = "";
  live.phase = "connecting";
  live.hardware = false;
  live.ledOn = false;
  live.autoConnect = saved.autoConnect;
  await stopAmpctld();
  if (gen !== sessionGen || !wantLink) return snap();
  try {
    await ensureSpeRfc2217Yaml();
  } catch {
  }
  const ep = await resolveEndpoint();
  if (!ep) {
    noteDown("noport");
    return snap();
  }
  if (gen !== sessionGen || !wantLink) return snap();
  live.port = `${ep.host}:${ep.port}`;
  return await new Promise((resolve) => {
    const s = new net.Socket();
    let settled = false;
    const finish2 = (ok, error3) => {
      if (settled) return;
      settled = true;
      if (gen !== sessionGen || !wantLink) {
        try {
          s.destroy();
        } catch {
        }
        resolve(snap());
        return;
      }
      if (!ok) {
        try {
          s.destroy();
        } catch {
        }
        noteDown(error3 || "timeout");
        resolve(snap());
        return;
      }
      attachSock(s, ep.host, ep.port);
      resolve(snap());
    };
    const timer = setTimeout(() => finish2(false, "timeout"), 3e3);
    s.once("error", (err) => {
      clearTimeout(timer);
      finish2(false, err.message);
    });
    s.connect(ep.port, ep.host, () => {
      clearTimeout(timer);
      finish2(true);
    });
  });
}
async function speConnect() {
  return enqueue(() => connectInside());
}
async function speDisconnect() {
  settleDown("");
  return snap();
}
async function spePowerOn() {
  return enqueue(async () => {
    const talking = Boolean(sock && !sock.destroyed && rfc && live.connected && live.hardware);
    if (talking) return snap();
    wakeUntil = Date.now() + WAKE_GRACE_MS;
    heardHardware = false;
    if (sock) {
      dropSock();
      live.connected = false;
    }
    live.tx = false;
    live.operate = false;
    live.pout = 0;
    live.ipa = 0;
    live.vpa = 0;
    live.ledOn = false;
    const up = await connectInside();
    if (!up.connected || !rfc) return up;
    const prev = statusEpoch;
    const gen = linkGen;
    live.error = "";
    await rfc.pulseWake(1e3);
    if (linkGen !== gen || !rfc || !sock || sock.destroyed) {
      const again = await connectInside();
      if (!again.connected || !rfc) return again;
      await rfc.pulseWake(1e3);
    }
    requestStatus();
    live.lastTxHex = "rfc2217:RTS/DTR wake";
    await waitStatus(prev, 500, linkGen);
    if (!live.hardware && live.connected) live.phase = "connecting";
    live.ledOn = live.hardware;
    return snap();
  });
}
async function speCmd(cmd) {
  const key = String(cmd || "").trim().toLowerCase();
  if (key === "on" || key === "poweron" || key === "wake") return spePowerOn();
  return enqueue(async () => {
    if (key === "off") {
      const gen2 = linkGen;
      const prev2 = statusEpoch;
      wakeUntil = 0;
      if (rfc && sock && !sock.destroyed) {
        writePacket(Buffer.from([10]));
        rfc.setDtr(false);
        rfc.setRts(false);
        await waitStatus(prev2, 350, gen2);
      }
      settleDown("");
      return snap();
    }
    if (!live.connected || !rfc) {
      const up = await connectInside();
      if (!up.connected) return up;
    }
    if (key === "op1" && live.operate) {
      requestStatus();
      await waitStatus(statusEpoch, 600, linkGen);
      return snap();
    }
    if (key === "op0" && !live.operate) {
      requestStatus();
      await waitStatus(statusEpoch, 600, linkGen);
      return snap();
    }
    const code = CMD_BYTE[key];
    if (code == null) {
      live.error = "cmd";
      return snap();
    }
    const prevPwr = live.pwr;
    const prevOp = live.operate;
    const prev = statusEpoch;
    const gen = linkGen;
    const ok = writePacket(Buffer.from([code]));
    if (!ok) {
      settleDown("nocomm");
      return snap();
    }
    await new Promise((r) => setTimeout(r, 100));
    if (linkGen !== gen) return snap();
    requestStatus();
    await waitStatus(prev, STATUS_WAIT_MS, gen);
    if (key === "pwr" || key === "power") {
      for (let i = 0; i < 6 && live.pwr === prevPwr && linkGen === gen; i++) {
        await new Promise((r) => setTimeout(r, 150));
        if (linkGen !== gen) break;
        const e = statusEpoch;
        requestStatus();
        await waitStatus(e, 500, gen);
      }
    }
    if (key === "op1" || key === "op0" || key === "op" || key === "operate") {
      for (let i = 0; i < 4 && live.operate === prevOp && linkGen === gen; i++) {
        await new Promise((r) => setTimeout(r, 120));
        if (linkGen !== gen) break;
        const e = statusEpoch;
        requestStatus();
        await waitStatus(e, 400, gen);
      }
    }
    return snap();
  });
}
var ROOT2, OPT_DIR2, SER2NET_CTL, SPE_BUILD, POLL_MS, BAUD, STATUS_WAIT_MS, SILENCE_MS, WAKE_GRACE_MS, CMD_BYTE, BANDS, saved, live, sock, rfc, rx, pollTimer, chain, statusEpoch, yamlEnsured, wantLink, reconnectTimer, reconnectDelay, silenceTimer, lastRxAt, linkGen, sessionGen, wakeUntil, heardHardware;
var init_spe = __esm({
  "server/spe.ts"() {
    "use strict";
    init_const();
    init_rfc2217();
    init_ser2net_store();
    ROOT2 = join2(dirname2(fileURLToPath2(import.meta.url)), "..");
    OPT_DIR2 = "/opt/ham-cockpit/spe";
    SER2NET_CTL = "/opt/ham-cockpit/bin/ser2net-ctl";
    SPE_BUILD = "spe-off-unwait";
    POLL_MS = 700;
    BAUD = 115200;
    STATUS_WAIT_MS = 1500;
    SILENCE_MS = 2500;
    WAKE_GRACE_MS = 12e3;
    CMD_BYTE = {
      input: 1,
      "band-": 2,
      "band+": 3,
      antenna: 4,
      ant: 4,
      "l-": 5,
      "l+": 6,
      "c-": 7,
      "c+": 8,
      tune: 9,
      tuner: 9,
      off: 10,
      pwr: 11,
      power: 11,
      disp: 12,
      display: 12,
      op: 13,
      operate: 13,
      op1: 13,
      op0: 13,
      cat: 14,
      nav: 15,
      left: 15,
      right: 16,
      set: 17,
      status: 144
    };
    BANDS = ["160m", "80m", "60m", "40m", "30m", "20m", "17m", "15m", "12m", "10m", "6m", "4m"];
    saved = loadSaved();
    try {
      if (!existsSync2(jsonPath())) persist();
    } catch {
    }
    live = {
      port: "",
      autoConnect: saved.autoConnect,
      connected: false,
      hardware: false,
      phase: "idle",
      error: "",
      model: "13K",
      operate: false,
      tx: false,
      bank: "A",
      pout: 0,
      pwr: "L",
      swrAtu: 1,
      swrAnt: 1,
      vpa: 0,
      ipa: 0,
      band: "20m",
      ant: 1,
      input: 1,
      temp: 0,
      alarm: "",
      warning: "",
      ledAl: false,
      ledTune: false,
      ledOn: false,
      lastRx: "",
      lastTxHex: ""
    };
    sock = null;
    rfc = null;
    rx = Buffer.alloc(0);
    pollTimer = null;
    chain = Promise.resolve();
    statusEpoch = 0;
    yamlEnsured = false;
    wantLink = false;
    reconnectTimer = null;
    reconnectDelay = 800;
    silenceTimer = null;
    lastRxAt = 0;
    linkGen = 0;
    sessionGen = 0;
    wakeUntil = 0;
    heardHardware = false;
    if (saved.autoConnect) {
      wantLink = true;
      scheduleReconnect();
    }
  }
});

// shared/equipment/types.ts
var EQUIPMENT_MAKERS;
var init_types = __esm({
  "shared/equipment/types.ts"() {
    "use strict";
    EQUIPMENT_MAKERS = [
      "icom",
      "kenwood",
      "elecraft",
      "yaesu",
      "flex",
      "tentec",
      "xiegu",
      "hermes",
      "anan"
    ];
  }
});

// shared/equipment/hamlib-rigs.ts
var CAP, HAMLIB_SERIAL_RADIOS;
var init_hamlib_rigs = __esm({
  "shared/equipment/hamlib-rigs.ts"() {
    "use strict";
    CAP = { vfo: true, ptt: true, mode: true, meter: true, split: true };
    HAMLIB_SERIAL_RADIOS = [
      {
        id: "elecraft-k2",
        maker: "elecraft",
        family: "K2",
        label: "Elecraft K2",
        protocol: "cat",
        hamlibModel: 2021,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "elecraft-k3",
        maker: "elecraft",
        family: "K3",
        label: "Elecraft K3",
        protocol: "cat",
        hamlibModel: 2029,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "elecraft-k3s",
        maker: "elecraft",
        family: "K3S",
        label: "Elecraft K3S",
        protocol: "cat",
        hamlibModel: 2043,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "elecraft-k4",
        maker: "elecraft",
        family: "K4",
        label: "Elecraft K4",
        protocol: "cat",
        hamlibModel: 2047,
        hamlibBackend: "ser2net",
        defaultBaud: 115200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 115200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "elecraft-kx2",
        maker: "elecraft",
        family: "KX2",
        label: "Elecraft KX2",
        protocol: "cat",
        hamlibModel: 2044,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "elecraft-kx3",
        maker: "elecraft",
        family: "KX3",
        label: "Elecraft KX3",
        protocol: "cat",
        hamlibModel: 2045,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-id-1",
        maker: "icom",
        family: "IC ID-1",
        label: "Icom IC ID-1",
        protocol: "civ",
        hamlibModel: 3054,
        hamlibBackend: "ser2net",
        civAddr: "0x01",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-1275",
        maker: "icom",
        family: "IC-1275",
        label: "Icom IC-1275",
        protocol: "civ",
        hamlibModel: 3002,
        hamlibBackend: "ser2net",
        civAddr: "0x18",
        defaultBaud: 9600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 9600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-271",
        maker: "icom",
        family: "IC-271",
        label: "Icom IC-271",
        protocol: "civ",
        hamlibModel: 3003,
        hamlibBackend: "ser2net",
        civAddr: "0x20",
        defaultBaud: 9600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 9600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-2730",
        maker: "icom",
        family: "IC-2730",
        label: "Icom IC-2730",
        protocol: "civ",
        hamlibModel: 3072,
        hamlibBackend: "ser2net",
        civAddr: "0x90",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-275",
        maker: "icom",
        family: "IC-275",
        label: "Icom IC-275",
        protocol: "civ",
        hamlibModel: 3004,
        hamlibBackend: "ser2net",
        civAddr: "0x10",
        defaultBaud: 9600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 9600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-375",
        maker: "icom",
        family: "IC-375",
        label: "Icom IC-375",
        protocol: "civ",
        hamlibModel: 3005,
        hamlibBackend: "ser2net",
        civAddr: "0x12",
        defaultBaud: 9600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 9600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-471",
        maker: "icom",
        family: "IC-471",
        label: "Icom IC-471",
        protocol: "civ",
        hamlibModel: 3006,
        hamlibBackend: "ser2net",
        civAddr: "0x22",
        defaultBaud: 9600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 9600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-475",
        maker: "icom",
        family: "IC-475",
        label: "Icom IC-475",
        protocol: "civ",
        hamlibModel: 3007,
        hamlibBackend: "ser2net",
        civAddr: "0x14",
        defaultBaud: 9600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 9600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-575",
        maker: "icom",
        family: "IC-575",
        label: "Icom IC-575",
        protocol: "civ",
        hamlibModel: 3008,
        hamlibBackend: "ser2net",
        civAddr: "0x16",
        defaultBaud: 9600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 9600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-7000",
        maker: "icom",
        family: "IC-7000",
        label: "Icom IC-7000",
        protocol: "civ",
        hamlibModel: 3060,
        hamlibBackend: "ser2net",
        civAddr: "0x70",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-703",
        maker: "icom",
        family: "IC-703",
        label: "Icom IC-703",
        protocol: "civ",
        hamlibModel: 3055,
        hamlibBackend: "ser2net",
        civAddr: "0x68",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-705",
        maker: "icom",
        family: "IC-705",
        label: "Icom IC-705",
        protocol: "civ",
        hamlibModel: 3085,
        hamlibBackend: "ser2net",
        civAddr: "0xA4",
        defaultBaud: 115200,
        standby: true,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 115200, hamlibReady: true }
        ],
        capabilities: CAP,
        notes: "CI-V USB 115200 (a capabilidade 4.6.5 lista serial_rate_max 19200; a porta USB da esta\xE7\xE3o \xE9 115200). Endere\xE7o padr\xE3o 0xA4. Standby = 1A 05 0073 em 01 e CI-V 0x18 0x00."
      },
      {
        id: "icom-ic-706",
        maker: "icom",
        family: "IC-706",
        label: "Icom IC-706",
        protocol: "civ",
        hamlibModel: 3009,
        hamlibBackend: "ser2net",
        civAddr: "0x48",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-706mkii",
        maker: "icom",
        family: "IC-706MkII",
        label: "Icom IC-706MkII",
        protocol: "civ",
        hamlibModel: 3010,
        hamlibBackend: "ser2net",
        civAddr: "0x4E",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-706mkiig",
        maker: "icom",
        family: "IC-706MkIIG",
        label: "Icom IC-706MkIIG",
        protocol: "civ",
        hamlibModel: 3011,
        hamlibBackend: "ser2net",
        civAddr: "0x58",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-707",
        maker: "icom",
        family: "IC-707",
        label: "Icom IC-707",
        protocol: "civ",
        hamlibModel: 3012,
        hamlibBackend: "ser2net",
        civAddr: "0x3E",
        defaultBaud: 9600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 9600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-7100",
        maker: "icom",
        family: "IC-7100",
        label: "Icom IC-7100",
        protocol: "civ",
        hamlibModel: 3070,
        hamlibBackend: "ser2net",
        civAddr: "0x88",
        defaultBaud: 19200,
        standby: true,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP,
        notes: "Hamlib 4.6.5 (icom.c) descreve este r\xE1dio como ainda respondendo CI-V em standby. Comando 0x18 0x02."
      },
      {
        id: "icom-ic-718",
        maker: "icom",
        family: "IC-718",
        label: "Icom IC-718",
        protocol: "civ",
        hamlibModel: 3013,
        hamlibBackend: "ser2net",
        civAddr: "0x5E",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-7200",
        maker: "icom",
        family: "IC-7200",
        label: "Icom IC-7200",
        protocol: "civ",
        hamlibModel: 3061,
        hamlibBackend: "ser2net",
        civAddr: "0x76",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-725",
        maker: "icom",
        family: "IC-725",
        label: "Icom IC-725",
        protocol: "civ",
        hamlibModel: 3014,
        hamlibBackend: "ser2net",
        civAddr: "0x28",
        defaultBaud: 9600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 9600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-726",
        maker: "icom",
        family: "IC-726",
        label: "Icom IC-726",
        protocol: "civ",
        hamlibModel: 3015,
        hamlibBackend: "ser2net",
        civAddr: "0x30",
        defaultBaud: 1200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 1200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-728",
        maker: "icom",
        family: "IC-728",
        label: "Icom IC-728",
        protocol: "civ",
        hamlibModel: 3016,
        hamlibBackend: "ser2net",
        civAddr: "0x38",
        defaultBaud: 9600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 9600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-729",
        maker: "icom",
        family: "IC-729",
        label: "Icom IC-729",
        protocol: "civ",
        hamlibModel: 3017,
        hamlibBackend: "ser2net",
        civAddr: "0x3A",
        defaultBaud: 9600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 9600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-7300",
        maker: "icom",
        family: "IC-7300",
        label: "Icom IC-7300",
        protocol: "civ",
        hamlibModel: 3073,
        hamlibBackend: "ser2net",
        civAddr: "0x94",
        defaultBaud: 115200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 115200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-735",
        maker: "icom",
        family: "IC-735",
        label: "Icom IC-735",
        protocol: "civ",
        hamlibModel: 3019,
        hamlibBackend: "ser2net",
        civAddr: "0x04",
        defaultBaud: 9600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 9600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-736",
        maker: "icom",
        family: "IC-736",
        label: "Icom IC-736",
        protocol: "civ",
        hamlibModel: 3020,
        hamlibBackend: "ser2net",
        civAddr: "0x40",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-737",
        maker: "icom",
        family: "IC-737",
        label: "Icom IC-737",
        protocol: "civ",
        hamlibModel: 3021,
        hamlibBackend: "ser2net",
        civAddr: "0x3C",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-738",
        maker: "icom",
        family: "IC-738",
        label: "Icom IC-738",
        protocol: "civ",
        hamlibModel: 3022,
        hamlibBackend: "ser2net",
        civAddr: "0x44",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-7410",
        maker: "icom",
        family: "IC-7410",
        label: "Icom IC-7410",
        protocol: "civ",
        hamlibModel: 3067,
        hamlibBackend: "ser2net",
        civAddr: "0x80",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-746",
        maker: "icom",
        family: "IC-746",
        label: "Icom IC-746",
        protocol: "civ",
        hamlibModel: 3023,
        hamlibBackend: "ser2net",
        civAddr: "0x56",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-746pro",
        maker: "icom",
        family: "IC-746PRO",
        label: "Icom IC-746PRO",
        protocol: "civ",
        hamlibModel: 3046,
        hamlibBackend: "ser2net",
        civAddr: "0x66",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-751",
        maker: "icom",
        family: "IC-751",
        label: "Icom IC-751",
        protocol: "civ",
        hamlibModel: 3024,
        hamlibBackend: "ser2net",
        civAddr: "0x1C",
        defaultBaud: 9600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 9600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-756",
        maker: "icom",
        family: "IC-756",
        label: "Icom IC-756",
        protocol: "civ",
        hamlibModel: 3026,
        hamlibBackend: "ser2net",
        civAddr: "0x50",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-756pro",
        maker: "icom",
        family: "IC-756PRO",
        label: "Icom IC-756PRO",
        protocol: "civ",
        hamlibModel: 3027,
        hamlibBackend: "ser2net",
        civAddr: "0x5C",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-756proii",
        maker: "icom",
        family: "IC-756PROII",
        label: "Icom IC-756PROII",
        protocol: "civ",
        hamlibModel: 3047,
        hamlibBackend: "ser2net",
        civAddr: "0x64",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-756proiii",
        maker: "icom",
        family: "IC-756PROIII",
        label: "Icom IC-756PROIII",
        protocol: "civ",
        hamlibModel: 3057,
        hamlibBackend: "ser2net",
        civAddr: "0x6E",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-7600",
        maker: "icom",
        family: "IC-7600",
        label: "Icom IC-7600",
        protocol: "civ",
        hamlibModel: 3063,
        hamlibBackend: "ser2net",
        civAddr: "0x7A",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-761",
        maker: "icom",
        family: "IC-761",
        label: "Icom IC-761",
        protocol: "civ",
        hamlibModel: 3028,
        hamlibBackend: "ser2net",
        civAddr: "0x1E",
        defaultBaud: 9600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 9600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-7610",
        maker: "icom",
        family: "IC-7610",
        label: "Icom IC-7610",
        protocol: "civ",
        hamlibModel: 3078,
        hamlibBackend: "ser2net",
        civAddr: "0x98",
        defaultBaud: 115200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 115200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-765",
        maker: "icom",
        family: "IC-765",
        label: "Icom IC-765",
        protocol: "civ",
        hamlibModel: 3029,
        hamlibBackend: "ser2net",
        civAddr: "0x2C",
        defaultBaud: 9600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 9600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-7700",
        maker: "icom",
        family: "IC-7700",
        label: "Icom IC-7700",
        protocol: "civ",
        hamlibModel: 3062,
        hamlibBackend: "ser2net",
        civAddr: "0x74",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-775",
        maker: "icom",
        family: "IC-775",
        label: "Icom IC-775",
        protocol: "civ",
        hamlibModel: 3030,
        hamlibBackend: "ser2net",
        civAddr: "0x46",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-7760",
        maker: "icom",
        family: "IC-7760",
        label: "Icom IC-7760",
        protocol: "civ",
        hamlibModel: 3092,
        hamlibBackend: "ser2net",
        civAddr: "0xB2",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-78",
        maker: "icom",
        family: "IC-78",
        label: "Icom IC-78",
        protocol: "civ",
        hamlibModel: 3045,
        hamlibBackend: "ser2net",
        civAddr: "0x62",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-7800",
        maker: "icom",
        family: "IC-7800",
        label: "Icom IC-7800",
        protocol: "civ",
        hamlibModel: 3056,
        hamlibBackend: "ser2net",
        civAddr: "0x6A",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-781",
        maker: "icom",
        family: "IC-781",
        label: "Icom IC-781",
        protocol: "civ",
        hamlibModel: 3031,
        hamlibBackend: "ser2net",
        civAddr: "0x26",
        defaultBaud: 9600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 9600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-820h",
        maker: "icom",
        family: "IC-820H",
        label: "Icom IC-820H",
        protocol: "civ",
        hamlibModel: 3032,
        hamlibBackend: "ser2net",
        civAddr: "0x42",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-821h",
        maker: "icom",
        family: "IC-821H",
        label: "Icom IC-821H",
        protocol: "civ",
        hamlibModel: 3034,
        hamlibBackend: "ser2net",
        civAddr: "0x4C",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-905",
        maker: "icom",
        family: "IC-905",
        label: "Icom IC-905",
        protocol: "civ",
        hamlibModel: 3090,
        hamlibBackend: "ser2net",
        civAddr: "0xAC",
        defaultBaud: 230400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 230400, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-910",
        maker: "icom",
        family: "IC-910",
        label: "Icom IC-910",
        protocol: "cat",
        hamlibModel: 3044,
        hamlibBackend: "ser2net",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-9100",
        maker: "icom",
        family: "IC-9100",
        label: "Icom IC-9100",
        protocol: "civ",
        hamlibModel: 3068,
        hamlibBackend: "ser2net",
        civAddr: "0x7C",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-92d",
        maker: "icom",
        family: "IC-92D",
        label: "Icom IC-92D",
        protocol: "civ",
        hamlibModel: 3065,
        hamlibBackend: "ser2net",
        civAddr: "0x01",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-970",
        maker: "icom",
        family: "IC-970",
        label: "Icom IC-970",
        protocol: "civ",
        hamlibModel: 3035,
        hamlibBackend: "ser2net",
        civAddr: "0x2E",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-ic-9700",
        maker: "icom",
        family: "IC-9700",
        label: "Icom IC-9700",
        protocol: "civ",
        hamlibModel: 3081,
        hamlibBackend: "ser2net",
        civAddr: "0xA2",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-id-31",
        maker: "icom",
        family: "ID-31",
        label: "Icom ID-31",
        protocol: "civ",
        hamlibModel: 3083,
        hamlibBackend: "ser2net",
        civAddr: "0xA0",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-id-4100",
        maker: "icom",
        family: "ID-4100",
        label: "Icom ID-4100",
        protocol: "civ",
        hamlibModel: 3082,
        hamlibBackend: "ser2net",
        civAddr: "0x9A",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-id-51",
        maker: "icom",
        family: "ID-51",
        label: "Icom ID-51",
        protocol: "civ",
        hamlibModel: 3084,
        hamlibBackend: "ser2net",
        civAddr: "0x86",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "icom-id-5100",
        maker: "icom",
        family: "ID-5100",
        label: "Icom ID-5100",
        protocol: "civ",
        hamlibModel: 3071,
        hamlibBackend: "ser2net",
        civAddr: "0x8C",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-th-d72a",
        maker: "kenwood",
        family: "TH-D72A",
        label: "Kenwood TH-D72A",
        protocol: "cat",
        hamlibModel: 2033,
        hamlibBackend: "ser2net",
        defaultBaud: 9600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 9600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-th-d74",
        maker: "kenwood",
        family: "TH-D74",
        label: "Kenwood TH-D74",
        protocol: "cat",
        hamlibModel: 2042,
        hamlibBackend: "ser2net",
        defaultBaud: 9600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 9600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-th-d7a",
        maker: "kenwood",
        family: "TH-D7A",
        label: "Kenwood TH-D7A",
        protocol: "cat",
        hamlibModel: 2017,
        hamlibBackend: "ser2net",
        defaultBaud: 9600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 9600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-th-f6a",
        maker: "kenwood",
        family: "TH-F6A",
        label: "Kenwood TH-F6A",
        protocol: "cat",
        hamlibModel: 2019,
        hamlibBackend: "ser2net",
        defaultBaud: 9600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 9600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-th-f7e",
        maker: "kenwood",
        family: "TH-F7E",
        label: "Kenwood TH-F7E",
        protocol: "cat",
        hamlibModel: 2020,
        hamlibBackend: "ser2net",
        defaultBaud: 9600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 9600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-th-g71",
        maker: "kenwood",
        family: "TH-G71",
        label: "Kenwood TH-G71",
        protocol: "cat",
        hamlibModel: 2023,
        hamlibBackend: "ser2net",
        defaultBaud: 9600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 9600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-tm-d700",
        maker: "kenwood",
        family: "TM-D700",
        label: "Kenwood TM-D700",
        protocol: "cat",
        hamlibModel: 2026,
        hamlibBackend: "ser2net",
        defaultBaud: 57600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 57600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-tm-d710-g",
        maker: "kenwood",
        family: "TM-D710(G)",
        label: "Kenwood TM-D710(G)",
        protocol: "cat",
        hamlibModel: 2034,
        hamlibBackend: "ser2net",
        defaultBaud: 57600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 57600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-tm-v7",
        maker: "kenwood",
        family: "TM-V7",
        label: "Kenwood TM-V7",
        protocol: "cat",
        hamlibModel: 2027,
        hamlibBackend: "ser2net",
        defaultBaud: 9600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 9600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-tm-v71-a",
        maker: "kenwood",
        family: "TM-V71(A)",
        label: "Kenwood TM-V71(A)",
        protocol: "cat",
        hamlibModel: 2035,
        hamlibBackend: "ser2net",
        defaultBaud: 57600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 57600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-trc-80",
        maker: "kenwood",
        family: "TRC-80",
        label: "Kenwood TRC-80",
        protocol: "cat",
        hamlibModel: 2030,
        hamlibBackend: "ser2net",
        defaultBaud: 9600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 9600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-ts-140s",
        maker: "kenwood",
        family: "TS-140S",
        label: "Kenwood TS-140S",
        protocol: "cat",
        hamlibModel: 2025,
        hamlibBackend: "ser2net",
        defaultBaud: 9600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 9600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-ts-2000",
        maker: "kenwood",
        family: "TS-2000",
        label: "Kenwood TS-2000",
        protocol: "cat",
        hamlibModel: 2014,
        hamlibBackend: "ser2net",
        defaultBaud: 115200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 115200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-ts-440s",
        maker: "kenwood",
        family: "TS-440S",
        label: "Kenwood TS-440S",
        protocol: "cat",
        hamlibModel: 2002,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-ts-450s",
        maker: "kenwood",
        family: "TS-450S",
        label: "Kenwood TS-450S",
        protocol: "cat",
        hamlibModel: 2003,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-ts-480",
        maker: "kenwood",
        family: "TS-480",
        label: "Kenwood TS-480",
        protocol: "cat",
        hamlibModel: 2028,
        hamlibBackend: "ser2net",
        defaultBaud: 115200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 115200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-ts-50s",
        maker: "kenwood",
        family: "TS-50S",
        label: "Kenwood TS-50S",
        protocol: "cat",
        hamlibModel: 2001,
        hamlibBackend: "ser2net",
        defaultBaud: 57600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 57600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-ts-570d",
        maker: "kenwood",
        family: "TS-570D",
        label: "Kenwood TS-570D",
        protocol: "cat",
        hamlibModel: 2004,
        hamlibBackend: "ser2net",
        defaultBaud: 57600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 57600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-ts-570s",
        maker: "kenwood",
        family: "TS-570S",
        label: "Kenwood TS-570S",
        protocol: "cat",
        hamlibModel: 2016,
        hamlibBackend: "ser2net",
        defaultBaud: 57600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 57600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-ts-590s",
        maker: "kenwood",
        family: "TS-590S",
        label: "Kenwood TS-590S",
        protocol: "cat",
        hamlibModel: 2031,
        hamlibBackend: "ser2net",
        defaultBaud: 115200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 115200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-ts-590sg",
        maker: "kenwood",
        family: "TS-590SG",
        label: "Kenwood TS-590SG",
        protocol: "cat",
        hamlibModel: 2037,
        hamlibBackend: "ser2net",
        defaultBaud: 115200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 115200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-ts-680s",
        maker: "kenwood",
        family: "TS-680S",
        label: "Kenwood TS-680S",
        protocol: "cat",
        hamlibModel: 2024,
        hamlibBackend: "ser2net",
        defaultBaud: 9600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 9600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-ts-690s",
        maker: "kenwood",
        family: "TS-690S",
        label: "Kenwood TS-690S",
        protocol: "cat",
        hamlibModel: 2005,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-ts-711",
        maker: "kenwood",
        family: "TS-711",
        label: "Kenwood TS-711",
        protocol: "cat",
        hamlibModel: 2006,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-ts-790",
        maker: "kenwood",
        family: "TS-790",
        label: "Kenwood TS-790",
        protocol: "cat",
        hamlibModel: 2007,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-ts-811",
        maker: "kenwood",
        family: "TS-811",
        label: "Kenwood TS-811",
        protocol: "cat",
        hamlibModel: 2008,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-ts-850",
        maker: "kenwood",
        family: "TS-850",
        label: "Kenwood TS-850",
        protocol: "cat",
        hamlibModel: 2009,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-ts-870s",
        maker: "kenwood",
        family: "TS-870S",
        label: "Kenwood TS-870S",
        protocol: "cat",
        hamlibModel: 2010,
        hamlibBackend: "ser2net",
        defaultBaud: 57600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 57600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-ts-890s",
        maker: "kenwood",
        family: "TS-890S",
        label: "Kenwood TS-890S",
        protocol: "cat",
        hamlibModel: 2041,
        hamlibBackend: "ser2net",
        defaultBaud: 115200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 115200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-ts-930",
        maker: "kenwood",
        family: "TS-930",
        label: "Kenwood TS-930",
        protocol: "cat",
        hamlibModel: 2022,
        hamlibBackend: "ser2net",
        defaultBaud: 57600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 57600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-ts-940s",
        maker: "kenwood",
        family: "TS-940S",
        label: "Kenwood TS-940S",
        protocol: "cat",
        hamlibModel: 2011,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-ts-950s",
        maker: "kenwood",
        family: "TS-950S",
        label: "Kenwood TS-950S",
        protocol: "cat",
        hamlibModel: 2012,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-ts-950sdx",
        maker: "kenwood",
        family: "TS-950SDX",
        label: "Kenwood TS-950SDX",
        protocol: "cat",
        hamlibModel: 2013,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "kenwood-ts-990s",
        maker: "kenwood",
        family: "TS-990S",
        label: "Kenwood TS-990S",
        protocol: "cat",
        hamlibModel: 2039,
        hamlibBackend: "ser2net",
        defaultBaud: 115200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 115200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "tentec-delta-ii",
        maker: "tentec",
        family: "Delta II",
        label: "Ten-Tec Delta II",
        protocol: "civ",
        hamlibModel: 3064,
        hamlibBackend: "ser2net",
        civAddr: "0x01",
        defaultBaud: 1200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 1200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "tentec-omni-vi-plus",
        maker: "tentec",
        family: "Omni VI Plus",
        label: "Ten-Tec Omni VI Plus",
        protocol: "civ",
        hamlibModel: 3051,
        hamlibBackend: "ser2net",
        civAddr: "0x04",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "tentec-tt-516-argonaut-v",
        maker: "tentec",
        family: "TT-516 Argonaut V",
        label: "Ten-Tec TT-516 Argonaut V",
        protocol: "cat",
        hamlibModel: 16007,
        hamlibBackend: "ser2net",
        defaultBaud: 1200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 1200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "tentec-tt-538-jupiter",
        maker: "tentec",
        family: "TT-538 Jupiter",
        label: "Ten-Tec TT-538 Jupiter",
        protocol: "cat",
        hamlibModel: 16002,
        hamlibBackend: "ser2net",
        defaultBaud: 57600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 57600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "tentec-tt-550",
        maker: "tentec",
        family: "TT-550",
        label: "Ten-Tec TT-550",
        protocol: "cat",
        hamlibModel: 16001,
        hamlibBackend: "ser2net",
        defaultBaud: 57600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 57600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "tentec-tt-565-566-orion-i-ii",
        maker: "tentec",
        family: "TT-565/566 Orion I/II",
        label: "Ten-Tec TT-565/566 Orion I/II",
        protocol: "cat",
        hamlibModel: 16008,
        hamlibBackend: "ser2net",
        defaultBaud: 57600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 57600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "tentec-tt-585-paragon",
        maker: "tentec",
        family: "TT-585 Paragon",
        label: "Ten-Tec TT-585 Paragon",
        protocol: "cat",
        hamlibModel: 16009,
        hamlibBackend: "ser2net",
        defaultBaud: 1200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 1200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "tentec-omniiii",
        maker: "tentec",
        family: "TT-588 Omni VII",
        label: "Ten-Tec TT-588 Omni VII",
        protocol: "cat",
        hamlibModel: 16011,
        hamlibBackend: "ser2net",
        defaultBaud: 57600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 57600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "tentec-eagle",
        maker: "tentec",
        family: "TT-599 Eagle",
        label: "Ten-Tec TT-599 Eagle",
        protocol: "cat",
        hamlibModel: 16013,
        hamlibBackend: "ser2net",
        defaultBaud: 57600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 57600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "xiegu-g90",
        maker: "xiegu",
        family: "G90",
        label: "Xiegu G90",
        protocol: "civ",
        hamlibModel: 3088,
        hamlibBackend: "ser2net",
        civAddr: "0xA4",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "xiegu-x108g",
        maker: "xiegu",
        family: "X108G",
        label: "Xiegu X108G",
        protocol: "civ",
        hamlibModel: 3076,
        hamlibBackend: "ser2net",
        civAddr: "0x70",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "xiegu-x5105",
        maker: "xiegu",
        family: "X5105",
        label: "Xiegu X5105",
        protocol: "civ",
        hamlibModel: 3089,
        hamlibBackend: "ser2net",
        civAddr: "0x70",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "xiegu-x6100",
        maker: "xiegu",
        family: "X6100",
        label: "Xiegu X6100",
        protocol: "civ",
        hamlibModel: 3087,
        hamlibBackend: "ser2net",
        civAddr: "0xA4",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "xiegu-x6200",
        maker: "xiegu",
        family: "X6200",
        label: "Xiegu X6200",
        protocol: "civ",
        hamlibModel: 3091,
        hamlibBackend: "ser2net",
        civAddr: "0xA4",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-100",
        maker: "yaesu",
        family: "FT-100",
        label: "Yaesu FT-100",
        protocol: "cat",
        hamlibModel: 1021,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-1000",
        maker: "yaesu",
        family: "FT-1000",
        label: "Yaesu FT-1000",
        protocol: "cat",
        hamlibModel: 1002,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-1000d",
        maker: "yaesu",
        family: "FT-1000D",
        label: "Yaesu FT-1000D",
        protocol: "cat",
        hamlibModel: 1003,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-1000mp",
        maker: "yaesu",
        family: "FT-1000MP",
        label: "Yaesu FT-1000MP",
        protocol: "cat",
        hamlibModel: 1024,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-2000",
        maker: "yaesu",
        family: "FT-2000",
        label: "Yaesu FT-2000",
        protocol: "cat",
        hamlibModel: 1029,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-450",
        maker: "yaesu",
        family: "FT-450",
        label: "Yaesu FT-450",
        protocol: "cat",
        hamlibModel: 1027,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-600",
        maker: "yaesu",
        family: "FT-600",
        label: "Yaesu FT-600",
        protocol: "cat",
        hamlibModel: 1039,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-650",
        maker: "yaesu",
        family: "FT-650",
        label: "Yaesu FT-650",
        protocol: "cat",
        hamlibModel: 1047,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-710",
        maker: "yaesu",
        family: "FT-710",
        label: "Yaesu FT-710",
        protocol: "cat",
        hamlibModel: 1049,
        hamlibBackend: "ser2net",
        defaultBaud: 115200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 115200, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-736r",
        maker: "yaesu",
        family: "FT-736R",
        label: "Yaesu FT-736R",
        protocol: "cat",
        hamlibModel: 1010,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-747gx",
        maker: "yaesu",
        family: "FT-747GX",
        label: "Yaesu FT-747GX",
        protocol: "cat",
        hamlibModel: 1005,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-757gx",
        maker: "yaesu",
        family: "FT-757GX",
        label: "Yaesu FT-757GX",
        protocol: "cat",
        hamlibModel: 1006,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-757gxii",
        maker: "yaesu",
        family: "FT-757GXII",
        label: "Yaesu FT-757GXII",
        protocol: "cat",
        hamlibModel: 1007,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-767gx",
        maker: "yaesu",
        family: "FT-767GX",
        label: "Yaesu FT-767GX",
        protocol: "cat",
        hamlibModel: 1009,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-817",
        maker: "yaesu",
        family: "FT-817",
        label: "Yaesu FT-817",
        protocol: "cat",
        hamlibModel: 1020,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-818",
        maker: "yaesu",
        family: "FT-818",
        label: "Yaesu FT-818",
        protocol: "cat",
        hamlibModel: 1041,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-840",
        maker: "yaesu",
        family: "FT-840",
        label: "Yaesu FT-840",
        protocol: "cat",
        hamlibModel: 1011,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-847",
        maker: "yaesu",
        family: "FT-847",
        label: "Yaesu FT-847",
        protocol: "cat",
        hamlibModel: 1001,
        hamlibBackend: "ser2net",
        defaultBaud: 57600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 57600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-847uni",
        maker: "yaesu",
        family: "FT-847UNI",
        label: "Yaesu FT-847UNI",
        protocol: "cat",
        hamlibModel: 1038,
        hamlibBackend: "ser2net",
        defaultBaud: 57600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 57600, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-857",
        maker: "yaesu",
        family: "FT-857",
        label: "Yaesu FT-857",
        protocol: "cat",
        hamlibModel: 1022,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-890",
        maker: "yaesu",
        family: "FT-890",
        label: "Yaesu FT-890",
        protocol: "cat",
        hamlibModel: 1015,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-891",
        maker: "yaesu",
        family: "FT-891",
        label: "Yaesu FT-891",
        protocol: "cat",
        hamlibModel: 1036,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-897",
        maker: "yaesu",
        family: "FT-897",
        label: "Yaesu FT-897",
        protocol: "cat",
        hamlibModel: 1023,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-897d",
        maker: "yaesu",
        family: "FT-897D",
        label: "Yaesu FT-897D",
        protocol: "cat",
        hamlibModel: 1043,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-900",
        maker: "yaesu",
        family: "FT-900",
        label: "Yaesu FT-900",
        protocol: "cat",
        hamlibModel: 1013,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-920",
        maker: "yaesu",
        family: "FT-920",
        label: "Yaesu FT-920",
        protocol: "cat",
        hamlibModel: 1014,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-950",
        maker: "yaesu",
        family: "FT-950",
        label: "Yaesu FT-950",
        protocol: "cat",
        hamlibModel: 1028,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-980",
        maker: "yaesu",
        family: "FT-980",
        label: "Yaesu FT-980",
        protocol: "cat",
        hamlibModel: 1031,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-990",
        maker: "yaesu",
        family: "FT-990",
        label: "Yaesu FT-990",
        protocol: "cat",
        hamlibModel: 1016,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-990-old-rom",
        maker: "yaesu",
        family: "FT-990 Old Rom",
        label: "Yaesu FT-990 Old Rom",
        protocol: "cat",
        hamlibModel: 1048,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ft-991a",
        maker: "yaesu",
        family: "FT-991",
        label: "Yaesu FT-991",
        protocol: "cat",
        hamlibModel: 1035,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ftdx10",
        maker: "yaesu",
        family: "FTDX-10",
        label: "Yaesu FTDX-10",
        protocol: "cat",
        hamlibModel: 1042,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ftdx101d",
        maker: "yaesu",
        family: "FTDX-101D",
        label: "Yaesu FTDX-101D",
        protocol: "cat",
        hamlibModel: 1040,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ftdx-101mp",
        maker: "yaesu",
        family: "FTDX-101MP",
        label: "Yaesu FTDX-101MP",
        protocol: "cat",
        hamlibModel: 1044,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ftdx-1200",
        maker: "yaesu",
        family: "FTDX-1200",
        label: "Yaesu FTDX-1200",
        protocol: "cat",
        hamlibModel: 1034,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ftdx-3000",
        maker: "yaesu",
        family: "FTDX-3000",
        label: "Yaesu FTDX-3000",
        protocol: "cat",
        hamlibModel: 1037,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ftdx-5000",
        maker: "yaesu",
        family: "FTDX-5000",
        label: "Yaesu FTDX-5000",
        protocol: "cat",
        hamlibModel: 1032,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ftdx-9000",
        maker: "yaesu",
        family: "FTDX-9000",
        label: "Yaesu FTDX-9000",
        protocol: "cat",
        hamlibModel: 1030,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-ftdx-9000-old",
        maker: "yaesu",
        family: "FTDX-9000 Old",
        label: "Yaesu FTDX-9000 Old",
        protocol: "cat",
        hamlibModel: 1050,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-mark-v-ft-1000mp",
        maker: "yaesu",
        family: "MARK-V FT-1000MP",
        label: "Yaesu MARK-V FT-1000MP",
        protocol: "cat",
        hamlibModel: 1004,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      },
      {
        id: "yaesu-mark-v-field-ft-1000mp",
        maker: "yaesu",
        family: "MARK-V Field FT-1000MP",
        label: "Yaesu MARK-V Field FT-1000MP",
        protocol: "cat",
        hamlibModel: 1025,
        hamlibBackend: "ser2net",
        defaultBaud: 4800,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 4800, hamlibReady: true }
        ],
        capabilities: CAP
      }
    ];
  }
});

// shared/equipment/catalog.ts
function overlay(id, connections, notes) {
  const base2 = HAMLIB_SERIAL_RADIOS.find((r) => r.id === id);
  if (!base2) return void 0;
  return { ...base2, connections, ...notes ? { notes } : {} };
}
function getEquipment(id) {
  return EQUIPMENT_CATALOG.find((e) => e.id === id);
}
function normalizeCivAddr(addr) {
  const m = String(addr || "").trim().match(/^0x([0-9a-fA-F]{2})$/i);
  return m ? `0x${m[1].toUpperCase()}` : "";
}
function inferEquipmentId(input) {
  const explicit = String(input.equipmentId || "").trim();
  if (explicit && getEquipment(explicit)) return explicit;
  const blob = `${input.name || ""} ${input.deviceName || ""} ${input.model || ""}`.toLowerCase();
  const list = input.maker ? listEquipmentByMaker(input.maker) : EQUIPMENT_CATALOG;
  const ranked = [...list].sort((a, b) => b.family.length - a.family.length);
  for (const eq of ranked) {
    const fam = eq.family.toLowerCase();
    if (fam && blob.includes(fam)) return eq.id;
  }
  if ((input.maker === "icom" || input.maker === "xiegu" || input.maker === "tentec") && input.proto !== "cat") {
    const hit = CIV_TO_EQUIPMENT[normalizeCivAddr(input.civAddr)];
    if (hit && getEquipment(hit)?.maker === input.maker) return hit;
  }
  return "";
}
function listEquipmentByMaker(maker) {
  return EQUIPMENT_CATALOG.filter((e) => e.maker === maker);
}
function listHamlibReady() {
  return EQUIPMENT_CATALOG.filter(
    (e) => e.hamlibModel != null && e.connections.some((c) => c.hamlibReady)
  );
}
var CAP_BASIC, CAP_SDR, LAN, ic705, ic7610, ic9700, x6100, ic905, ic7760, x6200, OVERRIDES, IC7300MK2, EQUIPMENT_CATALOG, CIV_TO_EQUIPMENT;
var init_catalog = __esm({
  "shared/equipment/catalog.ts"() {
    "use strict";
    init_hamlib_rigs();
    CAP_BASIC = { vfo: true, ptt: true, mode: true, meter: true, split: true };
    CAP_SDR = {
      vfo: true,
      ptt: true,
      mode: true,
      meter: true,
      split: true,
      panadapter: true,
      audioNet: true
    };
    LAN = {
      kind: "icom-lan-udp",
      auth: "network-user",
      ports: { control: 50001, serial: 50002, audio: 50003 },
      hamlibReady: true,
      notes: "Network Control (UDP). O gateway autentica e exp\xF5e CI-V em 127.0.0.1:45002 para o rigctld."
    };
    ic705 = overlay(
      "icom-ic-705",
      [
        {
          kind: "bluetooth-gatt",
          preferred: true,
          auth: "none",
          hamlibReady: false,
          notes: "Web Bluetooth GATT no Chrome; CI-V no navegador. Hamlib usa o caminho USB/ser2net."
        },
        {
          kind: "usb-serial",
          auth: "none",
          defaultBaud: 115200,
          hamlibReady: true,
          notes: "USB CI-V a 115200. ser2net TCP cru, rigctld -m 3085, sem -s. -c s\xF3 se o CI-V da esta\xE7\xE3o divergir de 0xA4."
        },
        { ...LAN, notes: "WLAN do IC-705. Gateway para 127.0.0.1:45002 e rigctld -m 3085." }
      ],
      "Endere\xE7o CI-V padr\xE3o 0xA4. Standby: item 1A 05 0073 = 01 e quadro 0x18 0x00. O 0x18 0x02 volta NAK."
    );
    ic7610 = overlay("icom-ic-7610", [
      { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 115200, hamlibReady: true },
      { ...LAN, notes: "Ethernet do IC-7610. CI-V padr\xE3o deste -m \xE9 0x98." }
    ]);
    ic9700 = overlay("icom-ic-9700", [
      { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true },
      { ...LAN, notes: "Ethernet do IC-9700. CI-V padr\xE3o deste -m \xE9 0xA2." }
    ]);
    x6100 = overlay("xiegu-x6100", [
      {
        kind: "usb-serial",
        preferred: true,
        auth: "none",
        defaultBaud: 19200,
        hamlibReady: true,
        notes: "DEV USB SERIAL-B. Hamlib 4.6.5: -m 3087."
      },
      {
        kind: "bluetooth-spp",
        auth: "none",
        hamlibReady: false,
        notes: "BT no X6100 \xE9 sobretudo perif\xE9rico; CAT est\xE1vel = USB."
      }
    ]);
    ic905 = overlay("icom-ic-905", [
      { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 230400, hamlibReady: true },
      { ...LAN, notes: "Ethernet do IC-905. CI-V padr\xE3o deste -m \xE9 0xAC." }
    ]);
    ic7760 = overlay("icom-ic-7760", [
      { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true },
      { ...LAN, notes: "Rede do IC-7760. CI-V padr\xE3o deste -m \xE9 0xB2." }
    ]);
    x6200 = overlay("xiegu-x6200", [
      {
        kind: "usb-serial",
        preferred: true,
        auth: "none",
        defaultBaud: 19200,
        hamlibReady: true,
        notes: "DEV USB SERIAL-B CI-V. Hamlib 4.6.5: -m 3091."
      },
      { kind: "bluetooth-spp", auth: "none", hamlibReady: false }
    ]);
    OVERRIDES = new Map(
      [ic705, ic7610, ic9700, ic905, ic7760, x6100, x6200].filter((r) => Boolean(r)).map((r) => [r.id, r])
    );
    IC7300MK2 = {
      id: "icom-ic-7300mk2",
      maker: "icom",
      family: "IC-7300MK2",
      label: "Icom IC-7300MK2",
      protocol: "civ",
      hamlibModel: null,
      hamlibBackend: "none",
      defaultBaud: 115200,
      connections: [
        {
          kind: "usb-serial",
          preferred: true,
          auth: "none",
          defaultBaud: 115200,
          hamlibReady: false,
          notes: "Sem -m no Hamlib 4.6.5. A ponte n\xE3o sobe com o 3073 do IC-7300."
        },
        {
          kind: "icom-lan-udp",
          auth: "network-user",
          ports: { control: 50001, serial: 50002, audio: 50003 },
          hamlibReady: false,
          notes: "A LAN CI-V do console fala com o r\xE1dio. O rigctld n\xE3o assume o modelo 3073."
        }
      ],
      capabilities: { ...CAP_BASIC, audioNet: true },
      notes: "Hamlib 4.6.5 n\xE3o tem IC-7300MK2. O -m 3073 fica s\xF3 no IC-7300."
    };
    EQUIPMENT_CATALOG = [
      ...HAMLIB_SERIAL_RADIOS.map((r) => OVERRIDES.get(r.id) ?? r),
      IC7300MK2,
      // ── FlexRadio ─────────────────────────────────────────────────────
      {
        id: "flex-6400",
        maker: "flex",
        family: "FLEX-6000",
        label: "FlexRadio FLEX-6400",
        protocol: "smartsdr",
        hamlibModel: null,
        hamlibBackend: "none",
        connections: [
          {
            kind: "flex-tcp",
            preferred: true,
            auth: "none",
            ports: { control: 4992, discover: 4992, stream: 4991 },
            hamlibReady: false,
            notes: "SmartSDR TCP 4992 + discovery UDP 4992 + VITA UDP 4991. Driver nativo futuro."
          },
          {
            kind: "sdr-cat-proxy",
            auth: "none",
            ports: { cat: 13013, hamlibListen: 4532 },
            via: "smartsdr-cat|third-party",
            hamlibReady: true,
            notes: "Se um proxy CAT/Hamlib estiver na LAN, use cat-proxy."
          }
        ],
        capabilities: { ...CAP_SDR },
        notes: "Fam\xEDlia Signature 6000. Hub Hamlib s\xF3 via proxy CAT at\xE9 o driver SmartSDR."
      },
      {
        id: "flex-6600",
        maker: "flex",
        family: "FLEX-6000",
        label: "FlexRadio FLEX-6600",
        protocol: "smartsdr",
        hamlibModel: null,
        hamlibBackend: "none",
        connections: [
          {
            kind: "flex-tcp",
            preferred: true,
            auth: "none",
            ports: { control: 4992, discover: 4992, stream: 4991 },
            hamlibReady: false
          },
          {
            kind: "sdr-cat-proxy",
            auth: "none",
            ports: { cat: 13013 },
            via: "smartsdr-cat|third-party",
            hamlibReady: true
          }
        ],
        capabilities: CAP_SDR
      },
      {
        id: "flex-8600",
        maker: "flex",
        family: "FLEX-8000",
        label: "FlexRadio FLEX-8600",
        protocol: "smartsdr",
        hamlibModel: null,
        hamlibBackend: "none",
        connections: [
          {
            kind: "flex-tcp",
            preferred: true,
            auth: "none",
            ports: { control: 4992, discover: 4992, stream: 4991 },
            hamlibReady: false
          },
          {
            kind: "sdr-cat-proxy",
            auth: "none",
            ports: { cat: 13013 },
            via: "smartsdr-cat|third-party",
            hamlibReady: true
          }
        ],
        capabilities: CAP_SDR
      },
      // ── Hermes Lite 2 ─────────────────────────────────────────────────
      {
        id: "hermes-lite-2",
        maker: "hermes",
        family: "Hermes-Lite",
        label: "Hermes Lite 2",
        protocol: "openhpsdr-p1",
        hamlibModel: 2054,
        hamlibBackend: "cat-proxy",
        connections: [
          {
            kind: "openhpsdr-p1",
            auth: "none",
            ports: { control: 1024, discover: 1025 },
            hamlibReady: false,
            notes: "Metis Protocol 1 UDP. Sem CAT no hardware \u2014 precisa de app SDR."
          },
          {
            kind: "sdr-cat-proxy",
            preferred: true,
            auth: "none",
            ports: { cat: 13013, hamlibListen: 4532 },
            via: "thetis",
            hamlibReady: true,
            notes: "Thetis CAT TCP 13013 \u2192 rigctld -m 2054 -r host:13013."
          },
          {
            kind: "sdr-cat-proxy",
            auth: "none",
            ports: { cat: 19090, hamlibListen: 4532 },
            via: "pihpsdr",
            hamlibReady: true,
            notes: "piHPSDR CAT TCP 19090 \u2192 Hamlib model 2040."
          },
          {
            kind: "tci",
            auth: "none",
            ports: { tci: 40001 },
            via: "pihpsdr|spark",
            hamlibReady: false,
            notes: "TCI do app SDR. Bridge TCI\u2192Hamlib futura; por ora use sdr-cat-proxy."
          }
        ],
        capabilities: CAP_SDR,
        notes: "Hub Hamlib aponta ao CAT do Thetis/piHPSDR, n\xE3o ao UDP 1024 do HL2."
      },
      // ── Anan (Apache Labs) ────────────────────────────────────────────
      {
        id: "anan-10e",
        maker: "anan",
        family: "ANAN-10",
        label: "Apache Labs ANAN-10E",
        protocol: "openhpsdr-p2",
        hamlibModel: 2054,
        hamlibBackend: "cat-proxy",
        connections: [
          {
            kind: "openhpsdr-p2",
            auth: "none",
            ports: { control: 1024 },
            hamlibReady: false,
            notes: "OpenHPSDR Protocol 2. Firmware P2 obrigat\xF3rio."
          },
          {
            kind: "sdr-cat-proxy",
            preferred: true,
            auth: "none",
            ports: { cat: 13013, hamlibListen: 4532 },
            via: "thetis",
            hamlibReady: true
          },
          {
            kind: "sdr-cat-proxy",
            auth: "none",
            ports: { cat: 19090 },
            via: "pihpsdr",
            hamlibReady: true,
            notes: "Hamlib model 2040 para piHPSDR."
          },
          {
            kind: "tci",
            auth: "none",
            ports: { tci: 40001 },
            via: "host-app",
            hamlibReady: false
          }
        ],
        capabilities: { ...CAP_SDR, puresignal: true }
      },
      {
        id: "anan-100d",
        maker: "anan",
        family: "ANAN-100",
        label: "Apache Labs ANAN-100D",
        protocol: "openhpsdr-p2",
        hamlibModel: 2054,
        hamlibBackend: "cat-proxy",
        connections: [
          { kind: "openhpsdr-p2", auth: "none", ports: { control: 1024 }, hamlibReady: false },
          {
            kind: "sdr-cat-proxy",
            preferred: true,
            auth: "none",
            ports: { cat: 13013, hamlibListen: 4532 },
            via: "thetis",
            hamlibReady: true
          },
          {
            kind: "sdr-cat-proxy",
            auth: "none",
            ports: { cat: 19090 },
            via: "pihpsdr",
            hamlibReady: true
          }
        ],
        capabilities: { ...CAP_SDR, puresignal: true }
      },
      {
        id: "anan-7000dle",
        maker: "anan",
        family: "ANAN-7000",
        label: "Apache Labs ANAN-7000DLE",
        protocol: "openhpsdr-p2",
        hamlibModel: 2054,
        hamlibBackend: "cat-proxy",
        connections: [
          { kind: "openhpsdr-p2", auth: "none", ports: { control: 1024 }, hamlibReady: false },
          {
            kind: "sdr-cat-proxy",
            preferred: true,
            auth: "none",
            ports: { cat: 13013, hamlibListen: 4532 },
            via: "thetis",
            hamlibReady: true
          },
          {
            kind: "sdr-cat-proxy",
            auth: "none",
            ports: { cat: 19090 },
            via: "pihpsdr",
            hamlibReady: true
          }
        ],
        capabilities: { ...CAP_SDR, puresignal: true }
      },
      {
        id: "anan-8000dle",
        maker: "anan",
        family: "ANAN-8000",
        label: "Apache Labs ANAN-8000DLE",
        protocol: "openhpsdr-p2",
        hamlibModel: 2054,
        hamlibBackend: "cat-proxy",
        connections: [
          { kind: "openhpsdr-p2", auth: "none", ports: { control: 1024 }, hamlibReady: false },
          {
            kind: "sdr-cat-proxy",
            preferred: true,
            auth: "none",
            ports: { cat: 13013, hamlibListen: 4532 },
            via: "thetis",
            hamlibReady: true
          }
        ],
        capabilities: { ...CAP_SDR, puresignal: true }
      },
      {
        id: "anan-g2",
        maker: "anan",
        family: "ANAN-G2",
        label: "Apache Labs ANAN G2",
        protocol: "openhpsdr-p2",
        hamlibModel: 2054,
        hamlibBackend: "cat-proxy",
        connections: [
          { kind: "openhpsdr-p2", auth: "none", ports: { control: 1024 }, hamlibReady: false },
          {
            kind: "sdr-cat-proxy",
            preferred: true,
            auth: "none",
            ports: { cat: 13013, hamlibListen: 4532 },
            via: "thetis",
            hamlibReady: true
          },
          {
            kind: "sdr-cat-proxy",
            auth: "none",
            ports: { cat: 19090 },
            via: "pihpsdr",
            hamlibReady: true
          },
          {
            kind: "tci",
            auth: "none",
            ports: { tci: 40001 },
            via: "host-app",
            hamlibReady: false
          }
        ],
        capabilities: { ...CAP_SDR, puresignal: true }
      },
      {
        id: "anan-g2e",
        maker: "anan",
        family: "ANAN-G2",
        label: "Apache Labs ANAN G2E",
        protocol: "openhpsdr-p2",
        hamlibModel: 2054,
        hamlibBackend: "cat-proxy",
        connections: [
          { kind: "openhpsdr-p2", auth: "none", ports: { control: 1024 }, hamlibReady: false },
          {
            kind: "sdr-cat-proxy",
            preferred: true,
            auth: "none",
            ports: { cat: 13013, hamlibListen: 4532 },
            via: "thetis",
            hamlibReady: true
          },
          {
            kind: "sdr-cat-proxy",
            auth: "none",
            ports: { cat: 19090 },
            via: "pihpsdr",
            hamlibReady: true
          },
          {
            kind: "tci",
            auth: "none",
            ports: { tci: 40001 },
            via: "host-app",
            hamlibReady: false
          }
        ],
        capabilities: { ...CAP_SDR, puresignal: true }
      }
    ];
    CIV_TO_EQUIPMENT = (() => {
      const buckets = /* @__PURE__ */ new Map();
      const clash = /* @__PURE__ */ new Set();
      for (const eq of EQUIPMENT_CATALOG) {
        if (eq.protocol !== "civ" || !eq.civAddr) continue;
        if (buckets.has(eq.civAddr)) clash.add(eq.civAddr);
        else buckets.set(eq.civAddr, eq.id);
      }
      clash.forEach((addr) => buckets.delete(addr));
      return Object.fromEntries(buckets);
    })();
  }
});

// shared/equipment/hamlib.ts
function pickConnection(eq, kind) {
  if (kind) {
    const hit = eq.connections.find((c) => c.kind === kind);
    if (hit) return hit;
  }
  return eq.connections.find((c) => c.preferred) || eq.connections.find((c) => c.hamlibReady) || eq.connections[0];
}
function proxyModel(via, fallback) {
  if (!via) return fallback;
  const key = via.split("|")[0]?.trim().toLowerCase() || "";
  if (key && HAMLIB_PROXY_MODELS[key] != null) return HAMLIB_PROXY_MODELS[key];
  return fallback;
}
function resolveBackend(eq, conn) {
  if (conn.kind === "hamlib-net") return "hamlib-net";
  if (conn.kind === "sdr-cat-proxy") return "cat-proxy";
  if (conn.kind === "icom-lan-udp") return "icom-lan";
  if (conn.kind === "usb-serial" && eq.hamlibBackend === "ser2net") return "ser2net";
  if (eq.hamlibBackend !== "none" && conn.hamlibReady) return eq.hamlibBackend;
  return "none";
}
function buildRigDevice(backend, binding, conn) {
  const host2 = (binding.host || "127.0.0.1").trim() || "127.0.0.1";
  if (backend === "ser2net") {
    const port = binding.ser2netPort ?? binding.ports?.control;
    if (!port) {
      return {
        rigDevice: "",
        ready: false,
        deferReason: "Informe ser2netPort (TCP do ser2net, ex. 4001)."
      };
    }
    return { rigDevice: `127.0.0.1:${port}`, ready: true };
  }
  if (backend === "cat-proxy" || backend === "hamlib-net") {
    const cat = binding.ports?.cat ?? binding.ports?.control ?? conn.ports?.cat ?? conn.ports?.control;
    if (!cat) {
      return {
        rigDevice: "",
        ready: false,
        deferReason: "Informe a porta CAT do proxy (Thetis 13013 / piHPSDR 19090)."
      };
    }
    return { rigDevice: `${host2}:${cat}`, ready: true };
  }
  if (backend === "icom-lan") {
    const local = binding.ports?.serial ?? 45002;
    return { rigDevice: `127.0.0.1:${local}`, ready: true };
  }
  return {
    rigDevice: "",
    ready: false,
    deferReason: "Este transporte ainda n\xE3o tem driver no hub Hamlib (GATT, Flex TCP, OpenHPSDR nativo, TCI)."
  };
}
function rigctldCivOverride(eq, civAddr2, proto) {
  if (eq.protocol !== "civ" || proto === "cat") return null;
  const cur = normalizeCivAddr(civAddr2);
  if (!cur) return null;
  if (eq.hamlibPassCiv) return cur;
  const def = normalizeCivAddr(eq.civAddr);
  if (def && cur !== def) return cur;
  return null;
}
function planHamlib(binding) {
  const eq = getEquipment(binding.equipmentId);
  if (!eq) return null;
  const conn = pickConnection(eq, binding.connectionKind);
  if (!conn) {
    return {
      equipmentId: eq.id,
      label: eq.label,
      maker: eq.maker,
      hamlibModel: 0,
      backend: "none",
      argv: [],
      rigDevice: "",
      listenPort: binding.hamlibListenPort ?? HAMLIB_DEFAULT_LISTEN,
      baud: eq.defaultBaud ?? 0,
      ready: false,
      deferReason: "Nenhuma conex\xE3o no cat\xE1logo para este modelo.",
      connectionKind: binding.connectionKind
    };
  }
  const backend = resolveBackend(eq, conn);
  const model = proxyModel(conn.via, eq.hamlibModel);
  const listenPort = binding.hamlibListenPort ?? binding.ports?.hamlibListen ?? conn.ports?.hamlibListen ?? HAMLIB_DEFAULT_LISTEN;
  const baud = binding.baud ?? conn.defaultBaud ?? eq.defaultBaud ?? 0;
  const civAddr2 = binding.civAddr ?? eq.civAddr;
  const { rigDevice, ready: pathReady, deferReason: pathDefer } = buildRigDevice(backend, binding, conn);
  if (model == null) {
    return {
      equipmentId: eq.id,
      label: eq.label,
      maker: eq.maker,
      hamlibModel: 0,
      backend,
      argv: [],
      rigDevice,
      listenPort,
      baud,
      civAddr: civAddr2,
      ready: false,
      deferReason: "Sem n\xFAmero de modelo Hamlib neste equipamento / via.",
      connectionKind: conn.kind
    };
  }
  if (!pathReady || backend === "none") {
    return {
      equipmentId: eq.id,
      label: eq.label,
      maker: eq.maker,
      hamlibModel: model,
      backend,
      argv: [],
      rigDevice,
      listenPort,
      baud,
      civAddr: civAddr2,
      ready: false,
      deferReason: pathDefer || "Backend Hamlib = none para este transporte.",
      connectionKind: conn.kind
    };
  }
  const argv = ["-m", String(model), "-r", rigDevice, "-t", String(listenPort)];
  if (backend === "ser2net" || backend === "icom-lan") {
    const civ = rigctldCivOverride(eq, civAddr2);
    if (civ) argv.push("-c", civ);
  }
  return {
    equipmentId: eq.id,
    label: eq.label,
    maker: eq.maker,
    hamlibModel: model,
    backend,
    argv,
    rigDevice,
    listenPort,
    baud,
    civAddr: civAddr2,
    ready: true,
    connectionKind: conn.kind
  };
}
function formatRigctldCommand(plan, binary = "/usr/bin/rigctld") {
  if (!plan.ready) return `# n\xE3o pronto: ${plan.deferReason || "indefinido"}`;
  return [binary, ...plan.argv].join(" ");
}
var HAMLIB_DEFAULT_LISTEN, HAMLIB_PROXY_MODELS;
var init_hamlib = __esm({
  "shared/equipment/hamlib.ts"() {
    "use strict";
    init_catalog();
    HAMLIB_DEFAULT_LISTEN = 4532;
    HAMLIB_PROXY_MODELS = {
      thetis: 2054,
      pihpsdr: 2040,
      powersdr: 2048,
      "sdr-console": 2056
    };
  }
});

// shared/equipment/labels.ts
var init_labels = __esm({
  "shared/equipment/labels.ts"() {
    "use strict";
  }
});

// shared/equipment/links.ts
var init_links = __esm({
  "shared/equipment/links.ts"() {
    "use strict";
    init_catalog();
    init_labels();
  }
});

// shared/equipment/index.ts
var init_equipment = __esm({
  "shared/equipment/index.ts"() {
    "use strict";
    init_types();
    init_catalog();
    init_hamlib();
    init_labels();
    init_links();
  }
});

// shared/icom-scope.ts
function civScopeOn(equipmentId, link) {
  const id = equipmentId || "";
  if (link === "bluetooth") return SCOPE_BT.has(id);
  if (link === "lan") return SCOPE_LAN.has(id);
  return SCOPE_SERIAL.has(id);
}
function civAddrByte(text) {
  const match = String(text || "").trim().match(/^0x([0-9a-fA-F]{2})$/);
  if (!match) return null;
  return Number.parseInt(match[1], 16);
}
function scopeCenterFrame(to) {
  return Uint8Array.from([254, 254, to & 255, 224, 39, 20, 0, 0, 253]);
}
function normalizeScopeSpan(spanHz) {
  const n = Math.round(spanHz);
  return SCOPE_SPAN_STEPS_HZ.includes(n) ? n : SCOPE_SPAN_HZ;
}
function scopeSpanData(spanHz = SCOPE_SPAN_HZ) {
  const half = normalizeScopeSpan(spanHz) / 2;
  return [39, 21, 0, ...bcd5(half)];
}
function scopeSpanFrame(to, spanHz = SCOPE_SPAN_HZ) {
  return Uint8Array.from([254, 254, to & 255, 224, ...scopeSpanData(spanHz), 253]);
}
function scopeSwitchFrames(to, on) {
  const steps = on ? [
    [39, 16, 1],
    [39, 17, 1]
  ] : [
    [39, 17, 0],
    [39, 16, 0]
  ];
  return steps.map((body) => Uint8Array.from([254, 254, to & 255, 224, ...body, 253]));
}
function isScopeWaveform(frame) {
  return frame.length >= 8 && frame[0] === 254 && frame[1] === 254 && frame[4] === 39 && frame[5] === 0 && frame[frame.length - 1] === 253;
}
function scopePayload(frame) {
  if (!isScopeWaveform(frame)) return null;
  return frame.subarray(5, frame.length - 1);
}
function bcdByte(n) {
  return (n >> 4 & 15) * 10 + (n & 15);
}
function bcd5(hz) {
  const out = [];
  let f = Math.max(0, Math.floor(hz));
  for (let i = 0; i < 5; i++) {
    const lo = f % 10;
    f = Math.floor(f / 10);
    const hi = f % 10;
    f = Math.floor(f / 10);
    out.push(hi << 4 | lo);
  }
  return out;
}
function bcdHz(data, off) {
  let hz = 0;
  let mul = 1;
  for (let i = 0; i < 5; i++) {
    const byte = data[off + i] ?? 0;
    hz += (byte & 15) * mul;
    mul *= 10;
    hz += (byte >> 4 & 15) * mul;
    mul *= 10;
  }
  return hz;
}
function scopeEdgeHz(data, off) {
  const sign = data[off + 4] ?? 0;
  if ((sign & 240) !== 240) return bcdHz(data, off);
  const copy = data.slice(off, off + 5);
  copy[4] = sign & 15;
  return -bcdHz(copy, 0);
}
function edges(mode, left, right) {
  if (mode === 0) {
    return { mode, startHz: left - right, endHz: left + right };
  }
  const startHz = Math.min(left, right);
  const endHz = Math.max(left, right);
  return { mode, startHz, endHz };
}
var CIV_SCOPE_TAP_HOST, CIV_SCOPE_TAP_PORT, SCOPE_SERIAL, SCOPE_LAN, SCOPE_BT, SCOPE_SPAN_STEPS_HZ, SCOPE_SPAN_HZ, BINS, ScopeAssembler;
var init_icom_scope = __esm({
  "shared/icom-scope.ts"() {
    "use strict";
    CIV_SCOPE_TAP_HOST = "127.0.0.1";
    CIV_SCOPE_TAP_PORT = 4012;
    SCOPE_SERIAL = /* @__PURE__ */ new Set([
      "icom-ic-705",
      "icom-ic-7300",
      "icom-ic-7300mk2",
      "icom-ic-7610",
      "icom-ic-9700",
      "icom-ic-905",
      "icom-ic-7760"
    ]);
    SCOPE_LAN = /* @__PURE__ */ new Set([
      "icom-ic-705",
      "icom-ic-7300mk2",
      "icom-ic-7610",
      "icom-ic-9700",
      "icom-ic-905",
      "icom-ic-7760"
    ]);
    SCOPE_BT = /* @__PURE__ */ new Set(["icom-ic-705"]);
    SCOPE_SPAN_STEPS_HZ = [5e3, 1e4, 2e4, 5e4, 1e5, 2e5, 5e5, 1e6];
    SCOPE_SPAN_HZ = 2e5;
    BINS = 689;
    ScopeAssembler = class {
      bins = new Uint8Array(BINS);
      filled = 0;
      expect = 1;
      header = null;
      reset() {
        this.filled = 0;
        this.expect = 1;
        this.header = null;
      }
      push(data) {
        if (data.length < 4 || data[0] !== 0) return null;
        if (data[1] === 1) return null;
        const seq = bcdByte(data[2] ?? 0);
        const seqMax = bcdByte(data[3] ?? 0);
        if (seq < 1 || seqMax < 1) return null;
        if (seq === 1) {
          if (data.length < 16) return null;
          const mode = data[4] ?? 0;
          const left = scopeEdgeHz(data, 5);
          const right = scopeEdgeHz(data, 10);
          const oor = data[15] === 1;
          this.filled = 0;
          this.expect = 2;
          this.header = edges(mode, left, right);
          if (oor) {
            this.reset();
            return null;
          }
          if (data.length > 16) this.take(data, 16);
          if (seqMax === 1 || this.filled >= BINS) return this.finish();
          return null;
        }
        if (!this.header || seq !== this.expect) {
          this.reset();
          return null;
        }
        this.take(data, 4);
        this.expect = seq + 1;
        if (seq >= seqMax || this.filled >= BINS) return this.finish();
        return null;
      }
      take(data, offset) {
        const n = Math.min(data.length - offset, BINS - this.filled);
        if (n <= 0) return;
        this.bins.set(data.subarray(offset, offset + n), this.filled);
        this.filled += n;
      }
      finish() {
        const header = this.header;
        const n = this.filled;
        if (!header || n < 1) {
          this.reset();
          return null;
        }
        const bins = this.bins.slice(0, n);
        this.reset();
        return { ...header, bins, oor: false };
      }
    };
  }
});

// shared/smeter.ts
function bcdMeterRaw(hi, lo) {
  return (hi >> 4 & 15) * 1e3 + (hi & 15) * 100 + (lo >> 4 & 15) * 10 + (lo & 15);
}
function civRawToUiSMeter(n) {
  if (!Number.isFinite(n) || n <= 0) return 0;
  if (n <= IC705_SMETER_S9) return n / IC705_SMETER_S9 * 9;
  const span = IC705_SMETER_S9_PLUS_60 - IC705_SMETER_S9;
  return 9 + (Math.min(IC705_SMETER_S9_PLUS_60, n) - IC705_SMETER_S9) / span * 3;
}
var IC705_SMETER_S9, IC705_SMETER_S9_PLUS_60, SMETER_POLL_MS, SMETER_FRAME_MS;
var init_smeter = __esm({
  "shared/smeter.ts"() {
    "use strict";
    IC705_SMETER_S9 = 120;
    IC705_SMETER_S9_PLUS_60 = 241;
    SMETER_POLL_MS = Math.round(1e3 / 60);
    SMETER_FRAME_MS = Math.round(1e3 / 30);
  }
});

// server/icom-scope-hub.ts
function publishScopeFrame(frame) {
  for (const fn of listeners) fn(frame);
}
function subscribeScopeFrame(fn) {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}
var listeners;
var init_icom_scope_hub = __esm({
  "server/icom-scope-hub.ts"() {
    "use strict";
    listeners = /* @__PURE__ */ new Set();
  }
});

// server/icom-lan.ts
import { execFile as execFile2, spawn as spawn2 } from "node:child_process";
import { createServer } from "node:net";
import { promisify as promisify2 } from "node:util";
import { IcomControl } from "icom-wlan-node";
function snap2() {
  return {
    ok: phase !== "error",
    phase,
    connected: phase === "ready",
    host,
    controlPort,
    civTcpPort: ICOM_LAN_CIV_TCP_PORT,
    civAddr,
    model: modelLabel,
    radioId,
    deviceName,
    error,
    hamlibPid: rigctld?.pid ?? null
  };
}
function parseCivAddr(raw) {
  const s = String(raw || "0xA4").trim();
  const n = Number.parseInt(s.replace(/^0x/i, ""), 16);
  return Number.isFinite(n) && n >= 0 && n <= 255 ? n : 164;
}
function formatCivAddr(n) {
  return `0x${n.toString(16).toUpperCase().padStart(2, "0")}`;
}
function normalizeIcomNetUser(user) {
  return String(user || "").trim().toUpperCase().slice(0, 16);
}
function loginRejectHint(errorCode) {
  const code = errorCode != null ? errorCode >>> 0 : void 0;
  const authFail = code === 4278190079 || code === 4294967294 || code === 4294967295;
  if (authFail) {
    return "Login Icom LAN recusado \u2014 confira Network User/senha (mai\xFAsculas/min\xFAsculas) e se outro cliente (wfview/RS-BA1) j\xE1 est\xE1 conectado";
  }
  if (code != null) {
    return `Login Icom LAN recusado (c\xF3digo 0x${code.toString(16).toUpperCase()}) \u2014 confira Network User/senha e sess\xE3o concorrente`;
  }
  return "Login Icom LAN recusado \u2014 confira Network User/senha e se outro cliente j\xE1 est\xE1 na LAN";
}
function resolveIcomLanModel(equipmentId, hint) {
  const id = `${equipmentId || ""} ${hint || ""}`.toLowerCase();
  if (id.includes("705")) return "IC-705";
  if (id.includes("905")) return "IC-905";
  if (id.includes("9700")) return "IC-9700";
  if (id.includes("7610")) return "IC-7610";
  if (id.includes("7760")) return "IC-7760";
  if (id.includes("7300mk2") || id.includes("7300-mk2") || id.includes("7300mkii")) return "IC-7300MK2";
  if (id.includes("7300")) return "IC-7300";
  return "auto";
}
function mapUiMode(mode) {
  const key = mode.trim().toUpperCase();
  if (key === "LSB-D") return { mode: "LSB", dataMode: true };
  if (key === "USB-D") return { mode: "USB", dataMode: true };
  if (key === "LSB" || key === "USB" || key === "AM" || key === "CW" || key === "FM" || key === "DV") {
    return { mode: key };
  }
  if (key === "RTTY") return { mode: "RTTY" };
  return { mode: "USB" };
}
function feedTcp(frame) {
  Array.from(tcpClients).forEach((sock3) => {
    if (sock3.destroyed) {
      tcpClients.delete(sock3);
      return;
    }
    try {
      sock3.write(frame);
    } catch {
      try {
        sock3.destroy();
      } catch {
      }
      tcpClients.delete(sock3);
    }
  });
}
function attachCivListeners(control) {
  control.events.on("civFrame", (frame) => {
    if (isScopeWaveform(frame)) {
      publishScopeFrame(frame);
      return;
    }
    feedTcp(Buffer.from(frame));
  });
  control.events.on("connectionLost", () => {
    if (phase === "ready") {
      phase = "error";
      error = "Sess\xE3o Icom LAN perdida";
    }
  });
  control.events.on("error", (err) => {
    if (phase === "connecting" || phase === "ready") {
      error = err?.message || String(err);
    }
  });
}
function ensureTcpBridge() {
  if (tcpServer) return;
  const server = createServer((sock3) => {
    tcpClients.add(sock3);
    let buf = Buffer.alloc(0);
    sock3.on("data", (chunk) => {
      buf = Buffer.concat([buf, chunk]);
      while (true) {
        const start = buf.indexOf(CIV_PRE);
        if (start < 0) {
          buf = Buffer.alloc(0);
          break;
        }
        if (start > 0) buf = buf.subarray(start);
        if (buf.length < 2) break;
        if (buf[1] !== CIV_PRE) {
          buf = buf.subarray(1);
          continue;
        }
        const end = buf.indexOf(CIV_END, 2);
        if (end < 0) break;
        const frame = buf.subarray(0, end + 1);
        buf = buf.subarray(end + 1);
        if (rig && phase === "ready") {
          try {
            rig.sendCiv(Buffer.from(frame));
          } catch {
          }
        }
      }
    });
    sock3.on("close", () => tcpClients.delete(sock3));
    sock3.on("error", () => tcpClients.delete(sock3));
  });
  server.on("error", (err) => {
    error = `TCP CI-V local: ${err.message}`;
  });
  server.listen(ICOM_LAN_CIV_TCP_PORT, "127.0.0.1");
  tcpServer = server;
}
async function stopSystemdHamlib() {
  if (process.platform !== "linux") return;
  try {
    await execFileAsync2("systemctl", ["stop", "rigctld@ic705.service"], {
      timeout: 8e3,
      windowsHide: true
    });
    stoppedSystemdHamlib = true;
  } catch {
    stoppedSystemdHamlib = false;
  }
}
async function startSystemdHamlib() {
  if (process.platform !== "linux" || !stoppedSystemdHamlib) return;
  try {
    await execFileAsync2("systemctl", ["start", "rigctld@ic705.service"], {
      timeout: 8e3,
      windowsHide: true
    });
  } catch {
  }
  stoppedSystemdHamlib = false;
}
function killRigctld() {
  if (!rigctld) return;
  try {
    rigctld.kill("SIGTERM");
  } catch {
  }
  rigctld = null;
}
async function startRigctldChild() {
  killRigctld();
  await stopSystemdHamlib();
  const addr = parseCivAddr(civAddr);
  const args = [
    "-m",
    String(hamlibModel || 3085),
    "-r",
    `127.0.0.1:${ICOM_LAN_CIV_TCP_PORT}`,
    "-t",
    "4532",
    "-c",
    `0x${addr.toString(16).toUpperCase()}`
  ];
  try {
    const child2 = spawn2("rigctld", args, {
      stdio: ["ignore", "ignore", "pipe"],
      windowsHide: true
    });
    child2.on("exit", () => {
      if (rigctld === child2) rigctld = null;
    });
    child2.stderr?.on("data", () => {
    });
    rigctld = child2;
  } catch (err) {
    error = `Hamlib (rigctld) n\xE3o iniciado: ${err instanceof Error ? err.message : String(err)}`;
  }
}
function icomLanStatus() {
  return snap2();
}
function icomLanLive() {
  return phase === "ready" && Boolean(rig);
}
function formatLanConnectError(raw, loginHint, targetHost, targetPort) {
  if (loginHint) return `${loginHint} (${targetHost}:${targetPort})`;
  const timeoutStage = raw.match(/timeout at ([^\s]+)/i)?.[1];
  if (timeoutStage) {
    return `Timeout Icom LAN na etapa ${timeoutStage} (${targetHost}:${targetPort}). Confira IP/rota, Network Control ON e se outro cliente (wfview/RS-BA1) n\xE3o est\xE1 na sess\xE3o`;
  }
  if (/login rejected/i.test(raw)) {
    return `${loginRejectHint(void 0)} (${targetHost}:${targetPort})`;
  }
  if (raw.trim()) return `${raw} (${targetHost}:${targetPort})`;
  return `Falha Icom LAN em ${targetHost}:${targetPort} (UDP controle). Confira IP, Network User, senha, Network Control ON e sess\xE3o concorrente`;
}
async function icomLanConnect(opts) {
  await icomLanDisconnect({ keepRadioMark: true });
  const gen = ++connectGen;
  radioId = opts.radioId;
  host = String(opts.host || "").trim();
  controlPort = Number(opts.controlPort) > 0 ? Number(opts.controlPort) : 50001;
  civAddr = formatCivAddr(parseCivAddr(opts.civAddr));
  hamlibModel = opts.hamlibModel && opts.hamlibModel > 0 ? opts.hamlibModel : 3085;
  deviceName = String(opts.deviceName || "").trim();
  modelLabel = resolveIcomLanModel(opts.equipmentId, deviceName);
  error = "";
  phase = "connecting";
  if (!host) {
    phase = "error";
    error = "Informe o IP ou hostname do r\xE1dio";
    return snap2();
  }
  const userName = normalizeIcomNetUser(opts.userName || "");
  if (!userName) {
    phase = "error";
    error = "Informe o Network User do Icom LAN";
    return snap2();
  }
  ensureTcpBridge();
  const password = String(opts.password || "").slice(0, 16);
  const control = new IcomControl({
    control: { ip: host, port: controlPort },
    userName,
    password,
    model: modelLabel === "auto" ? "auto" : modelLabel,
    connectTimeoutMs: 18e3,
    logger: () => {
    }
  });
  attachCivListeners(control);
  let loginHint = "";
  let loginCode;
  control.events.on("login", (res) => {
    if (!res.ok) {
      loginCode = res.errorCode;
      loginHint = loginRejectHint(res.errorCode);
    }
  });
  rig = control;
  try {
    await control.connect({ timeout: 22e3 });
    if (gen !== connectGen) {
      await control.disconnect().catch(() => void 0);
      if (rig === control) rig = null;
      if (!error) error = "Conex\xE3o Icom LAN cancelada";
      if (phase === "connecting") phase = "idle";
      return snap2();
    }
    phase = "ready";
    error = "";
    try {
      const id = await control.getRadioIdentity({ timeout: 2500 });
      if (id.civAddress != null) civAddr = formatCivAddr(id.civAddress);
      if (id.rigName) deviceName = id.rigName;
      if (id.modelId) modelLabel = id.modelId;
    } catch {
    }
    await startRigctldChild();
    return snap2();
  } catch (err) {
    phase = "error";
    const raw = err instanceof Error ? err.message : String(err);
    if (!loginHint && loginCode != null) loginHint = loginRejectHint(loginCode);
    error = formatLanConnectError(raw, loginHint, host, controlPort);
    try {
      await control.disconnect().catch(() => void 0);
    } catch {
    }
    if (rig === control) rig = null;
    return snap2();
  }
}
async function withTimeout(p, ms) {
  let timer;
  try {
    return await Promise.race([
      p,
      new Promise((resolve) => {
        timer = setTimeout(() => resolve(void 0), ms);
      })
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}
async function icomLanDisconnect(opts) {
  connectGen += 1;
  phase = "idle";
  error = "";
  killRigctld();
  void startSystemdHamlib();
  const cur = rig;
  rig = null;
  Array.from(tcpClients).forEach((sock3) => {
    try {
      sock3.destroy();
    } catch {
    }
  });
  tcpClients.clear();
  if (cur) {
    try {
      await withTimeout(cur.disconnect().catch(() => void 0), 2500);
    } catch {
    }
  }
  if (!opts?.keepRadioMark) {
    radioId = "";
    host = "";
    deviceName = "";
    modelLabel = "";
  }
  return snap2();
}
function civPayload(...body) {
  const to = parseCivAddr(civAddr);
  return Buffer.from([CIV_PRE, CIV_PRE, to, 224, ...body, CIV_END]);
}
async function icomLanCmd(cmd, body = {}) {
  if (cmd === "smeter") {
    if (!rig || phase !== "ready") return { ok: true, reply: { skipped: true } };
    return { ok: true, reply: await readLanSmeter() };
  }
  if (!rig || phase !== "ready") {
    return { ok: false, error: "Icom LAN n\xE3o conectado" };
  }
  try {
    switch (cmd) {
      case "freq":
      case "setFreq": {
        const hz = Number(body.hz ?? body.freq);
        if (!Number.isFinite(hz) || hz < 1e3) return { ok: false, error: "frequ\xEAncia inv\xE1lida" };
        await rig.setFrequency(Math.round(hz));
        return { ok: true };
      }
      case "ptt":
      case "setPtt": {
        await rig.setPtt(Boolean(body.on ?? body.ptt));
        return { ok: true };
      }
      case "mode":
      case "setMode": {
        const raw = String(body.mode ?? "USB");
        const mapped = mapUiMode(raw);
        await rig.setMode(mapped.mode, mapped.dataMode ? { dataMode: true } : void 0);
        return { ok: true };
      }
      case "vfo":
      case "setVfo": {
        const which = String(body.vfo ?? body.which ?? "A").toUpperCase() === "B" ? "B" : "A";
        await rig.setVfo(which);
        return { ok: true };
      }
      case "setNr":
      case "nr": {
        await rig.setFunction("NR", Boolean(body.on ?? body.nr));
        return { ok: true };
      }
      case "setNb":
      case "nb": {
        await rig.setFunction("NB", Boolean(body.on ?? body.nb));
        return { ok: true };
      }
      case "setPre":
      case "pre": {
        const v = String(body.pre ?? body.value ?? "OFF").toUpperCase();
        const byte = v === "ON1" || v === "ON2" ? PRE_BYTE[v] : PRE_BYTE.OFF;
        rig.sendCiv(civPayload(22, 2, byte));
        return { ok: true };
      }
      case "setAtt":
      case "att": {
        rig.sendCiv(civPayload(17, Boolean(body.on ?? body.att) ? 32 : 0));
        return { ok: true };
      }
      case "setAgc":
      case "agc": {
        const v = String(body.agc ?? body.value ?? "OFF").toUpperCase();
        const byte = v === "OFF" ? 1 : AGC_BYTE[v] ?? AGC_BYTE.MID;
        rig.sendCiv(civPayload(22, 18, byte));
        return { ok: true };
      }
      case "setPower":
      case "power": {
        const on = Boolean(body.on ?? body.power ?? body.value);
        if (on) {
          rig.sendCiv(civPayload(24, 1));
          return { ok: true };
        }
        if (body.standby === true && hamlibModel === 3085) {
          rig.sendCiv(civPayload(26, 5, 0, 115, 1));
          await new Promise((r) => setTimeout(r, 80));
          rig.sendCiv(civPayload(24, 0));
          return { ok: true };
        }
        rig.sendCiv(civPayload(24, body.standby === true ? 2 : 0));
        return { ok: true };
      }
      case "readFreq": {
        const hz = await rig.readOperatingFrequency();
        return { ok: true, reply: { hz } };
      }
      case "readMode": {
        const mode = await rig.readOperatingMode();
        return { ok: true, reply: { mode } };
      }
      case "poll":
      case "readTelemetry": {
        const tick = Number(body.tick ?? 0) || 0;
        const reply = await pollLanTelemetry(tick);
        return { ok: true, reply };
      }
      case "scope": {
        const on = Boolean(body.on);
        if (on) {
          rig.sendCiv(civPayload(39, 16, 1));
          rig.sendCiv(civPayload(39, 17, 1));
          rig.sendCiv(civPayload(39, 20, 0, 0));
          rig.sendCiv(civPayload(...scopeSpanData()));
        } else {
          rig.sendCiv(civPayload(39, 17, 0));
          rig.sendCiv(civPayload(39, 16, 0));
        }
        return { ok: true };
      }
      case "scopeCenter": {
        rig.sendCiv(civPayload(39, 20, 0, 0));
        return { ok: true };
      }
      case "scopeSpan": {
        const spanHz = body.spanHz != null ? Number(body.spanHz) : void 0;
        rig.sendCiv(civPayload(39, 20, 0, 0));
        rig.sendCiv(civPayload(...scopeSpanData(spanHz)));
        return { ok: true };
      }
      case "civ": {
        const hex = String(body.hex || "").replace(/\s+/g, "");
        if (!/^[0-9a-fA-F]+$/.test(hex) || hex.length < 10) return { ok: false, error: "frame CI-V inv\xE1lido" };
        rig.sendCiv(Buffer.from(hex, "hex"));
        return { ok: true };
      }
      default:
        return { ok: false, error: `comando desconhecido: ${cmd}` };
    }
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : String(err) };
  }
}
function mapModeReply(mode) {
  if (!mode) return void 0;
  const name = String(mode.modeName || "").toUpperCase();
  if (!name) return void 0;
  if (mode.dataMode && (name === "USB" || name === "LSB")) return `${name}-D`;
  return name;
}
function askCivReply(match, body, timeoutMs = 900) {
  const control = rig;
  if (!control || phase !== "ready") return Promise.resolve(null);
  return new Promise((resolve) => {
    let done = false;
    const finish2 = (frame) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      control.events.off("civFrame", onFrame2);
      resolve(frame);
    };
    const onFrame2 = (frame) => {
      try {
        if (match(frame)) finish2(Buffer.from(frame));
      } catch {
      }
    };
    const timer = setTimeout(() => finish2(null), timeoutMs);
    control.events.on("civFrame", onFrame2);
    try {
      control.sendCiv(civPayload(...body));
    } catch {
      finish2(null);
    }
  });
}
function parsePreFrame(frame) {
  if (frame.length < 8 || frame[4] !== 22 || frame[5] !== 2) return void 0;
  const v = frame[6];
  if (v === 2) return "ON2";
  if (v === 1) return "ON1";
  if (v === 0) return "OFF";
  return void 0;
}
function parseAttFrame(frame) {
  if (frame.length < 7 || frame[4] !== 17) return void 0;
  return frame[5] === 32;
}
function parseAgcFrame(frame) {
  if (frame.length < 8 || frame[4] !== 22 || frame[5] !== 18) return void 0;
  const v = frame[6];
  if (v === 3) return "SLOW";
  if (v === 2) return "MID";
  if (v === 1) return "FAST";
  if (v === 0) return "OFF";
  return void 0;
}
function releaseCiv() {
  civHeld = false;
}
async function holdCiv(waitMs) {
  const start = Date.now();
  for (; ; ) {
    if (!civHeld) {
      civHeld = true;
      return true;
    }
    if (waitMs <= 0 || Date.now() - start >= waitMs) return false;
    await new Promise((r) => setTimeout(r, 10));
  }
}
async function readLanSmeter() {
  if (!await holdCiv(0)) return { skipped: true };
  try {
    const meterFrame = await askCivReply(
      (f) => f.length >= 9 && f[4] === 21 && f[5] === 2,
      [21, 2],
      320
    );
    if (!meterFrame) return { skipped: true };
    const raw = bcdMeterRaw(meterFrame[6], meterFrame[7]);
    return { smeter: civRawToUiSMeter(raw) };
  } finally {
    releaseCiv();
  }
}
async function pollLanTelemetry(tick) {
  const control = rig;
  const out = {};
  if (!control || phase !== "ready") return out;
  if (!await holdCiv(500)) return out;
  try {
    return await pollLanTelemetryHeld(tick);
  } finally {
    releaseCiv();
  }
}
async function pollLanTelemetryHeld(tick) {
  const control = rig;
  const out = {};
  if (!control || phase !== "ready") return out;
  const q = { timeout: 1200 };
  const seq = (tick % 8 + 8) % 8;
  try {
    const vfo = await control.getVfo(q);
    if (vfo === "A" || vfo === "B") out.vfo = vfo;
  } catch {
  }
  try {
    const hz = await control.readOperatingFrequency(q);
    if (hz != null && hz >= 1e5) {
      out.freq = hz;
      if (out.vfo === "B") out.freqB = hz;
      else out.freqA = hz;
    }
  } catch {
  }
  if (seq === 1 || seq === 5) {
    try {
      const mode = await control.readOperatingMode(q);
      const mapped = mapModeReply(mode);
      if (mapped) {
        out.mode = mapped;
        if (out.vfo === "B") out.modeB = mapped;
        else out.modeA = mapped;
      }
    } catch {
    }
  }
  try {
    const ptt = await control.readPtt(q);
    if (ptt != null) out.ptt = ptt;
  } catch {
  }
  if (out.ptt) {
    try {
      const po = await control.readPowerLevel(q);
      if (po?.watts != null && Number.isFinite(po.watts)) out.po = po.watts;
      else if (po?.percent != null) out.po = Math.max(0, Math.min(10, po.percent / 100 * 10));
    } catch {
    }
    try {
      const swr = await control.readSWR(q);
      if (swr?.swr != null && Number.isFinite(swr.swr)) out.swr = swr.swr;
    } catch {
    }
  } else if (seq === 0 || seq === 2 || seq === 4 || seq === 6) {
    const meterFrame = await askCivReply(
      (f) => f.length >= 9 && f[4] === 21 && f[5] === 2,
      [21, 2],
      q.timeout
    );
    if (meterFrame) {
      const raw = bcdMeterRaw(meterFrame[6], meterFrame[7]);
      out.smeter = civRawToUiSMeter(raw);
    }
  }
  if (seq === 3) {
    try {
      const nr = await control.getNoiseReductionEnabled(q);
      if (nr != null) out.nr = nr;
    } catch {
    }
    try {
      const nb = await control.getNoiseBlankerEnabled(q);
      if (nb != null) out.nb = nb;
    } catch {
    }
  }
  if (seq === 7) {
    try {
      const split = await control.getSplitEnabled(q);
      if (split != null) out.split = split;
    } catch {
    }
    const preFrame = await askCivReply((f) => f.length >= 8 && f[4] === 22 && f[5] === 2, [22, 2]);
    const pre = preFrame ? parsePreFrame(preFrame) : void 0;
    if (pre) out.pre = pre;
    const attFrame = await askCivReply((f) => f.length >= 7 && f[4] === 17, [17]);
    const att = attFrame ? parseAttFrame(attFrame) : void 0;
    if (att != null) out.att = att;
    const agcFrame = await askCivReply((f) => f.length >= 8 && f[4] === 22 && f[5] === 18, [22, 18]);
    const agc = agcFrame ? parseAgcFrame(agcFrame) : void 0;
    if (agc) out.agc = agc;
    const pwrFrame = await askCivReply(
      (f) => f.length >= 7 && f[4] === 24 && (f[5] === 0 || f[5] === 1 || f[5] === 2),
      [24],
      q.timeout
    );
    if (pwrFrame && (pwrFrame[5] === 0 || pwrFrame[5] === 1 || pwrFrame[5] === 2)) {
      out.power = pwrFrame[5] === 1;
    }
  }
  if (!out.ptt && (seq === 2 || seq === 6) && (out.vfo === "A" || out.vfo === "B")) {
    const cur = out.vfo;
    const other = cur === "A" ? "B" : "A";
    try {
      await control.setVfo(other);
      const otherHz = await control.readOperatingFrequency(q);
      const otherMode = await control.readOperatingMode(q);
      await control.setVfo(cur);
      if (otherHz != null && otherHz >= 1e5) {
        if (other === "B") out.freqB = otherHz;
        else out.freqA = otherHz;
      }
      const mapped = mapModeReply(otherMode);
      if (mapped) {
        if (other === "B") out.modeB = mapped;
        else out.modeA = mapped;
      }
    } catch {
      try {
        await control.setVfo(cur);
      } catch {
      }
    }
  }
  return out;
}
var execFileAsync2, ICOM_LAN_CIV_TCP_PORT, CIV_PRE, CIV_END, rig, phase, error, radioId, host, controlPort, civAddr, modelLabel, deviceName, hamlibModel, tcpServer, tcpClients, rigctld, stoppedSystemdHamlib, connectGen, PRE_BYTE, AGC_BYTE, civHeld;
var init_icom_lan = __esm({
  "server/icom-lan.ts"() {
    "use strict";
    init_icom_scope();
    init_smeter();
    init_icom_scope_hub();
    execFileAsync2 = promisify2(execFile2);
    ICOM_LAN_CIV_TCP_PORT = 45002;
    CIV_PRE = 254;
    CIV_END = 253;
    rig = null;
    phase = "idle";
    error = "";
    radioId = "";
    host = "";
    controlPort = 50001;
    civAddr = "0xA4";
    modelLabel = "";
    deviceName = "";
    hamlibModel = 3085;
    tcpServer = null;
    tcpClients = /* @__PURE__ */ new Set();
    rigctld = null;
    stoppedSystemdHamlib = false;
    connectGen = 0;
    PRE_BYTE = { OFF: 0, ON1: 1, ON2: 2 };
    AGC_BYTE = { OFF: 0, FAST: 1, MID: 2, SLOW: 3 };
    civHeld = false;
  }
});

// server/list-serials.ts
import { execFile as execFile3 } from "node:child_process";
import { readdir } from "node:fs/promises";
import { join as join3 } from "node:path";
import { promisify as promisify3 } from "node:util";
async function listSerialDevices() {
  const found = process.platform === "win32" ? await listWindows() : await listUnix();
  const uniq = /* @__PURE__ */ new Map();
  for (const d of found) uniq.set(d.path, d);
  return Array.from(uniq.values()).sort((a, b) => a.path.localeCompare(b.path));
}
async function listUnix() {
  const out = [];
  const byId = "/dev/serial/by-id";
  try {
    const names = await readdir(byId);
    for (const name of names) {
      out.push({ path: `${byId}/${name}`, label: name, kind: "usb" });
    }
  } catch {
  }
  for (const dir of ["/dev"]) {
    let names = [];
    try {
      names = await readdir(dir);
    } catch {
      continue;
    }
    for (const name of names) {
      if (!/^(ttyUSB|ttyACM|ttyAMA|ttyS)\d+$/.test(name)) continue;
      const path5 = join3(dir, name);
      if (out.some((d) => d.path === path5)) continue;
      const kind = name.startsWith("ttyUSB") || name.startsWith("ttyACM") ? "usb" : "serial";
      out.push({ path: path5, label: name, kind });
    }
  }
  return out;
}
async function listWindows() {
  const script = [
    "$ports = @()",
    "try { [System.IO.Ports.SerialPort]::GetPortNames() | ForEach-Object { $ports += [pscustomobject]@{ path = $_; label = $_; kind = 'serial' } } } catch {}",
    "Get-CimInstance Win32_SerialPort -ErrorAction SilentlyContinue | ForEach-Object { $ports += [pscustomobject]@{ path = $_.DeviceID; label = $_.Name; kind = 'serial' } }",
    "Get-PnpDevice -Class Ports -Status OK -ErrorAction SilentlyContinue | ForEach-Object { $name = $_.FriendlyName; if ($name) { $com = [regex]::Match($name,'COM\\d+').Value; $path = if ($com) { $com } else { $name }; $ports += [pscustomobject]@{ path = $path; label = $name; kind = 'usb' } } }",
    "$ports | ConvertTo-Json -Compress"
  ].join("; ");
  try {
    const { stdout } = await execFileAsync3(
      "powershell.exe",
      ["-NoProfile", "-NonInteractive", "-Command", script],
      { windowsHide: true, timeout: 8e3 }
    );
    const raw = stdout.trim();
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    const rows = Array.isArray(parsed) ? parsed : [parsed];
    return rows.filter((r) => r?.path).map((r) => ({
      path: String(r.path),
      label: String(r.label || r.path),
      kind: r.kind === "usb" ? "usb" : "serial"
    }));
  } catch {
    return [];
  }
}
var execFileAsync3;
var init_list_serials = __esm({
  "server/list-serials.ts"() {
    "use strict";
    execFileAsync3 = promisify3(execFile3);
  }
});

// server/radios.ts
var radios_exports = {};
__export(radios_exports, {
  currentSerialHamlib: () => currentSerialHamlib,
  radiosConnect: () => radiosConnect,
  radiosDisconnect: () => radiosDisconnect,
  radiosMarkBle: () => radiosMarkBle,
  radiosRemove: () => radiosRemove,
  radiosResumeIcomLan: () => radiosResumeIcomLan,
  radiosSave: () => radiosSave,
  radiosSetPrimary: () => radiosSetPrimary,
  radiosStatus: () => radiosStatus,
  radiosUpsert: () => radiosUpsert,
  serialHamlibRadio: () => serialHamlibRadio,
  setBeforeHamlibRestart: () => setBeforeHamlibRestart
});
import { execFile as execFile4 } from "node:child_process";
import { chmodSync, existsSync as existsSync3, mkdirSync as mkdirSync3, readFileSync as readFileSync3, renameSync as renameSync3, writeFileSync as writeFileSync3 } from "node:fs";
import { dirname as dirname3, join as join4 } from "node:path";
import { fileURLToPath as fileURLToPath3 } from "node:url";
import { promisify as promisify4 } from "node:util";
import { randomBytes as randomBytes2 } from "node:crypto";
function dataDir3() {
  if (existsSync3("/opt/ham-cockpit")) {
    if (existsSync3(LEGACY_DIR) && !existsSync3(OPT_DIR3)) return LEGACY_DIR;
    mkdirSync3(OPT_DIR3, { recursive: true });
    return OPT_DIR3;
  }
  const local = join4(ROOT3, "data", "radios");
  mkdirSync3(local, { recursive: true });
  return local;
}
function jsonPath2() {
  return join4(dataDir3(), "radios.json");
}
function newId2() {
  return randomBytes2(4).toString("hex");
}
function writeAtomic3(file, body) {
  const tmp = `${file}.${process.pid}.tmp`;
  writeFileSync3(tmp, body, { encoding: "utf8" });
  renameSync3(tmp, file);
  try {
    chmodSync(file, 384);
  } catch {
  }
}
function publicRadio(r) {
  const { netPassword, ...rest } = r;
  if (r.link !== "network") return rest;
  return {
    ...rest,
    ...netPassword ? { hasNetPassword: true } : {}
  };
}
function publicList(list) {
  return list.map(publicRadio);
}
function isIcomLan(row) {
  if (row.link !== "network" || row.maker !== "icom") return false;
  if (row.netProfile?.startsWith("icom-lan-udp")) return true;
  return !row.netProfile || row.netProfile.includes("icom");
}
function hamlibModelFor(row) {
  if (row.equipmentId) {
    const eq = getEquipment(row.equipmentId);
    if (eq) return eq.hamlibModel ?? 0;
  }
  if (row.hamlibModel && row.hamlibModel > 0) return row.hamlibModel;
  const model = resolveIcomLanModel(row.equipmentId, `${row.name} ${row.deviceName} ${row.model || ""}`);
  if (model === "IC-705") return 3085;
  if (model === "IC-9700") return 3081;
  if (model === "IC-7610") return 3078;
  if (model === "IC-7300") return 3073;
  return 0;
}
function currentSerialHamlib() {
  return serialHamlibRadio(radios);
}
function serialHamlibRadio(list) {
  const usable = list.filter((r) => r.link !== "network" && (r.hamlibModel || 0) > 0);
  return usable.find((r) => r.primary) || usable[0];
}
function serialHamlibSig(list) {
  const row = serialHamlibRadio(list);
  if (!row) return "";
  return `${row.hamlibModel}|${row.hamlibPassCiv ? 1 : 0}|${row.civAddr}|${row.scope ? 1 : 0}`;
}
function setBeforeHamlibRestart(fn) {
  beforeHamlibRestart = fn;
}
function pokeSerialHamlib() {
  if (icomLanLive()) return;
  void (async () => {
    if (beforeHamlibRestart) await beforeHamlibRestart();
    await hamlibCtl("start");
  })();
}
function persistAndPoke(beforeSig) {
  persist2();
  if (serialHamlibSig(radios) !== beforeSig) pokeSerialHamlib();
}
function asMaker(v) {
  return MAKERS.includes(v) ? v : "icom";
}
function asLink(v) {
  if (v === "bluetooth") return "bluetooth";
  if (v === "network") return "network";
  return "usb";
}
function asProto(maker, v) {
  if (maker === "icom" || maker === "xiegu") return v === "cat" ? "cat" : "civ";
  return "cat";
}
function asBaud(v, fallback) {
  const n = Number(v);
  if (n === 0) return 0;
  return BAUDS2.has(n) ? n : fallback;
}
function defaultBaud(maker, link) {
  if (link === "bluetooth" && maker !== "icom") return 9600;
  if (maker === "kenwood" || maker === "yaesu" || maker === "elecraft") return 38400;
  if (maker === "tentec") return 57600;
  if (maker === "xiegu") return 19200;
  return 115200;
}
function defaultName(maker, deviceName2, civAddr2, proto) {
  const brand = {
    icom: "Icom",
    kenwood: "Kenwood",
    elecraft: "Elecraft",
    yaesu: "Yaesu",
    flex: "Flex",
    tentec: "Ten-Tec",
    xiegu: "Xiegu",
    hermes: "Hermes Lite",
    anan: "Anan"
  };
  const trimmed = deviceName2.trim();
  if (trimmed) return trimmed;
  if ((maker === "icom" || maker === "xiegu") && proto !== "cat") {
    const addr = String(civAddr2 || "0xA4").trim();
    const key = /^0x[0-9A-Fa-f]{2}$/i.test(addr) ? `0x${addr.slice(2).toUpperCase()}` : "0xA4";
    const model = CIV_MODEL_NAMES[key];
    if (model) return model;
  }
  return brand[maker] || "R\xE1dio";
}
function sanitize(raw, fallback) {
  const maker = asMaker(raw.maker ?? fallback?.maker);
  const link = asLink(raw.link ?? fallback?.link);
  const proto = asProto(maker, raw.proto ?? fallback?.proto);
  const baud = link === "network" ? 0 : asBaud(raw.baud ?? fallback?.baud, defaultBaud(maker, link));
  const device = String(raw.device ?? fallback?.device ?? "").trim();
  const deviceName2 = String(raw.deviceName ?? fallback?.deviceName ?? "").trim();
  const host2 = String(raw.host ?? fallback?.host ?? "").trim();
  const netProfile = String(raw.netProfile ?? fallback?.netProfile ?? "").trim();
  const netUserRaw = String(raw.netUser ?? fallback?.netUser ?? "").trim();
  const netUser = link === "network" && maker === "icom" ? normalizeIcomNetUser(netUserRaw) : netUserRaw;
  const incomingPass = raw.netPassword;
  const netPassword = incomingPass === void 0 || incomingPass === null ? String(fallback?.netPassword ?? "") : String(incomingPass) === "" && fallback?.netPassword ? String(fallback.netPassword) : String(incomingPass);
  const port = link === "network" ? String(raw.port ?? fallback?.port ?? "").trim() : String(raw.port ?? fallback?.port ?? device).trim() || device;
  const civAddr2 = String(raw.civAddr ?? fallback?.civAddr ?? "0xA4").trim() || "0xA4";
  const endpoint = link === "network" && host2 ? `${host2}${port ? `:${port}` : ""}` : "";
  const name = String(raw.name ?? fallback?.name ?? "").trim() || defaultName(maker, deviceName2 || endpoint || port || device, civAddr2, proto);
  const hsUuid = String(raw.hsUuid ?? fallback?.hsUuid ?? "").trim().toUpperCase();
  const equipmentId = inferEquipmentId({
    maker,
    equipmentId: String(raw.equipmentId ?? fallback?.equipmentId ?? "").trim(),
    name,
    deviceName: deviceName2,
    model: String(raw.model ?? fallback?.model ?? ""),
    civAddr: civAddr2,
    proto
  });
  const eq = equipmentId ? getEquipment(equipmentId) : void 0;
  const modelName = eq?.family || "";
  const serialHamlib = Boolean(eq && eq.hamlibBackend === "ser2net" && eq.hamlibModel);
  const hamlibModel2 = serialHamlib ? eq.hamlibModel : void 0;
  const civOverride = eq && serialHamlib ? rigctldCivOverride(eq, civAddr2, proto) : null;
  const scope = link === "usb" && proto === "civ" && (raw.scope === void 0 ? Boolean(fallback?.scope) : Boolean(raw.scope));
  return {
    id: String(raw.id ?? fallback?.id ?? newId2()),
    name,
    maker,
    link,
    device: link === "network" ? host2 || device : device,
    deviceName: link === "network" ? deviceName2 || endpoint || host2 : deviceName2,
    proto,
    port,
    baud,
    civAddr: /^0x[0-9A-Fa-f]{2}$/.test(civAddr2) ? civAddr2.toUpperCase().replace("0X", "0x") : "0xA4",
    hsUuid: /^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}$/.test(hsUuid) ? hsUuid : "",
    paired: Boolean(raw.paired ?? fallback?.paired),
    connected: Boolean(raw.connected ?? fallback?.connected),
    primary: Boolean(raw.primary ?? fallback?.primary),
    error: String(raw.error ?? fallback?.error ?? ""),
    ...equipmentId ? { equipmentId } : {},
    ...modelName ? { model: modelName } : {},
    ...hamlibModel2 ? { hamlibModel: hamlibModel2 } : {},
    ...civOverride ? { hamlibPassCiv: true } : {},
    ...scope ? { scope: true } : {},
    ...link === "network" ? {
      host: host2,
      ...netProfile ? { netProfile } : {},
      ...netUser ? { netUser } : {},
      ...netPassword ? { netPassword } : {}
    } : {}
  };
}
function normalizePrimary() {
  const hits = radios.filter((r) => r.primary);
  if (hits.length === 1) return;
  if (hits.length === 0 && radios.length === 1) {
    radios[0] = { ...radios[0], primary: true };
    return;
  }
  if (hits.length > 1) {
    const keep = hits[hits.length - 1].id;
    radios = radios.map((r) => ({ ...r, primary: r.id === keep }));
  }
}
function persist2() {
  writeAtomic3(jsonPath2(), `${JSON.stringify({ radios }, null, 2)}
`);
}
function load() {
  try {
    const raw = JSON.parse(readFileSync3(jsonPath2(), "utf8"));
    const previousSig = Array.isArray(raw.radios) ? serialHamlibSig(raw.radios) : "";
    if (Array.isArray(raw.radios)) radios = raw.radios.map((r) => sanitize(r));
    const before = radios.map((r) => `${r.id}:${r.primary}:${r.connected}:${r.equipmentId || ""}:${r.hamlibModel || 0}`).join();
    normalizePrimary();
    radios = radios.map(
      (r) => r.link === "bluetooth" && r.proto === "civ" && r.connected ? { ...r, connected: false } : r
    );
    const after = radios.map((r) => `${r.id}:${r.primary}:${r.connected}:${r.equipmentId || ""}:${r.hamlibModel || 0}`).join();
    const hamlibChanged = serialHamlibSig(radios) !== previousSig;
    if (before !== after || hamlibChanged) persist2();
    if (hamlibChanged) pokeSerialHamlib();
  } catch {
    radios = [];
  }
}
async function listBluetooth() {
  const out = [];
  if (process.platform === "win32") {
    try {
      const { stdout } = await execFileAsync4(
        "reg",
        ["query", "HKLM\\SYSTEM\\CurrentControlSet\\Services\\BTHPORT\\Parameters\\Devices"],
        { windowsHide: true, timeout: 8e3 }
      );
      const keys = stdout.split(/\r?\n/).map((l) => l.trim()).filter((l) => /\\Devices\\[0-9a-fA-F]{12}$/.test(l));
      for (const key of keys) {
        const hex = (key.split("\\").pop() || "").toUpperCase();
        if (!hex || hex === "000000000000") continue;
        const addr = hex.match(/.{2}/g)?.join(":") ?? hex;
        let name = "Bluetooth";
        try {
          const { stdout: det } = await execFileAsync4("reg", ["query", key, "/v", "Name"], { windowsHide: true, timeout: 4e3 });
          const m = det.match(/Name\s+REG_BINARY\s+([0-9A-Fa-f ]+)/i);
          if (m) {
            const raw = Buffer.from(m[1].replace(/\s+/g, ""), "hex");
            name = raw.toString("ascii").replace(/\0/g, "").trim() || raw.toString("utf16le").replace(/\0/g, "").trim() || name;
          }
        } catch {
        }
        out.push({ id: addr, path: addr, label: `${name} (${addr})`, kind: "bluetooth" });
      }
    } catch {
    }
    try {
      const script = [
        "Get-PnpDevice -Class Ports -Status OK -ErrorAction SilentlyContinue | ForEach-Object {",
        "  $com = [regex]::Match($_.FriendlyName,'COM\\d+').Value",
        "  if (-not $com -or $_.InstanceId -notmatch 'BTHENUM') { return }",
        "  $m = [regex]::Match($_.InstanceId, '([0-9A-Fa-f]{12})_')",
        "  $hex = if ($m.Success) { $m.Groups[1].Value.ToUpper() } else { '' }",
        "  if ($hex -eq '000000000000' -or $hex -eq '') { return }",
        '  "$com`t$hex`t$($_.FriendlyName)"',
        "}"
      ].join(" ");
      const { stdout } = await execFileAsync4("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", script], {
        windowsHide: true,
        timeout: 8e3
      });
      for (const line of stdout.split(/\r?\n/).map((l) => l.trim()).filter(Boolean)) {
        const [com, hex, friendly] = line.split("	");
        if (!com) continue;
        const addr = (hex || "").match(/.{2}/g)?.join(":") ?? hex ?? "";
        const label = `${com} \xB7 ${friendly || addr}`;
        if (!out.some((d) => d.path === com)) out.push({ id: com, path: com, label, kind: "bluetooth" });
        const byMac = out.find((d) => d.path === addr);
        if (byMac && !byMac.label.includes(com)) byMac.label = `${byMac.label} \xB7 ${com}`;
      }
    } catch {
    }
  }
  if (process.platform === "linux") {
    try {
      const { stdout } = await execFileAsync4("bluetoothctl", ["devices"], { timeout: 8e3, windowsHide: true });
      for (const line of stdout.split(/\r?\n/)) {
        const m = line.match(/^Device\s+([0-9A-Fa-f:]{11,17})\s+(.*)$/);
        if (!m) continue;
        const addr = m[1].toUpperCase();
        const name = m[2].trim() || addr;
        out.push({ id: addr, path: addr, label: `${name} (${addr})`, kind: "bluetooth" });
      }
    } catch {
    }
  }
  const uniq = /* @__PURE__ */ new Map();
  for (const d of out) uniq.set(d.path, d);
  return Array.from(uniq.values()).sort((a, b) => a.label.localeCompare(b.label));
}
async function listUsb() {
  const list = await listSerialDevices();
  return list.map((d) => ({
    id: d.path,
    path: d.path,
    label: d.label || d.path,
    kind: "usb"
  }));
}
function lanOverlay(list) {
  const lan = icomLanStatus();
  return list.map((r) => {
    if (!isIcomLan(r)) return r;
    if (lan.connected && lan.radioId === r.id) {
      return { ...r, connected: true, error: "", ...lan.civAddr ? { civAddr: lan.civAddr } : {} };
    }
    if (lan.connected && lan.radioId && lan.radioId !== r.id) {
      return { ...r, connected: false };
    }
    if (!lan.connected && r.connected && !icomLanLive()) {
      return { ...r, connected: false };
    }
    return r;
  });
}
function radiosSnapshotFast() {
  return { ok: true, folder: dataDir3(), radios: publicList(lanOverlay(radios)) };
}
async function radiosStatus() {
  let usb = [];
  let bluetooth = [];
  try {
    usb = await listUsb();
  } catch {
    usb = [];
  }
  try {
    bluetooth = await listBluetooth();
  } catch {
    bluetooth = [];
  }
  return { ok: true, folder: dataDir3(), radios: publicList(lanOverlay(radios)), usb, bluetooth };
}
async function radiosSave(body) {
  if (Array.isArray(body.radios)) {
    radios = body.radios.map((r) => sanitize(r));
    normalizePrimary();
    persist2();
  }
  return radiosStatus();
}
async function radiosUpsert(raw) {
  const beforeSig = serialHamlibSig(radios);
  const next = sanitize(raw, radios.find((r) => r.id === raw.id));
  if (next.primary) radios = radios.map((r) => ({ ...r, primary: r.id === next.id }));
  else if (!radios.some((r) => r.primary && r.id !== next.id)) next.primary = radios.length === 0 || radios.every((r) => r.id === next.id);
  const idx = radios.findIndex((r) => r.id === next.id);
  if (idx >= 0) radios[idx] = { ...radios[idx], ...next, id: radios[idx].id };
  else radios.push(next);
  normalizePrimary();
  persist2();
  if (serialHamlibSig(radios) !== beforeSig) pokeSerialHamlib();
  return radiosStatus();
}
async function radiosSetPrimary(id) {
  if (!id || !radios.some((r) => r.id === id)) return radiosStatus();
  const beforeSig = serialHamlibSig(radios);
  radios = radios.map((r) => ({ ...r, primary: r.id === id }));
  persist2();
  if (serialHamlibSig(radios) !== beforeSig) pokeSerialHamlib();
  return radiosStatus();
}
function findRadio(id) {
  return radios.find((r) => r.id === id);
}
async function radiosRemove(id) {
  const beforeSig = serialHamlibSig(radios);
  const row = findRadio(id);
  radios = radios.map((r) => r.id === id ? { ...r, connected: false } : r).filter((r) => r.id !== id);
  normalizePrimary();
  persist2();
  if (serialHamlibSig(radios) !== beforeSig) pokeSerialHamlib();
  if (row && (isIcomLan(row) || icomLanStatus().radioId === id)) {
    try {
      await icomLanDisconnect();
    } catch {
    }
  }
  return radiosSnapshotFast();
}
async function radiosConnect(raw) {
  const beforeSig = serialHamlibSig(radios);
  const next = sanitize(raw, radios.find((r) => r.id === raw.id));
  next.error = "";
  const ble = next.link === "bluetooth" && next.maker === "icom" && next.proto === "civ";
  if (next.link === "network") {
    if (!next.host) {
      next.connected = false;
      next.error = "Informe o IP ou hostname do r\xE1dio / proxy CAT";
    } else if (!next.port || !/^\d{1,5}$/.test(next.port) || Number(next.port) < 1 || Number(next.port) > 65535) {
      next.connected = false;
      next.error = "Informe a porta de rede (1\u201365535)";
    } else if (isIcomLan(next) && !next.netUser) {
      next.connected = false;
      next.error = "Informe o Network User do Icom LAN";
    } else if (isIcomLan(next)) {
      next.device = next.host;
      next.deviceName = next.deviceName || `${next.host}:${next.port}`;
      const lan = await icomLanConnect({
        radioId: next.id,
        host: next.host,
        controlPort: Number(next.port) || 50001,
        userName: next.netUser || "",
        password: next.netPassword || "",
        civAddr: next.civAddr,
        hamlibModel: hamlibModelFor(next),
        equipmentId: next.equipmentId,
        deviceName: next.deviceName || next.name
      });
      if (lan.connected) {
        next.connected = true;
        next.error = "";
        if (lan.civAddr) next.civAddr = lan.civAddr;
        if (lan.deviceName) next.deviceName = lan.deviceName;
        radios = radios.map((r) => r.id === next.id ? r : { ...r, connected: false });
      } else {
        next.connected = false;
        next.error = lan.error || (lan.phase === "idle" ? "Conex\xE3o Icom LAN cancelada" : `Falha Icom LAN (${next.host}:${next.port || 50001}). Confira IP, Network User, senha e Network Control`);
      }
    } else {
      next.device = next.host;
      next.deviceName = next.deviceName || `${next.host}:${next.port}`;
      next.connected = true;
      next.error = "";
    }
    const idx2 = radios.findIndex((r) => r.id === next.id);
    if (idx2 >= 0) radios[idx2] = next;
    else radios.push(next);
    persistAndPoke(beforeSig);
    const snap6 = await radiosStatus();
    if (next.error) {
      snap6.ok = false;
      snap6.error = next.error;
    }
    return snap6;
  }
  if (!next.device && !next.port && !ble) {
    next.connected = false;
    next.error = next.link === "usb" ? "Selecione uma conex\xE3o ser2net" : "Selecione o dispositivo Bluetooth";
    const idx2 = radios.findIndex((r) => r.id === next.id);
    if (idx2 >= 0) radios[idx2] = next;
    else radios.push(next);
    persistAndPoke(beforeSig);
    const snap6 = await radiosStatus();
    snap6.ok = false;
    snap6.error = next.error;
    return snap6;
  }
  if (ble) {
    next.connected = false;
    const idx2 = radios.findIndex((r) => r.id === next.id);
    if (idx2 >= 0) radios[idx2] = next;
    else radios.push(next);
    persistAndPoke(beforeSig);
    const snap6 = await radiosStatus();
    snap6.needBle = true;
    snap6.bleAddr = next.civAddr;
    return snap6;
  }
  if (next.link === "usb") {
    const cfg = await loadSer2net();
    const svc = cfg.services.find((x) => x.id === next.device) || cfg.services.find((x) => `${ser2netDialHost(cfg.bind)}:${x.tcpPort}` === next.port) || cfg.services.find((x) => `${cfg.bind}:${x.tcpPort}` === next.port) || cfg.services.find((x) => x.device === SER2NET_RADIO_ID);
    const taken = Boolean(svc?.device && svc.device !== SER2NET_RADIO_ID);
    if (!svc || taken) {
      next.error = "Selecione uma conex\xE3o ser2net (IP/porta/serial) j\xE1 cadastrada";
      next.connected = false;
    } else {
      next.device = svc.id;
      next.deviceName = svc.name || next.deviceName;
      next.port = `${ser2netDialHost(cfg.bind)}:${svc.tcpPort}`;
      next.baud = svc.baud;
      next.connected = true;
      radios = radios.map((r) => r.id === next.id ? r : { ...r, connected: r.link === "usb" ? false : r.connected });
      if (svc.device !== SER2NET_RADIO_ID) {
        await saveSer2net({
          bind: cfg.bind,
          folder: cfg.folder,
          services: cfg.services.map((x) => ({
            ...x,
            device: x.id === svc.id ? SER2NET_RADIO_ID : x.device === SER2NET_RADIO_ID ? "" : x.device
          }))
        });
      }
    }
  } else {
    next.connected = true;
  }
  const idx = radios.findIndex((r) => r.id === next.id);
  if (idx >= 0) radios[idx] = next;
  else radios.push(next);
  persistAndPoke(beforeSig);
  const snap5 = await radiosStatus();
  if (next.error) {
    snap5.ok = false;
    snap5.error = next.error;
  }
  return snap5;
}
async function radiosDisconnect(id) {
  const row = findRadio(id);
  if (!row) return radiosSnapshotFast();
  row.connected = false;
  row.error = "";
  persist2();
  if (isIcomLan(row) || icomLanStatus().radioId === id) {
    try {
      await icomLanDisconnect();
    } catch {
    }
  }
  if (row.link === "usb") {
    try {
      const cfg = await loadSer2net();
      const hit = cfg.services.find((x) => x.id === row.device || x.device === SER2NET_RADIO_ID);
      if (hit?.device === SER2NET_RADIO_ID) {
        await saveSer2net({
          bind: cfg.bind,
          folder: cfg.folder,
          services: cfg.services.map((x) => ({
            ...x,
            device: x.device === SER2NET_RADIO_ID ? "" : x.device
          }))
        });
      }
    } catch {
    }
  }
  return radiosSnapshotFast();
}
async function radiosResumeIcomLan() {
  const row = radios.find((r) => r.primary && isIcomLan(r)) || radios.find((r) => r.connected && isIcomLan(r));
  if (!row?.host || !row.netUser) return;
  const lan = await icomLanConnect({
    radioId: row.id,
    host: row.host,
    controlPort: Number(row.port) || 50001,
    userName: row.netUser,
    password: row.netPassword || "",
    civAddr: row.civAddr,
    hamlibModel: hamlibModelFor(row),
    equipmentId: row.equipmentId,
    deviceName: row.deviceName || row.name
  });
  const idx = radios.findIndex((r) => r.id === row.id);
  if (idx < 0) return;
  if (lan.connected) {
    radios[idx] = {
      ...radios[idx],
      connected: true,
      error: "",
      ...lan.civAddr ? { civAddr: lan.civAddr } : {},
      ...lan.deviceName ? { deviceName: lan.deviceName } : {}
    };
  } else {
    radios[idx] = { ...radios[idx], connected: false, error: lan.error || "Icom LAN offline no boot" };
  }
  persist2();
}
async function radiosMarkBle(id, connected, name, error3) {
  const row = findRadio(id);
  if (row) {
    row.connected = connected;
    if (name) row.deviceName = name;
    row.error = error3 || "";
    persist2();
  }
  return radiosStatus();
}
var execFileAsync4, ROOT3, OPT_DIR3, LEGACY_DIR, BAUDS2, MAKERS, beforeHamlibRestart, CIV_MODEL_NAMES, radios;
var init_radios = __esm({
  "server/radios.ts"() {
    "use strict";
    init_const();
    init_equipment();
    init_icom_lan();
    init_list_serials();
    init_ser2net_store();
    execFileAsync4 = promisify4(execFile4);
    ROOT3 = join4(dirname3(fileURLToPath3(import.meta.url)), "..");
    OPT_DIR3 = "/opt/ham-cockpit/radios";
    LEGACY_DIR = "/opt/radios";
    BAUDS2 = /* @__PURE__ */ new Set([1200, 4800, 9600, 19200, 38400, 57600, 115200, 230400]);
    MAKERS = [...EQUIPMENT_MAKERS];
    beforeHamlibRestart = null;
    CIV_MODEL_NAMES = {
      "0x94": "IC-7300",
      "0x88": "IC-7100",
      "0x98": "IC-7610",
      "0xA2": "IC-9700"
    };
    radios = [];
    load();
  }
});

// server/ldg.ts
var ldg_exports = {};
__export(ldg_exports, {
  LDG_MODELS: () => LDG_MODELS,
  ldgCmd: () => ldgCmd,
  ldgConnect: () => ldgConnect,
  ldgDisconnect: () => ldgDisconnect,
  ldgPeek: () => ldgPeek,
  ldgSave: () => ldgSave,
  ldgStatus: () => ldgStatus
});
import { existsSync as existsSync4, mkdirSync as mkdirSync4, readFileSync as readFileSync4, renameSync as renameSync4, writeFileSync as writeFileSync4 } from "node:fs";
import net2 from "node:net";
import { dirname as dirname4, join as join5 } from "node:path";
import { fileURLToPath as fileURLToPath4 } from "node:url";
function dataDir4() {
  if (existsSync4("/opt/ham-cockpit")) {
    mkdirSync4(OPT_DIR4, { recursive: true });
    return OPT_DIR4;
  }
  const local = join5(ROOT4, "data", "ldg");
  mkdirSync4(local, { recursive: true });
  return local;
}
function jsonPath3() {
  return join5(dataDir4(), "ldg.json");
}
function writeAtomic4(file, body) {
  const tmp = `${file}.${process.pid}.tmp`;
  writeFileSync4(tmp, body, { encoding: "utf8" });
  renameSync4(tmp, file);
}
function asModel(v) {
  return LDG_MODELS.includes(v) ? v : "at1000pro2";
}
function loadSaved2() {
  try {
    const raw = JSON.parse(readFileSync4(jsonPath3(), "utf8"));
    return {
      model: asModel(raw.model),
      port: String(raw.port || ""),
      autoConnect: raw.autoConnect !== false
    };
  } catch {
    return { model: "at1000pro2", port: "", autoConnect: true };
  }
}
function persist3() {
  writeAtomic4(jsonPath3(), `${JSON.stringify({ model: saved2.model, port: saved2.port, autoConnect: saved2.autoConnect }, null, 2)}
`);
}
function swrOf(fwd, ref) {
  if (fwd <= 0.2) return 1;
  const rho = Math.sqrt(Math.max(0, Math.min(0.98, ref / fwd)));
  return (1 + rho) / (1 - rho);
}
function watts(raw, maxW) {
  if (!Number.isFinite(raw) || raw <= 0) return 0;
  if (raw <= maxW * 1.25) return raw;
  return raw / 65535 * maxW;
}
async function resolveEndpoint2() {
  const cfg = await loadSer2net();
  const svc = cfg.services.find((x) => x.device === "ldg");
  if (!svc) return null;
  return { host: ser2netDialHost(cfg.bind), port: svc.tcpPort };
}
function tcpSession(host2, port, send, timeoutMs) {
  return new Promise((resolve) => {
    const sock3 = new net2.Socket();
    const chunks2 = [];
    let settled = false;
    const finish2 = (ok, error3) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      sock3.destroy();
      resolve({ ok, buf: Buffer.concat(chunks2), error: error3 });
    };
    const timer = setTimeout(() => finish2(true), timeoutMs);
    sock3.once("error", (err) => finish2(false, err.message));
    sock3.on("data", (d) => chunks2.push(d));
    sock3.connect(port, host2, () => {
      if (send?.length) sock3.write(send);
    });
  });
}
async function trx(cmdByte, timeoutMs) {
  const ep = await resolveEndpoint2();
  if (!ep) return { ok: false, rx: "", buf: Buffer.alloc(0), error: "noport" };
  live2.port = `${ep.host}:${ep.port}`;
  const send = cmdByte ? Buffer.from(` ${cmdByte}`, "ascii") : null;
  const r = await tcpSession(ep.host, ep.port, send, timeoutMs);
  const sim = !r.ok && /ECONNREFUSED|ENOTFOUND|EHOSTUNREACH|connect /i.test(r.error || "");
  return {
    ok: r.ok,
    rx: r.buf.toString("latin1"),
    buf: r.buf,
    error: sim ? "sim" : r.error
  };
}
function enqueue2(fn) {
  const run6 = chain2.then(fn, fn);
  chain2 = run6.then(
    () => void 0,
    () => void 0
  );
  return run6;
}
function snap3() {
  const meta = META[live2.model];
  return {
    ok: true,
    ...live2,
    serialOk: meta.serial,
    maxW: meta.maxW,
    label: meta.label,
    folder: dataDir4(),
    baud: 38400
  };
}
function applyLocal(cmd) {
  if (cmd === "ant") live2.ant = live2.ant === 1 ? 2 : 1;
  if (cmd === "bypass") {
    live2.mode = "BYPASS";
    live2.match = "";
  }
  if (cmd === "auto") {
    live2.mode = "AUTO";
  }
  if (cmd === "manual") {
    live2.mode = "MANUAL";
  }
  if (cmd === "mem" || cmd === "full") {
    live2.tuning = true;
    live2.mode = "AUTO";
    live2.match = "";
    live2.phase = "tuning";
    if (tuneTimer) clearTimeout(tuneTimer);
    tuneTimer = setTimeout(() => {
      live2.tuning = false;
      live2.match = "T";
      live2.phase = live2.connected ? "ready" : "idle";
      live2.lastRx = "T";
    }, 1200);
  }
}
function parseReply(cmd, rx3) {
  const t = rx3.replace(/\s+/g, "");
  live2.lastRx = t.slice(-24);
  if (cmd === "ant") {
    if (t.includes("2")) live2.ant = 2;
    else if (t.includes("1")) live2.ant = 1;
  }
  if (cmd === "bypass" && t.includes("P")) live2.mode = "BYPASS";
  if (cmd === "auto" && t.includes("A")) live2.mode = "AUTO";
  if (cmd === "manual" && /M/.test(t)) live2.mode = "MANUAL";
  if (cmd === "mem" || cmd === "full") {
    live2.tuning = false;
    live2.phase = "ready";
    if (t.includes("F") && !t.endsWith("T")) live2.match = t.includes("T") ? "T" : "F";
    const last = t.replace(/[^TMF]/g, "").slice(-1);
    if (last === "T" || last === "M" || last === "F") live2.match = last;
    if (live2.match && live2.match !== "F") live2.mode = "AUTO";
  }
  if (cmd === "sync" && t.includes(SYNC_MARK)) {
    live2.hardware = true;
    live2.phase = "ready";
    live2.error = "";
  }
}
function parseFramesBuf(buf) {
  const maxW = META[live2.model].maxW;
  for (let i = 0; i + 8 <= buf.length; i++) {
    if (buf[i + 6] !== 59 || buf[i + 7] !== 59) continue;
    const fwd = watts(buf.readUInt16BE(i), maxW);
    const ref = watts(buf.readUInt16BE(i + 2), maxW);
    live2.fwd = Math.round(fwd * 10) / 10;
    live2.ref = Math.round(ref * 10) / 10;
    live2.swr = Math.round(swrOf(live2.fwd, live2.ref) * 100) / 100;
  }
}
function parseFrames(hexOrAscii) {
  const buf = Buffer.from(hexOrAscii, /[^0-9a-fA-F]/.test(hexOrAscii) ? "latin1" : "hex");
  parseFramesBuf(buf);
}
function ldgStatus() {
  return snap3();
}
async function ldgSave(body) {
  if (typeof body.model === "string") saved2.model = asModel(body.model);
  if (typeof body.autoConnect === "boolean") saved2.autoConnect = body.autoConnect;
  persist3();
  live2.model = saved2.model;
  live2.autoConnect = saved2.autoConnect;
  return snap3();
}
async function ldgConnect(body = {}) {
  return enqueue2(async () => {
    if (typeof body.model === "string") saved2.model = asModel(body.model);
    persist3();
    live2.model = saved2.model;
    live2.autoConnect = saved2.autoConnect;
    live2.error = "";
    live2.phase = "connecting";
    const meta = META[live2.model];
    if (!meta.serial) {
      live2.connected = true;
      live2.hardware = false;
      live2.phase = "ready";
      live2.error = "noserial";
      return snap3();
    }
    const r = await trx("Z", 2e3);
    if (live2.port) {
      saved2.port = live2.port;
      persist3();
    }
    if (r.error === "noport") {
      live2.connected = false;
      live2.hardware = false;
      live2.phase = "error";
      live2.error = "noport";
      return snap3();
    }
    if (r.ok && r.rx.includes(SYNC_MARK)) {
      live2.connected = true;
      live2.hardware = true;
      live2.phase = "ready";
      live2.lastRx = r.rx;
      return snap3();
    }
    live2.connected = true;
    live2.hardware = false;
    live2.phase = "ready";
    live2.error = r.error === "sim" || !r.ok ? r.error || "sim" : "sync";
    live2.lastRx = r.rx;
    return snap3();
  });
}
async function ldgDisconnect() {
  live2.connected = false;
  live2.hardware = false;
  live2.tuning = false;
  live2.phase = "idle";
  live2.error = "";
  live2.fwd = 0;
  live2.ref = 0;
  live2.swr = 1;
  return snap3();
}
async function ldgCmd(cmd) {
  const c = cmd;
  if (!CMD_BYTE2[c]) {
    live2.error = "cmd";
    return snap3();
  }
  return enqueue2(async () => {
    applyLocal(c);
    if (!live2.connected) live2.connected = true;
    if (!live2.hardware || !META[live2.model].serial) return snap3();
    const timeout = c === "mem" || c === "full" ? 16e3 : 2500;
    if (c === "mem" || c === "full") {
      live2.tuning = true;
      live2.phase = "tuning";
    }
    const r = await trx(CMD_BYTE2[c], timeout);
    if (r.ok && r.rx) parseReply(c, r.rx);
    else if (!r.ok && r.error && r.error !== "sim" && r.error !== "noport") live2.error = r.error;
    if (r.buf.length) parseFramesBuf(r.buf);
    return snap3();
  });
}
async function ldgPeek() {
  if (!live2.connected || !live2.hardware) return snap3();
  const r = await trx(null, 400);
  if (r.ok && r.buf.length) parseFramesBuf(r.buf);
  else if (r.ok && r.rx) parseFrames(r.rx);
  return snap3();
}
var ROOT4, OPT_DIR4, SYNC_MARK, LDG_MODELS, META, CMD_BYTE2, saved2, live2, chain2, tuneTimer;
var init_ldg = __esm({
  "server/ldg.ts"() {
    "use strict";
    init_ser2net_store();
    ROOT4 = join5(dirname4(fileURLToPath4(import.meta.url)), "..");
    OPT_DIR4 = "/opt/ham-cockpit/ldg";
    SYNC_MARK = "AzAz";
    LDG_MODELS = ["at100pro2", "at600pro2", "at1000pro2"];
    META = {
      at100pro2: { label: "AT-100ProII", maxW: 125, serial: false },
      at600pro2: { label: "AT-600ProII", maxW: 600, serial: true },
      at1000pro2: { label: "AT-1000ProII", maxW: 1e3, serial: true }
    };
    CMD_BYTE2 = {
      mem: "T",
      full: "F",
      bypass: "P",
      auto: "C",
      manual: "M",
      ant: "A",
      sync: "Z"
    };
    saved2 = loadSaved2();
    live2 = {
      model: saved2.model,
      port: saved2.port,
      baud: 38400,
      autoConnect: saved2.autoConnect,
      connected: false,
      hardware: false,
      phase: "idle",
      error: "",
      ant: 1,
      mode: "AUTO",
      match: "",
      tuning: false,
      fwd: 0,
      ref: 0,
      swr: 1,
      lastRx: ""
    };
    chain2 = Promise.resolve();
    tuneTimer = null;
  }
});

// server/lp100a.ts
var lp100a_exports = {};
__export(lp100a_exports, {
  lp100aAlarmSwr: () => lp100aAlarmSwr,
  lp100aCmd: () => lp100aCmd,
  lp100aConnect: () => lp100aConnect,
  lp100aDisconnect: () => lp100aDisconnect,
  lp100aPeek: () => lp100aPeek,
  lp100aSave: () => lp100aSave,
  lp100aStatus: () => lp100aStatus
});
import { existsSync as existsSync5, mkdirSync as mkdirSync5, readFileSync as readFileSync5, renameSync as renameSync5, writeFileSync as writeFileSync5 } from "node:fs";
import net3 from "node:net";
import { dirname as dirname5, join as join6 } from "node:path";
import { fileURLToPath as fileURLToPath5 } from "node:url";
function dataDir5() {
  if (existsSync5("/opt/ham-cockpit")) {
    mkdirSync5(OPT_DIR5, { recursive: true });
    return OPT_DIR5;
  }
  const local = join6(ROOT5, "data", "lp100a");
  mkdirSync5(local, { recursive: true });
  return local;
}
function jsonPath4() {
  return join6(dataDir5(), "lp100a.json");
}
function writeAtomic5(file, body) {
  const tmp = `${file}.${process.pid}.tmp`;
  writeFileSync5(tmp, body, { encoding: "utf8" });
  renameSync5(tmp, file);
}
function loadSaved3() {
  try {
    const raw = JSON.parse(readFileSync5(jsonPath4(), "utf8"));
    return { autoConnect: raw.autoConnect !== false };
  } catch {
    return { autoConnect: true };
  }
}
function persist4() {
  writeAtomic5(jsonPath4(), `${JSON.stringify({ autoConnect: saved3.autoConnect }, null, 2)}
`);
}
function reflected(fwd, swr) {
  if (!(fwd > 0) || !(swr > 1)) return 0;
  const rho = (swr - 1) / (swr + 1);
  return fwd * rho * rho;
}
function dbmOf(watts2) {
  if (!(watts2 > 0)) return -99;
  return 10 * Math.log10(watts2 * 1e3);
}
async function resolveEndpoint3() {
  const cfg = await loadSer2net();
  const svc = cfg.services.find((x) => x.device === "lp100a");
  if (!svc) return null;
  return { host: ser2netDialHost(cfg.bind), port: svc.tcpPort };
}
function asMeter(n) {
  if (n === 1) return "PEAK";
  if (n === 2) return "TUNE";
  return "AVG";
}
function asRange(n) {
  if (n === 1) return "MID";
  if (n === 2) return "LOW";
  return "HIGH";
}
function parseFrame(raw) {
  const line = raw.replace(/[\r\n]+/g, "").trim();
  if (!line.startsWith(";")) return false;
  const parts = line.slice(1).split(",").map((p) => p.trim());
  if (parts.length < 7) return false;
  const fwd = Number(parts[0]);
  const z = Number(parts[1]);
  const phaseDeg = Number(parts[2]);
  const alarm = Math.trunc(Number(parts[3]));
  const callsign = (parts[4] || "").replace(/\s+$/g, "");
  const rangeN = Math.trunc(Number(parts[5]));
  const meterN = Math.trunc(Number(parts[6]));
  const dbm = parts.length >= 8 ? Number(parts[7]) : dbmOf(fwd);
  const swr = parts.length >= 9 ? Number(parts[8]) : 1;
  if (!Number.isFinite(fwd)) return false;
  live3.fwd = Math.round(fwd * 100) / 100;
  live3.z = Number.isFinite(z) ? Math.round(z * 10) / 10 : 0;
  live3.phaseDeg = Number.isFinite(phaseDeg) ? Math.round(phaseDeg * 10) / 10 : 0;
  live3.alarm = alarm >= 0 && alarm <= 5 ? alarm : 0;
  live3.callsign = callsign.slice(0, 12);
  live3.range = asRange(rangeN);
  live3.meter = asMeter(meterN);
  live3.dbm = Number.isFinite(dbm) ? Math.round(dbm * 10) / 10 : dbmOf(fwd);
  live3.swr = Number.isFinite(swr) && swr > 0 ? Math.round(swr * 100) / 100 : 1;
  live3.ref = Math.round(reflected(live3.fwd, live3.swr) * 100) / 100;
  live3.tx = live3.fwd > 0.2;
  live3.lastRx = line.slice(0, 64);
  live3.hardware = true;
  live3.phase = "ready";
  live3.error = "";
  return true;
}
function consumeRx2() {
  for (; ; ) {
    const start = rx2.indexOf(";");
    if (start < 0) {
      if (rx2.length > 96) rx2 = rx2.slice(-24);
      return;
    }
    if (start > 0) rx2 = rx2.slice(start);
    const next = rx2.indexOf(";", 1);
    const chunk = next >= 0 ? rx2.slice(0, next) : rx2;
    const commas = (chunk.match(/,/g) || []).length;
    if (commas < 6) {
      if (next >= 0) {
        rx2 = rx2.slice(next);
        continue;
      }
      if (chunk.length > 96) rx2 = "";
      return;
    }
    if (next < 0 && commas < 8 && chunk.length < 52) return;
    parseFrame(chunk);
    if (next < 0) {
      rx2 = "";
      return;
    }
    rx2 = rx2.slice(next);
  }
}
function enqueue3(fn) {
  const run6 = chain3.then(fn, fn);
  chain3 = run6.then(
    () => void 0,
    () => void 0
  );
  return run6;
}
function snap4() {
  return { ok: true, ...live3, baud: BAUD2, folder: dataDir5() };
}
function stopPoll2() {
  if (pollTimer2) {
    clearInterval(pollTimer2);
    pollTimer2 = null;
  }
}
function dropSock2() {
  stopPoll2();
  rx2 = "";
  const s = sock2;
  sock2 = null;
  if (!s) return;
  try {
    s.removeAllListeners();
    s.destroy();
  } catch {
  }
}
function writeCmd(ch) {
  if (!sock2 || sock2.destroyed) return false;
  try {
    sock2.write(ch, "ascii");
    return true;
  } catch {
    return false;
  }
}
function startPoll2() {
  stopPoll2();
  const tick = () => {
    if (!sock2 || sock2.destroyed) return;
    writeCmd("P");
  };
  tick();
  pollTimer2 = setInterval(tick, POLL_MS2);
  pollTimer2.unref?.();
}
function attachSock2(s, host2, port) {
  dropSock2();
  sock2 = s;
  rx2 = "";
  live3.port = `${host2}:${port}`;
  live3.connected = true;
  live3.hardware = false;
  live3.phase = "ready";
  live3.error = "";
  s.setNoDelay(true);
  s.on("data", (buf) => {
    rx2 += buf.toString("latin1");
    consumeRx2();
  });
  s.on("error", (err) => {
    live3.error = err.message;
    live3.phase = "error";
    live3.hardware = false;
    live3.connected = false;
    dropSock2();
  });
  s.on("close", () => {
    if (sock2 !== s) return;
    sock2 = null;
    stopPoll2();
    live3.connected = false;
    live3.hardware = false;
    if (live3.phase !== "idle") live3.phase = "error";
  });
  startPoll2();
}
function lp100aStatus() {
  return snap4();
}
function lp100aAlarmSwr(idx) {
  return ALARM_SWR[idx] ?? 0;
}
async function lp100aSave(body) {
  if (typeof body.autoConnect === "boolean") saved3.autoConnect = body.autoConnect;
  persist4();
  live3.autoConnect = saved3.autoConnect;
  return snap4();
}
async function lp100aConnect() {
  return enqueue3(async () => {
    live3.error = "";
    live3.phase = "connecting";
    live3.autoConnect = saved3.autoConnect;
    const ep = await resolveEndpoint3();
    if (!ep) {
      live3.connected = false;
      live3.hardware = false;
      live3.phase = "error";
      live3.error = "noport";
      return snap4();
    }
    live3.port = `${ep.host}:${ep.port}`;
    return await new Promise((resolve) => {
      const s = new net3.Socket();
      let settled = false;
      const finish2 = (ok, error3) => {
        if (settled) return;
        settled = true;
        if (!ok) {
          try {
            s.destroy();
          } catch {
          }
          const sim = /ECONNREFUSED|ENOTFOUND|EHOSTUNREACH|connect /i.test(error3 || "");
          live3.connected = true;
          live3.hardware = false;
          live3.phase = "ready";
          live3.error = sim ? "sim" : error3 || "sim";
          resolve(snap4());
          return;
        }
        attachSock2(s, ep.host, ep.port);
        resolve(snap4());
      };
      const timer = setTimeout(() => finish2(false, "timeout"), 2500);
      s.once("error", (err) => {
        clearTimeout(timer);
        finish2(false, err.message);
      });
      s.connect(ep.port, ep.host, () => {
        clearTimeout(timer);
        finish2(true);
      });
    });
  });
}
async function lp100aDisconnect() {
  dropSock2();
  live3.connected = false;
  live3.hardware = false;
  live3.phase = "idle";
  live3.error = "";
  live3.fwd = 0;
  live3.ref = 0;
  live3.swr = 1;
  live3.tx = false;
  live3.dbm = -99;
  return snap4();
}
async function lp100aCmd(cmd) {
  const c = cmd;
  if (!CMD_BYTE3[c]) {
    live3.error = "cmd";
    return snap4();
  }
  return enqueue3(async () => {
    if (!live3.connected) live3.connected = true;
    if (c === "alarm") live3.alarm = live3.alarm >= 5 ? 0 : live3.alarm + 1;
    if (c === "meter") live3.meter = live3.meter === "AVG" ? "PEAK" : live3.meter === "PEAK" ? "TUNE" : "AVG";
    if (!live3.hardware || !sock2) return snap4();
    writeCmd(CMD_BYTE3[c]);
    return snap4();
  });
}
async function lp100aPeek() {
  return snap4();
}
var ROOT5, OPT_DIR5, POLL_MS2, BAUD2, ALARM_SWR, CMD_BYTE3, saved3, live3, sock2, rx2, pollTimer2, chain3;
var init_lp100a = __esm({
  "server/lp100a.ts"() {
    "use strict";
    init_ser2net_store();
    ROOT5 = join6(dirname5(fileURLToPath5(import.meta.url)), "..");
    OPT_DIR5 = "/opt/ham-cockpit/lp100a";
    POLL_MS2 = 200;
    BAUD2 = 115200;
    ALARM_SWR = [0, 1.5, 2, 2.5, 3, 0];
    CMD_BYTE3 = { alarm: "A", meter: "F" };
    saved3 = loadSaved3();
    live3 = {
      port: "",
      autoConnect: saved3.autoConnect,
      connected: false,
      hardware: false,
      phase: "idle",
      error: "",
      fwd: 0,
      ref: 0,
      swr: 1,
      z: 0,
      phaseDeg: 0,
      dbm: -99,
      alarm: 0,
      callsign: "",
      range: "HIGH",
      meter: "AVG",
      tx: false,
      lastRx: ""
    };
    sock2 = null;
    rx2 = "";
    pollTimer2 = null;
    chain3 = Promise.resolve();
  }
});

// server/services.ts
var services_exports = {};
__export(services_exports, {
  apDhcpIsUp: () => apDhcpIsUp,
  isServiceAutostart: () => isServiceAutostart,
  serviceLinuxRunning: () => serviceLinuxRunning,
  servicesApplyBoot: () => servicesApplyBoot,
  servicesPower: () => servicesPower,
  servicesSetAutostart: () => servicesSetAutostart,
  servicesStatus: () => servicesStatus,
  tcpListenPorts: () => tcpListenPorts
});
import { execFile as execFile5 } from "node:child_process";
import { existsSync as existsSync6, mkdirSync as mkdirSync6, readFileSync as readFileSync6, renameSync as renameSync6, writeFileSync as writeFileSync6 } from "node:fs";
import { dirname as dirname6, join as join7 } from "node:path";
import { fileURLToPath as fileURLToPath6 } from "node:url";
import { promisify as promisify5 } from "node:util";
function serviceLinuxRunning(id, facts) {
  if (SER2NET_PORT_IDS.has(id)) {
    if (facts.states.ser2net !== "active") return false;
    const port = facts.ports[id];
    if (!port) return false;
    if (facts.listen && !facts.listen.has(port)) return false;
    return true;
  }
  if (id === "dhcp") {
    const ap = facts.states.wifi || "";
    if (ap === "active") return true;
    if (ap === "inactive" || ap === "failed" || ap === "") return false;
    return ap === "activating" && facts.apDhcpUp;
  }
  if (id === "web") return facts.states.web === "active" && facts.nginx === "active";
  if (id === "lextel") return false;
  if (!UNITS[id]) return false;
  return facts.states[id] === "active";
}
function tcpListenPorts(text) {
  const ports = /* @__PURE__ */ new Set();
  for (const line of text.split(/\r?\n/)) {
    const parts = line.trim().split(/\s+/);
    if (parts.length < 4 || !parts[0]?.endsWith(":")) continue;
    if (parts[3] !== "0A") continue;
    const port = Number.parseInt(parts[1]?.split(":")[1] || "", 16);
    if (Number.isInteger(port) && port > 0) ports.add(port);
  }
  return ports;
}
function apDhcpIsUp(text) {
  for (const line of text.split(/\r?\n/)) {
    const parts = line.trim().split(/\s+/);
    if (parts.length < 2 || !parts[0]?.endsWith(":")) continue;
    const [addr, hexPort] = (parts[1] || "").split(":");
    const port = Number.parseInt(hexPort || "", 16);
    if (port === 67) return true;
    if (port === 53 && (addr || "").toLowerCase() === AP_ADDR) return true;
  }
  return false;
}
function dataDir6() {
  if (existsSync6("/opt/ham-cockpit")) {
    mkdirSync6(OPT_DIR6, { recursive: true });
    return OPT_DIR6;
  }
  const local = join7(ROOT6, "data", "services");
  mkdirSync6(local, { recursive: true });
  return local;
}
function jsonPath5() {
  return join7(dataDir6(), "boot.json");
}
function allOn() {
  return Object.fromEntries(SERVICE_IDS.map((id) => [id, true]));
}
function loadBoot() {
  const base2 = allOn();
  try {
    const raw = JSON.parse(readFileSync6(jsonPath5(), "utf8"));
    for (const id of SERVICE_IDS) {
      if (typeof raw[id] === "boolean") base2[id] = raw[id];
    }
  } catch {
  }
  return base2;
}
function persist5() {
  const tmp = `${jsonPath5()}.${process.pid}.tmp`;
  writeFileSync6(tmp, `${JSON.stringify(boot, null, 2)}
`, "utf8");
  renameSync6(tmp, jsonPath5());
}
function isServiceAutostart(id) {
  return boot[id] !== false;
}
function serialize(fn) {
  const run6 = heavyChain.then(fn, fn);
  heavyChain = run6.catch(() => void 0);
  return run6;
}
function helperTimeout(cmd, id) {
  if (cmd === "start" || cmd === "stop") {
    if (id === "wavelog" || id === "db") return 24e4;
    if (id === "mmdvm") return 12e4;
    return 4e4;
  }
  return 1e4;
}
async function helper(cmd, id) {
  if (!existsSync6(HELPER2)) return "";
  try {
    const { stdout } = await execFileAsync5("sudo", ["-n", HELPER2, cmd, id], {
      timeout: helperTimeout(cmd, id),
      windowsHide: true
    });
    if (cmd === "start" || cmd === "stop") stateCache = null;
    return String(stdout || "").trim();
  } catch {
    return "";
  }
}
async function unitStates(fresh = false) {
  if (!fresh && stateCache && Date.now() - stateCache.at < 2500) return stateCache.map;
  if (stateInflight) return stateInflight;
  stateInflight = (async () => {
    const map = {};
    if (existsSync6(HELPER2)) {
      try {
        const { stdout } = await execFileAsync5("sudo", ["-n", HELPER2, "is-active-all"], {
          timeout: 12e3,
          windowsHide: true
        });
        for (const line of String(stdout).split(/\r?\n/)) {
          const m = line.match(/^(\w+)=(\S+)/);
          if (m) map[m[1]] = m[2];
        }
      } catch {
      }
    }
    stateCache = { at: Date.now(), map };
    return map;
  })().finally(() => {
    stateInflight = null;
  });
  return stateInflight;
}
function readProc(file) {
  try {
    return readFileSync6(file, "utf8");
  } catch {
    return "";
  }
}
function readSer2netPorts() {
  const file = existsSync6("/opt/ser2net/services.json") ? "/opt/ser2net/services.json" : join7(ROOT6, "data", "ser2net", "services.json");
  try {
    const raw = JSON.parse(readFileSync6(file, "utf8"));
    const out = {};
    for (const row of raw.services || []) {
      const device = typeof row.device === "string" ? row.device : "";
      const port = Number(row.tcpPort);
      if (!SER2NET_PORT_IDS.has(device)) continue;
      if (!Number.isInteger(port) || port < 1 || port > 65535) continue;
      out[device] = port;
    }
    return out;
  } catch {
    return {};
  }
}
async function unitActiveState(unit) {
  try {
    const { stdout } = await execFileAsync5("systemctl", ["is-active", unit], {
      timeout: 4e3,
      windowsHide: true
    });
    return String(stdout || "").trim() || "inactive";
  } catch (err) {
    const stdout = err && typeof err === "object" && "stdout" in err ? String(err.stdout || "") : "";
    return stdout.trim() || "inactive";
  }
}
async function linuxFacts() {
  const states = await unitStates();
  const ports = readSer2netPorts();
  const listen = existsSync6("/proc/net/tcp") ? tcpListenPorts(`${readProc("/proc/net/tcp")}
${readProc("/proc/net/tcp6")}`) : null;
  const nginx = await unitActiveState("nginx.service");
  const apDhcpUp = existsSync6("/proc/net/udp") ? apDhcpIsUp(readProc("/proc/net/udp")) : false;
  return { states, ports, listen, nginx, apDhcpUp };
}
function emptyFacts() {
  return { states: {}, ports: {}, listen: null, nginx: "inactive", apDhcpUp: false };
}
async function servicesStatus() {
  const facts = process.platform === "linux" ? await linuxFacts() : emptyFacts();
  return {
    ok: true,
    folder: dataDir6(),
    items: SERVICE_IDS.map((id) => ({
      id,
      autostart: boot[id] !== false,
      running: serviceLinuxRunning(id, facts),
      unit: UNITS[id],
      power: POWER_IDS.has(id)
    })),
    error: ""
  };
}
async function servicesSetAutostart(id, autostart) {
  if (!SERVICE_IDS.includes(id)) {
    return { ...await servicesStatus(), ok: false, error: "servi\xE7o desconhecido" };
  }
  const sid = id;
  boot[sid] = Boolean(autostart);
  persist5();
  if (process.platform === "linux" && HELPER_IDS.has(sid)) {
    await helper(autostart ? "enable" : "disable", sid);
    if (sid !== "web") {
      await serialize(() => helper(autostart ? "start" : "stop", sid));
    }
  }
  if (sid === "spe") {
    if (process.platform === "linux" && existsSync6(HELPER2)) {
      await helper("stop", "spe");
      await helper("disable", "spe");
    }
    const m = await Promise.resolve().then(() => (init_spe(), spe_exports));
    await m.speSave({ autoConnect: autostart });
    if (autostart) await m.speConnect();
    else await m.speDisconnect();
  }
  if (sid === "radio" && autostart) {
    const { radiosResumeIcomLan: radiosResumeIcomLan2 } = await Promise.resolve().then(() => (init_radios(), radios_exports));
    void radiosResumeIcomLan2().catch(() => void 0);
  }
  if (sid === "radio" && !autostart) {
    const { radiosDisconnect: radiosDisconnect2, radiosStatus: radiosStatus2 } = await Promise.resolve().then(() => (init_radios(), radios_exports));
    const snap5 = await radiosStatus2();
    const primary = snap5.radios.find((r) => r.primary) || snap5.radios[0];
    if (primary?.connected) void radiosDisconnect2(primary.id).catch(() => void 0);
  }
  return servicesStatus();
}
async function servicesPower(id, on) {
  if (!SERVICE_IDS.includes(id) || !POWER_IDS.has(id)) {
    return { ...await servicesStatus(), ok: false, error: "servi\xE7o sem Ligar/Desligar" };
  }
  const sid = id;
  try {
    if (HELPER_IDS.has(sid)) {
      if (process.platform !== "linux" || !existsSync6(HELPER2)) {
        return { ...await servicesStatus(), ok: false, error: "dispon\xEDvel s\xF3 no Ubuntu da esta\xE7\xE3o" };
      }
      const out = await serialize(() => helper(on ? "start" : "stop", sid));
      if (!out) {
        const states = await unitStates(true);
        const now = states[sid] === "active";
        if (now !== on) {
          return { ...await servicesStatus(), ok: false, error: `falha ao ${on ? "ligar" : "desligar"} ${sid}` };
        }
      }
    } else if (sid === "radio") {
      if (on) {
        const { radiosResumeIcomLan: radiosResumeIcomLan2 } = await Promise.resolve().then(() => (init_radios(), radios_exports));
        await radiosResumeIcomLan2();
      } else {
        const { radiosDisconnect: radiosDisconnect2, radiosStatus: radiosStatus2 } = await Promise.resolve().then(() => (init_radios(), radios_exports));
        const snap5 = await radiosStatus2();
        const primary = snap5.radios.find((r) => r.primary) || snap5.radios[0];
        if (primary?.connected) await radiosDisconnect2(primary.id);
      }
    } else if (sid === "lextel") {
      const m = await Promise.resolve().then(() => (init_lextel(), lextel_exports));
      if (on) await m.lextelAutoConnect();
      else await m.lextelDisconnect();
    } else if (sid === "ldg") {
      const m = await Promise.resolve().then(() => (init_ldg(), ldg_exports));
      if (on) await m.ldgConnect();
      else await m.ldgDisconnect();
    } else if (sid === "lp100a") {
      const m = await Promise.resolve().then(() => (init_lp100a(), lp100a_exports));
      if (on) await m.lp100aConnect();
      else await m.lp100aDisconnect();
    } else if (sid === "spe") {
      const m = await Promise.resolve().then(() => (init_spe(), spe_exports));
      if (on) await m.speConnect();
      else await m.speDisconnect();
      return servicesStatus();
    }
  } catch (err) {
    return { ...await servicesStatus(), ok: false, error: err instanceof Error ? err.message : String(err) };
  }
  stateCache = null;
  return servicesStatus();
}
async function reconcileBoot(first) {
  if (process.platform !== "linux" || !existsSync6(HELPER2)) return;
  const states = await unitStates(true);
  for (const id of BOOT_UNIT_IDS) {
    const st = states[id] || "inactive";
    if (boot[id]) {
      if (first) await helper("enable", id);
      if (st === "inactive" || st === "failed") {
        await serialize(() => helper("start", id));
      }
    } else if (first && (st === "active" || st === "activating")) {
      await serialize(() => helper("stop", id));
    }
  }
  if (first && boot.wifi) await helper("enable", "wifi");
}
async function reconcileDevices() {
  if (boot.radio) {
    try {
      const { radiosResumeIcomLan: radiosResumeIcomLan2, radiosStatus: radiosStatus2 } = await Promise.resolve().then(() => (init_radios(), radios_exports));
      const snap5 = await radiosStatus2();
      const primary = snap5.radios.find((r) => r.primary);
      if (!primary?.connected) await radiosResumeIcomLan2();
    } catch {
    }
  }
  if (boot.lextel) {
    const { lextelAutoConnect: lextelAutoConnect2 } = await Promise.resolve().then(() => (init_lextel(), lextel_exports));
    void lextelAutoConnect2().catch(() => void 0);
  }
  if (boot.ldg) {
    const { ldgConnect: ldgConnect2, ldgStatus: ldgStatus2 } = await Promise.resolve().then(() => (init_ldg(), ldg_exports));
    const st = ldgStatus2();
    if (st.autoConnect && st.port && !st.connected) void ldgConnect2().catch(() => void 0);
  }
  if (boot.lp100a) {
    const { lp100aConnect: lp100aConnect2, lp100aStatus: lp100aStatus2 } = await Promise.resolve().then(() => (init_lp100a(), lp100a_exports));
    const st = lp100aStatus2();
    if (st.autoConnect && st.port && !st.connected) void lp100aConnect2().catch(() => void 0);
  }
  if (boot.spe) {
    const { speConnect: speConnect2, speStatus: speStatus2 } = await Promise.resolve().then(() => (init_spe(), spe_exports));
    const st = speStatus2();
    if (st.autoConnect && !st.connected) void speConnect2().catch(() => void 0);
  }
}
async function servicesApplyBoot() {
  if (bootTried) return;
  bootTried = true;
  persist5();
  const passes = [2e4, 7e4, 15e4];
  let elapsed = 0;
  passes.forEach((delay, i) => {
    elapsed += delay;
    setTimeout(() => {
      void (async () => {
        try {
          await reconcileBoot(i === 0);
          await reconcileDevices();
        } catch {
        }
      })();
    }, elapsed).unref?.();
  });
}
var execFileAsync5, ROOT6, OPT_DIR6, HELPER2, UNITS, HELPER_IDS, SER2NET_PORT_IDS, AP_ADDR, POWER_IDS, boot, bootTried, heavyChain, stateCache, stateInflight, BOOT_UNIT_IDS;
var init_services = __esm({
  "server/services.ts"() {
    "use strict";
    init_const();
    execFileAsync5 = promisify5(execFile5);
    ROOT6 = join7(dirname6(fileURLToPath6(import.meta.url)), "..");
    OPT_DIR6 = "/opt/ham-cockpit/services";
    HELPER2 = "/opt/ham-cockpit/bin/station-svc";
    UNITS = {
      ser2net: "ser2net.service",
      wavelog: "wavelog.service",
      db: "wavelog-db",
      wlg: "waveloggate.service",
      mmdvm: "mmdvmhost.service",
      radio: "ser2net.service",
      hamlib: "rigctld@ic705.service",
      spe: "ser2net.service",
      hamplus: "ser2net.service",
      palstar: "ser2net.service",
      ldg: "ser2net.service",
      lp100a: "ser2net.service",
      acom: "ser2net.service",
      lextel: "",
      wifi: "ham-cockpit-ap.service",
      bluetooth: "bluetooth.service",
      dhcp: "ham-cockpit-ap.service",
      web: "ham-cockpit.service"
    };
    HELPER_IDS = /* @__PURE__ */ new Set([
      "ser2net",
      "wavelog",
      "db",
      "wlg",
      "mmdvm",
      "hamlib",
      "wifi",
      "bluetooth",
      "web"
    ]);
    SER2NET_PORT_IDS = /* @__PURE__ */ new Set(["radio", "spe", "hamplus", "palstar", "ldg", "lp100a", "acom"]);
    AP_ADDR = "0104a8c0";
    POWER_IDS = /* @__PURE__ */ new Set([
      "ser2net",
      "wavelog",
      "db",
      "wlg",
      "mmdvm",
      "hamlib",
      "spe",
      "bluetooth",
      "radio",
      "lextel",
      "ldg",
      "lp100a"
    ]);
    boot = loadBoot();
    bootTried = false;
    heavyChain = Promise.resolve();
    stateCache = null;
    stateInflight = null;
    BOOT_UNIT_IDS = ["ser2net", "db", "wavelog", "wlg", "mmdvm", "hamlib", "bluetooth"];
  }
});

// server/lextel.ts
var lextel_exports = {};
__export(lextel_exports, {
  lextelAutoConnect: () => lextelAutoConnect,
  lextelConnect: () => lextelConnect,
  lextelDisconnect: () => lextelDisconnect,
  lextelKeepalive: () => lextelKeepalive,
  lextelLearn: () => lextelLearn,
  lextelOpenBluetooth: () => lextelOpenBluetooth,
  lextelSave: () => lextelSave,
  lextelScan: () => lextelScan,
  lextelStatus: () => lextelStatus
});
import { execFile as execFile6, spawn as spawn3 } from "node:child_process";
import {
  close,
  closeSync,
  constants as fsConstants,
  createReadStream,
  existsSync as existsSync7,
  mkdirSync as mkdirSync7,
  open as openFd,
  openSync,
  read,
  readFileSync as readFileSync7,
  readSync,
  renameSync as renameSync7,
  statSync,
  unlinkSync,
  writeFileSync as writeFileSync7
} from "node:fs";
import { dirname as dirname7, join as join8 } from "node:path";
import { fileURLToPath as fileURLToPath7 } from "node:url";
import { promisify as promisify6 } from "node:util";
function dataDir7() {
  if (existsSync7(OPT_DIR7)) return OPT_DIR7;
  const local = join8(ROOT7, "data", "lextel");
  mkdirSync7(local, { recursive: true });
  return local;
}
function jsonPath6() {
  return join8(dataDir7(), "config.json");
}
function capturePath() {
  return join8(dataDir7(), "capture.bin");
}
function winSppScript() {
  return join8(ROOT7, "deploy", "lextel", "win-spp.ps1");
}
function isRfcommPath(addr) {
  return /(?:^|\/)dev\/rfcomm\d+$/i.test(addr.trim().replace(/\\/g, "/"));
}
function normalizeSerialPath(addr) {
  const t = addr.trim().replace(/\\/g, "/");
  if (!t) return t;
  if (isRfcommPath(t) || /^\/DEV\//i.test(t)) {
    return t.replace(/^\/DEV\//i, "/dev/").replace(/RFCOMM(\d*)/gi, (_m, n) => `rfcomm${n}`);
  }
  if (/^\/dev\//i.test(t)) return `/dev/${t.slice(5)}`;
  return addr.trim();
}
function ensureCaptureReady() {
  mkdirSync7(dataDir7(), { recursive: true });
  const cap = capturePath();
  if (!existsSync7(cap)) writeFileSync7(cap, Buffer.alloc(0));
  return cap;
}
function loadSaved4() {
  const fallback = { addr: "", name: "", pin: "1234", channel: 1, autoConnect: true, layout: null };
  try {
    const raw = JSON.parse(readFileSync7(jsonPath6(), "utf8"));
    const addrRaw = typeof raw.addr === "string" ? raw.addr : "";
    const addr = normalizeSerialPath(addrRaw);
    return {
      addr: isRfcommPath(addr) ? "" : addr,
      name: typeof raw.name === "string" ? raw.name : "",
      pin: typeof raw.pin === "string" && raw.pin ? raw.pin : "1234",
      channel: Number(raw.channel) > 0 ? Number(raw.channel) : 1,
      autoConnect: raw.autoConnect !== false,
      layout: raw.layout && typeof raw.layout === "object" ? raw.layout : null
    };
  } catch {
    return fallback;
  }
}
function diskAddr() {
  try {
    const raw = JSON.parse(readFileSync7(jsonPath6(), "utf8"));
    return typeof raw.addr === "string" ? raw.addr.trim() : "";
  } catch {
    return "";
  }
}
function persist6(opts) {
  if (!opts?.allowEmpty && !saved4.addr.trim()) {
    const disk = diskAddr().toUpperCase();
    if (/^[0-9A-F]{2}(:[0-9A-F]{2}){5}$/.test(disk)) saved4.addr = disk;
  }
  const tmp = `${jsonPath6()}.${process.pid}.tmp`;
  writeFileSync7(tmp, JSON.stringify(saved4, null, 2), "utf8");
  renameSync7(tmp, jsonPath6());
}
function parsePairedMac(text, nameHint) {
  const hint = nameHint.trim().toLowerCase();
  const rows = [];
  for (const line of text.split(/\r?\n/)) {
    const m = /^DEV\s+([0-9A-Fa-f:]{17})\s+([01])\s+(.*)$/.exec(line.trim());
    if (!m) continue;
    const mac = m[1].toUpperCase();
    if (SKIP_SPP_MAC.has(mac.replace(/:/g, ""))) continue;
    rows.push({ mac, paired: m[2] === "1", name: (m[3] || "").trim() });
  }
  const paired = rows.filter((r) => r.paired);
  const pool = paired.length ? paired : rows;
  const byHint = hint ? pool.find((r) => {
    const n = r.name.toLowerCase();
    return Boolean(n) && (n === hint || n.includes(hint) || hint.includes(n));
  }) : void 0;
  if (byHint) return byHint.mac;
  const byName = pool.find((r) => NAME_RE.test(r.name));
  if (byName) return byName.mac;
  if (pool.length === 1) return pool[0].mac;
  return "";
}
async function ensureSavedMac() {
  if (/^[0-9A-Fa-f]{2}(:[0-9A-Fa-f]{2}){5}$/.test(saved4.addr)) {
    saved4.addr = saved4.addr.toUpperCase();
    return true;
  }
  if (process.platform !== "linux" || !helperExists()) return false;
  for (let i = 0; i < 6; i++) {
    try {
      const out = await runHelper(["devices"], 8e3);
      const mac = parsePairedMac(out, saved4.name);
      if (mac) {
        saved4.addr = mac;
        if (!saved4.name) saved4.name = "Monitor Station";
        persist6();
        return true;
      }
    } catch (err) {
      if (noController(helperText(err))) return false;
    }
    await new Promise((r) => setTimeout(r, 2e3));
  }
  return false;
}
function helperText(err) {
  return err instanceof Error ? err.message : String(err);
}
function noController(msg) {
  return /sem controlador|no default controller|no controller available/i.test(msg);
}
function helperBusy(msg) {
  return /lextel-bt ocupado/i.test(msg);
}
function helperExists() {
  return existsSync7(HELPER3);
}
function openNoctty(path5, _flags, mode, cb) {
  const flags = fsConstants.O_RDONLY | (fsConstants.O_NOCTTY || 0);
  openFd(path5, flags, mode, cb);
}
function killHelper(child2) {
  const pid = child2.pid;
  if (!pid) return;
  try {
    if (process.platform !== "win32") {
      process.kill(-pid, "SIGTERM");
      return;
    }
  } catch {
  }
  try {
    child2.kill("SIGTERM");
  } catch {
  }
}
function runHelper(args, timeout = 3e4) {
  if (!helperExists()) {
    const err = new Error("BlueZ helper ausente \u2014 o SPP Classic roda no Raspberry Pi");
    err.code = "NO_BLUEZ";
    return Promise.reject(err);
  }
  return new Promise((resolve, reject) => {
    const child2 = spawn3("sudo", ["-n", HELPER3, ...args], {
      detached: process.platform !== "win32",
      windowsHide: true,
      stdio: ["ignore", "pipe", "pipe"]
    });
    let stdout = "";
    let stderr = "";
    let settled = false;
    let timer;
    const finish2 = (err, out) => {
      if (settled) return;
      settled = true;
      if (timer) clearTimeout(timer);
      if (err) reject(err);
      else resolve(out ?? "");
    };
    timer = setTimeout(() => {
      finish2(new Error(`lextel-bt ${args[0] || "?"} excedeu ${timeout} ms`));
      killHelper(child2);
    }, timeout);
    child2.stdout?.setEncoding("utf8");
    child2.stderr?.setEncoding("utf8");
    child2.stdout?.on("data", (chunk) => {
      stdout = (stdout + chunk).slice(-1024 * 1024);
    });
    child2.stderr?.on("data", (chunk) => {
      stderr = (stderr + chunk).slice(-256 * 1024);
    });
    child2.on("error", (err) => finish2(err));
    child2.on("close", (code, signal) => {
      const text = `${stdout}
${stderr}`.trim();
      if (signal) {
        finish2(new Error(text || `lextel-bt encerrou (${signal})`));
        return;
      }
      if (code === 0) finish2(null, stdout.trim());
      else finish2(new Error(text || `lextel-bt saiu com c\xF3digo ${code}`));
    });
  });
}
function bluetoothMac(addr) {
  const t = addr.trim();
  if (!t || /COM\d+/i.test(t) || /[\\/]/.test(t) || /rfcomm|tty/i.test(t)) return "";
  const mac = t.toUpperCase();
  return BT_MAC.test(mac) ? mac : "";
}
function onlyBluetooth(list) {
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const d of list) {
    if (d.kind === "serial") continue;
    const addr = bluetoothMac(d.addr);
    if (!addr || seen.has(addr)) continue;
    seen.add(addr);
    out.push({ ...d, addr, kind: "bt" });
  }
  return out;
}
function parseDevLines(text) {
  const out = [];
  for (const line of text.split(/\r?\n/)) {
    const m = line.match(/^DEV\s+([0-9A-Fa-f:]{17})\s+([01])\s+(.*)$/);
    if (!m) continue;
    const addr = bluetoothMac(m[1]);
    if (!addr) continue;
    const name = m[3].trim() || "unknown";
    out.push({ addr, name, paired: m[2] === "1", kind: "bt", likely: NAME_RE.test(name) });
  }
  return out;
}
function winComPath(p) {
  const m = p.match(/COM\d+/i);
  if (!m) return p;
  const n = Number(m[0].slice(3));
  return n >= 10 ? `\\\\.\\${m[0].toUpperCase()}` : m[0].toUpperCase();
}
function pidRunning(pid) {
  if (!Number.isFinite(pid) || pid <= 0) return false;
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}
function sppLockPath(com) {
  return join8(dataDir7(), `spp-${comKey(com) || "port"}.lock`);
}
function acquireSppLock(com) {
  const p = sppLockPath(com);
  try {
    if (existsSync7(p)) {
      const old = Number(readFileSync7(p, "utf8").trim());
      if (old && old !== process.pid && pidRunning(old)) return false;
    }
  } catch {
  }
  try {
    writeFileSync7(p, String(process.pid), "utf8");
    sppLockCom = comKey(com);
    return true;
  } catch {
    return true;
  }
}
function releaseSppLock() {
  if (!sppLockCom) return;
  const p = sppLockPath(sppLockCom);
  sppLockCom = "";
  try {
    if (!existsSync7(p)) return;
    const old = Number(readFileSync7(p, "utf8").trim());
    if (!old || old === process.pid) unlinkSync(p);
  } catch {
  }
}
function captureSize(path5) {
  try {
    return statSync(path5).size;
  } catch {
    return 0;
  }
}
function readCaptureSlice(path5, from, len) {
  if (len <= 0) return Buffer.alloc(0);
  const fd = openSync(path5, "r");
  try {
    const buf = Buffer.alloc(len);
    let off = 0;
    while (off < len) {
      const n = readSync(fd, buf, off, len - off, from + off);
      if (n <= 0) break;
      off += n;
    }
    return off === len ? buf : buf.subarray(0, off);
  } finally {
    closeSync(fd);
  }
}
function rollCapture(buf) {
  captureRing = pushCaptureRing(captureRing, buf);
  const now = Date.now();
  if (!captureResetAt) captureResetAt = now;
  if (now - captureResetAt < CAPTURE_RESET_MS) return;
  captureRing = Buffer.alloc(0);
  captureResetAt = now;
  decoder.trimWindow();
  captureLen = 0;
  captureOff = 0;
}
function startCaptureWatch() {
  if (captureWatch) clearInterval(captureWatch);
  try {
    const p = capturePath();
    if (existsSync7(p)) {
      const size = captureSize(p);
      captureLen = size;
      if (!reading && size) {
        const from = Math.max(0, size - 2048);
        const tail2 = readCaptureSlice(p, from, size - from);
        if (tail2?.length) ingest(tail2, true);
      }
      captureOff = size;
    }
  } catch {
  }
  captureWatch = setInterval(() => {
    try {
      const p = capturePath();
      if (!existsSync7(p)) return;
      const size = captureSize(p);
      let from = captureOff;
      if (size < from) from = 0;
      if (size <= from) return;
      if (size - from > CAPTURE_RING_MAX) from = Math.max(0, size - 4096);
      const take = Math.min(size - from, 64 * 1024);
      const chunk = readCaptureSlice(p, from, take);
      if (!chunk?.length) return;
      ingest(chunk, true);
      captureOff = from + chunk.length;
    } catch {
    }
  }, 200);
}
async function winSppPorts() {
  const script = [
    "Get-PnpDevice -Class Ports -Status OK -ErrorAction SilentlyContinue | ForEach-Object {",
    "  $com = [regex]::Match($_.FriendlyName,'COM\\d+').Value",
    "  if (-not $com -or $_.InstanceId -notmatch 'BTHENUM') { return }",
    "  $m = [regex]::Match($_.InstanceId, '([0-9A-Fa-f]{12})_')",
    "  $hex = if ($m.Success) { $m.Groups[1].Value.ToUpper() } else { '' }",
    "  $inc = if ($hex -eq '000000000000' -or $hex -eq '') { '1' } else { '0' }",
    '  "$com`t$inc`t$hex"',
    "}"
  ].join(" ");
  try {
    const { stdout } = await execFileAsync6("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", script], {
      windowsHide: true,
      timeout: 8e3
    });
    const ports = stdout.split(/\r?\n/).map((l) => l.trim()).filter(Boolean).map((l) => {
      const [com, inc, mac] = l.split("	");
      return { com: (com || "").toUpperCase(), incoming: inc === "1", mac: (mac || "").toUpperCase() };
    }).filter((p) => /^COM\d+$/.test(p.com));
    sppPortsCache = ports;
    sppPortsAt = Date.now();
    return ports;
  } catch {
    return sppPortsCache;
  }
}
async function winSppPortsCached() {
  if (sppPortsCache.length && Date.now() - sppPortsAt < 4e3) return sppPortsCache;
  return winSppPorts();
}
async function winComForMac(mac) {
  const hex = mac.replace(/[^0-9A-Fa-f]/g, "").toUpperCase();
  if (hex.length !== 12) return null;
  const ports = await winSppPorts();
  const hit = ports.find((p) => !p.incoming && p.mac === hex) || ports.find((p) => p.mac === hex && !p.incoming);
  return hit?.com ?? null;
}
function isIncomingPort(ports, com) {
  const hit = ports.find((p) => p.com === com);
  if (!hit) return false;
  return hit.incoming || SKIP_SPP_MAC.has(hit.mac);
}
function pickOutgoing(ports, prefer = "") {
  const outgoing = ports.filter((p) => !p.incoming && p.mac && !SKIP_SPP_MAC.has(p.mac));
  if (prefer && outgoing.some((p) => p.com === prefer)) return prefer;
  if (resolvedOutgoing && outgoing.some((p) => p.com === resolvedOutgoing)) return resolvedOutgoing;
  return outgoing[0]?.com || "";
}
async function winPreferOutgoingCom(addr) {
  const want = (addr.match(/COM\d+/i) || [])[0]?.toUpperCase() || "";
  const ports = await winSppPortsCached();
  if (!ports.length) return resolvedOutgoing || want || addr;
  if (want && !isIncomingPort(ports, want) && ports.some((p) => p.com === want && !p.incoming)) {
    resolvedOutgoing = want;
    return want;
  }
  const picked = pickOutgoing(ports, want) || (!want || isIncomingPort(ports, want) ? "" : want);
  if (/^COM\d+$/i.test(picked)) resolvedOutgoing = picked.toUpperCase();
  return picked || want || addr;
}
function colonMac(hex) {
  const h = hex.replace(/[^0-9a-fA-F]/g, "").toUpperCase();
  if (h.length !== 12) return hex.toUpperCase();
  return h.match(/.{2}/g)?.join(":") ?? h;
}
async function winClassicDevices() {
  const out = [];
  try {
    const { stdout } = await execFileAsync6(
      "reg",
      ["query", "HKLM\\SYSTEM\\CurrentControlSet\\Services\\BTHPORT\\Parameters\\Devices"],
      { windowsHide: true, timeout: 8e3 }
    );
    const keys = stdout.split(/\r?\n/).map((l) => l.trim()).filter((l) => /\\Devices\\[0-9a-fA-F]{12}$/.test(l));
    for (const key of keys) {
      const hex = key.split("\\").pop() || "";
      const addr = colonMac(hex);
      let name = "Bluetooth";
      try {
        const { stdout: det } = await execFileAsync6("reg", ["query", key, "/v", "Name"], { windowsHide: true, timeout: 4e3 });
        const m = det.match(/Name\s+REG_BINARY\s+([0-9A-Fa-f ]+)/i);
        if (m) {
          const hex2 = m[1].replace(/\s+/g, "");
          const raw = Buffer.from(hex2, "hex");
          name = raw.toString("ascii").replace(/\0/g, "").trim() || raw.toString("utf16le").replace(/\0/g, "").trim() || name;
        }
      } catch {
      }
      const mac = bluetoothMac(addr);
      if (!mac) continue;
      out.push({ addr: mac, name, paired: true, kind: "bt", likely: NAME_RE.test(name) });
    }
  } catch {
  }
  return out;
}
async function lextelLearn() {
  try {
    const cap = ensureCaptureReady();
    const buf = readFileSync7(cap);
    bytes = Math.max(bytes, buf.length);
    inspect = inspectCapture(buf);
    if (inspect.reading) reading = inspect.reading;
    if (inspect.layout) {
      decoder.layout = inspect.layout;
      saved4.layout = inspect.layout;
      persist6();
    }
    if (!buf.length) {
      error2 = "Sem captura \u2014 conecte o SPP do MS-2000, deixe transmitir alguns segundos (PTT ajuda) e tente de novo. Arquivo: " + cap;
      inspect = { ...inspect, note: error2 };
    } else if (!inspect.reading) {
      error2 = inspect.note || `Dump com ${buf.length} B, mas ainda sem mapa PEP/ROE/V \u2014 transmita mais ou confira o quadro`;
      inspect = { ...inspect, note: error2 };
    } else {
      error2 = "";
      inspect = { ...inspect, note: `decoder ${inspect.layout?.kind || "ok"} \xB7 ${buf.length} B` };
    }
  } catch (err) {
    error2 = err instanceof Error ? err.message : String(err);
  }
  return lextelStatus();
}
async function lextelOpenBluetooth() {
  if (process.platform === "win32") {
    try {
      await execFileAsync6("cmd.exe", ["/c", "start", "ms-settings:bluetooth"], { windowsHide: true, timeout: 5e3 });
    } catch (err) {
      error2 = err instanceof Error ? err.message : String(err);
    }
  }
  return lextelScan(8);
}
function ingest(buf, alreadyOnDisk = false) {
  if (!buf.length) return;
  bytes += buf.length;
  updatedAt = Date.now();
  if (process.platform === "win32" && /COM\d+/i.test(pathOpen)) {
    const live4 = comKey(pathOpen);
    if (live4 && saved4.addr !== live4) {
      saved4.addr = live4;
      saved4.name = saved4.name.replace(/COM\d+/gi, live4).replace(/\s*\(entrada\)/i, "").trim() || live4;
      persist6();
    }
  }
  const got = decoder.push(buf);
  if (!alreadyOnDisk) {
    try {
      rollCapture(buf);
    } catch {
    }
  } else if (!captureResetAt) {
    captureResetAt = Date.now();
  } else if (Date.now() - captureResetAt >= CAPTURE_RESET_MS) {
    captureResetAt = Date.now();
    decoder.trimWindow();
  }
  if (got) {
    reading = got;
    if (error2 && /UnauthorizedAccess|win-spp/i.test(error2)) error2 = "";
    if (decoder.layout && JSON.stringify(decoder.layout) !== JSON.stringify(saved4.layout)) {
      saved4.layout = decoder.layout;
      persist6();
    }
  }
  inspect = {
    ascii: buf.toString("latin1").replace(/[^\t\r\n\x20-\x7e]/g, ".").slice(-480),
    printable: 1,
    period: inspect.period,
    hexHead: decoder.lastHex,
    note: decoder.layout?.kind === "ascii" ? "ASCII A-F (PEP/AVG/REF mW \u2192 W, ROE, V; F = MHz)" : decoder.layout ? `quadro ${decoder.layout.kind}` : inspect.note || "aguardando bytes",
    layout: decoder.layout,
    reading
  };
}
function killPidTree(pid) {
  if (process.platform !== "win32" || !pid) return;
  try {
    const child2 = spawn3("taskkill", ["/F", "/T", "/PID", String(pid)], {
      windowsHide: true,
      stdio: "ignore",
      detached: true
    });
    child2.unref();
  } catch {
  }
}
function sppEstablishing() {
  if (!opening || !attachedAt) return false;
  return Date.now() - attachedAt < SPP_OPEN_MS;
}
function linkAlive() {
  if (process.platform === "win32") return Boolean(stream || sppChild);
  if (sppEstablishing() && (pumpChild || stream)) return true;
  if (pumpChild && opened) return true;
  return opened && Boolean(stream);
}
function comKey(s) {
  const t = s.trim();
  if (!t) return "";
  const m = t.match(/COM\d+/i);
  if (m) return m[0].toUpperCase();
  if (/^\/dev\//i.test(t) || t.startsWith("/")) {
    return normalizeSerialPath(t);
  }
  if (/^[0-9A-Fa-f]{2}(:[0-9A-Fa-f]{2}){5}$/.test(t)) return t.toUpperCase();
  return t.replace(/\\/g, "");
}
function samePort(a, b) {
  if (!a || !b) return false;
  const ca = comKey(a);
  const cb = comKey(b);
  if (ca && cb && ca === cb) return true;
  if (/COM\d+/i.test(a) && /COM\d+/i.test(b)) return a.toUpperCase() === b.toUpperCase();
  return a === b;
}
function preferBtMac(hint = "") {
  const want = hint.trim().toUpperCase();
  if (/^[0-9A-F]{2}(:[0-9A-F]{2}){5}$/.test(want)) return want;
  const hit = devices.find((d) => d.kind === "bt" && d.likely) || devices.find((d) => d.kind === "bt" && NAME_RE.test(d.name));
  return hit?.addr || "";
}
function clearReconnect2() {
  if (reconnectTimer2) {
    clearTimeout(reconnectTimer2);
    reconnectTimer2 = null;
  }
}
function noteSppOpenTimeout() {
  sppOpenMisses = Math.min(8, sppOpenMisses + 1);
  rfcommStale = sppOpenMisses >= 2;
}
function clearSppOpenMisses() {
  sppOpenMisses = 0;
}
function scheduleReconnect2() {
  if (!wantOpen || reconnectTimer2) return;
  const wait = reconnectDelay2;
  reconnectTimer2 = setTimeout(() => {
    reconnectTimer2 = null;
    void recoverLink();
  }, wait);
  reconnectDelay2 = nextReconnectDelay(wait, "grow");
}
async function remapIfWrongCom() {
  if (process.platform !== "win32" || !wantOpen || recoverBusy || connectBusy) return;
  const now = Date.now();
  if (now - lastRemapAt < 8e3) return;
  lastRemapAt = now;
  const next = await winPreferOutgoingCom(saved4.addr || pathOpen);
  if (!next || samePort(pathOpen, next)) return;
  recoverBusy = true;
  try {
    closeStream();
    saved4.addr = comKey(next) || next;
    saved4.name = saved4.name.replace(/COM\d+/gi, saved4.addr).replace(/\s*\(entrada\)/i, "").trim() || saved4.addr;
    persist6();
    attach(winComPath(next));
  } finally {
    recoverBusy = false;
  }
}
async function recoverLink() {
  if (!wantOpen) return;
  if (sppEstablishing()) return;
  if (recoverBusy || connectBusy) {
    scheduleReconnect2();
    return;
  }
  if (linkAlive()) {
    if (process.platform === "win32" && bytes === 0 && attachedAt && Date.now() - attachedAt > 5e3) {
      await remapIfWrongCom();
    }
    reconnectDelay2 = 600;
    return;
  }
  recoverBusy = true;
  if (phase2 !== "scanning" && phase2 !== "pairing") phase2 = "connecting";
  try {
    if (!bluetoothMac(saved4.addr)) {
      const ready = await ensureSavedMac();
      if (!wantOpen) return;
      if (!ready || !bluetoothMac(saved4.addr)) {
        if (!error2) error2 = "Aguardando o MAC do MS-2000. O endere\xE7o salvo n\xE3o foi apagado.";
        reconnectDelay2 = 1e4;
        return;
      }
    }
    await lextelConnectBody({ addr: saved4.addr, pin: saved4.pin, name: saved4.name, channel: saved4.channel });
  } catch {
  } finally {
    recoverBusy = false;
    if (pendingConnect && wantOpen) {
      const next = pendingConnect;
      pendingConnect = null;
      clearReconnect2();
      void lextelConnect(next);
      return;
    }
    if (wantOpen && !linkAlive() && !opening) scheduleReconnect2();
    else if (linkAlive()) reconnectDelay2 = 600;
  }
}
function killLeftoverWinSpp(_com) {
  if (process.platform !== "win32") return;
  const pid = sppChild?.pid;
  if (pid) killPidTree(pid);
}
function reopenStalledPump() {
  const now = Date.now();
  if (now - lastStallReopen < CAPTURE_STALL_MS * 2) return;
  if (!wantOpen || recoverBusy || connectBusy || opening) return;
  lastStallReopen = now;
  captureRing = Buffer.alloc(0);
  captureResetAt = now;
  decoder.trimWindow();
  captureLen = 0;
  captureOff = 0;
  try {
    writeFileSync7(ensureCaptureReady(), Buffer.alloc(0));
  } catch {
  }
  closeStream();
  wantOpen = true;
  phase2 = "connecting";
  opening = true;
  opened = false;
  pathOpen = RFCOMM;
  attachedAt = now;
  attachPump(RFCOMM);
}
function clearOpenTimer() {
  if (openTimer) {
    clearTimeout(openTimer);
    openTimer = null;
  }
}
function closeStream() {
  clearOpenTimer();
  opened = false;
  opening = false;
  if (pumpChild) {
    const child2 = pumpChild;
    pumpChild = null;
    killHelper(child2);
  }
  if (stream) {
    const rs = stream;
    stream = null;
    rs.removeAllListeners();
    rs.on("error", () => {
    });
    rs.destroy();
  }
  if (captureWatch) {
    clearInterval(captureWatch);
    captureWatch = null;
  }
  captureOff = 0;
  if (sppChild) {
    const pid = sppChild.pid;
    try {
      sppChild.kill();
    } catch {
    }
    sppChild = null;
    killPidTree(pid);
  }
  pathOpen = "";
  releaseSppLock();
  if (!wantOpen && (phase2 === "streaming" || phase2 === "connecting")) phase2 = "idle";
}
function attachFd(path5) {
  const rs = createReadStream(path5, {
    flags: "r",
    highWaterMark: 256,
    ...process.platform === "linux" ? { fs: { open: openNoctty, read, close } } : {}
  });
  stream = rs;
  clearOpenTimer();
  openTimer = setTimeout(() => {
    if (opened || stream !== rs) return;
    error2 = `MS-2000 ${saved4.addr || "salvo"} sem resposta no SPP. Nova tentativa, sem desligar o Bluetooth.`;
    noteSppOpenTimeout();
    opening = false;
    phase2 = "connecting";
    reconnectDelay2 = nextReconnectDelay(reconnectDelay2, "drop");
    closeStream();
    scheduleReconnect2();
  }, SPP_OPEN_MS);
  openTimer.unref?.();
  rs.on("open", () => {
    opened = true;
    opening = false;
    clearOpenTimer();
    phase2 = "streaming";
    reconnectDelay2 = 600;
    clearSppOpenMisses();
    rfcommStale = false;
    error2 = "";
  });
  rs.on("data", (chunk) => {
    ingest(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
  });
  rs.on("error", (err) => {
    clearOpenTimer();
    opened = false;
    opening = false;
    const code = err.code || "";
    if (!error2.startsWith("MS-2000")) error2 = err.message;
    rfcommStale = code === "ENODEV";
    if (wantOpen) {
      phase2 = "connecting";
      if (stream === rs) closeStream();
      scheduleReconnect2();
      return;
    }
    phase2 = "error";
    if (stream === rs) closeStream();
  });
  rs.on("close", () => {
    if (pathOpen === path5) {
      stream = null;
      pathOpen = "";
      if (wantOpen) {
        scheduleReconnect2();
        return;
      }
      if (phase2 !== "error" && !sppChild && !pumpChild) phase2 = "idle";
    }
  });
}
function attachWinSpp(com) {
  const script = winSppScript();
  if (!existsSync7(script)) {
    attachFd(winComPath(com));
    return;
  }
  if (!acquireSppLock(com)) {
    startCaptureWatch();
    phase2 = "connecting";
    error2 = `${com} em uso`;
    scheduleReconnect2();
    return;
  }
  killLeftoverWinSpp(com);
  const bauds = [9600];
  const run6 = (baud) => {
    const child2 = spawn3(
      "powershell.exe",
      [
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        script,
        "-Port",
        com,
        "-Baud",
        String(baud),
        "-OutFile",
        capturePath()
      ],
      { windowsHide: true, stdio: ["ignore", "ignore", "pipe"] }
    );
    sppChild = child2;
    startCaptureWatch();
    child2.stderr?.on("data", (chunk) => {
      const msg = chunk.toString("utf8").trim();
      if (msg) error2 = msg.split(/\r?\n/).pop() || msg;
    });
    child2.on("error", (err) => {
      error2 = err.message;
      if (wantOpen) {
        phase2 = "connecting";
        scheduleReconnect2();
        return;
      }
      phase2 = "error";
    });
    child2.on("exit", () => {
      if (sppChild !== child2) return;
      sppChild = null;
      const idx = bauds.indexOf(baud);
      const busy = /UnauthorizedAccess|porta em uso|em uso/i.test(error2);
      if (!busy && bytes === 0 && idx >= 0 && idx < bauds.length - 1 && wantOpen && phase2 !== "idle") {
        run6(bauds[idx + 1]);
        return;
      }
      if (wantOpen) {
        phase2 = "connecting";
        scheduleReconnect2();
        return;
      }
      if (bytes > 0) {
        phase2 = "streaming";
        return;
      }
      if (phase2 === "streaming" || phase2 === "connecting") {
        phase2 = "error";
        if (!error2) error2 = `N\xE3o abriu ${com} (baud ${baud})`;
      }
    });
    phase2 = "streaming";
  };
  run6(bauds[0]);
}
function markPumpOpen() {
  if (opened) return;
  opened = true;
  opening = false;
  clearOpenTimer();
  phase2 = "streaming";
  reconnectDelay2 = 600;
  clearSppOpenMisses();
  rfcommStale = false;
  error2 = "";
}
function attachPump(path5) {
  if (!helperExists()) {
    attachFd(path5);
    return;
  }
  const child2 = spawn3(HELPER3, ["pump"], {
    detached: process.platform !== "win32",
    windowsHide: true,
    stdio: ["ignore", "pipe", "pipe"]
  });
  pumpChild = child2;
  clearOpenTimer();
  let stderrBuf = "";
  openTimer = setTimeout(() => {
    if (opened || pumpChild !== child2) return;
    error2 = `MS-2000 ${saved4.addr || "salvo"} sem resposta no SPP. Nova tentativa, sem desligar o Bluetooth.`;
    noteSppOpenTimeout();
    opening = false;
    phase2 = "connecting";
    reconnectDelay2 = nextReconnectDelay(reconnectDelay2, "drop");
    closeStream();
    scheduleReconnect2();
  }, SPP_OPEN_MS);
  openTimer.unref?.();
  child2.stderr?.setEncoding("utf8");
  child2.stderr?.on("data", (chunk) => {
    stderrBuf = (stderrBuf + chunk).slice(-2e3);
    if (/(?:^|\n)OPEN(?:\n|$)/.test(stderrBuf)) markPumpOpen();
    if (/ENODEV/.test(stderrBuf)) rfcommStale = true;
  });
  child2.stdout?.on("data", (chunk) => {
    markPumpOpen();
    ingest(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
  });
  child2.on("error", (err) => {
    if (pumpChild !== child2) return;
    pumpChild = null;
    clearOpenTimer();
    opened = false;
    opening = false;
    error2 = err.message;
    if (wantOpen) {
      phase2 = "connecting";
      scheduleReconnect2();
      return;
    }
    phase2 = "error";
  });
  child2.on("close", () => {
    if (pumpChild !== child2) return;
    pumpChild = null;
    clearOpenTimer();
    const wasOpen = opened;
    opened = false;
    opening = false;
    if (/ENODEV/.test(stderrBuf)) rfcommStale = true;
    if (!wantOpen) {
      if (!wasOpen && phase2 !== "error") phase2 = "idle";
      return;
    }
    if (!error2.startsWith("MS-2000")) {
      const line = stderrBuf.trim().split(/\n/).pop() || "";
      if (line && line !== "OPEN") error2 = line;
    }
    phase2 = "connecting";
    scheduleReconnect2();
  });
}
function attach(path5) {
  if (!wantOpen) return;
  const openPath = normalizeSerialPath(path5) || path5;
  if (samePort(pathOpen, openPath) && linkAlive()) {
    phase2 = "streaming";
    return;
  }
  closeStream();
  if (!decoder.layout && saved4.layout) decoder.reset(saved4.layout);
  try {
    writeFileSync7(ensureCaptureReady(), Buffer.alloc(0));
    captureLen = 0;
    captureOff = 0;
    captureRing = Buffer.alloc(0);
    captureResetAt = 0;
  } catch {
  }
  phase2 = "connecting";
  error2 = "";
  opening = true;
  opened = false;
  pathOpen = openPath;
  attachedAt = Date.now();
  bytes = 0;
  if (process.platform === "win32" && /COM\d+/i.test(openPath)) {
    const m = openPath.match(/COM\d+/i);
    attachWinSpp(m ? m[0].toUpperCase() : openPath);
    return;
  }
  if (process.platform === "linux" && isRfcommPath(openPath)) {
    attachPump(openPath);
    return;
  }
  attachFd(openPath);
}
function lextelStatus() {
  const r = reading;
  return {
    ok: phase2 !== "error",
    folder: dataDir7(),
    sppUuid: SPP_UUID,
    phase: phase2,
    connected: phase2 === "streaming" && linkAlive(),
    decoded: Boolean(r) || Boolean(decoder.layout && bytes > 0),
    addr: saved4.addr,
    name: saved4.name,
    pin: saved4.pin,
    channel: saved4.channel,
    autoConnect: saved4.autoConnect,
    path: pathOpen,
    error: error2,
    hex: decoder.lastHex,
    layout: decoder.layout?.kind ?? "",
    bytes,
    updatedAt,
    pep: r?.pep ?? 0,
    avg: r?.avg ?? 0,
    ref: r?.ref ?? 0,
    swr: r?.swr ?? 1,
    vdc: r?.vdc ?? 0,
    z: r?.z ?? 0,
    mod: r?.mod ?? 0,
    alarms: r?.labels ?? [],
    devices,
    ascii: inspect.ascii,
    note: inspect.note || error2,
    captureBytes: bytes,
    period: inspect.period
  };
}
async function lextelScan(seconds = 12) {
  phase2 = "scanning";
  error2 = "";
  let classic = [];
  if (process.platform === "win32") {
    classic = await winClassicDevices();
  }
  if (process.platform === "linux") {
    try {
      const out = await runHelper(["scan", String(Math.min(20, Math.max(5, seconds)))], 25e3);
      classic = parseDevLines(out);
    } catch (err) {
      const msg = helperText(err);
      error2 = noController(msg) ? NO_CONTROLLER_MSG : msg;
      if (!noController(msg)) {
        try {
          const out = await runHelper(["devices"], 8e3);
          classic = parseDevLines(out);
        } catch {
        }
      }
    }
  }
  devices = onlyBluetooth(classic);
  devices.sort((a, b) => Number(b.likely) - Number(a.likely) || a.name.localeCompare(b.name));
  if (phase2 === "scanning") {
    if (linkAlive()) phase2 = "streaming";
    else if (wantOpen) {
      phase2 = "connecting";
      scheduleReconnect2();
    } else phase2 = "idle";
  }
  return lextelStatus();
}
async function lextelSave(body) {
  if (typeof body.addr === "string") {
    const next = body.addr.trim();
    if (!isRfcommPath(next)) saved4.addr = normalizeSerialPath(next) || next;
  }
  if (typeof body.name === "string") saved4.name = body.name.trim();
  if (typeof body.pin === "string" && /^\d{4,6}$/.test(body.pin.trim())) saved4.pin = body.pin.trim();
  if (typeof body.channel === "number" && body.channel >= 1 && body.channel <= 30) saved4.channel = Math.round(body.channel);
  if (typeof body.autoConnect === "boolean") saved4.autoConnect = body.autoConnect;
  persist6({ allowEmpty: typeof body.addr === "string" });
  return lextelStatus();
}
function isSerialPath(addr) {
  return /^(COM\d+|\\\\\.\\COM\d+|\/dev\/)/i.test(addr);
}
async function lextelConnect(body = {}) {
  if (connectBusy || recoverBusy) {
    pendingConnect = { ...body };
    wantOpen = true;
    return { ...lextelStatus(), queued: true };
  }
  connectBusy = true;
  try {
    return await lextelConnectBody(body);
  } finally {
    connectBusy = false;
    const next = pendingConnect;
    pendingConnect = null;
    if (next && wantOpen) {
      clearReconnect2();
      void lextelConnect(next);
    }
  }
}
async function lextelConnectBody(body) {
  let addr = String(body.addr || saved4.addr).trim();
  if (process.platform === "linux" && isRfcommPath(addr)) {
    const kept = bluetoothMac(saved4.addr) || preferBtMac();
    if (kept) addr = kept;
  } else if (isSerialPath(addr)) {
    addr = normalizeSerialPath(addr);
  }
  if (!addr) {
    phase2 = "error";
    error2 = "Selecione o MS-2000 no scan";
    return lextelStatus();
  }
  wantOpen = true;
  if (typeof body.pin === "string" && body.pin) saved4.pin = body.pin.trim();
  if (typeof body.name === "string" && body.name) saved4.name = body.name.trim();
  if (typeof body.channel === "number" && body.channel >= 1) saved4.channel = Math.round(body.channel);
  error2 = "";
  if (isSerialPath(addr) && !(process.platform === "linux" && isRfcommPath(addr))) {
    const serial = process.platform === "win32" ? await winPreferOutgoingCom(addr) : normalizeSerialPath(addr);
    if (linkAlive() && samePort(pathOpen, serial) && (bytes > 0 || Date.now() - attachedAt < 8e3)) {
      if (phase2 !== "error") phase2 = "streaming";
      saved4.addr = process.platform === "win32" ? comKey(serial) || serial : serial;
      persist6();
      return lextelStatus();
    }
    if (serial !== saved4.addr) {
      saved4.name = saved4.name.replace(/COM\d+/gi, serial).replace(/\s*\(entrada\)/i, "").trim() || serial;
    }
    saved4.addr = process.platform === "win32" ? comKey(serial) || serial : serial;
    persist6();
    attach(process.platform === "win32" ? winComPath(serial) : serial);
    return lextelStatus();
  }
  if (process.platform === "win32") {
    const serial = await winComForMac(addr) || await winPreferOutgoingCom(addr);
    if (serial && isSerialPath(serial)) {
      saved4.name = saved4.name || "Monitor Station";
      saved4.addr = serial;
      persist6();
      attach(winComPath(serial));
      return lextelStatus();
    }
    phase2 = "error";
    error2 = "No Windows o MS-2000 precisa estar pareado (PIN 1234 ou 0000). Abra Configura\xE7\xF5es \u2192 Bluetooth, pareie, e o SPP vira um COM. Depois toque em Procurar e Conectar.";
    try {
      await execFileAsync6("cmd.exe", ["/c", "start", "ms-settings:bluetooth"], { windowsHide: true, timeout: 5e3 });
    } catch {
    }
    return lextelStatus();
  }
  if (process.platform !== "linux") {
    phase2 = "error";
    error2 = "Bluetooth Classic SPP precisa do BlueZ no Raspberry Pi";
    return lextelStatus();
  }
  if (isRfcommPath(addr) || isSerialPath(addr)) {
    phase2 = "connecting";
    error2 = "Endere\xE7o SPP inv\xE1lido (ex.: /DEV/RFCOMM0). O MAC salvo foi mantido. Procure o MS-2000 e conecte pelo endere\xE7o Bluetooth.";
    if (wantOpen) scheduleReconnect2();
    return lextelStatus();
  }
  try {
    const listed = devices.find((d) => d.addr.toUpperCase() === addr.toUpperCase());
    let known = listed?.paired === true;
    if (!known) {
      try {
        const st = await runHelper(["paired", addr], 6e3);
        known = /paired=yes/.test(st);
      } catch (err) {
        const msg = helperText(err);
        if (noController(msg)) throw err;
      }
    }
    if (!known) {
      phase2 = "pairing";
      try {
        await runHelper(["pair", addr, saved4.pin], 28e3);
      } catch (err) {
        const msg = helperText(err);
        if (noController(msg) || helperBusy(msg)) throw err;
        error2 = `Pareamento: ${msg}`;
      }
    }
    phase2 = "connecting";
    let ch = saved4.channel;
    try {
      const out = await runHelper(["channel", addr], 8e3);
      const n = Number((out.match(/\d+/) || [])[0]);
      if (n >= 1 && n <= 30) ch = n;
    } catch (err) {
      if (noController(helperText(err))) throw err;
    }
    saved4.channel = ch;
    saved4.addr = addr.toUpperCase();
    saved4.name = saved4.name || listed?.name || "Monitor Station";
    persist6();
    await runHelper(["bind", addr, saved4.pin, String(ch), rfcommStale ? "rebind" : ""], 12e3);
    attach(RFCOMM);
  } catch (err) {
    const msg = helperText(err);
    if (noController(msg)) {
      error2 = NO_CONTROLLER_MSG;
      reconnectDelay2 = 1e4;
    } else if (helperBusy(msg)) {
      error2 = "Bluetooth do Lextel ocupado \u2014 nova tentativa em seguida, sem derrubar a outra sess\xE3o.";
    } else {
      error2 = msg;
    }
    rfcommStale = !helperBusy(msg) && !noController(msg) && /ENODEV|nao apareceu|não apareceu/i.test(msg);
    if (/continua closed|nao saiu|não saiu|tx timeout/i.test(msg)) {
      reconnectDelay2 = nextReconnectDelay(reconnectDelay2, "drop");
    }
    closeStream();
    if (wantOpen) {
      phase2 = "connecting";
      scheduleReconnect2();
    } else {
      phase2 = "error";
    }
  }
  return lextelStatus();
}
async function lextelKeepalive() {
  const stuckLong = wantOpen && !linkAlive() && (sppOpenMisses >= 2 || attachedAt > 0 && Date.now() - attachedAt > 25e3);
  if (reconnectTimer2 && reconnectDelay2 >= 15e3 && !stuckLong) return lextelStatus();
  if (!wantOpen && saved4.autoConnect && phase2 !== "scanning" && phase2 !== "pairing") {
    const { isServiceAutostart: isServiceAutostart2 } = await Promise.resolve().then(() => (init_services(), services_exports));
    if (isServiceAutostart2("lextel")) void lextelAutoConnect();
  } else if (!connectBusy && !recoverBusy && !autoRunning && wantOpen && !linkAlive() && !sppEstablishing()) {
    reconnectDelay2 = 400;
    clearReconnect2();
    void recoverLink();
  }
  return lextelStatus();
}
async function lextelDisconnect() {
  wantOpen = false;
  pendingConnect = null;
  rfcommStale = true;
  clearReconnect2();
  closeStream();
  if (process.platform === "linux" && helperExists()) {
    try {
      if (saved4.addr && !isSerialPath(saved4.addr)) await runHelper(["disconnect", saved4.addr], 8e3);
      else await runHelper(["release"], 5e3);
    } catch {
    }
  }
  phase2 = "idle";
  error2 = "";
  reading = null;
  return lextelStatus();
}
async function lextelAutoConnect() {
  const { isServiceAutostart: isServiceAutostart2 } = await Promise.resolve().then(() => (init_services(), services_exports));
  if (!isServiceAutostart2("lextel")) return;
  if (!saved4.autoConnect) return;
  if (autoRunning || linkAlive() || connectBusy || recoverBusy || wantOpen) return;
  if (process.platform !== "linux" && !isSerialPath(saved4.addr) && !bluetoothMac(saved4.addr)) return;
  autoRunning = true;
  wantOpen = true;
  try {
    if (process.platform === "linux") {
      const ready = await ensureSavedMac();
      if (!wantOpen) return;
      if (!ready || !bluetoothMac(saved4.addr)) {
        phase2 = "connecting";
        if (!error2) error2 = "Aguardando o MS-2000 no Bluetooth. O MAC salvo n\xE3o foi apagado.";
        scheduleReconnect2();
        return;
      }
    }
    await lextelConnect({ addr: saved4.addr, pin: saved4.pin, name: saved4.name, channel: saved4.channel });
  } catch {
    if (wantOpen && !linkAlive()) scheduleReconnect2();
  } finally {
    autoRunning = false;
  }
}
var execFileAsync6, ROOT7, OPT_DIR7, HELPER3, RFCOMM, SPP_UUID, NAME_RE, SKIP_SPP_MAC, SPP_OPEN_MS, stream, sppChild, pumpChild, decoder, phase2, error2, pathOpen, reading, devices, bytes, updatedAt, inspect, captureWatch, captureOff, captureLen, captureRing, captureResetAt, lastStallReopen, wantOpen, autoRunning, recoverBusy, connectBusy, pendingConnect, rfcommStale, sppOpenMisses, reconnectTimer2, opened, opening, openTimer, reconnectDelay2, sppPortsAt, sppPortsCache, sppLockCom, attachedAt, lastRemapAt, saved4, NO_CONTROLLER_MSG, BT_MAC, resolvedOutgoing, recoverWatch;
var init_lextel = __esm({
  "server/lextel.ts"() {
    "use strict";
    init_lextel_parse();
    execFileAsync6 = promisify6(execFile6);
    ROOT7 = join8(dirname7(fileURLToPath7(import.meta.url)), "..");
    OPT_DIR7 = "/opt/lextel";
    HELPER3 = "/opt/ham-cockpit/bin/lextel-bt";
    RFCOMM = "/dev/rfcomm0";
    SPP_UUID = "00001101-0000-1000-8000-00805f9b34fb";
    NAME_RE = /lextel|ms-?2000|ms-?800|ms-?600|ms-?1000|ms-?1200|ms-?1800|hc-?0[56]|linvor|monitor.?station/i;
    SKIP_SPP_MAC = /* @__PURE__ */ new Set(["000000000000", "30317DBAC263"]);
    SPP_OPEN_MS = 12e3;
    stream = null;
    sppChild = null;
    pumpChild = null;
    decoder = new LextelDecoder();
    phase2 = "idle";
    error2 = "";
    pathOpen = "";
    reading = null;
    devices = [];
    bytes = 0;
    updatedAt = 0;
    inspect = inspectCapture(Buffer.alloc(0));
    captureWatch = null;
    captureOff = 0;
    captureLen = -1;
    captureRing = Buffer.alloc(0);
    captureResetAt = 0;
    lastStallReopen = 0;
    wantOpen = false;
    autoRunning = false;
    recoverBusy = false;
    connectBusy = false;
    pendingConnect = null;
    rfcommStale = false;
    sppOpenMisses = 0;
    reconnectTimer2 = null;
    opened = false;
    opening = false;
    openTimer = null;
    reconnectDelay2 = 600;
    sppPortsAt = 0;
    sppPortsCache = [];
    sppLockCom = "";
    attachedAt = 0;
    lastRemapAt = 0;
    saved4 = loadSaved4();
    decoder = new LextelDecoder(saved4.layout);
    NO_CONTROLLER_MSG = "Sem controlador Bluetooth. O Dual Hat segue em ttyAMA0. O MAC salvo continua; a conex\xE3o tenta de novo quando aparecer um adaptador.";
    BT_MAC = /^(?:[0-9A-F]{2}:){5}[0-9A-F]{2}$/;
    resolvedOutgoing = "";
    recoverWatch = setInterval(() => {
      if (!wantOpen || recoverBusy || connectBusy || autoRunning) return;
      if (phase2 === "scanning" || phase2 === "pairing") return;
      if (opening && attachedAt && Date.now() - attachedAt < SPP_OPEN_MS) return;
      if (linkAlive()) {
        if (process.platform === "linux" && captureStreamStalled(Date.now(), updatedAt, attachedAt, CAPTURE_STALL_MS)) {
          reopenStalledPump();
          return;
        }
        if (process.platform === "win32" && bytes === 0 && attachedAt && Date.now() - attachedAt > 5e3) {
          void remapIfWrongCom();
        }
        return;
      }
      scheduleReconnect2();
    }, 2e3);
    recoverWatch.unref();
  }
});

// server/index.ts
init_lextel();
init_list_serials();
import express from "express";
import { createReadStream as createReadStream2 } from "node:fs";
import { createServer as createServer3 } from "http";
import path4 from "path";
import { fileURLToPath as fileURLToPath19 } from "url";

// server/civ-scope-tap.ts
import { createServer as createServer2, Socket as Socket2 } from "node:net";

// shared/civ-peel.ts
init_icom_scope();
function peelCivScope(input) {
  const forward = [];
  const scopes = [];
  let i = 0;
  while (i < input.length) {
    if (input[i] !== 254) {
      forward.push(input[i]);
      i += 1;
      continue;
    }
    if (i + 1 >= input.length) break;
    if (input[i + 1] !== 254) {
      forward.push(input[i]);
      i += 1;
      continue;
    }
    let end = -1;
    for (let j = i + 2; j < input.length; j += 1) {
      if (input[j] === 253) {
        end = j;
        break;
      }
    }
    if (end < 0) break;
    const frame = input.subarray(i, end + 1);
    if (isScopeWaveform(frame)) scopes.push(frame);
    else for (let k = i; k <= end; k += 1) forward.push(input[k]);
    i = end + 1;
  }
  return { forward: Uint8Array.from(forward), scopes, rest: input.subarray(i) };
}

// server/civ-scope-tap.ts
init_icom_scope();
init_radios();
var tap = null;
var onFrame = null;
var onRevive = null;
var rigQuiet = false;
var outputWanted = false;
var scopeSpanHz = SCOPE_SPAN_HZ;
function onSerialScopeRevive(fn) {
  onRevive = fn;
  return () => {
    if (onRevive === fn) onRevive = null;
  };
}
function onSerialScopeFrame(fn) {
  onFrame = fn;
  return () => {
    if (onFrame === fn) onFrame = null;
  };
}
function serialScopeReady() {
  return tap != null;
}
function scopeTx(state, on) {
  const frames = scopeSwitchFrames(state.civ, on);
  if (on) {
    frames.push(scopeCenterFrame(state.civ));
    frames.push(scopeSpanFrame(state.civ, scopeSpanHz));
  }
  return frames;
}
function writeFrames(state, frames) {
  const sock3 = state.up;
  if (!sock3 || sock3.destroyed) return false;
  for (const frame of frames) writeUp(state, Buffer.from(frame));
  return true;
}
function flushDeferred(state) {
  if (Date.now() < state.replyUntil) return;
  const frames = state.deferred;
  state.deferred = null;
  if (!frames?.length) return;
  writeFrames(state, frames);
}
function noteRigCommand(state) {
  const waitMs = 5e3;
  state.replyUntil = Date.now() + waitMs;
  if (state.replyTimer) clearTimeout(state.replyTimer);
  state.replyTimer = setTimeout(() => {
    state.replyTimer = null;
    if (tap === state) flushDeferred(state);
  }, waitMs);
  state.replyTimer.unref?.();
}
function sendFrames(state, frames) {
  if (Date.now() < state.replyUntil) {
    state.deferred = frames;
    return true;
  }
  return writeFrames(state, frames);
}
function applyScopeOutput(on, force = false) {
  if (!tap) return;
  if (!force && tap.output === on) return;
  tap.output = on;
  if (on) {
    tap.armedAt = Date.now();
    tap.sawScope = false;
    tap.samples = 0;
    tap.pendingOff = false;
  } else {
    tap.pendingOff = true;
  }
  const frames = scopeTx(tap, on);
  const hex = frames.map((frame) => Buffer.from(frame).toString("hex")).join(" ");
  console.log(`civ-scope-tap: sa\xEDda do espectro ${on ? "ligada" : "desligada"} ${hex}`);
  if (!sendFrames(tap, frames)) return;
  if (!on) tap.pendingOff = false;
}
function serialScopeOutput(on) {
  outputWanted = on;
  if (rigQuiet && on) return;
  applyScopeOutput(on);
}
async function withSerialScopeQuiet(fn) {
  if (rigQuiet) return fn();
  rigQuiet = true;
  try {
    return await fn();
  } finally {
    rigQuiet = false;
    if (outputWanted) applyScopeOutput(true, true);
  }
}
function serialScopeCenter() {
}
function serialScopeSpan(spanHz) {
  if (spanHz != null) scopeSpanHz = normalizeScopeSpan(spanHz);
  if (!tap || rigQuiet || !outputWanted) return;
  sendFrames(tap, [scopeSpanFrame(tap.civ, scopeSpanHz)]);
}
function writeUp(state, buf) {
  state.chain = state.chain.then(
    () => new Promise((resolve) => {
      const sock3 = state.up;
      if (!sock3 || sock3.destroyed) {
        resolve();
        return;
      }
      let done = false;
      const finish2 = () => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        resolve();
      };
      const timer = setTimeout(() => finish2(), 1500);
      try {
        sock3.write(buf, finish2);
      } catch {
        finish2();
      }
    })
  );
}
function dropUp(state) {
  if (state.upTimer) {
    clearTimeout(state.upTimer);
    state.upTimer = null;
  }
  const sock3 = state.up;
  state.up = null;
  state.upRest = new Uint8Array();
  state.lastRxAt = 0;
  if (!sock3) return;
  sock3.removeAllListeners();
  sock3.destroy();
}
function scheduleUp(state) {
  if (state.upTimer || state.up) return;
  if (!state.down || state.down.destroyed) return;
  const wait = state.upDelay;
  state.upTimer = setTimeout(() => {
    state.upTimer = null;
    if (tap !== state || state.up) return;
    if (!state.down || state.down.destroyed) return;
    state.upDelay = Math.min(2e3, Math.round(Math.max(200, state.upDelay) * 1.5));
    console.log("civ-scope-tap: reconectando upstream");
    connectUp(state);
  }, wait);
  state.upTimer.unref?.();
}
function connectUp(state) {
  if (state.up) return;
  const sock3 = new Socket2();
  state.up = sock3;
  sock3.on("connect", () => {
    state.upSince = Date.now();
    state.lastRxAt = 0;
    state.upDelay = 200;
    state.pendingOff = false;
    if (outputWanted) {
      state.output = true;
      state.armedAt = Date.now();
      sendFrames(state, scopeTx(state, true));
    }
  });
  sock3.on("data", (chunk) => {
    const now = Date.now();
    state.lastRxAt = now;
    const pending2 = new Uint8Array(state.upRest.length + chunk.length);
    pending2.set(state.upRest, 0);
    pending2.set(chunk, state.upRest.length);
    const peeled = peelCivScope(pending2);
    state.upRest = peeled.rest;
    if (peeled.scopes.length) state.lastScopeAt = now;
    for (const frame of peeled.scopes) {
      if (state.samples < 6) {
        state.samples += 1;
        const head = Buffer.from(frame.subarray(0, Math.min(frame.length, 28))).toString("hex");
        console.log(`civ-scope-tap: quadro ${frame.length} ${head}`);
      }
      onFrame?.(frame);
    }
    const down = state.down;
    const rigWaiting = now < state.replyUntil;
    if (down && !down.destroyed && peeled.forward.length && rigWaiting) down.write(Buffer.from(peeled.forward));
  });
  sock3.on("error", () => {
  });
  sock3.on("close", () => {
    if (state.up !== sock3) return;
    state.up = null;
    state.upRest = new Uint8Array();
    scheduleUp(state);
  });
  sock3.connect(state.upstreamPort, state.upstreamHost);
}
function radioEndpoint(row) {
  const match = row.port.trim().match(/^(.*):(\d+)$/);
  if (!match) return null;
  const port = Number(match[2]);
  if (!Number.isInteger(port) || port < 1 || port > 65535 || port === CIV_SCOPE_TAP_PORT) return null;
  const civ = civAddrByte(row.civAddr);
  if (civ == null) return null;
  return { host: match[1] || CIV_SCOPE_TAP_HOST, port };
}
function closeTap() {
  const cur = tap;
  tap = null;
  if (!cur) return Promise.resolve();
  cur.down?.destroy();
  dropUp(cur);
  return new Promise((resolve) => cur.server.close(() => resolve()));
}
function openTap(row, endpoint) {
  if (tap && tap.upstreamHost === endpoint.host && tap.upstreamPort === endpoint.port && tap.civ === (civAddrByte(row.civAddr) ?? -1)) {
    return Promise.resolve();
  }
  return closeTap().then(
    () => new Promise((resolve, reject) => {
      const server = createServer2((down) => {
        const state = tap;
        if (!state) {
          down.destroy();
          return;
        }
        try {
          const prev = state.down;
          state.down = down;
          if (prev) {
            prev.removeAllListeners();
            prev.destroy();
          }
          down.on("data", (chunk) => {
            noteRigCommand(state);
            const up = state.up;
            if (!up || up.destroyed) return;
            try {
              up.write(chunk);
            } catch {
            }
          });
          down.on("error", () => void 0);
          down.resume();
          down.on("close", () => {
            if (state.down !== down) return;
            state.down = null;
          });
          if (!state.up) connectUp(state);
        } catch (err) {
          console.error("civ-scope-tap", err);
          down.destroy();
        }
      });
      const civ = civAddrByte(row.civAddr) ?? 0;
      tap = {
        server,
        upstreamHost: endpoint.host,
        upstreamPort: endpoint.port,
        civ,
        output: false,
        sawScope: false,
        samples: 0,
        pendingOff: false,
        lastRxAt: 0,
        upSince: 0,
        armedAt: 0,
        lastScopeAt: 0,
        upDelay: 200,
        upTimer: null,
        down: null,
        up: null,
        upRest: new Uint8Array(),
        chain: Promise.resolve(),
        replyUntil: 0,
        deferred: null,
        replyTimer: null,
        heldScope: false,
        holdTimer: null
      };
      server.once("error", reject);
      server.listen(CIV_SCOPE_TAP_PORT, CIV_SCOPE_TAP_HOST, () => {
        server.off("error", reject);
        resolve();
      });
    })
  );
}
async function prepareSerialScopeTap() {
  const row = currentSerialHamlib();
  const endpoint = row && row.link === "usb" && row.proto === "civ" && row.scope ? radioEndpoint(row) : null;
  if (!row || !endpoint) {
    await closeTap();
    return false;
  }
  await openTap(row, endpoint);
  return true;
}
async function syncSerialScopeTap() {
  await prepareSerialScopeTap();
}

// server/index.ts
init_radios();
init_ser2net_store();

// server/radio-audio.ts
import { spawn as spawn4 } from "node:child_process";
import { existsSync as existsSync9 } from "node:fs";
import { WebSocket, WebSocketServer } from "ws";

// shared/pc-audio.ts
var ONBOARD = /bcm2835|vc4|hdmi|headphone/i;
var RADIO_USB = /icom|usb audio|usb codec/i;
function pickAlsaCapture(listing) {
  const found = [];
  const re = /^card (\d+):\s*(\S+)\s*\[([^\]]+)\],\s*device (\d+):/gm;
  let match;
  while (match = re.exec(listing)) {
    found.push({
      card: Number(match[1]),
      id: match[2] ?? "",
      name: match[3] ?? "",
      device: Number(match[4])
    });
  }
  const usable = found.filter((d) => !ONBOARD.test(d.id) && !ONBOARD.test(d.name));
  const usb = usable.find((d) => RADIO_USB.test(`${d.id} ${d.name}`) || /usb/i.test(`${d.id} ${d.name}`));
  const hit = usb ?? (usable.length === 1 ? usable[0] : null);
  return hit ? { card: hit.card, device: hit.device } : null;
}
function pickAlsaPlayback(listing, capture2 = pickAlsaCapture(listing)) {
  return capture2;
}

// server/console-session.ts
import { createHmac, randomBytes as randomBytes3, timingSafeEqual } from "node:crypto";
import { chmodSync as chmodSync2, existsSync as existsSync8, mkdirSync as mkdirSync8, readFileSync as readFileSync8, writeFileSync as writeFileSync8 } from "node:fs";
import { dirname as dirname8, join as join9 } from "node:path";
import { fileURLToPath as fileURLToPath8 } from "node:url";
var COOKIE = "hc_console";
var MAX_AGE_SEC = 12 * 60 * 60;
var ACCOUNTS = [
  { user: "admin", pass: "1234" },
  { user: "suporte", pass: "doidona1" }
];
function matchAccount(user, password) {
  const name = user.trim().toLowerCase();
  for (const acc of ACCOUNTS) {
    if (name === acc.user && password === acc.pass) return acc.user;
  }
  return null;
}
function secretFile() {
  if (existsSync8("/opt/ham-cockpit")) return "/opt/ham-cockpit/console-session.key";
  return join9(dirname8(fileURLToPath8(import.meta.url)), "..", "data", "console-session.key");
}
function secret() {
  const path5 = secretFile();
  try {
    if (existsSync8(path5)) {
      const cur = readFileSync8(path5);
      if (cur.length >= 32) return cur;
    }
  } catch {
  }
  const next = randomBytes3(32);
  mkdirSync8(dirname8(path5), { recursive: true });
  writeFileSync8(path5, next, { mode: 384 });
  try {
    chmodSync2(path5, 384);
  } catch {
  }
  return next;
}
function consoleSessionToken(user, password) {
  const name = matchAccount(user, password);
  if (!name) return null;
  const exp = Math.floor(Date.now() / 1e3) + MAX_AGE_SEC;
  const payload = Buffer.from(JSON.stringify({ u: name, exp }), "utf8").toString("base64url");
  const sig = createHmac("sha256", secret()).update(payload).digest("base64url");
  return `${payload}.${sig}`;
}
function consoleSessionCookie(token) {
  return `${COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${MAX_AGE_SEC}`;
}
function consoleSessionClearCookie() {
  return `${COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`;
}
function consoleSessionOk(cookieHeader) {
  if (!cookieHeader) return false;
  const raw = cookieHeader.split(";").map((part) => part.trim()).find((part) => part.startsWith(`${COOKIE}=`));
  if (!raw) return false;
  let token = raw.slice(COOKIE.length + 1);
  try {
    token = decodeURIComponent(token);
  } catch {
    return false;
  }
  const dot = token.lastIndexOf(".");
  if (dot <= 0) return false;
  const payload = token.slice(0, dot);
  const sig = token.slice(dot + 1);
  const expect = createHmac("sha256", secret()).update(payload).digest("base64url");
  const a = Buffer.from(sig);
  const b = Buffer.from(expect);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return false;
  try {
    const body = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
    if (!ACCOUNTS.some((acc) => acc.user === body.u)) return false;
    return typeof body.exp === "number" && body.exp >= Date.now() / 1e3;
  } catch {
    return false;
  }
}

// server/radio-audio.ts
var attached = /* @__PURE__ */ new WeakSet();
var capture = null;
var captureOwner = null;
var captureReserved = null;
var captureKind = null;
var playbackHold = false;
var digitalWanted = false;
var announced = false;
var captureFault = null;
var taps = /* @__PURE__ */ new Set();
var pcmSink = null;
var FORMAT = { type: "format", sampleRate: 48e3, channels: 1, via: "usb" };
function setRadioPcmSink(fn) {
  pcmSink = fn;
}
function holdRadioCapture(on) {
  playbackHold = on;
  if (on) killChild();
  else if (digitalWanted) void beginDigitalCapture();
}
function arecordBin() {
  if (existsSync9("/usr/bin/arecord")) return "/usr/bin/arecord";
  return "arecord";
}
function sendJson(ws, body) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(body));
}
function killChild() {
  captureOwner = null;
  captureKind = null;
  announced = false;
  const child2 = capture;
  capture = null;
  if (!child2) return;
  child2.kill("SIGTERM");
  const timer = setTimeout(() => {
    if (child2.exitCode == null && child2.signalCode == null) {
      try {
        child2.kill("SIGKILL");
      } catch {
      }
    }
  }, 300);
  child2.once("close", () => clearTimeout(timer));
}
function stopSocketCapture() {
  if (captureKind === "digital") return;
  killChild();
  if (digitalWanted && !playbackHold) {
    setTimeout(() => {
      if (digitalWanted && !playbackHold && !capture) void beginDigitalCapture();
    }, 200);
  }
}
async function listCapture() {
  if (process.platform !== "linux") return "";
  return await new Promise((resolve) => {
    const child2 = spawn4(arecordBin(), ["-l"], { stdio: ["ignore", "pipe", "pipe"] });
    const out = [];
    const timer = setTimeout(() => {
      child2.kill("SIGTERM");
    }, 4e3);
    child2.stdout.on("data", (chunk) => out.push(chunk));
    child2.on("error", () => {
      clearTimeout(timer);
      resolve("");
    });
    child2.on("close", () => {
      clearTimeout(timer);
      resolve(Buffer.concat(out).toString("utf8"));
    });
  });
}
function releaseStaleCapture() {
  if (captureOwner && captureOwner.readyState !== WebSocket.OPEN) stopSocketCapture();
  if (captureReserved && captureReserved !== "digital" && captureReserved.readyState !== WebSocket.OPEN) captureReserved = null;
}
function fanPcm(chunk) {
  pcmSink?.(chunk);
  if (captureOwner && captureOwner.readyState === WebSocket.OPEN) captureOwner.send(chunk);
  for (const ws of taps) {
    if (ws.readyState === WebSocket.OPEN) ws.send(chunk);
  }
}
function fanFormat() {
  if (captureOwner) sendJson(captureOwner, FORMAT);
  for (const ws of taps) sendJson(ws, FORMAT);
}
function attachTap(ws) {
  taps.add(ws);
  if (announced) sendJson(ws, FORMAT);
  ws.on("close", () => {
    taps.delete(ws);
  });
}
async function spawnCapture(kind, owner) {
  const listing = await listCapture();
  if (playbackHold) return "none";
  if (capture) return "none";
  const hit = pickAlsaCapture(listing);
  if (!hit) return "none";
  const child2 = spawn4(
    arecordBin(),
    ["-D", `plughw:${hit.card},${hit.device}`, "-f", "S16_LE", "-r", "48000", "-c", "1", "-t", "raw"],
    { stdio: ["ignore", "pipe", "pipe"] }
  );
  capture = child2;
  captureKind = kind;
  captureOwner = owner;
  announced = false;
  captureFault = null;
  const fail = (reason) => {
    captureFault = "none";
    if (owner && owner.readyState === WebSocket.OPEN) sendJson(owner, { type: "error", reason });
    if (capture === child2) killChild();
    if (owner && owner.readyState === WebSocket.OPEN) owner.close();
  };
  child2.on("error", () => fail("no-device"));
  child2.stderr.on("data", (chunk) => {
    const text = chunk.toString("utf8");
    if (/audio open error|não encontrado|No such file|Permission denied/i.test(text)) fail("no-device");
  });
  child2.stdout.on("data", (chunk) => {
    if (!announced) {
      announced = true;
      fanFormat();
    }
    fanPcm(chunk);
  });
  child2.on("close", () => {
    if (capture !== child2) return;
    capture = null;
    captureOwner = null;
    captureKind = null;
    announced = false;
    if (owner && owner.readyState === WebSocket.OPEN) owner.close();
    if (digitalWanted && !playbackHold && captureFault !== "none") {
      setTimeout(() => {
        if (digitalWanted && !playbackHold && !capture && captureFault !== "none") void beginDigitalCapture();
      }, 500);
    }
  });
  return "on";
}
async function beginDigitalCapture() {
  digitalWanted = true;
  if (playbackHold) return "busy";
  if (capture && captureKind === "digital") return "on";
  if (capture && captureKind === "socket") {
    captureKind = "digital";
    if (captureOwner) {
      taps.add(captureOwner);
      captureOwner = null;
    }
    return "on";
  }
  if (captureReserved) return "busy";
  captureReserved = "digital";
  try {
    const started = await spawnCapture("digital", null);
    if (started === "on") return "on";
    if (capture && captureKind === "socket") {
      captureKind = "digital";
      if (captureOwner) {
        taps.add(captureOwner);
        captureOwner = null;
      }
      return "on";
    }
    return started === "none" && capture ? "busy" : started;
  } finally {
    if (captureReserved === "digital") captureReserved = null;
  }
}
function endDigitalCapture() {
  digitalWanted = false;
  for (const ws of taps) {
    if (ws.readyState === WebSocket.OPEN) ws.close();
  }
  taps.clear();
  killChild();
}
async function bindRadioAudio(ws) {
  releaseStaleCapture();
  if (playbackHold) {
    sendJson(ws, { type: "error", reason: "busy" });
    ws.close();
    return;
  }
  if (digitalWanted || captureKind === "digital" || capture) {
    attachTap(ws);
    return;
  }
  captureReserved = ws;
  let gone = ws.readyState !== WebSocket.OPEN;
  ws.on("close", () => {
    gone = true;
    if (captureReserved === ws) captureReserved = null;
    if (captureOwner === ws) stopSocketCapture();
  });
  if (gone || ws.readyState !== WebSocket.OPEN) {
    if (captureReserved === ws) captureReserved = null;
    return;
  }
  const started = await spawnCapture("socket", ws);
  if (captureReserved === ws) captureReserved = null;
  if (gone || ws.readyState !== WebSocket.OPEN) {
    if (captureOwner === ws) stopSocketCapture();
    return;
  }
  if (started === "none") {
    sendJson(ws, { type: "error", reason: capture ? "busy" : "no-device" });
    ws.close();
  }
}
function attachRadioAudio(server) {
  if (attached.has(server)) return;
  attached.add(server);
  const wss = new WebSocketServer({ noServer: true });
  server.on("upgrade", (req, socket, head) => {
    const path5 = req.url?.split("?")[0];
    if (path5 !== "/ws/radio-audio") return;
    if (!consoleSessionOk(req.headers.cookie)) {
      socket.write("HTTP/1.1 401 Unauthorized\r\nConnection: close\r\n\r\n");
      socket.destroy();
      return;
    }
    wss.handleUpgrade(req, socket, head, (ws) => {
      void bindRadioAudio(ws);
    });
  });
}

// server/digital-decode.ts
import { spawn as spawn5 } from "node:child_process";
import { existsSync as existsSync10 } from "node:fs";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
var LINE = /^(\d{6})\s+([+-]?\d+(?:\.\d+)?)\s+([+-]?\d+(?:\.\d+)?)\s+(\d+)\s+~\s+(.+)$/;
function decodeBin() {
  return process.env.FT8_DECODE || "/opt/ham-cockpit/bin/decode_ft8";
}
function parseDecodeLines(text) {
  const out = [];
  for (const raw of text.split(/\r?\n/)) {
    const m = LINE.exec(raw.trim());
    if (!m) continue;
    const message = m[5].trim();
    if (!message || message.startsWith("Error [")) continue;
    const db = Number(m[2]);
    const dt = Number(m[3]);
    const hz = Number(m[4]);
    if (!Number.isFinite(db) || !Number.isFinite(dt) || !Number.isFinite(hz)) continue;
    out.push({ db, dt, hz, message });
  }
  return out;
}
function wavPcm16(pcm, rate) {
  const header = Buffer.alloc(44);
  header.write("RIFF", 0);
  header.writeUInt32LE(36 + pcm.length, 4);
  header.write("WAVE", 8);
  header.write("fmt ", 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20);
  header.writeUInt16LE(1, 22);
  header.writeUInt32LE(rate, 24);
  header.writeUInt32LE(rate * 2, 28);
  header.writeUInt16LE(2, 32);
  header.writeUInt16LE(16, 34);
  header.write("data", 36);
  header.writeUInt32LE(pcm.length, 40);
  return Buffer.concat([header, pcm]);
}
function runBin(bin, args, timeoutMs) {
  return new Promise((resolve, reject) => {
    const child2 = spawn5(bin, args, { stdio: ["ignore", "pipe", "pipe"] });
    const out = [];
    const timer = setTimeout(() => {
      child2.kill("SIGTERM");
    }, timeoutMs);
    child2.stdout.on("data", (chunk) => out.push(chunk));
    child2.on("error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
    child2.on("close", (code) => {
      clearTimeout(timer);
      resolve({ code: code ?? 1, stdout: Buffer.concat(out).toString("utf8") });
    });
  });
}
async function decodeSlot(mode, pcm) {
  const bin = decodeBin();
  if (!existsSync10(bin)) return { ran: false, lines: [] };
  const dir = await mkdtemp(path.join(tmpdir(), "hc-ft8-"));
  const wav = path.join(dir, "slot.wav");
  try {
    await writeFile(wav, wavPcm16(pcm, 12e3));
    const args = mode === "FT4" ? ["-ft4", wav] : [wav];
    const result = await runBin(bin, args, 25e3);
    return { ran: true, lines: parseDecodeLines(result.stdout) };
  } catch {
    return { ran: false, lines: [] };
  } finally {
    await rm(dir, { recursive: true, force: true }).catch(() => void 0);
  }
}

// client/src/console/digital-modes-model.ts
function periodAt(ms, mode) {
  const d = new Date(ms);
  const sec = d.getUTCHours() * 3600 + d.getUTCMinutes() * 60 + d.getUTCSeconds() + d.getUTCMilliseconds() / 1e3;
  const period = mode === "FT8" ? 15 : 7.5;
  const index = Math.floor(sec / period);
  const elapsed = sec - index * period;
  const trim = (n) => {
    const s = n.toFixed(1);
    return s.endsWith(".0") ? s.slice(0, -2) : s;
  };
  return { period, index, elapsed, even: index % 2 === 0, label: `${trim(elapsed)}/${trim(period)}` };
}

// client/src/console/digital-spectrum.ts
function fftInPlace(re, im) {
  const n = re.length;
  if (n <= 1) return;
  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) {
      const tr = re[i];
      re[i] = re[j];
      re[j] = tr;
      const ti = im[i];
      im[i] = im[j];
      im[j] = ti;
    }
  }
  for (let len = 2; len <= n; len <<= 1) {
    const ang = -2 * Math.PI / len;
    const wlenRe = Math.cos(ang);
    const wlenIm = Math.sin(ang);
    const half = len >> 1;
    for (let i = 0; i < n; i += len) {
      let wRe = 1;
      let wIm = 0;
      for (let k = 0; k < half; k++) {
        const even = i + k;
        const odd = even + half;
        const tRe = wRe * re[odd] - wIm * im[odd];
        const tIm = wRe * im[odd] + wIm * re[odd];
        re[odd] = re[even] - tRe;
        im[odd] = im[even] - tIm;
        re[even] = re[even] + tRe;
        im[even] = im[even] + tIm;
        const nextRe = wRe * wlenRe - wIm * wlenIm;
        wIm = wRe * wlenIm + wIm * wlenRe;
        wRe = nextRe;
      }
    }
  }
}
function fftMag(time) {
  const n = time.length;
  const re = new Float32Array(n);
  const im = new Float32Array(n);
  re.set(time);
  fftInPlace(re, im);
  const mag = new Float32Array(n / 2);
  for (let i = 0; i < mag.length; i++) mag[i] = Math.hypot(re[i], im[i]);
  return mag;
}
function spectrumPeak(pcm, sampleRate, startHz, endHz, columns) {
  const n = pcm.length;
  const cols = new Float32Array(Math.max(1, columns));
  if (n < 16 || (n & n - 1) !== 0) return cols;
  const time = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const w = 0.5 * (1 - Math.cos(2 * Math.PI * i / (n - 1)));
    time[i] = (pcm[i] ?? 0) / 32768 * w;
  }
  const mag = fftMag(time);
  const span = Math.max(1, endHz - startHz);
  for (let c = 0; c < cols.length; c++) {
    const hz0 = startHz + span * c / cols.length;
    const hz1 = startHz + span * (c + 1) / cols.length;
    const i0 = Math.max(1, Math.floor(hz0 * n / sampleRate));
    const i1 = Math.min(mag.length - 1, Math.ceil(hz1 * n / sampleRate));
    let peak = 0;
    for (let i = i0; i <= i1; i++) if (mag[i] > peak) peak = mag[i];
    cols[c] = peak;
  }
  return cols;
}

// client/src/console/digital-pcm.ts
var CAPTURE_RATE = 48e3;
function periodSamples(mode) {
  return mode === "FT8" ? 18e4 : 9e4;
}
function periodSeconds(mode) {
  return mode === "FT8" ? 15 : 7.5;
}
function chunkStart(nowMs, samples2, rate = CAPTURE_RATE) {
  return nowMs - samples2 / rate * 1e3;
}
function trimChunks(chunks2, nowMs, keepMs = 22e3) {
  const cut = nowMs - keepMs;
  return chunks2.filter((c) => c.t0 + c.pcm.length / CAPTURE_RATE * 1e3 >= cut);
}
function periodAt12k(chunks2, startMs, mode) {
  const n = periodSamples(mode);
  const sum = new Float64Array(n);
  const count = new Uint16Array(n);
  let covered = 0;
  for (const chunk of chunks2) {
    const pcm = chunk.pcm;
    const base2 = Math.round((chunk.t0 - startMs) * CAPTURE_RATE / 1e3);
    for (let i = 0; i + 3 < pcm.length; i += 4) {
      const src = base2 + i;
      if (src < 0) continue;
      const idx = src >> 2;
      if (idx >= n) continue;
      const avg = ((pcm[i] ?? 0) + (pcm[i + 1] ?? 0) + (pcm[i + 2] ?? 0) + (pcm[i + 3] ?? 0)) / 4;
      if (count[idx] === 0) covered++;
      sum[idx] += avg;
      count[idx]++;
    }
  }
  if (covered < n * 0.7) return null;
  const out = new Int16Array(n);
  for (let i = 0; i < n; i++) {
    if (!count[i]) continue;
    const v = Math.round(sum[i] / count[i]);
    out[i] = v < -32768 ? -32768 : v > 32767 ? 32767 : v;
  }
  return out;
}
function pcmDbfs(pcm) {
  if (!pcm.length) return -120;
  let acc = 0;
  for (let i = 0; i < pcm.length; i++) {
    const v = (pcm[i] ?? 0) / 32768;
    acc += v * v;
  }
  return 20 * Math.log10(Math.sqrt(acc / pcm.length) + 1e-12);
}
function pcmLevel(pcm) {
  const db = pcmDbfs(pcm);
  const norm = (db + 55) / 40;
  return norm < 0 ? 0 : norm > 1 ? 1 : norm;
}
function utcStamp(ms) {
  const d = new Date(ms);
  const p = (n) => String(n).padStart(2, "0");
  return `${p(d.getUTCHours())}${p(d.getUTCMinutes())}${p(d.getUTCSeconds())}`;
}
function rowsFromDecode(lines, startMs, even) {
  const utc = utcStamp(startMs);
  const out = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const message = line.message.trim();
    if (!message || message.startsWith("Error [")) continue;
    out.push({
      id: `${utc}-${Math.round(line.hz)}-${i}-${message}`,
      utc,
      db: Math.round(line.db),
      dt: line.dt,
      hz: Math.round(line.hz),
      message,
      even
    });
  }
  return out;
}

// server/digital-rx-plan.ts
var DIGITAL_DATA_MODE = "PKTUSB";
function parseRigFreq(reply) {
  for (const raw of reply.split(/\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith("RPRT")) continue;
    if (!/^\d+(?:\.\d+)?$/.test(line)) continue;
    const hz = Math.round(Number(line));
    if (hz >= 1e5 && hz <= 5e8) return hz;
  }
  return null;
}
function parseRigMode(reply) {
  const lines = reply.split(/\n/).map((l) => l.trim()).filter((l) => l && !l.startsWith("RPRT"));
  const mode = (lines[0] || "").toUpperCase();
  if (!/^[A-Z0-9+-]{2,12}$/.test(mode)) return null;
  const width = Number(lines[1] ?? "0");
  return { mode, width: Number.isFinite(width) && width >= 0 ? Math.round(width) : 0 };
}
function enableRigCommands(hz) {
  return [`M ${DIGITAL_DATA_MODE} 0`, `F ${Math.round(hz)}`];
}
function tuneRigCommand(hz) {
  return `F ${Math.round(hz)}`;
}
function restoreRigCommands(saved6) {
  return [`F ${Math.round(saved6.hz)}`, `M ${saved6.mode} ${saved6.width}`];
}

// server/hamlib-hub.ts
init_equipment();
import { existsSync as existsSync11, mkdirSync as mkdirSync9, readFileSync as readFileSync9, renameSync as renameSync8, writeFileSync as writeFileSync9 } from "node:fs";
import { dirname as dirname9, join as join10 } from "node:path";
import { fileURLToPath as fileURLToPath9 } from "node:url";
import { Socket as Socket3 } from "node:net";
var ROOT8 = join10(dirname9(fileURLToPath9(import.meta.url)), "..");
var OPT_DIR8 = "/opt/ham-cockpit/equipment";
function dataDir8() {
  if (existsSync11("/opt/ham-cockpit")) {
    mkdirSync9(OPT_DIR8, { recursive: true });
    return OPT_DIR8;
  }
  const local = join10(ROOT8, "data", "equipment");
  mkdirSync9(local, { recursive: true });
  return local;
}
function bindingsPath() {
  return join10(dataDir8(), "bindings.json");
}
function writeAtomic6(file, body) {
  const tmp = `${file}.${process.pid}.tmp`;
  writeFileSync9(tmp, body, { encoding: "utf8" });
  renameSync8(tmp, file);
}
var bindings = [];
function load2() {
  try {
    const raw = JSON.parse(readFileSync9(bindingsPath(), "utf8"));
    if (!Array.isArray(raw.bindings)) {
      bindings = [];
      return;
    }
    bindings = raw.bindings.map((b) => sanitizeBinding(b)).filter(Boolean);
  } catch {
    bindings = [];
  }
}
function persist7() {
  writeAtomic6(bindingsPath(), `${JSON.stringify({ bindings }, null, 2)}
`);
}
function newId3() {
  return Math.random().toString(16).slice(2, 10);
}
function sanitizeBinding(raw) {
  const equipmentId = String(raw.equipmentId || "").trim();
  if (!equipmentId || !getEquipment(equipmentId)) return null;
  return {
    id: String(raw.id || newId3()),
    equipmentId,
    connectionKind: raw.connectionKind || "usb-serial",
    host: raw.host ? String(raw.host).trim() : void 0,
    ports: raw.ports,
    ser2netPort: raw.ser2netPort != null ? Number(raw.ser2netPort) : void 0,
    baud: raw.baud != null ? Number(raw.baud) : void 0,
    civAddr: raw.civAddr ? String(raw.civAddr).trim() : void 0,
    username: raw.username ? String(raw.username) : void 0,
    password: raw.password ? String(raw.password) : void 0,
    hamlibListenPort: raw.hamlibListenPort != null ? Number(raw.hamlibListenPort) : void 0,
    label: raw.label ? String(raw.label).trim() : void 0,
    enabled: raw.enabled !== false
  };
}
load2();
function buildPlans() {
  return bindings.filter((b) => b.enabled).map((b) => {
    const plan = planHamlib(b);
    if (!plan) return null;
    return {
      ...plan,
      bindingId: b.id,
      command: formatRigctldCommand(plan)
    };
  }).filter(Boolean);
}
function hubCatalog(maker) {
  const list = maker ? EQUIPMENT_CATALOG.filter((e) => e.maker === maker) : EQUIPMENT_CATALOG;
  return {
    ok: true,
    makers: Array.from(new Set(EQUIPMENT_CATALOG.map((e) => e.maker))),
    hamlibReady: listHamlibReady().map((e) => e.id),
    equipment: list
  };
}
function hubStatus() {
  return {
    ok: true,
    folder: dataDir8(),
    catalogCount: EQUIPMENT_CATALOG.length,
    hamlibReadyCount: listHamlibReady().length,
    bindings,
    plans: buildPlans()
  };
}
function hubSaveBindings(body) {
  if (Array.isArray(body.bindings)) {
    bindings = body.bindings.map((b) => sanitizeBinding(b)).filter(Boolean);
    persist7();
  }
  return hubStatus();
}
function hubUpsertBinding(raw) {
  const next = sanitizeBinding(raw);
  if (!next) {
    const snap5 = hubStatus();
    snap5.ok = false;
    snap5.error = "equipmentId inv\xE1lido ou ausente no cat\xE1logo";
    return snap5;
  }
  const idx = bindings.findIndex((b) => b.id === next.id);
  if (idx >= 0) bindings[idx] = { ...bindings[idx], ...next, id: bindings[idx].id };
  else bindings.push(next);
  persist7();
  return hubStatus();
}
function hubRemoveBinding(id) {
  bindings = bindings.filter((b) => b.id !== id);
  persist7();
  return hubStatus();
}
function hubPlanOne(raw) {
  const equipmentId = String(raw.equipmentId || "").trim();
  if (!equipmentId || !getEquipment(equipmentId)) {
    return { ok: false, plan: null, error: "equipmentId inv\xE1lido" };
  }
  const plan = planHamlib({
    equipmentId,
    connectionKind: raw.connectionKind || "usb-serial",
    host: raw.host,
    ports: raw.ports,
    ser2netPort: raw.ser2netPort,
    baud: raw.baud,
    civAddr: raw.civAddr,
    hamlibListenPort: raw.hamlibListenPort
  });
  if (!plan) return { ok: false, plan: null, error: "falha ao montar plano" };
  return { ok: plan.ready, plan, command: formatRigctldCommand(plan), error: plan.deferReason };
}
var lanes = /* @__PURE__ */ new Map();
function laneFor(host2, port) {
  const key = `${host2}:${port}`;
  let lane = lanes.get(key);
  if (!lane) {
    lane = {
      host: host2,
      port,
      sock: null,
      buf: "",
      lines: [],
      queue: [],
      pumping: false,
      current: null,
      power: "unknown",
      idle: null,
      hard: null,
      caller: null,
      txnDone: null,
      skip: false,
      priorityWaiting: 0,
      currentSince: 0
    };
    lanes.set(key, lane);
  }
  return lane;
}
function isPollCommand(command) {
  const c = command.trim();
  if (c.startsWith("\\get_") || c.startsWith("get_")) return true;
  return c === "f" || c === "m" || c === "t" || c === "v" || c === "s" || c === "l";
}
function isPttCommand(command) {
  return /^T\s+[01]$/.test(command.trim());
}
function isSmeterPoll(command) {
  return /^\\?get_level\s+strength\b/i.test(command.trim());
}
function isChipRead(command) {
  const c = command.trim();
  return c === "f" || c === "m" || c === "t";
}
function rigCommandAdmission(command, laneBusy, queueLength, power = "unknown", priority = false, currentCommand = "") {
  if (!priority && power === "off" && isPollCommand(command)) return "ocupado";
  if (!priority && isSmeterPoll(command)) {
    if (laneBusy && isSmeterPoll(currentCommand)) return "ocupado";
    return "ok";
  }
  if (!priority && isChipRead(command)) {
    if (queueLength >= 2) return "ocupado";
    return "ok";
  }
  if (!priority && isPollCommand(command) && (laneBusy || queueLength > 0)) {
    if (queueLength > 0) return "ocupado";
  }
  if (!isPollCommand(command) && queueLength >= 4) return "fila cheia";
  return "ok";
}
function rewriteIc705PowerOn(command, radio) {
  const c = command.trim();
  if (!/^\\set_powerstat\s+1$/i.test(c)) return command;
  if (!radio) return command;
  if (radio.hamlibModel !== 3085 && radio.equipmentId !== "icom-ic-705") return command;
  const addr = (normalizeCivAddr(radio.civAddr) || "0xA4").slice(2);
  return `\\send_raw icom 0xFE:0xFE:0x${addr}:0xE0:0x18:0x01:0xFD`;
}
function isRigWake(command) {
  const c = command.trim();
  if (/^\\set_powerstat\s+1$/i.test(c)) return true;
  return /\\send_raw\b/i.test(c) && /0x18:0x01\b/i.test(c);
}
function rememberPower(lane, command, value) {
  const c = command.trim();
  if (/^\\get_powerstat\b/i.test(c)) {
    if (!value.ok) return;
    const line = value.reply.split("\n").map((s) => s.trim()).find((s) => s && !s.startsWith("RPRT")) || "";
    if (line === "1" || /^on$/i.test(line)) lane.power = "on";
    else if (line === "0" || line === "2" || /off|standby/i.test(line)) lane.power = "off";
    return;
  }
  if (!value.ok) return;
  if (/^\\set_powerstat\s+0$/i.test(c)) lane.power = "off";
  else if (/^\\set_powerstat\s+1$/i.test(c)) lane.power = "on";
  else if (/\\send_raw\b/i.test(c) && /0x18:0x00\b/i.test(c)) lane.power = "off";
  else if (/\\send_raw\b/i.test(c) && /0x18:0x02\b/i.test(c)) lane.power = "off";
  else if (/\\send_raw\b/i.test(c) && /0x18:0x01\b/i.test(c)) lane.power = "on";
}
function releaseQueuedPolls(lane) {
  if (!lane.queue.length) return;
  const keep = [];
  for (const job2 of lane.queue) {
    if (isPollCommand(job2.command)) settle(job2, { ok: false, reply: "", error: "ocupado" });
    else keep.push(job2);
  }
  lane.queue = keep;
}
function releaseSlowMeter(lane) {
  const job2 = lane.current;
  if (!job2 || !isSmeterPoll(job2.command)) return;
  const age = lane.currentSince ? Date.now() - lane.currentSince : 0;
  if (!job2.settled && age < 500) return;
  preemptStalePoll(lane);
}
function preemptStalePoll(lane) {
  const job2 = lane.current;
  const meter = Boolean(job2 && isSmeterPoll(job2.command));
  if (job2 && isPollCommand(job2.command)) {
    const written = Boolean(lane.txnDone);
    job2.drop = true;
    if (!job2.settled) settle(job2, { ok: false, reply: "", error: meter ? "ocupado" : "timeout" });
    if (written && !lane.skip) lane.skip = true;
    finishTxn(lane, null);
  }
}
function settle(job2, value) {
  if (job2.settled) return;
  job2.settled = true;
  job2.resolve(value);
}
function classifyReply(text) {
  const lines = text.split("\n").map((l) => l.trim()).filter(Boolean);
  const bad = lines.find((l) => /^RPRT\s+-\d+/.test(l));
  if (bad) {
    const code = Number(bad.slice(4).trim());
    if (code === -5 || code === -11) return { ok: false, reply: lines.join("\n"), error: "timeout" };
    return { ok: false, reply: lines.join("\n"), error: bad };
  }
  if (!lines.length) return { ok: false, reply: "", error: "resposta vazia" };
  return { ok: true, reply: lines.join("\n") };
}
function clearLaneTimers(lane) {
  if (lane.idle) clearTimeout(lane.idle);
  if (lane.hard) clearTimeout(lane.hard);
  if (lane.caller) clearTimeout(lane.caller);
  lane.idle = null;
  lane.hard = null;
  lane.caller = null;
}
function finishTxn(lane, value) {
  const done = lane.txnDone;
  if (!done && !lane.current) return;
  const job2 = lane.current;
  clearLaneTimers(lane);
  lane.txnDone = null;
  lane.current = null;
  lane.currentSince = 0;
  lane.lines = [];
  lane.buf = "";
  if (job2 && value) {
    rememberPower(lane, job2.command, value);
    settle(job2, value);
    if (value.ok) {
      const c = job2.command.trim();
      if (c === "f" || c === "m" || c === "t") {
        console.log(`civ ${c.split(/\s+/)[0]} ${value.reply.split("\n")[0]}`);
      }
    }
  }
  if (done) done();
}
function dropSock3(lane) {
  const sock3 = lane.sock;
  lane.sock = null;
  if (!sock3) return;
  sock3.removeAllListeners();
  try {
    sock3.destroy();
  } catch {
  }
}
function pullLines(lane) {
  while (true) {
    const i = lane.buf.indexOf("\n");
    if (i < 0) break;
    const line = lane.buf.slice(0, i).replace(/\r$/, "").trim();
    lane.buf = lane.buf.slice(i + 1);
    if (line) lane.lines.push(line);
  }
}
function readLinesReady(command, lines) {
  const c = command.trim();
  const body = lines.filter((l) => !l.startsWith("RPRT"));
  if (c === "f") return body.some((l) => /^\d+(?:\.\d+)?$/.test(l));
  if (c === "m") {
    const hasMode = body.some((l) => /^[A-Za-z][A-Za-z0-9_-]*$/.test(l));
    const hasWidth = body.some((l) => /^\d+$/.test(l));
    return hasMode && hasWidth;
  }
  if (c === "t") return body.some((l) => l === "0" || l === "1");
  if (/^\\?get_powerstat\b/i.test(c)) return body.some((l) => /^(0|1|2|on|off|standby)$/i.test(l));
  if (isSmeterPoll(c)) return body.some((l) => /^-?\d+(?:\.\d+)?$/.test(l));
  return false;
}
function onLaneData(lane, chunk) {
  lane.buf += chunk;
  if (lane.skip || lane.current) pullLines(lane);
  if (lane.skip) {
    if (lane.lines.some((l) => l.startsWith("RPRT"))) {
      lane.skip = false;
      lane.buf = "";
      lane.lines = [];
    }
    return;
  }
  if (!lane.current) {
    if (lane.buf.length > 4096) lane.buf = "";
    return;
  }
  if (lane.lines.some((l) => l.startsWith("RPRT"))) {
    finishTxn(lane, classifyReply(lane.lines.join("\n")));
    return;
  }
  const job2 = lane.current;
  if (!job2.settled && readLinesReady(job2.command, lane.lines)) {
    const reply = lane.lines.filter((l) => !l.startsWith("RPRT")).join("\n");
    const rprtSeen = lane.lines.some((l) => l.startsWith("RPRT"));
    settle(job2, { ok: true, reply });
    lane.skip = !rprtSeen;
    finishTxn(lane, null);
  }
}
async function waitSkip(lane, job2) {
  const start = Date.now();
  while (lane.skip && lane.sock && !lane.sock.destroyed) {
    if (job2.drop || lane.current !== job2) return;
    const limit = 120;
    if (Date.now() - start > limit) {
      lane.skip = false;
      lane.buf = "";
      lane.lines = [];
      return;
    }
    await new Promise((r) => setTimeout(r, 40));
  }
}
function ensureSock(lane) {
  if (lane.sock && !lane.sock.destroyed) return Promise.resolve();
  dropSock3(lane);
  return new Promise((resolve, reject) => {
    const sock3 = new Socket3();
    let opened2 = false;
    const fail = (err) => {
      if (opened2) return;
      opened2 = true;
      clearTimeout(timer);
      sock3.removeAllListeners();
      sock3.destroy();
      if (lane.sock === sock3) lane.sock = null;
      reject(err);
    };
    const timer = setTimeout(() => fail(new Error("timeout na conex\xE3o")), 2e3);
    sock3.on("error", (err) => {
      if (!opened2) fail(err);
      else if (lane.current) finishTxn(lane, { ok: false, reply: "", error: err.message });
      else if (lane.sock === sock3) lane.sock = null;
    });
    sock3.on("close", () => {
      if (lane.sock === sock3) lane.sock = null;
      if (lane.current) finishTxn(lane, { ok: false, reply: lane.lines.join("\n"), error: "conex\xE3o fechada" });
    });
    sock3.setEncoding("utf8");
    sock3.setNoDelay(true);
    sock3.on("data", (chunk) => onLaneData(lane, chunk.toString()));
    sock3.connect(lane.port, lane.host, () => {
      if (opened2) return;
      opened2 = true;
      clearTimeout(timer);
      lane.sock = sock3;
      resolve();
    });
  });
}
async function runJob(lane, job2) {
  lane.current = job2;
  lane.currentSince = Date.now();
  await waitSkip(lane, job2);
  if (job2.drop || job2.settled) {
    if (lane.current === job2) {
      lane.current = null;
      lane.currentSince = 0;
    }
    settle(job2, { ok: false, reply: "", error: "ocupado" });
    return;
  }
  lane.lines = [];
  lane.buf = "";
  try {
    await ensureSock(lane);
  } catch (err) {
    if (lane.current === job2) lane.current = null;
    settle(job2, { ok: false, reply: "", error: err instanceof Error ? err.message : String(err) });
    return;
  }
  if (!lane.sock) {
    if (lane.current === job2) lane.current = null;
    settle(job2, { ok: false, reply: "", error: "sem socket" });
    return;
  }
  await new Promise((done) => {
    lane.txnDone = done;
    lane.current = job2;
    lane.currentSince = Date.now();
    lane.caller = setTimeout(() => {
      lane.caller = null;
      if (lane.current !== job2) return;
      settle(job2, { ok: false, reply: "", error: "timeout" });
      lane.skip = true;
      finishTxn(lane, null);
    }, job2.timeoutMs);
    lane.hard = setTimeout(() => {
      lane.hard = null;
      lane.skip = true;
      finishTxn(lane, job2.settled ? null : { ok: false, reply: "", error: "timeout" });
    }, job2.timeoutMs + 200);
    lane.sock.write(job2.command);
  });
}
function pump(lane) {
  if (lane.pumping) return;
  lane.pumping = true;
  void (async () => {
    try {
      while (lane.queue.length) {
        const job2 = lane.queue.shift();
        if (!job2) break;
        await runJob(lane, job2);
      }
    } finally {
      lane.pumping = false;
      if (lane.queue.length) pump(lane);
    }
  })();
}
function hubRigctl(listenPort, command, host2 = "127.0.0.1", timeoutMs = 900, preempt = false) {
  const cmd = command.trim().endsWith("\n") ? command.trim() : `${command.trim()}
`;
  const lane = laneFor(host2, listenPort);
  return new Promise((resolve) => {
    if (preempt || !isPollCommand(cmd)) releaseQueuedPolls(lane);
    if (preempt) preemptStalePoll(lane);
    else if (isChipRead(cmd)) releaseSlowMeter(lane);
    if (isRigWake(cmd)) {
      releaseQueuedPolls(lane);
      if (lane.current && isPollCommand(lane.current.command)) {
        const job3 = lane.current;
        job3.drop = true;
        dropSock3(lane);
        finishTxn(lane, job3.settled ? null : { ok: false, reply: "", error: "ocupado" });
      }
    }
    if (!preempt && isSmeterPoll(cmd)) {
      const meterNow = Boolean(lane.current && isSmeterPoll(lane.current.command));
      const meterWait = lane.queue.some((job3) => isSmeterPoll(job3.command));
      if (meterNow || meterWait) {
        resolve({ ok: false, reply: "", error: "ocupado" });
        return;
      }
    }
    const admission = rigCommandAdmission(
      cmd,
      Boolean(lane.current),
      isSmeterPoll(cmd) ? 0 : lane.queue.length,
      lane.power,
      preempt,
      lane.current?.command ?? ""
    );
    if (admission === "ocupado") {
      resolve({ ok: false, reply: "", error: "ocupado" });
      return;
    }
    if (admission === "fila cheia") {
      resolve({ ok: false, reply: "", error: "fila cheia" });
      return;
    }
    if (preempt) lane.priorityWaiting += 1;
    const job2 = {
      command: cmd,
      timeoutMs,
      settled: false,
      priority: preempt,
      drop: false,
      resolve: (value) => {
        if (preempt) lane.priorityWaiting = Math.max(0, lane.priorityWaiting - 1);
        resolve(value);
      }
    };
    if (!preempt && isSmeterPoll(cmd) || preempt && isPttCommand(cmd)) lane.queue.unshift(job2);
    else lane.queue.push(job2);
    pump(lane);
  });
}

// shared/digital-waterfall.ts
var WF_AVG_DEFAULT = 5;
var WF_COLS = 160;
var WF_START_HZ = 0;
var WF_END_HZ = 4e3;
var WF_NSPS = 6912;
var WF_SPEC_RATE = 12e3;
var WF_SPEC_STEP = WF_NSPS / 2;
var WF_SPEC_MS = WF_SPEC_STEP / WF_SPEC_RATE * 1e3;
var WF_SAMPLE_RATE = 48e3;
var WF_HOP = WF_SPEC_STEP * (WF_SAMPLE_RATE / WF_SPEC_RATE);
var WF_FFT = 16384;
var WF_WINDOW_MS = 6 * 60 * 1e3;
var WF_MAX_STRIPES = 4800;
var DB_LO = -140;
var DB_HI = 20;
var B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
function quantizeDb(db) {
  if (!Number.isFinite(db) || db < -120) return 0;
  const t = (Math.min(DB_HI, db) - DB_LO) / (DB_HI - DB_LO);
  return Math.max(1, Math.min(255, Math.round(t * 255)));
}
function dbOfPeak(peak, fftN = WF_FFT) {
  return 20 * Math.log10(peak / (fftN / 2) + 1e-12);
}
function encodeCols(cols) {
  let out = "";
  for (let i = 0; i < cols.length; i += 3) {
    const a = cols[i] ?? 0;
    const b = i + 1 < cols.length ? cols[i + 1] : 0;
    const c = i + 2 < cols.length ? cols[i + 2] : 0;
    const n = a << 16 | b << 8 | c;
    out += B64[n >> 18 & 63] + B64[n >> 12 & 63];
    out += i + 1 < cols.length ? B64[n >> 6 & 63] : "=";
    out += i + 2 < cols.length ? B64[n & 63] : "=";
  }
  return out;
}
function createFallLog(opts) {
  const windowMs = opts?.windowMs ?? WF_WINDOW_MS;
  const max = opts?.max ?? WF_MAX_STRIPES;
  let avg = WF_AVG_DEFAULT;
  let gen = 1;
  let seq = 0;
  let count = 0;
  let sum = null;
  let wrapped = false;
  let lastIndex2 = null;
  const stripes = [];
  const trim = (nowMs) => {
    const cutoff = nowMs - windowMs;
    while (stripes.length && (stripes[0].t < cutoff || stripes.length > max)) stripes.shift();
  };
  return {
    setAvg(n) {
      if (!Number.isFinite(n)) return;
      const next = Math.max(1, Math.min(99, Math.round(n)));
      if (next === avg) return;
      avg = next;
      count = 0;
      sum = null;
    },
    avg: () => avg,
    gen: () => gen,
    clear() {
      stripes.length = 0;
      count = 0;
      sum = null;
      wrapped = false;
      lastIndex2 = null;
      seq = 0;
      gen += 1;
    },
    push(peaks, nowMs, periodIndex) {
      if (lastIndex2 == null) lastIndex2 = periodIndex;
      else if (periodIndex !== lastIndex2) {
        wrapped = true;
        lastIndex2 = periodIndex;
      }
      if (!sum || sum.length !== peaks.length) {
        sum = new Float32Array(peaks.length);
        count = 0;
      }
      if (count === 0) sum.set(peaks);
      else for (let i = 0; i < peaks.length; i++) sum[i] = (sum[i] ?? 0) + (peaks[i] ?? 0);
      count += 1;
      if (count < avg) return null;
      const cols = new Uint8Array(peaks.length);
      for (let i = 0; i < peaks.length; i++) cols[i] = quantizeDb(dbOfPeak((sum[i] ?? 0) / count));
      count = 0;
      const stripe = { seq: seq += 1, t: nowMs, cycle: wrapped, cols };
      wrapped = false;
      stripes.push(stripe);
      trim(nowMs);
      return stripe;
    },
    since(after) {
      if (!(after > 0)) return stripes.slice();
      return stripes.filter((row) => row.seq > after);
    },
    payload(after) {
      return {
        ok: true,
        gen,
        avg,
        startHz: WF_START_HZ,
        endHz: WF_END_HZ,
        stripes: this.since(after).map((row) => ({
          seq: row.seq,
          t: row.t,
          cycle: row.cycle,
          cols: encodeCols(row.cols)
        }))
      };
    }
  };
}

// server/digital-rx.ts
var PORT = 4532;
var HOST = "127.0.0.1";
var session = {
  enabled: false,
  mode: "FT8",
  hz: 0,
  band: "",
  dialId: "",
  dataMode: "",
  phase: "off",
  level: 0,
  dbfs: -120,
  decode: null,
  rows: [],
  saved: null
};
var chunks = [];
var lastIndex = null;
var decoding = false;
var pending = null;
var tail = Promise.resolve();
var fall = createFallLog();
var hop = new Int16Array(WF_HOP);
var hopFill = 0;
var frameStart = 0;
var frameOpen = false;
var frameJobs = [];
var fftRunning = false;
function resetHop() {
  hopFill = 0;
  frameOpen = false;
  frameJobs.length = 0;
}
function resetAudio() {
  chunks = [];
  lastIndex = null;
  pending = null;
  resetHop();
}
function enqueueFrame(pcm, at, index) {
  if (frameJobs.length > 4) frameJobs.shift();
  frameJobs.push({ pcm, at, index });
  if (fftRunning) return;
  fftRunning = true;
  setImmediate(drainFrames);
}
function drainFrames() {
  const job2 = frameJobs.shift();
  if (!job2 || !session.enabled) {
    fftRunning = false;
    if (session.enabled && frameJobs.length) {
      fftRunning = true;
      setImmediate(drainFrames);
    }
    return;
  }
  try {
    const peaks = spectrumPeak(job2.pcm, WF_SAMPLE_RATE, WF_START_HZ, WF_END_HZ, WF_COLS);
    if (session.enabled) fall.push(peaks, job2.at, job2.index);
  } catch {
  }
  if (session.enabled && frameJobs.length) setImmediate(drainFrames);
  else fftRunning = false;
}
function feedHop(pcm, t0) {
  const mode = session.mode;
  for (let i = 0; i < pcm.length; i++) {
    if (!frameOpen) {
      frameStart = t0 + i / WF_SAMPLE_RATE * 1e3;
      frameOpen = true;
    }
    hop[hopFill++] = pcm[i] ?? 0;
    if (hopFill < WF_HOP) continue;
    const at = frameStart + WF_HOP / WF_SAMPLE_RATE * 1e3;
    const frame = new Int16Array(WF_FFT);
    frame.set(hop);
    hopFill = 0;
    frameOpen = false;
    enqueueFrame(frame, at, periodAt(at, mode).index);
  }
}
function snapshot(error3) {
  return {
    ok: !error3,
    enabled: session.enabled,
    mode: session.mode,
    hz: session.hz,
    band: session.band,
    dialId: session.dialId,
    dataMode: session.dataMode,
    phase: session.phase,
    level: session.level,
    dbfs: session.dbfs,
    decode: session.decode,
    rows: session.rows,
    error: error3
  };
}
function digitalRxSnapshot() {
  return snapshot();
}
async function rig2(command) {
  let last = { ok: false, reply: "", error: "ocupado" };
  const deadline = Date.now() + 18e3;
  for (let i = 0; i < 8; i++) {
    last = await hubRigctl(PORT, command, HOST, 900, true);
    if (last.ok) return last;
    if (last.error !== "ocupado" && last.error !== "timeout" && last.error !== "fila cheia") return last;
    if (Date.now() >= deadline) return last;
    await new Promise((r) => setTimeout(r, 400));
  }
  return last;
}
async function pauseRig() {
  await new Promise((r) => setTimeout(r, 400));
}
async function readSnap() {
  const freq = await rig2("f");
  if (!freq.ok) return { snap: null, error: freq.error || "r\xE1dio" };
  await pauseRig();
  const mode = await rig2("m");
  if (!mode.ok) return { snap: null, error: mode.error || "r\xE1dio" };
  const hz = parseRigFreq(freq.reply);
  const parsed = parseRigMode(mode.reply);
  if (hz == null || !parsed) return { snap: null, error: "r\xE1dio" };
  return { snap: { hz, mode: parsed.mode, width: parsed.width }, error: "" };
}
async function restore(saved6) {
  const [freq, mode] = restoreRigCommands(saved6);
  const f = await rig2(freq);
  const m = await rig2(mode);
  return f.ok && m.ok;
}
function remember(mode, hz, band, dialId) {
  session.mode = mode;
  session.hz = hz;
  session.band = band.slice(0, 24);
  session.dialId = dialId.slice(0, 80);
}
function validHz(hz) {
  return Number.isFinite(hz) && hz >= 1e5 && hz <= 5e8;
}
async function applyTune(mode, hz, band, dialId) {
  if (!session.enabled) return snapshot();
  return withSerialScopeQuiet(() => tuneNow(mode, hz, band, dialId));
}
async function tuneNow(mode, hz, band, dialId) {
  const cmd = tuneRigCommand(hz);
  const out = await rig2(cmd);
  if (!out.ok) return snapshot(out.error || "frequ\xEAncia");
  remember(mode, hz, band, dialId);
  resetAudio();
  console.log(`[digital] dial ${mode} ${hz} Hz`);
  return snapshot();
}
async function enable(mode, hz, band, dialId) {
  if (session.enabled) return applyTune(mode, hz, band, dialId);
  return withSerialScopeQuiet(() => enableNow(mode, hz, band, dialId));
}
async function enableNow(mode, hz, band, dialId) {
  const read2 = await readSnap();
  const saved6 = read2.snap;
  if (!saved6) {
    console.log(`[digital] escuta n\xE3o abriu: ${read2.error}`);
    return snapshot(read2.error);
  }
  const [setMode, setFreq] = enableRigCommands(hz);
  const modeOut = await rig2(setMode);
  if (!modeOut.ok) {
    console.log(`[digital] escuta n\xE3o abriu: ${modeOut.error || "modo"}`);
    return snapshot(modeOut.error || "modo");
  }
  await pauseRig();
  const freqOut = await rig2(setFreq);
  if (!freqOut.ok) {
    await restore(saved6);
    console.log(`[digital] escuta n\xE3o abriu: ${freqOut.error || "frequ\xEAncia"}`);
    return snapshot(freqOut.error || "frequ\xEAncia");
  }
  await pauseRig();
  const check = await rig2("m");
  if (!check.ok) {
    await restore(saved6);
    console.log(`[digital] escuta n\xE3o abriu: ${check.error || "modo"}`);
    return snapshot(check.error || "modo");
  }
  const measured = parseRigMode(check.reply);
  if (!measured || measured.mode !== DIGITAL_DATA_MODE) {
    await restore(saved6);
    const got = measured?.mode || "modo";
    console.log(`[digital] modo medido ${got}`);
    return snapshot(got);
  }
  session.saved = saved6;
  session.enabled = true;
  session.dataMode = measured.mode;
  remember(mode, hz, band, dialId);
  resetAudio();
  fall.clear();
  const cap = await beginDigitalCapture();
  session.phase = cap === "on" ? "on" : cap === "busy" ? "busy" : "none";
  session.level = 0;
  session.dbfs = -120;
  console.log(`[digital] escuta on ${mode} ${hz} Hz ${measured.mode} guardou ${saved6.hz} ${saved6.mode}`);
  return snapshot();
}
async function disable() {
  return withSerialScopeQuiet(() => disableNow());
}
async function disableNow() {
  const saved6 = session.saved;
  session.enabled = false;
  session.phase = "off";
  session.dataMode = "";
  session.saved = null;
  session.level = 0;
  session.dbfs = -120;
  endDigitalCapture();
  resetAudio();
  fall.clear();
  if (!saved6) {
    console.log("[digital] escuta off");
    return snapshot();
  }
  const ok = await restore(saved6);
  console.log(`[digital] escuta off restaura ${saved6.hz} ${saved6.mode} ok=${ok}`);
  return ok ? snapshot() : snapshot("restaurar");
}
function clearRows() {
  session.rows = [];
  session.decode = null;
  return snapshot();
}
function digitalWaterfallSince(after) {
  return fall.payload(Number.isFinite(after) ? after : 0);
}
function digitalRxCommand(body) {
  const run6 = tail.then(() => runCommand(body), () => runCommand(body));
  tail = run6.then(
    () => void 0,
    () => void 0
  );
  return run6;
}
async function runCommand(body) {
  if (body.op === "disable") return disable();
  if (body.op === "clear") return clearRows();
  if (body.op === "navg") {
    fall.setAvg(Number(body.n));
    return snapshot();
  }
  const mode = body.mode === "FT4" ? "FT4" : "FT8";
  const hz = Math.round(Number(body.hz));
  if (!validHz(hz)) return snapshot("frequ\xEAncia");
  const band = String(body.band || "").slice(0, 24);
  const dialId = String(body.dialId || "").slice(0, 80);
  if (body.op === "tune") return applyTune(mode, hz, band, dialId);
  if (body.op === "enable") return enable(mode, hz, band, dialId);
  return snapshot("comando");
}
function onPcm(chunk) {
  if (!session.enabled || session.phase === "off") return;
  const bytes2 = chunk.length - chunk.length % 2;
  if (bytes2 < 2) return;
  const pcm = new Int16Array(bytes2 / 2);
  for (let i = 0; i < pcm.length; i++) pcm[i] = chunk.readInt16LE(i * 2);
  const now = Date.now();
  if (session.phase !== "on") session.phase = "on";
  session.dbfs = pcmDbfs(pcm);
  session.level = pcmLevel(pcm);
  const t0 = chunkStart(now, pcm.length);
  chunks.push({ t0, pcm });
  const kept = trimChunks(chunks, now);
  if (kept.length !== chunks.length) chunks = kept;
  feedHop(pcm, t0);
  const mode = session.mode;
  const mark = periodAt(now, mode);
  if (lastIndex == null) {
    lastIndex = mark.index;
    return;
  }
  if (lastIndex === mark.index) return;
  const currentStart = now - mark.elapsed * 1e3;
  const startMs = currentStart - periodSeconds(mode) * 1e3;
  const even = lastIndex % 2 === 0;
  lastIndex = mark.index;
  const slot = periodAt12k(chunks, startMs, mode);
  if (!slot) return;
  pending = { pcm: slot, mode, startMs, even };
  void pump2();
}
async function pump2() {
  if (decoding || !pending) return;
  const job2 = pending;
  pending = null;
  decoding = true;
  try {
    const pcm = Buffer.from(job2.pcm.buffer, job2.pcm.byteOffset, job2.pcm.byteLength);
    const out = await decodeSlot(job2.mode, pcm);
    if (!session.enabled) return;
    const rows = out.ran ? rowsFromDecode(out.lines, job2.startMs, job2.even) : [];
    if (rows.length) session.rows = [...session.rows, ...rows].slice(-300);
    session.decode = { ran: out.ran, count: rows.length };
    if (rows.length) console.log(`[digital] decode ${rows.length}`);
  } catch {
    if (session.enabled) session.decode = { ran: false, count: 0 };
  } finally {
    decoding = false;
    if (session.enabled && pending) void pump2();
  }
}
setRadioPcmSink(onPcm);

// server/digital-tx.ts
import { spawn as spawn6, execFile as execFile7 } from "node:child_process";
import { existsSync as existsSync12 } from "node:fs";
import { mkdtemp as mkdtemp2, readFile, rm as rm2 } from "node:fs/promises";
import { tmpdir as tmpdir2 } from "node:os";
import path2 from "node:path";

// shared/digital-slot.ts
function slotTiming(mode) {
  if (mode === "FT4") {
    return {
      period: 7.5,
      pttLead: 0.02,
      toneAt: 0.3,
      tone: 5.04,
      txEnd: 6.04,
      pttTail: 0.2,
      symbols: 105,
      samplesPerSymbol: 576
    };
  }
  return {
    period: 15,
    pttLead: 0.2,
    toneAt: 0.5,
    tone: 12.64,
    txEnd: 13.64,
    pttTail: 0.2,
    symbols: 79,
    samplesPerSymbol: 1920
  };
}
function playbackPlan(mode) {
  const slot = slotTiming(mode);
  const leadSilence = slot.toneAt;
  const trailSilence = slot.txEnd - (slot.toneAt + slot.tone);
  return {
    ...slot,
    leadSilence,
    trailSilence,
    pttDrop: slot.txEnd + slot.pttTail,
    toneSamples: slot.symbols * slot.samplesPerSymbol
  };
}
function playbackBytes(mode) {
  const plan = playbackPlan(mode);
  const lead = Math.round(plan.leadSilence * 48e3) * 2;
  const tone = plan.toneSamples * 8;
  const trail = Math.round(plan.trailSilence * 48e3) * 2;
  return { lead, tone, trail, total: lead + tone + trail };
}
function utcIntoPeriod(nowMs, period) {
  const d = new Date(nowMs);
  const sec = d.getUTCHours() * 3600 + d.getUTCMinutes() * 60 + d.getUTCSeconds() + d.getUTCMilliseconds() / 1e3;
  const index = Math.floor(sec / period);
  const elapsed = sec - index * period;
  return { index, elapsed, even: index % 2 === 0 };
}
function nextTxSlot(nowMs, mode, even) {
  const period = slotTiming(mode).period;
  const mark = utcIntoPeriod(nowMs, period);
  if (mark.even === even && mark.elapsed < 0.2) return nowMs - mark.elapsed * 1e3;
  let index = mark.index + 1;
  if (index % 2 === 0 !== even) index += 1;
  const currentStart = nowMs - mark.elapsed * 1e3;
  return currentStart + (index - mark.index) * period * 1e3;
}

// server/digital-tx.ts
var job = null;
var generation = 0;
var haltedGen = -1;
var player = null;
function cancelled(gen) {
  return gen !== generation || haltedGen === gen;
}
function encodeBin() {
  return process.env.FTX_ENCODE || "/opt/ham-cockpit/bin/ftx-encode";
}
function txSnapshot() {
  if (!job) return { phase: "idle", message: "", mode: "", ptt: false, error: "", startInMs: 0 };
  return {
    phase: job.phase,
    message: job.message,
    mode: job.mode,
    ptt: job.ptt,
    error: job.error,
    startInMs: Math.max(0, job.startAt - Date.now())
  };
}
function sleepUntil(at, gen) {
  return new Promise((resolve) => {
    const tick = () => {
      if (cancelled(gen) || Date.now() >= at) {
        resolve();
        return;
      }
      setTimeout(tick, 20);
    };
    tick();
  });
}
function arecordLive() {
  return new Promise((resolve) => {
    execFile7("pgrep", ["-x", "arecord"], (err) => resolve(!err));
  });
}
async function waitCaptureClear(limitMs) {
  const t0 = Date.now();
  while (Date.now() - t0 < limitMs) {
    if (!await arecordLive()) return;
    await new Promise((r) => setTimeout(r, 60));
  }
}
function listCards() {
  return new Promise((resolve) => {
    execFile7("arecord", ["-l"], (err, stdout) => resolve(err ? "" : String(stdout || "")));
  });
}
function listPlayback() {
  return new Promise((resolve) => {
    execFile7("aplay", ["-l"], (err, stdout) => resolve(err ? "" : String(stdout || "")));
  });
}
function upsample4(pcm, level) {
  const n = Math.floor(pcm.length / 2);
  const out = Buffer.alloc(n * 4 * 2);
  const gain = Math.max(0.05, Math.min(0.9, level));
  const clip = (v) => v < -32767 ? -32767 : v > 32767 ? 32767 : v;
  for (let i = 0; i < n; i++) {
    const a = Math.round(pcm.readInt16LE(i * 2) * gain);
    const next = i + 1 < n ? pcm.readInt16LE((i + 1) * 2) : pcm.readInt16LE(i * 2);
    const b = Math.round(next * gain);
    const o = i * 4;
    out.writeInt16LE(clip(a), (o + 0) * 2);
    out.writeInt16LE(clip(Math.round((a * 3 + b) / 4)), (o + 1) * 2);
    out.writeInt16LE(clip(Math.round((a + b) / 2)), (o + 2) * 2);
    out.writeInt16LE(clip(Math.round((a + b * 3) / 4)), (o + 3) * 2);
  }
  return out;
}
function buildPlayback(mode, tone12, level) {
  const bytes2 = playbackBytes(mode);
  const tone = upsample4(tone12, level);
  if (tone.length !== bytes2.tone) throw new Error(`tom ${tone.length}`);
  const lead = Buffer.alloc(bytes2.lead);
  const trail = Buffer.alloc(bytes2.trail);
  return Buffer.concat([lead, tone, trail]);
}
function waveHead(mode, pcm) {
  const lead = playbackBytes(mode).lead;
  let silent = lead > 0;
  for (let i = 0; i < lead && i < pcm.length; i++) {
    if (pcm[i] !== 0) {
      silent = false;
      break;
    }
  }
  const end = Math.min(pcm.length, lead + 48e3);
  let tone = false;
  for (let i = lead; i + 1 < end; i += 2) {
    if (pcm.readInt16LE(i) !== 0) {
      tone = true;
      break;
    }
  }
  const sec = (lead / 96e3).toFixed(1);
  return silent && tone ? `sil\xEAncio ${sec} s e tom inteiro` : "tom cortado";
}
async function encodeTone(mode, hz, message) {
  const bin = encodeBin();
  if (!existsSync12(bin)) throw new Error("no-modem");
  const dir = await mkdtemp2(path2.join(tmpdir2(), "hc-ftx-"));
  const out = path2.join(dir, "tone.s16");
  try {
    await new Promise((resolve, reject) => {
      const child2 = spawn6(bin, [mode, String(Math.round(hz)), message, out], { stdio: ["ignore", "ignore", "pipe"] });
      let err = "";
      child2.stderr.on("data", (chunk) => {
        err += chunk.toString("utf8");
      });
      child2.on("error", reject);
      child2.on("close", (code) => {
        if (code === 0) resolve();
        else reject(new Error(err.trim() || "encode"));
      });
    });
    const pcm = await readFile(out);
    const want = playbackPlan(mode).toneSamples * 2;
    if (pcm.length !== want) throw new Error(`amostras ${pcm.length}`);
    return pcm;
  } finally {
    await rm2(dir, { recursive: true, force: true }).catch(() => void 0);
  }
}
function playRaw(device, pcm, timeoutMs, gen) {
  return new Promise((resolve, reject) => {
    const child2 = spawn6("aplay", ["-D", device, "-f", "S16_LE", "-r", "48000", "-c", "1", "-t", "raw", "-q"], {
      stdio: ["pipe", "ignore", "pipe"]
    });
    player = child2;
    const err = [];
    const timer = setTimeout(() => child2.kill("SIGTERM"), timeoutMs);
    child2.stderr.on("data", (chunk) => err.push(chunk));
    child2.on("error", (error3) => {
      clearTimeout(timer);
      if (player === child2) player = null;
      reject(error3);
    });
    child2.on("close", (code) => {
      clearTimeout(timer);
      if (player === child2) player = null;
      if (cancelled(gen) || code === 0) resolve();
      else reject(new Error(Buffer.concat(err).toString("utf8").trim() || `aplay ${code}`));
    });
    child2.stdin.on("error", () => void 0);
    child2.stdin.end(pcm);
  });
}
async function playbackDevice() {
  const capList = await listCards();
  const cap = pickAlsaCapture(capList);
  const hit = pickAlsaPlayback(await listPlayback(), cap) ?? cap;
  if (!hit) throw new Error("no-device");
  return `plughw:${hit.card},${hit.device}`;
}
async function ensurePktUsb(port) {
  const m = await hubRigctl(port, "m", "127.0.0.1", PTT_TIMEOUT_MS, true);
  const parsed = parseRigMode(m.reply || "");
  if (parsed?.mode === DIGITAL_DATA_MODE) return;
  const set = await hubRigctl(port, `M ${DIGITAL_DATA_MODE} 0`, "127.0.0.1", PTT_TIMEOUT_MS, true);
  if (!set.ok) throw new Error(set.error || "data-mode");
}
async function playOnCodec(device, pcm, timeoutMs, gen) {
  console.log(`[digital] aplay ${device} ${pcm.length} bytes`);
  try {
    await playRaw(device, pcm, timeoutMs, gen);
  } catch (err) {
    const last = err instanceof Error ? err.message : String(err);
    console.log(`[digital] aplay ${device} falhou: ${last}`);
    if (cancelled(gen)) return;
    const hw = device.replace("plughw:", "hw:");
    if (hw === device) throw err instanceof Error ? err : new Error(last);
    console.log(`[digital] aplay ${hw} ${pcm.length} bytes`);
    await playRaw(hw, pcm, timeoutMs, gen);
  }
}
var PTT_TIMEOUT_MS = 2500;
function rigPtt(port, command) {
  return hubRigctl(port, command, "127.0.0.1", PTT_TIMEOUT_MS, true);
}
async function setPtt(port, on) {
  const reply = await rigPtt(port, `T ${on ? 1 : 0}`);
  console.log(`[digital] PTT ${on ? 1 : 0} porta ${port} ok=${reply.ok} ${reply.error || ""}`.trim());
  if (!reply.ok) throw new Error(reply.error || "ptt");
}
function pttBit(reply) {
  return reply.split("\n").map((s) => s.trim()).find((s) => s === "0" || s === "1") || "";
}
async function readPtt(port) {
  for (let i = 0; i < 3; i++) {
    const reply = await rigPtt(port, "t");
    const bit = pttBit(reply.reply || "");
    if (bit) return bit;
    await new Promise((r) => setTimeout(r, 250));
  }
  return "";
}
async function readPttOnce(port) {
  const reply = await rigPtt(port, "t");
  return pttBit(reply.reply || "");
}
async function raisePtt(port) {
  try {
    await setPtt(port, true);
    return;
  } catch (err) {
    const bit = await readPttOnce(port);
    if (bit === "1") {
      console.log(`[digital] PTT 1 porta ${port} leitura t=1`);
      return;
    }
    try {
      await setPtt(port, false);
    } catch {
    }
    throw err instanceof Error ? err : new Error("ptt");
  }
}
async function dropPtt(port) {
  let last = "ptt";
  for (let i = 0; i < 3; i++) {
    try {
      await setPtt(port, false);
    } catch (err) {
      last = err instanceof Error ? err.message : String(err);
    }
    if (await readPtt(port) === "0") {
      console.log(`[digital] PTT leitura t=0`);
      return;
    }
  }
  throw new Error(last);
}
async function codecReady(slot, mode, even, gen) {
  holdRadioCapture(true);
  let target = slot;
  for (let attempt = 0; attempt < 3; attempt++) {
    await sleepUntil(target - 2e3, gen);
    if (cancelled(gen)) throw new Error("halt");
    holdRadioCapture(true);
    await waitCaptureClear(1500);
    if (await arecordLive()) {
      console.log("[digital] arecord ainda vivo; o per\xEDodo seguinte leva a onda inteira");
      target = nextTxSlot(target + 1e3, mode, even);
      continue;
    }
    await sleepUntil(target, gen);
    if (cancelled(gen)) throw new Error("halt");
    const late = Date.now() - target;
    if (late > 80) {
      console.log(`[digital] slot perdido por ${late} ms; n\xE3o corta a onda`);
      target = nextTxSlot(Date.now() + 200, mode, even);
      continue;
    }
    return target;
  }
  throw new Error("codec ocupado");
}
async function run(current) {
  const gen = current.gen;
  let keyed = false;
  try {
    const play = current.play;
    const plan = playbackPlan(current.mode);
    const device = await playbackDevice();
    if (cancelled(gen)) throw new Error("halt");
    current.phase = "wait";
    console.log(`[digital] TX ${current.mode} "${current.message}" onda ${play.length} bytes ${waveHead(current.mode, play)}`);
    const slot = await codecReady(current.startAt, current.mode, current.even, gen);
    current.startAt = slot;
    if (cancelled(gen)) throw new Error("halt");
    await ensurePktUsb(current.port);
    if (cancelled(gen)) throw new Error("halt");
    current.phase = "ptt";
    await raisePtt(current.port);
    keyed = true;
    current.ptt = true;
    if (cancelled(gen)) throw new Error("halt");
    current.phase = "audio";
    await playOnCodec(device, play, Math.ceil(plan.txEnd * 1e3) + 4e3, gen);
    if (cancelled(gen)) throw new Error("halt");
    await sleepUntil(slot + plan.pttDrop * 1e3, gen);
    if (cancelled(gen)) throw new Error("halt");
    current.phase = "done";
    console.log(`[digital] TX conclu\xEDdo "${current.message}"`);
  } catch (err) {
    const text = err instanceof Error ? err.message : String(err);
    if (current.gen === generation) {
      current.phase = cancelled(gen) || text === "halt" ? "halt" : "error";
      current.error = text === "halt" ? "" : text;
    }
    console.log(`[digital] TX ${text === "halt" ? "halt" : "error"} ${text === "halt" ? "" : text}`.trim());
  } finally {
    if (generation !== gen) return;
    if (player) {
      player.kill("SIGTERM");
      player = null;
    }
    if (keyed) {
      try {
        await dropPtt(current.port);
      } catch (err) {
        current.error = current.error || (err instanceof Error ? err.message : String(err));
        if (current.phase === "done") current.phase = "error";
      }
      current.ptt = false;
    }
    holdRadioCapture(false);
  }
}
async function scheduleDigitalTx(input) {
  const message = input.message.trim().replace(/\s+/g, " ");
  if (!message || message.length > 40) return { ok: false, error: "mensagem" };
  if (job && (job.phase === "ptt" || job.phase === "audio")) return { ok: false, error: "ocupado" };
  if (!existsSync12(encodeBin())) return { ok: false, error: "no-modem" };
  const audioHz = Number.isFinite(input.audioHz) ? Math.max(200, Math.min(3e3, input.audioHz)) : 1500;
  const port = Number.isFinite(input.port) && input.port > 0 ? Math.round(input.port) : 4532;
  const level = Number.isFinite(input.level) ? input.level : 0.5;
  let play;
  try {
    play = buildPlayback(input.mode, await encodeTone(input.mode, audioHz, message), level);
  } catch (err) {
    const text = err instanceof Error ? err.message : String(err);
    return { ok: false, error: text || "encode" };
  }
  if (job && (job.phase === "ptt" || job.phase === "audio")) return { ok: false, error: "ocupado" };
  generation += 1;
  const gen = generation;
  haltedGen = -1;
  const slot = nextTxSlot(Date.now(), input.mode, input.even);
  job = {
    mode: input.mode,
    message,
    audioHz,
    even: input.even,
    port,
    level,
    play,
    phase: "wait",
    ptt: false,
    error: "",
    startAt: slot,
    gen
  };
  void run(job);
  return { ok: true, startInMs: Math.max(0, slot - Date.now()), message };
}
async function haltDigitalTx() {
  const gen = generation;
  haltedGen = gen;
  if (player && job?.gen === gen) {
    player.kill("SIGTERM");
    player = null;
  }
  if (!job || job.gen !== gen) return;
  const keyed = job.ptt;
  const port = job.port;
  if (job.phase === "wait" || job.phase === "ptt" || job.phase === "audio") job.phase = "halt";
  if (!keyed) return;
  try {
    await rigPtt(port, "T 0");
  } catch {
  }
  if (generation !== gen || job?.gen !== gen) return;
  job.ptt = false;
}

// server/icom-scope-ws.ts
init_icom_scope();
import { WebSocket as WebSocket2, WebSocketServer as WebSocketServer2 } from "ws";
init_icom_scope();
init_icom_scope_hub();
init_icom_lan();
init_radios();
var attached2 = /* @__PURE__ */ new WeakSet();
var lanAsm = new ScopeAssembler();
var serialAsm = new ScopeAssembler();
var lanClients = /* @__PURE__ */ new Set();
var serialClients = /* @__PURE__ */ new Set();
var scopeOn = false;
var serialOn = false;
var serialOffTimer = null;
var unlisten = null;
var unlistenSerial = null;
var serialAsmLogged = false;
var centerAt = 0;
function askScopeCenter(via, span = false, spanHz) {
  const now = Date.now();
  if (!span && now - centerAt < 800) return;
  centerAt = now;
  if (via === "serial") {
    if (span) serialScopeSpan(spanHz);
    else serialScopeCenter();
    return;
  }
  void icomLanCmd(span ? "scopeSpan" : "scopeCenter", spanHz != null ? { spanHz } : {});
}
function sendJson2(ws, body) {
  if (ws.readyState === WebSocket2.OPEN) ws.send(JSON.stringify(body));
}
function readScopeAsk(data) {
  const text = typeof data === "string" ? data : Buffer.isBuffer(data) ? data.toString("utf8") : "";
  if (!text) return null;
  try {
    const body = JSON.parse(text);
    if (body.type === "center") return { kind: "center" };
    if (body.type === "span") return { kind: "span", spanHz: body.spanHz };
    return null;
  } catch {
    return null;
  }
}
function broadcast(group, sweep) {
  const body = {
    type: "sweep",
    startHz: sweep.startHz,
    endHz: sweep.endHz,
    mode: sweep.mode,
    bins: Array.from(sweep.bins)
  };
  for (const ws of group) sendJson2(ws, body);
}
async function setLanScope(on) {
  if (scopeOn === on) return { ok: true };
  scopeOn = on;
  lanAsm.reset();
  const result = await icomLanCmd("scope", { on });
  if (!result.ok && on) scopeOn = false;
  return result;
}
function ensureLanListen() {
  if (unlisten) return;
  unlisten = subscribeScopeFrame((frame) => {
    if (lanClients.size === 0) return;
    const payload = scopePayload(frame);
    if (!payload) return;
    const sweep = lanAsm.push(payload);
    if (sweep) broadcast(lanClients, sweep);
  });
}
function ensureSerialListen() {
  if (unlistenSerial) return;
  onSerialScopeRevive(() => {
    serialAsm.reset();
    serialAsmLogged = false;
  });
  unlistenSerial = onSerialScopeFrame((frame) => {
    if (serialClients.size === 0) return;
    const payload = scopePayload(frame);
    if (!payload) return;
    const sweep = serialAsm.push(payload);
    if (sweep) {
      if (!serialAsmLogged) {
        serialAsmLogged = true;
        console.log(`civ-scope: varredura ${sweep.bins.length} pontos, ${sweep.startHz}\u2013${sweep.endHz} Hz`);
      }
      broadcast(serialClients, sweep);
      return;
    }
    if (!serialAsmLogged && payload.length <= 24) {
      console.log(`civ-scope: cabe\xE7alho ${Buffer.from(payload).toString("hex")}`);
    }
  });
}
function setSerialScope(on) {
  const radio = currentSerialHamlib();
  if (!radio?.scope || radio.link !== "usb" || radio.proto !== "civ" || !civScopeOn(radio.equipmentId, "serial")) {
    return { ok: false, error: "off" };
  }
  if (on && !serialScopeReady()) return { ok: false, error: "tap" };
  ensureSerialListen();
  if (on) {
    if (serialOffTimer) {
      clearTimeout(serialOffTimer);
      serialOffTimer = null;
    }
    if (serialOn) return { ok: true };
    serialAsm.reset();
    serialOn = true;
    return { ok: true };
  }
  if (serialOffTimer) return { ok: true };
  serialOffTimer = setTimeout(() => {
    serialOffTimer = null;
    if (serialClients.size > 0) return;
    serialOn = false;
    serialAsm.reset();
  }, 4e3);
  serialOffTimer.unref?.();
  return { ok: true };
}
async function bind(ws, via) {
  if (via === "serial") {
    serialClients.add(ws);
    const result2 = await setSerialScope(true);
    if (!result2.ok) {
      sendJson2(ws, { type: "error", reason: result2.error || "serial" });
      if (result2.error === "tap") {
        setTimeout(() => {
          if (serialClients.has(ws)) void setSerialScope(true);
        }, 1500);
      }
    } else {
      sendJson2(ws, { type: "ready", via: "serial" });
      void prepareSerialScopeTap().then((ok) => {
        if (!ok) return;
        serialScopeOutput(true);
        serialScopeSpan(SCOPE_SPAN_HZ);
      });
    }
    ws.on("message", (data) => {
      const ask = readScopeAsk(data);
      if (ask) askScopeCenter("serial", ask.kind === "span", ask.kind === "span" ? ask.spanHz : void 0);
    });
    ws.on("close", () => {
      serialClients.delete(ws);
      if (serialClients.size === 0) void setSerialScope(false);
    });
    return;
  }
  lanClients.add(ws);
  ensureLanListen();
  const result = await setLanScope(true);
  if (!result.ok) sendJson2(ws, { type: "error", reason: "lan" });
  else sendJson2(ws, { type: "ready", via: "lan" });
  ws.on("message", (data) => {
    const ask = readScopeAsk(data);
    if (ask) askScopeCenter("lan", ask.kind === "span", ask.kind === "span" ? ask.spanHz : void 0);
  });
  ws.on("close", () => {
    lanClients.delete(ws);
    if (lanClients.size === 0) void setLanScope(false);
  });
}
function attachScopeWs(server) {
  if (attached2.has(server)) return;
  attached2.add(server);
  const wss = new WebSocketServer2({ noServer: true });
  server.on("upgrade", (req, socket, head) => {
    const url = new URL(req.url || "/", "http://127.0.0.1");
    if (url.pathname !== "/ws/scope") return;
    if (!consoleSessionOk(req.headers.cookie)) {
      socket.write("HTTP/1.1 401 Unauthorized\r\nConnection: close\r\n\r\n");
      socket.destroy();
      return;
    }
    const via = url.searchParams.get("via") === "serial" ? "serial" : "lan";
    wss.handleUpgrade(req, socket, head, (ws) => {
      void bind(ws, via);
    });
  });
}

// server/term.ts
import { spawn as spawn7 } from "node:child_process";
import { existsSync as existsSync13 } from "node:fs";
import { WebSocket as WebSocket3, WebSocketServer as WebSocketServer3 } from "ws";
var ROOT_LOGIN = "/opt/ham-cockpit/bin/root-login";
var attached3 = /* @__PURE__ */ new WeakSet();
function spawnShell() {
  const env = { ...process.env, TERM: "xterm-256color", COLORTERM: "truecolor" };
  if (process.platform === "win32") {
    return spawn7("powershell.exe", ["-NoLogo"], { env, windowsHide: true });
  }
  const cwd = existsSync13("/opt/ham-cockpit") ? "/opt/ham-cockpit" : process.cwd();
  const rootEnv = { ...env, HOME: "/root", USER: "root", LOGNAME: "root" };
  const sudoBin = existsSync13("/usr/bin/sudo") ? "/usr/bin/sudo" : "sudo";
  if (existsSync13(ROOT_LOGIN) && existsSync13("/usr/bin/script")) {
    return spawn7(sudoBin, ["-n", "/usr/bin/script", "-qefc", ROOT_LOGIN, "/dev/null"], { env: rootEnv, cwd });
  }
  if (existsSync13(ROOT_LOGIN)) {
    return spawn7(sudoBin, ["-n", ROOT_LOGIN], { env: rootEnv, cwd });
  }
  return spawn7(sudoBin, ["-n", "/bin/bash", "-l"], { env: rootEnv, cwd });
}
function bindSocket(ws) {
  const proc = spawnShell();
  const send = (data) => {
    if (ws.readyState === WebSocket3.OPEN) ws.send(data);
  };
  send(
    process.platform === "win32" ? "Ham Cockpit \xB7 PowerShell (neste PC Windows). No Raspberry Pi isso \xE9 root.\r\n" : "Ham Cockpit \xB7 shell root\r\n"
  );
  proc.stdout.on("data", (d) => send(d.toString("utf8")));
  proc.stderr.on("data", (d) => send(d.toString("utf8")));
  proc.on("error", (err) => send(`\r
${err.message}\r
`));
  proc.on("close", (code) => {
    send(`\r
[exit ${code ?? 0}]\r
`);
    if (ws.readyState === WebSocket3.OPEN) ws.close();
  });
  ws.on("message", (raw) => {
    const text = typeof raw === "string" ? raw : Array.isArray(raw) ? Buffer.concat(raw).toString("utf8") : Buffer.from(raw).toString("utf8");
    if (text.startsWith("{")) {
      try {
        const msg = JSON.parse(text);
        if (msg.type === "resize") return;
      } catch {
      }
    }
    const payload = process.platform === "win32" ? text.replace(/\r(?!\n)/g, "\r\n") : text;
    proc.stdin.write(payload);
  });
  ws.on("close", () => {
    proc.kill();
  });
}
function attachTerminal(server) {
  if (attached3.has(server)) return;
  attached3.add(server);
  const wss = new WebSocketServer3({ noServer: true });
  server.on("upgrade", (req, socket, head) => {
    const path5 = req.url?.split("?")[0];
    if (path5 !== "/ws/term") return;
    wss.handleUpgrade(req, socket, head, (ws) => bindSocket(ws));
  });
}

// server/users.ts
import { spawn as spawn8 } from "node:child_process";
import { existsSync as existsSync14 } from "node:fs";
import { promisify as promisify7 } from "node:util";
import { execFile as execFile8 } from "node:child_process";
var execFileAsync7 = promisify7(execFile8);
var HELPER4 = "/opt/ham-cockpit/bin/station-user";
var NAME_RE2 = /^[a-z][a-z0-9_-]{0,31}$/;
var FORBIDDEN = /* @__PURE__ */ new Set(["root", "daemon", "bin", "sys", "sync", "games", "man", "mail", "www-data", "nobody"]);
var PROTECTED = /* @__PURE__ */ new Set(["root", "hamcockpit", "suporte"]);
var mockUsers = [
  { name: "hamcockpit", sudo: true },
  { name: "admin", sudo: true },
  { name: "suporte", sudo: true }
];
function linux() {
  return process.platform === "linux";
}
function run2(cmd, args, input) {
  return new Promise((resolve, reject) => {
    const child2 = spawn8(cmd, args, { stdio: ["pipe", "pipe", "pipe"] });
    let stdout = "";
    let stderr = "";
    child2.stdout.on("data", (d) => {
      stdout += d.toString("utf8");
    });
    child2.stderr.on("data", (d) => {
      stderr += d.toString("utf8");
    });
    child2.on("error", reject);
    child2.on("close", (code) => resolve({ code: code ?? 1, stdout, stderr }));
    if (input !== void 0) {
      child2.stdin.write(input);
      child2.stdin.end();
    } else {
      child2.stdin.end();
    }
  });
}
async function listUsers() {
  if (!linux()) {
    return mockUsers.map((u) => ({ ...u }));
  }
  if (existsSync14(HELPER4)) {
    const r = await run2("sudo", ["-n", HELPER4, "list"]);
    if (r.code === 0) {
      const names = r.stdout.split(/[,\n]/).map((n) => n.trim()).filter(Boolean);
      const uniq = Array.from(/* @__PURE__ */ new Set(["hamcockpit", "catbridge", ...names]));
      return uniq.sort().map((name) => ({ name, sudo: true }));
    }
  }
  try {
    const { stdout } = await execFileAsync7("getent", ["group", "sudo"], { timeout: 4e3 });
    const members = stdout.trim().split(":").pop()?.split(",").filter(Boolean) ?? [];
    return Array.from(/* @__PURE__ */ new Set(["hamcockpit", "catbridge", ...members])).sort().map((name) => ({ name, sudo: true }));
  } catch {
    return [{ name: "hamcockpit", sudo: true }];
  }
}
async function createUser(name, password) {
  const user = name.trim().toLowerCase();
  if (user === "suporte") {
    return { ok: false, error: "usu\xE1rio protegido" };
  }
  if (!NAME_RE2.test(user) || FORBIDDEN.has(user)) {
    return { ok: false, error: "nome inv\xE1lido" };
  }
  if (!password || password.length < 4) {
    return { ok: false, error: "senha muito curta" };
  }
  if (!linux()) {
    if (mockUsers.some((u) => u.name === user)) {
      return { ok: false, error: "j\xE1 existe" };
    }
    mockUsers.push({ name: user, sudo: true });
    return { ok: true };
  }
  if (!existsSync14(HELPER4)) {
    return { ok: false, error: "station-user ausente" };
  }
  const r = await run2("sudo", ["-n", HELPER4, "add", user], password);
  if (r.code !== 0) {
    return { ok: false, error: (r.stderr || r.stdout || "falha ao criar usu\xE1rio").trim() };
  }
  return { ok: true };
}
async function deleteUser(name) {
  const user = name.trim().toLowerCase();
  if (PROTECTED.has(user) || !NAME_RE2.test(user)) {
    return { ok: false, error: "usu\xE1rio protegido" };
  }
  if (!linux()) {
    const i = mockUsers.findIndex((u) => u.name === user);
    if (i < 0) return { ok: false, error: "n\xE3o encontrado" };
    mockUsers.splice(i, 1);
    return { ok: true };
  }
  if (!existsSync14(HELPER4)) {
    return { ok: false, error: "station-user ausente" };
  }
  const r = await run2("sudo", ["-n", HELPER4, "del", user]);
  if (r.code !== 0) {
    return { ok: false, error: (r.stderr || r.stdout || "falha ao remover").trim() };
  }
  return { ok: true };
}
async function sshStatus() {
  if (!linux()) return { ok: false, unit: "ssh" };
  for (const unit of ["ssh", "sshd"]) {
    try {
      const { stdout } = await execFileAsync7("systemctl", ["is-active", unit], { timeout: 3e3 });
      if (stdout.trim() === "active") return { ok: true, unit };
    } catch {
    }
  }
  return { ok: false, unit: "ssh" };
}

// server/wavelog-status.ts
import { execFile as execFile9 } from "node:child_process";
import { access, copyFile, readFile as readFile2 } from "node:fs/promises";
import { request as httpRequest } from "node:http";
import { dirname as dirname10, join as join11 } from "node:path";
import { fileURLToPath as fileURLToPath10 } from "node:url";
import { promisify as promisify8 } from "node:util";
var execFileAsync8 = promisify8(execFile9);
var ROOT9 = join11(dirname10(fileURLToPath10(import.meta.url)), "..");
var STATION_SVC = "/opt/ham-cockpit/bin/station-svc";
var STATION_BACKUP = "/opt/ham-cockpit/bin/station-backup";
var DB_CONTAINER = "wavelog-db";
var DB_NAME = "wavelog";
var DB_USER = "wavelog";
var DB_HOST = "wavelog-db";
var DB_PORT = 3306;
async function composeDir() {
  if (process.env.WAVELOG_DIR) return process.env.WAVELOG_DIR;
  const pi = "/opt/wavelog";
  if (await fileExists(join11(pi, "docker-compose.yml"))) return pi;
  return join11(ROOT9, "deploy", "wavelog");
}
async function stationSvc(action, id) {
  if (!await fileExists(STATION_SVC)) return "";
  try {
    const { stdout } = await execFileAsync8("sudo", ["-n", STATION_SVC, action, id], {
      timeout: 18e4,
      windowsHide: true
    });
    return String(stdout || "").trim();
  } catch {
    return "";
  }
}
async function systemctlWavelog(action) {
  const viaHelper = await stationSvc(action, "wavelog");
  if (viaHelper === "started" || viaHelper === "stopped" || viaHelper === "enabled") return true;
  try {
    await execFileAsync8("systemctl", [action, "wavelog.service"], {
      timeout: 12e4,
      windowsHide: true
    });
    return true;
  } catch {
    return false;
  }
}
function probeWavelog(port = 8086, host2 = "127.0.0.1") {
  const url = `http://${host2}:${port}/`;
  return new Promise((resolve) => {
    const req = httpRequest(url, { method: "GET", timeout: 2500 }, (res) => {
      res.resume();
      const httpStatus = res.statusCode ?? 0;
      resolve({ ok: httpStatus > 0 && httpStatus < 500, httpStatus, url });
    });
    req.on("timeout", () => {
      req.destroy();
      resolve({ ok: false, error: "timeout", url });
    });
    req.on("error", (err) => resolve({ ok: false, error: err.message, url }));
    req.end();
  });
}
async function dockerBinaryPresent() {
  for (const p of ["/usr/bin/docker", "/bin/docker"]) {
    if (await fileExists(p)) return true;
  }
  try {
    await execFileAsync8("docker", ["--version"], { timeout: 3e3, windowsHide: true });
    return true;
  } catch {
    return false;
  }
}
async function dockerDaemonUp() {
  try {
    await execFileAsync8("docker", ["info", "--format", "{{.ServerVersion}}"], {
      timeout: 5e3,
      windowsHide: true
    });
    return true;
  } catch {
    const active = await stationSvc("is-active", "docker");
    return active === "active";
  }
}
async function fileExists(path5) {
  try {
    await access(path5);
    return true;
  } catch {
    return false;
  }
}
async function wavelogStatus(port = 8086) {
  const compose = await composeDir();
  const url = `http://127.0.0.1:${port}/`;
  const probe2 = await probeWavelog(port);
  if (probe2.ok) {
    return { ok: true, url, port, docker: true, compose, reason: "ok", httpStatus: probe2.httpStatus };
  }
  const hasBin = await dockerBinaryPresent();
  const daemon = hasBin ? await dockerDaemonUp() : false;
  const hasCompose = await fileExists(join11(compose, "docker-compose.yml"));
  if (!hasCompose) {
    return { ok: false, url, port, docker: hasBin, compose, reason: "no-compose", error: probe2.error };
  }
  if (!hasBin) {
    return { ok: false, url, port, docker: false, compose, reason: "no-docker", error: probe2.error };
  }
  if (!daemon) {
    return {
      ok: false,
      url,
      port,
      docker: false,
      compose,
      reason: "docker-down",
      error: probe2.error
    };
  }
  return { ok: false, url, port, docker: true, compose, reason: "down", error: probe2.error };
}
async function ensureEnv(dir) {
  const env = join11(dir, ".env");
  if (await fileExists(env)) return;
  const example = join11(dir, ".env.example");
  if (await fileExists(example)) await copyFile(example, env);
}
async function wavelogUp(port = 8086) {
  const status = await wavelogStatus(port);
  if (status.ok) return status;
  if (status.reason === "no-docker") return status;
  if (status.reason === "no-compose") return status;
  try {
    await ensureEnv(status.compose);
    const viaSystemd = await systemctlWavelog("enable") && await systemctlWavelog("start");
    if (!viaSystemd) {
      await stationSvc("start", "docker");
      await execFileAsync8("docker", ["compose", "up", "-d"], {
        cwd: status.compose,
        timeout: 12e4,
        windowsHide: true
      });
    }
  } catch (err) {
    return { ...status, reason: "error", error: err instanceof Error ? err.message : String(err) };
  }
  const after = await wavelogStatus(port);
  return after.ok ? after : { ...after, reason: after.reason === "ok" ? "down" : after.reason };
}
async function wavelogDown(port = 8086) {
  const stopped = await systemctlWavelog("stop");
  if (!stopped && await dockerDaemonUp()) {
    try {
      await execFileAsync8("docker", ["compose", "stop"], {
        cwd: await composeDir(),
        timeout: 6e4,
        windowsHide: true
      });
    } catch {
    }
  }
  return wavelogStatus(port);
}
function envValueFromText(text, key) {
  const line = text.split(/\r?\n/).find((l) => l.startsWith(`${key}=`));
  return line ? line.slice(key.length + 1).trim().replace(/^["']|["']$/g, "") : "";
}
function scrubSecret(msg, secret2) {
  if (!secret2) return msg;
  return msg.split(secret2).join("***");
}
async function readEnvFile(file) {
  try {
    return await readFile2(file, "utf8");
  } catch (err) {
    const code = err && typeof err === "object" && "code" in err ? String(err.code) : "";
    if (code !== "EACCES" && code !== "EPERM") return "";
  }
  try {
    const { stdout } = await execFileAsync8("sudo", ["-n", STATION_BACKUP, "cat", file], {
      timeout: 8e3,
      windowsHide: true
    });
    return String(stdout || "");
  } catch {
    return "";
  }
}
async function passwordFromContainer() {
  try {
    const { stdout } = await execFileAsync8(
      "docker",
      ["inspect", "--format", "{{range .Config.Env}}{{println .}}{{end}}", DB_CONTAINER],
      { timeout: 6e3, windowsHide: true }
    );
    return envValueFromText(String(stdout), "MARIADB_PASSWORD");
  } catch {
    return "";
  }
}
async function readDbPassword(dir) {
  const envFile = join11(dir, ".env");
  let password = "";
  if (await fileExists(envFile)) {
    const text = await readEnvFile(envFile);
    password = envValueFromText(text, "WAVELOG_DB_PASSWORD");
  }
  if (!password) password = await passwordFromContainer();
  return { password, envFile, source: password ? "env" : "missing" };
}
async function wavelogDbPassword() {
  const compose = await composeDir();
  const out = await readDbPassword(compose);
  return out.password ? out : { ...out, error: "WAVELOG_DB_PASSWORD ausente em .env e no container" };
}
async function wavelogDbUp(httpPort = 8086) {
  await stationSvc("start", "db");
  return wavelogDatabase(httpPort);
}
async function wavelogDbDown(httpPort = 8086) {
  await stationSvc("stop", "db");
  return wavelogDatabase(httpPort);
}
async function dockerInspectDb() {
  try {
    const { stdout } = await execFileAsync8(
      "docker",
      [
        "inspect",
        "--format",
        "{{.State.Running}}|{{if .State.Health}}{{.State.Health.Status}}{{end}}|{{.Config.Image}}",
        DB_CONTAINER
      ],
      { timeout: 5e3, windowsHide: true }
    );
    const [runningS, healthS, imageS] = stdout.trim().split("|");
    const running = runningS === "true";
    const health = healthS || (running ? "running" : "exited");
    return { running, health, image: imageS || "" };
  } catch {
    return { running: false, health: "missing", image: "" };
  }
}
function shSingleQuote(s) {
  return `'${s.replace(/'/g, `'\\''`)}'`;
}
var DB_STATS_SQL = "SELECT VERSION(), @@character_set_server, @@collation_server, (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = 'wavelog' AND TABLE_TYPE = 'BASE TABLE'), (SELECT IFNULL(SUM(DATA_LENGTH + INDEX_LENGTH), 0) FROM information_schema.TABLES WHERE TABLE_SCHEMA = 'wavelog'), (SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA = 'wavelog' AND ENGINE IS NOT NULL ORDER BY DATA_LENGTH DESC LIMIT 1);";
async function mariadbQueryUser(sql) {
  const inner = `mariadb -uwavelog -p"$MARIADB_PASSWORD" -N -B -e ${shSingleQuote(sql)}`;
  const { stdout } = await execFileAsync8("docker", ["exec", DB_CONTAINER, "sh", "-c", inner], {
    timeout: 12e3,
    windowsHide: true
  });
  return stdout.trim();
}
async function mariadbQueryRoot(sql) {
  const { stdout } = await execFileAsync8(
    "docker",
    ["exec", DB_CONTAINER, "mariadb", "-uroot", "--protocol=tcp", "-h127.0.0.1", "--skip-password", "-N", "-B", "-e", sql],
    { timeout: 12e3, windowsHide: true }
  );
  return stdout.trim();
}
async function mariadbVersionFallback() {
  try {
    const { stdout } = await execFileAsync8("docker", ["exec", DB_CONTAINER, "mariadbd", "--version"], {
      timeout: 8e3,
      windowsHide: true
    });
    const m = stdout.match(/Ver\s+(\S+)/);
    return m?.[1] || stdout.trim();
  } catch {
    return "";
  }
}
function parseStats(row) {
  const cols = row.split("	");
  return {
    version: cols[0] || "",
    charset: cols[1] || "",
    collation: cols[2] || "",
    tables: Number(cols[3] || 0) || 0,
    sizeBytes: Number(cols[4] || 0) || 0,
    engine: cols[5] || ""
  };
}
async function wavelogDatabase(httpPort = 8086) {
  const compose = await composeDir();
  const { password, envFile, source } = await readDbPassword(compose);
  const inspect2 = await dockerInspectDb();
  const base2 = {
    ok: false,
    running: inspect2.running,
    connected: false,
    health: inspect2.health,
    deploy: "docker",
    compose,
    envFile,
    passwordSource: source,
    queryVia: "none",
    host: DB_HOST,
    port: DB_PORT,
    published: false,
    name: DB_NAME,
    user: DB_USER,
    password,
    version: "",
    charset: "",
    collation: "",
    engine: "",
    tables: 0,
    sizeBytes: 0,
    url: `http://127.0.0.1:${httpPort}/`,
    network: "wavelog",
    volume: "wavelog-dbdata",
    image: inspect2.image
  };
  if (!password) {
    return { ...base2, error: "WAVELOG_DB_PASSWORD ausente em .env" };
  }
  if (!inspect2.running) {
    return { ...base2, error: inspect2.health === "missing" ? "container wavelog-db ausente" : "MariaDB parado" };
  }
  try {
    const stats = parseStats(await mariadbQueryUser(DB_STATS_SQL));
    return { ...base2, ...stats, ok: true, connected: true, queryVia: "user" };
  } catch (userErr) {
    const userMsg = scrubSecret(userErr instanceof Error ? userErr.message : String(userErr), password);
    try {
      const stats = parseStats(await mariadbQueryRoot(DB_STATS_SQL));
      return {
        ...base2,
        ...stats,
        ok: true,
        connected: false,
        queryVia: "root-socket",
        error: "Usu\xE1rio/banco wavelog ainda n\xE3o existem neste volume. Credenciais do .env s\xE3o as do instalador web."
      };
    } catch {
      const version = await mariadbVersionFallback();
      return {
        ...base2,
        version,
        error: userMsg || "falha ao consultar o MariaDB no container"
      };
    }
  }
}
async function wavelogDbUpdate(httpPort = 8086) {
  const compose = await composeDir();
  await ensureEnv(compose);
  await stationSvc("start", "wavelog");
  const ctl = join11(compose, "wavelog-ctl.sh");
  try {
    if (await fileExists(ctl)) {
      await execFileAsync8("bash", [ctl, "pull"], { cwd: compose, timeout: 24e4, windowsHide: true });
    } else {
      await execFileAsync8("docker", ["compose", "pull"], { cwd: compose, timeout: 18e4, windowsHide: true });
      await execFileAsync8("docker", ["compose", "up", "-d", "--remove-orphans"], {
        cwd: compose,
        timeout: 12e4,
        windowsHide: true
      });
    }
  } catch (err) {
    const db2 = await wavelogDatabase(httpPort);
    return {
      ...db2,
      updated: false,
      error: scrubSecret(err instanceof Error ? err.message : String(err), db2.password)
    };
  }
  await probeWavelog(httpPort);
  const db = await wavelogDatabase(httpPort);
  return { ...db, updated: true };
}

// server/wlg-status.ts
import { execFile as execFile10, spawn as spawn9 } from "node:child_process";
import { existsSync as existsSync15 } from "node:fs";
import { request as httpRequest2 } from "node:http";
import { dirname as dirname11, join as join12 } from "node:path";
import { fileURLToPath as fileURLToPath11 } from "node:url";
import { promisify as promisify9 } from "node:util";
var execFileAsync9 = promisify9(execFile10);
var ROOT10 = join12(dirname11(fileURLToPath11(import.meta.url)), "..");
var SCRIPT = existsSync15("/opt/wavelog-gate/wavelog-gate.mjs") ? "/opt/wavelog-gate/wavelog-gate.mjs" : join12(ROOT10, "deploy", "wavelog-gate", "wavelog-gate.mjs");
var child = null;
function probe(port) {
  return new Promise((resolve) => {
    const req = httpRequest2(`http://127.0.0.1:${port}/status`, { method: "GET", timeout: 1500 }, (res) => {
      res.resume();
      resolve((res.statusCode ?? 0) >= 200 && (res.statusCode ?? 0) < 500);
    });
    req.on("timeout", () => {
      req.destroy();
      resolve(false);
    });
    req.on("error", () => resolve(false));
    req.end();
  });
}
var STATION_SVC2 = "/opt/ham-cockpit/bin/station-svc";
async function systemctl(action) {
  try {
    if (existsSync15(STATION_SVC2)) {
      const { stdout: stdout2 } = await execFileAsync9("sudo", ["-n", STATION_SVC2, action, "wlg"], {
        timeout: 3e4,
        windowsHide: true
      });
      if (action === "is-active") return stdout2.trim() === "active";
      return true;
    }
    const { stdout } = await execFileAsync9("systemctl", [action, "waveloggate.service"], {
      timeout: 2e4,
      windowsHide: true
    });
    if (action === "is-active") return stdout.trim() === "active";
    return true;
  } catch {
    return false;
  }
}
async function wlgStatus(udpPort = 2333, qsyPort = 54321) {
  const ok = await probe(qsyPort);
  if (ok) return { ok: true, udpPort, qsyPort, reason: "ok" };
  const unit = process.platform === "linux" ? await systemctl("is-active") : Boolean(child && !child.killed);
  return {
    ok: unit,
    udpPort,
    qsyPort,
    reason: unit ? "ok" : "down"
  };
}
async function wlgUp(udpPort = 2333, qsyPort = 54321) {
  const already = await wlgStatus(udpPort, qsyPort);
  if (already.ok) return already;
  if (process.platform === "linux") {
    await systemctl("enable");
    await systemctl("start");
  } else if (!child || child.killed) {
    child = spawn9(process.execPath, [SCRIPT], {
      cwd: dirname11(SCRIPT),
      detached: false,
      stdio: "ignore",
      windowsHide: true
    });
    child.on("exit", () => {
      child = null;
    });
  }
  await new Promise((r) => setTimeout(r, 800));
  return wlgStatus(udpPort, qsyPort);
}
async function wlgDown(udpPort = 2333, qsyPort = 54321) {
  if (process.platform === "linux") {
    await systemctl("stop");
  } else if (child) {
    child.kill();
    child = null;
  }
  await new Promise((r) => setTimeout(r, 400));
  return wlgStatus(udpPort, qsyPort);
}

// server/net.ts
import { execFile as execFile11, spawn as spawn10 } from "node:child_process";
import { existsSync as existsSync16, mkdirSync as mkdirSync10, readFileSync as readFileSync10, renameSync as renameSync9, writeFileSync as writeFileSync10 } from "node:fs";
import { hostname as osHostname } from "node:os";
import { dirname as dirname12, join as join13 } from "node:path";
import { fileURLToPath as fileURLToPath12 } from "node:url";
import { promisify as promisify10 } from "node:util";
var execFileAsync10 = promisify10(execFile11);
var ROOT11 = join13(dirname12(fileURLToPath12(import.meta.url)), "..");
var OPT_DIR9 = "/opt/ham-cockpit/net";
var HELPER5 = "/opt/ham-cockpit/bin/station-net";
var HOST_RE = /^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$/;
var IPV4_RE = /^(?:\d{1,3}\.){3}\d{1,3}$/;
function dataDir9() {
  if (existsSync16("/opt/ham-cockpit")) {
    mkdirSync10(OPT_DIR9, { recursive: true });
    return OPT_DIR9;
  }
  const local = join13(ROOT11, "data", "net");
  mkdirSync10(local, { recursive: true });
  return local;
}
function jsonPath7() {
  return join13(dataDir9(), "config.json");
}
function validIp(s) {
  if (!IPV4_RE.test(s)) return false;
  return s.split(".").every((p) => {
    const n = Number(p);
    return n >= 0 && n <= 255;
  });
}
function loadSaved5() {
  const fallback = {
    hostname: "ham-cockpit",
    link: "wifi",
    dhcp: true,
    ip: "",
    mask: "255.255.255.0",
    gw: "",
    dns1: "1.1.1.1",
    dns2: "8.8.8.8",
    staSsid: "",
    staPass: "",
    apSsid: "Ham-Cockpit",
    apPass: "hamcockpit",
    managed: []
  };
  try {
    const raw = JSON.parse(readFileSync10(jsonPath7(), "utf8"));
    return {
      hostname: typeof raw.hostname === "string" && HOST_RE.test(raw.hostname) ? raw.hostname : fallback.hostname,
      link: raw.link === "ethernet" ? "ethernet" : "wifi",
      dhcp: raw.dhcp !== false,
      ip: typeof raw.ip === "string" ? raw.ip : "",
      mask: typeof raw.mask === "string" && raw.mask ? raw.mask : fallback.mask,
      gw: typeof raw.gw === "string" ? raw.gw : "",
      dns1: typeof raw.dns1 === "string" && raw.dns1 ? raw.dns1 : fallback.dns1,
      dns2: typeof raw.dns2 === "string" ? raw.dns2 : fallback.dns2,
      staSsid: typeof raw.staSsid === "string" ? raw.staSsid : "",
      staPass: typeof raw.staPass === "string" ? raw.staPass : "",
      apSsid: typeof raw.apSsid === "string" && raw.apSsid ? raw.apSsid : fallback.apSsid,
      apPass: typeof raw.apPass === "string" && raw.apPass ? raw.apPass : fallback.apPass,
      managed: Array.isArray(raw.managed) ? raw.managed.filter((m) => m && typeof m.ssid === "string").map((m) => ({ ssid: m.ssid, psk: typeof m.psk === "string" ? m.psk : "" })) : []
    };
  } catch {
    return fallback;
  }
}
var saved5 = loadSaved5();
var lastScan = [];
var lastError = "";
var lastNote = "";
function persist8() {
  const tmp = `${jsonPath7()}.${process.pid}.tmp`;
  writeFileSync10(tmp, JSON.stringify(saved5, null, 2), "utf8");
  renameSync9(tmp, jsonPath7());
}
function rememberSsid(ssid, psk) {
  if (!ssid) return;
  const rest = saved5.managed.filter((m) => m.ssid !== ssid);
  saved5.managed = [{ ssid, psk: psk || rest.find((m) => m.ssid === ssid)?.psk }, ...rest].slice(0, 12);
}
function run3(cmd, args, input, timeout = 2e4) {
  return new Promise((resolve, reject) => {
    const child2 = spawn10(cmd, args, { stdio: ["pipe", "pipe", "pipe"], windowsHide: true });
    let stdout = "";
    let stderr = "";
    const timer = setTimeout(() => {
      try {
        child2.kill();
      } catch {
      }
    }, timeout);
    child2.stdout.on("data", (d) => {
      stdout += d.toString("utf8");
    });
    child2.stderr.on("data", (d) => {
      stderr += d.toString("utf8");
    });
    child2.on("error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
    child2.on("close", (code) => {
      clearTimeout(timer);
      resolve({ code: code ?? 1, stdout, stderr });
    });
    if (input !== void 0) {
      child2.stdin.write(input);
      child2.stdin.end();
    } else {
      child2.stdin.end();
    }
  });
}
async function helper2(args, input) {
  if (!existsSync16(HELPER5)) {
    const err = new Error("helper station-net ausente \u2014 use no Raspberry Pi");
    err.code = "NO_HELPER";
    throw err;
  }
  return run3("sudo", ["-n", HELPER5, ...args], input);
}
function pctToRssi(pct) {
  const n = Math.max(0, Math.min(100, pct));
  return Math.round(n / 2 - 100);
}
function signalToRssi(raw) {
  const n = Number(String(raw).replace(/[^\d.-]/g, ""));
  if (!Number.isFinite(n)) return -80;
  if (n <= 0 && n >= -100) return Math.round(n);
  return pctToRssi(n);
}
async function winScan() {
  const { stdout } = await execFileAsync10("netsh", ["wlan", "show", "networks", "mode=bssid"], {
    timeout: 18e3,
    windowsHide: true,
    encoding: "utf8"
  }).catch(async () => {
    const r = await execFileAsync10("cmd.exe", ["/c", "chcp 65001>nul & netsh wlan show networks mode=bssid"], {
      timeout: 18e3,
      windowsHide: true
    });
    return { stdout: r.stdout.toString() };
  });
  const text = String(stdout || "");
  const bySsid = /* @__PURE__ */ new Map();
  let ssid = "";
  let auth = "";
  for (const line of text.split(/\r?\n/)) {
    const s = line.match(/^\s*SSID\s+\d+\s*:\s*(.*)$/i);
    if (s) {
      ssid = s[1].trim();
      auth = "";
      continue;
    }
    const a = line.match(/^\s*Authentication\s*:\s*(.*)$/i) || line.match(/^\s*Autenticação\s*:\s*(.*)$/i);
    if (a) {
      auth = a[1].trim();
      continue;
    }
    const sig = line.match(/^\s*Signal\s*:\s*(\d+)\s*%/i) || line.match(/^\s*Sinal\s*:\s*(\d+)\s*%/i);
    if (sig && ssid) {
      const rssi = pctToRssi(Number(sig[1]));
      const open = !auth || /^open$/i.test(auth) || /abert/i.test(auth);
      const prev = bySsid.get(ssid);
      if (!prev || rssi > prev.rssi) bySsid.set(ssid, { ssid, rssi, open });
    }
  }
  return Array.from(bySsid.values()).sort((a, b) => b.rssi - a.rssi);
}
async function linuxScan() {
  const r = existsSync16(HELPER5) ? await helper2(["scan"]) : await run3("nmcli", ["-t", "-f", "SSID,SIGNAL,SECURITY", "device", "wifi", "list"]);
  const bySsid = /* @__PURE__ */ new Map();
  for (const line of r.stdout.split(/\r?\n/)) {
    const parts = line.split("	");
    const ssid = (parts[0] || "").trim();
    if (!ssid || ssid === "--") continue;
    const rssi = signalToRssi(parts[1] || "40");
    const sec = (parts[2] || "").trim();
    const open = !sec || sec === "--" || /^none$/i.test(sec);
    const prev = bySsid.get(ssid);
    if (!prev || rssi > prev.rssi) bySsid.set(ssid, { ssid, rssi, open });
  }
  return Array.from(bySsid.values()).sort((a, b) => b.rssi - a.rssi);
}
function guessKind(name, hint = "") {
  const n = `${name} ${hint}`.toLowerCase();
  if (/wi-?fi|wlan|wireless|802\.11/.test(n)) return "wifi";
  if (/eth|ethernet|end0|enp|eno|cabo|local area/.test(n)) return "ethernet";
  return "other";
}
function parseIpconfig(text) {
  const blocks = text.split(/\r?\n(?=\S)/);
  const out = [];
  for (const block of blocks) {
    const head = block.split(/\r?\n/)[0] || "";
    if (!/adapter|adaptador/i.test(head)) continue;
    const name = head.replace(/:\s*$/, "").replace(/^(wireless\s+lan\s+adapter|ethernet\s+adapter|adaptador\s+de\s+rede\s+sem\s+fio|adaptador\s+ethernet|adaptador)\s+/i, "").trim();
    const disconnected = /media disconnected|m[ií]dia desconectada|midia desconectada/i.test(block);
    const ip = (block.match(/IPv4[^:\n]*:\s*([\d.]+)/i) || [])[1] || "";
    const mask = (block.match(/Subnet Mask[^:\n]*:\s*([\d.]+)/i) || block.match(/M[aá]scara[^:\n]*:\s*([\d.]+)/i) || [])[1] || "";
    const gw = (block.match(/Default Gateway[^:\n]*:\s*([\d.]+)/i) || block.match(/Gateway Padr[aã]o[^:\n]*:\s*([\d.]+)/i) || block.match(/Gateway[^:\n]*:\s*([\d.]+)/i) || [])[1] || "";
    const dns = [];
    const dnsBlock = block.split(/DNS Servers[^:\n]*:\s*/i)[1] || block.split(/Servidores DNS[^:\n]*:\s*/i)[1] || "";
    for (const line of dnsBlock.split(/\r?\n/)) {
      const m = line.match(/([\d.]+)/);
      if (m && validIp(m[1])) dns.push(m[1]);
      else if (line.trim() && !/^\s*[\d.]+/.test(line) && dns.length) break;
    }
    const ssid = (block.match(/SSID[^:\n]*:\s*(.+)/i) || [])[1]?.trim() || "";
    out.push({
      name,
      kind: guessKind(name, head),
      connected: !disconnected && Boolean(ip),
      ip,
      mask,
      gw: validIp(gw) ? gw : "",
      dns,
      ssid
    });
  }
  return out;
}
async function winLive() {
  const { stdout } = await execFileAsync10("ipconfig", ["/all"], { timeout: 8e3, windowsHide: true }).catch(() => ({ stdout: "" }));
  const ifs = parseIpconfig(String(stdout || ""));
  try {
    const wlan = await execFileAsync10("netsh", ["wlan", "show", "interfaces"], { timeout: 6e3, windowsHide: true });
    const text = String(wlan.stdout || "");
    const ssid = (text.match(/^\s*SSID\s*:\s*(.+)$/im) || [])[1]?.trim() || "";
    const state = (text.match(/^\s*State\s*:\s*(.+)$/im) || text.match(/^\s*Estado\s*:\s*(.+)$/im) || [])[1] || "";
    const connected = /connected|conectado/i.test(state);
    const wifi = ifs.find((i) => i.kind === "wifi");
    if (wifi) {
      wifi.ssid = ssid || wifi.ssid;
      if (connected) wifi.connected = true;
    } else if (ssid) {
      ifs.push({ name: "Wi-Fi", kind: "wifi", connected, ip: "", mask: "", gw: "", dns: [], ssid });
    }
  } catch {
  }
  return ifs;
}
async function linuxLive() {
  const ifs = [];
  try {
    const { stdout } = await execFileAsync10("ip", ["-j", "addr"], { timeout: 5e3 });
    const rows = JSON.parse(String(stdout || "[]"));
    for (const row of rows) {
      const name = row.ifname || "";
      if (!name || name === "lo") continue;
      const v4 = (row.addr_info || []).find((a) => a.family === "inet");
      const prefix = Number(v4?.prefixlen) || 24;
      const mask = prefixToMask(prefix);
      ifs.push({
        name,
        kind: guessKind(name),
        connected: Boolean(v4?.local),
        ip: v4?.local || "",
        mask,
        gw: "",
        dns: [],
        ssid: ""
      });
    }
  } catch {
  }
  try {
    const { stdout } = await execFileAsync10("ip", ["-j", "route"], { timeout: 4e3 });
    const routes = JSON.parse(String(stdout || "[]"));
    const def = routes.find((r) => r.dst === "default");
    if (def?.gateway && def.dev) {
      const hit = ifs.find((i) => i.name === def.dev);
      if (hit) hit.gw = def.gateway;
    }
  } catch {
  }
  try {
    const resolv = readFileSync10("/etc/resolv.conf", "utf8");
    const dns = [];
    const re = /^nameserver\s+([\d.]+)/gm;
    let m;
    while (m = re.exec(resolv)) dns.push(m[1]);
    for (const i of ifs) if (i.connected) i.dns = dns;
  } catch {
  }
  try {
    const { stdout } = await execFileAsync10("iwgetid", ["-r"], { timeout: 3e3 });
    const ssid = String(stdout || "").trim();
    const wifi = ifs.find((i) => i.kind === "wifi") || ifs.find((i) => /^wlan/i.test(i.name));
    if (wifi && ssid) {
      wifi.ssid = ssid;
      wifi.kind = "wifi";
      wifi.connected = true;
    }
  } catch {
  }
  return ifs;
}
function prefixToMask(prefix) {
  const n = Math.max(0, Math.min(32, prefix));
  const bits = n === 0 ? 0 : -1 << 32 - n >>> 0;
  return [24, 16, 8, 0].map((s) => (bits >>> s & 255).toString()).join(".");
}
async function liveIfs() {
  if (process.platform === "win32") return winLive();
  if (process.platform === "linux") return linuxLive();
  return [];
}
function pickLive(ifs, link) {
  if (link === "ethernet") return ifs.find((i) => i.kind === "ethernet" && i.connected) || ifs.find((i) => i.kind === "ethernet");
  return ifs.find((i) => i.kind === "wifi" && i.connected) || ifs.find((i) => i.kind === "wifi");
}
async function netStatus() {
  const ifs = await liveIfs().catch(() => []);
  const wifi = pickLive(ifs, "wifi");
  const eth = pickLive(ifs, "ethernet");
  const chosen = pickLive(ifs, saved5.link) || wifi || eth;
  const liveHost = osHostname().replace(/\.local$/i, "");
  return {
    ok: lastError === "",
    folder: dataDir9(),
    hostname: saved5.hostname,
    liveHostname: liveHost,
    link: saved5.link,
    dhcp: saved5.dhcp,
    ip: saved5.ip || chosen?.ip || "",
    mask: saved5.mask || chosen?.mask || "255.255.255.0",
    gw: saved5.gw || chosen?.gw || "",
    dns1: saved5.dns1 || chosen?.dns[0] || "1.1.1.1",
    dns2: saved5.dns2 || chosen?.dns[1] || "",
    staSsid: wifi?.ssid || saved5.staSsid,
    staConnected: Boolean(wifi?.connected && wifi.ssid),
    staPassSet: Boolean(saved5.staPass),
    apSsid: saved5.apSsid,
    apPassSet: Boolean(saved5.apPass),
    ethConnected: Boolean(eth?.connected),
    ethName: eth?.name || "",
    wlanName: wifi?.name || "",
    liveIp: chosen?.ip || "",
    liveMask: chosen?.mask || "",
    liveGw: chosen?.gw || "",
    scan: lastScan,
    managed: saved5.managed.map((m) => ({ ssid: m.ssid })),
    error: lastError,
    note: lastNote
  };
}
async function netScan() {
  lastError = "";
  lastNote = "";
  try {
    lastScan = process.platform === "win32" ? await winScan() : await linuxScan();
    if (!lastScan.length) lastNote = process.platform === "win32" ? "Nenhuma rede Wi\u2011Fi vis\xEDvel. Ligue o adaptador wireless." : "Nenhuma rede vis\xEDvel. Confira a antena wlan0.";
  } catch (err) {
    lastError = err instanceof Error ? err.message : String(err);
    lastScan = [];
  }
  return netStatus();
}
async function netConnect(body) {
  const ssid = String(body.ssid || saved5.staSsid).trim();
  const pass = typeof body.pass === "string" && body.pass ? body.pass : saved5.staPass;
  lastError = "";
  lastNote = "";
  if (!ssid) {
    lastError = "Escolha uma rede Wi\u2011Fi";
    return netStatus();
  }
  saved5.staSsid = ssid;
  if (typeof body.pass === "string" && body.pass) saved5.staPass = body.pass;
  saved5.link = "wifi";
  rememberSsid(ssid, pass);
  persist8();
  try {
    if (process.platform === "linux") {
      await helper2(["connect", ssid], pass);
      if (!saved5.dhcp) await applyIpv4Linux();
    } else if (process.platform === "win32") {
      await winConnect(ssid, pass);
    } else {
      lastError = "Wi\u2011Fi STA precisa do Raspberry Pi";
    }
  } catch (err) {
    lastError = err instanceof Error ? err.message : String(err);
  }
  return netStatus();
}
async function winConnect(ssid, pass) {
  const profile = join13(dataDir9(), "wlan-profile.xml");
  const open = !pass;
  const xml = open ? `<?xml version="1.0"?><WLANProfile xmlns="http://www.microsoft.com/networking/WLAN/profile/v1"><name>${escXml(ssid)}</name><SSIDConfig><SSID><name>${escXml(ssid)}</name></SSID></SSIDConfig><connectionType>ESS</connectionType><connectionMode>auto</connectionMode><MSM><security><authEncryption><authentication>open</authentication><encryption>none</encryption><useOneX>false</useOneX></authEncryption></security></MSM></WLANProfile>` : `<?xml version="1.0"?><WLANProfile xmlns="http://www.microsoft.com/networking/WLAN/profile/v1"><name>${escXml(ssid)}</name><SSIDConfig><SSID><name>${escXml(ssid)}</name></SSID></SSIDConfig><connectionType>ESS</connectionType><connectionMode>auto</connectionMode><MSM><security><authEncryption><authentication>WPA2PSK</authentication><encryption>AES</encryption><useOneX>false</useOneX></authEncryption><sharedKey><keyType>passPhrase</keyType><protected>false</protected><keyMaterial>${escXml(pass)}</keyMaterial></sharedKey></security></MSM></WLANProfile>`;
  writeFileSync10(profile, xml, "utf8");
  const add = await run3("netsh", ["wlan", "add", "profile", `filename=${profile}`, "user=current"]);
  if (add.code !== 0 && !/already|já existe/i.test(add.stdout + add.stderr)) {
    throw new Error((add.stderr || add.stdout || "falha ao gravar perfil Wi\u2011Fi").trim());
  }
  const con = await run3("netsh", ["wlan", "connect", `name=${ssid}`, `ssid=${ssid}`]);
  if (con.code !== 0) throw new Error((con.stderr || con.stdout || "falha ao conectar").trim());
}
function escXml(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
async function netForget(ssid) {
  const name = ssid.trim();
  saved5.managed = saved5.managed.filter((m) => m.ssid !== name);
  if (saved5.staSsid === name) saved5.staPass = "";
  persist8();
  lastError = "";
  try {
    if (process.platform === "linux") await helper2(["forget", name]);
  } catch (err) {
    lastError = err instanceof Error ? err.message : String(err);
  }
  return netStatus();
}
async function netSetLink(link) {
  saved5.link = link === "ethernet" ? "ethernet" : "wifi";
  persist8();
  lastError = "";
  lastNote = "";
  try {
    if (process.platform === "linux") {
      await helper2(["link", saved5.link]);
      await applyIpv4Linux();
    } else {
      lastNote = saved5.link === "ethernet" ? "Cabo selecionado. No Raspberry Pi a STA Wi\u2011Fi desliga e o Ethernet sobe. Neste Windows s\xF3 salva a prefer\xEAncia." : "Wi\u2011Fi selecionado. No Raspberry Pi o cabo deixa de ser o uplink. Neste Windows s\xF3 salva a prefer\xEAncia.";
    }
  } catch (err) {
    lastError = err instanceof Error ? err.message : String(err);
  }
  return netStatus();
}
async function netSetIp(body) {
  if (typeof body.dhcp === "boolean") saved5.dhcp = body.dhcp;
  if (typeof body.ip === "string") saved5.ip = body.ip.trim();
  if (typeof body.mask === "string") saved5.mask = body.mask.trim() || "255.255.255.0";
  if (typeof body.gw === "string") saved5.gw = body.gw.trim();
  if (typeof body.dns1 === "string") saved5.dns1 = body.dns1.trim();
  if (typeof body.dns2 === "string") saved5.dns2 = body.dns2.trim();
  lastError = "";
  lastNote = "";
  if (!saved5.dhcp) {
    if (!validIp(saved5.ip)) lastError = "IP inv\xE1lido";
    else if (!validIp(saved5.mask)) lastError = "M\xE1scara inv\xE1lida";
    else if (saved5.gw && !validIp(saved5.gw)) lastError = "Gateway inv\xE1lido";
    else if (saved5.dns1 && !validIp(saved5.dns1)) lastError = "DNS prim\xE1rio inv\xE1lido";
    else if (saved5.dns2 && !validIp(saved5.dns2)) lastError = "DNS secund\xE1rio inv\xE1lido";
  }
  persist8();
  if (lastError) return netStatus();
  try {
    if (process.platform === "linux") await applyIpv4Linux();
    else if (process.platform === "win32") lastNote = saved5.dhcp ? "DHCP gravado. No Pi aplica na interface ativa." : "IP fixo gravado. No Raspberry Pi aplica com nmcli; neste Windows n\xE3o altera o adaptador.";
  } catch (err) {
    lastError = err instanceof Error ? err.message : String(err);
  }
  return netStatus();
}
async function applyIpv4Linux() {
  const conn = saved5.link === "ethernet" ? "" : saved5.staSsid;
  if (saved5.dhcp) {
    await helper2(["ipv4", "dhcp", conn]);
    return;
  }
  await helper2(["ipv4", "manual", conn, saved5.ip, saved5.mask, saved5.gw, saved5.dns1, saved5.dns2]);
}
async function netSetHostname(name) {
  const host2 = name.trim().toLowerCase();
  lastError = "";
  lastNote = "";
  if (!HOST_RE.test(host2)) {
    lastError = "Nome inv\xE1lido (letras, n\xFAmeros e h\xEDfen)";
    return netStatus();
  }
  saved5.hostname = host2;
  persist8();
  try {
    if (process.platform === "linux") {
      await helper2(["hostname", host2]);
      lastNote = `Na LAN: http://${host2}.local`;
    } else {
      lastNote = `Nome gravado (${host2}.local no Pi). Neste Windows o nome do PC continua ${osHostname()}.`;
    }
  } catch (err) {
    lastError = err instanceof Error ? err.message : String(err);
  }
  return netStatus();
}
async function netSetAp(body) {
  if (typeof body.ssid === "string" && body.ssid.trim()) saved5.apSsid = body.ssid.trim();
  if (typeof body.pass === "string" && body.pass) saved5.apPass = body.pass;
  persist8();
  lastError = "";
  lastNote = "";
  if (saved5.apPass && saved5.apPass.length < 8) {
    lastError = "Senha do AP precisa de pelo menos 8 caracteres";
    return netStatus();
  }
  try {
    if (process.platform === "linux") await helper2(["ap", saved5.apSsid], saved5.apPass);
    else lastNote = "AP gravado. Sobe no Raspberry Pi (192.168.4.1).";
  } catch (err) {
    lastError = err instanceof Error ? err.message : String(err);
  }
  return netStatus();
}
async function netSave(body) {
  if (typeof body.hostname === "string" && HOST_RE.test(body.hostname.trim())) saved5.hostname = body.hostname.trim().toLowerCase();
  if (body.link === "ethernet" || body.link === "wifi") saved5.link = body.link;
  if (typeof body.dhcp === "boolean") saved5.dhcp = body.dhcp;
  if (typeof body.ip === "string") saved5.ip = body.ip.trim();
  if (typeof body.mask === "string") saved5.mask = body.mask.trim();
  if (typeof body.gw === "string") saved5.gw = body.gw.trim();
  if (typeof body.dns1 === "string") saved5.dns1 = body.dns1.trim();
  if (typeof body.dns2 === "string") saved5.dns2 = body.dns2.trim();
  if (typeof body.staSsid === "string") saved5.staSsid = body.staSsid.trim();
  if (typeof body.pass === "string") saved5.staPass = body.pass;
  if (typeof body.apSsid === "string") saved5.apSsid = body.apSsid.trim();
  persist8();
  return netStatus();
}

// server/processes.ts
import { execFile as execFile12 } from "node:child_process";
import { existsSync as existsSync17 } from "node:fs";
import { promisify as promisify11 } from "node:util";

// shared/process-unit.ts
var UNIT_RE = /^[A-Za-z0-9][A-Za-z0-9:_.@+-]{0,127}\.service$/;
var DENY = /* @__PURE__ */ new Set([
  "systemd-poweroff.service",
  "systemd-reboot.service",
  "systemd-halt.service",
  "systemd-kexec.service",
  "systemd-soft-reboot.service",
  "poweroff.service",
  "reboot.service",
  "halt.service"
]);
function validServiceUnit(name) {
  if (typeof name !== "string" || !UNIT_RE.test(name)) return false;
  if (name.includes("/") || name.includes("\\") || name.includes("..")) return false;
  return !DENY.has(name);
}
function isConsoleUnit(name) {
  return name === "ham-cockpit.service" || name === "nginx.service";
}

// server/processes.ts
var execFileAsync11 = promisify11(execFile12);
var HELPER6 = "/opt/ham-cockpit/bin/station-svc";
var NOT_LINUX = "Este host n\xE3o \xE9 Linux. O systemd n\xE3o est\xE1 dispon\xEDvel e nenhum servi\xE7o foi listado.";
var LINUX_ONLY = "Parar e reiniciar s\xF3 funcionam na esta\xE7\xE3o Linux.";
function asText(value) {
  if (typeof value === "string") return value;
  if (value == null) return "";
  return String(value);
}
function cleanErr(err) {
  const e = err;
  const raw = (asText(e?.stderr) || asText(e?.message) || "falha").replace(/\s+/g, " ").trim();
  return raw.slice(0, 300) || "falha";
}
async function run4(file, args, timeout) {
  const { stdout } = await execFileAsync11(file, args, {
    timeout,
    windowsHide: true,
    maxBuffer: 1048576
  });
  return asText(stdout);
}
async function listRunningRaw() {
  if (existsSync17(HELPER6)) return run4("sudo", ["-n", HELPER6, "list-running"], 12e3);
  return run4("systemctl", ["list-units", "--type=service", "--state=running", "--no-pager", "--output=json"], 12e3);
}
function parseUnits(raw) {
  const start = raw.indexOf("[");
  if (start < 0) throw new Error("resposta do systemctl sem JSON");
  const data = JSON.parse(raw.slice(start));
  if (!Array.isArray(data)) throw new Error("resposta do systemctl inv\xE1lida");
  const items = [];
  for (const row of data) {
    if (!row || typeof row !== "object") continue;
    const rec = row;
    const unit = typeof rec.unit === "string" ? rec.unit : "";
    if (!validServiceUnit(unit)) continue;
    const active = typeof rec.active === "string" ? rec.active : "";
    const sub = typeof rec.sub === "string" ? rec.sub : "";
    if (active === "inactive" || active === "failed" || sub === "dead" || sub === "failed" || sub === "exited") continue;
    const description = typeof rec.description === "string" ? rec.description.replace(/\s+/g, " ").trim().slice(0, 180) : "";
    items.push({ unit, active: active || "active", sub: sub || "running", description });
  }
  items.sort((a, b) => a.unit.localeCompare(b.unit));
  return items;
}
async function processesList() {
  if (process.platform !== "linux") {
    return { ok: true, available: false, items: [], error: NOT_LINUX };
  }
  try {
    return { ok: true, available: true, items: parseUnits(await listRunningRaw()), error: "" };
  } catch (err) {
    return { ok: false, available: true, items: [], error: cleanErr(err) };
  }
}
async function processesAction(unit, action) {
  const act = action === "stop" || action === "restart" ? action : "";
  if (!act) return { ok: false, unit, action, error: "A\xE7\xE3o inv\xE1lida." };
  if (!validServiceUnit(unit)) return { ok: false, unit, action: act, error: "Nome de servi\xE7o inv\xE1lido." };
  if (process.platform !== "linux") return { ok: false, unit, action: act, error: LINUX_ONLY };
  const timeout = isConsoleUnit(unit) && act === "restart" ? 8e3 : 45e3;
  try {
    if (existsSync17(HELPER6)) {
      await run4("sudo", ["-n", HELPER6, act === "stop" ? "stop-unit" : "restart-unit", unit], timeout);
    } else if (act === "stop") {
      await run4("systemctl", ["stop", "--", unit], timeout);
    } else if (isConsoleUnit(unit)) {
      await run4("systemctl", ["restart", "--no-block", "--", unit], timeout);
    } else {
      await run4("systemctl", ["restart", "--", unit], timeout);
    }
    return { ok: true, unit, action: act, error: "" };
  } catch (err) {
    return { ok: false, unit, action: act, error: cleanErr(err) };
  }
}

// server/index.ts
init_services();

// server/updates.ts
import { execFile as execFile13, spawn as spawn11 } from "node:child_process";
import { existsSync as existsSync18, readFileSync as readFileSync11 } from "node:fs";
import { dirname as dirname13, join as join14 } from "node:path";
import { fileURLToPath as fileURLToPath13 } from "node:url";
import { promisify as promisify12 } from "node:util";

// shared/version.ts
var VERSION_RE = /^v?(\d+)\.(\d+)\.(\d+)(?:\.(\d{1,2}))?$/i;
function pad2(n) {
  return String(Math.max(0, Math.floor(n))).padStart(2, "0");
}
function cleanVersion(raw) {
  return String(raw || "").trim().replace(/^v/i, "");
}
function parseVersion(raw) {
  const m = cleanVersion(raw).match(VERSION_RE);
  if (!m) return null;
  return {
    major: Number(m[1]) || 0,
    minor: Number(m[2]) || 0,
    patch: Number(m[3]) || 0,
    ota: m[4] != null ? Number(m[4]) || 0 : 0
  };
}
function imageBase(raw) {
  const p = parseVersion(raw);
  if (!p) return cleanVersion(raw);
  return `${p.major}.${p.minor}.${pad2(p.patch)}`;
}
function versionNums(raw) {
  return cleanVersion(raw).replace(/^[^\d]+/, "").split(/[^\d]+/).filter(Boolean).map((n) => Number(n) || 0);
}
function compareVersion(a, b) {
  const pa = parseVersion(a);
  const pb = parseVersion(b);
  if (pa && pb) {
    if (pa.major !== pb.major) return pa.major > pb.major ? 1 : -1;
    if (pa.minor !== pb.minor) return pa.minor > pb.minor ? 1 : -1;
    if (pa.patch !== pb.patch) return pa.patch > pb.patch ? 1 : -1;
    if (pa.ota !== pb.ota) return pa.ota > pb.ota ? 1 : -1;
    return 0;
  }
  const aa = versionNums(a);
  const bb = versionNums(b);
  const n = Math.max(aa.length, bb.length);
  for (let i = 0; i < n; i++) {
    const x = aa[i] || 0;
    const y = bb[i] || 0;
    if (x > y) return 1;
    if (x < y) return -1;
  }
  return 0;
}
function isNewerVersion(available, current) {
  const avail = cleanVersion(available);
  const cur = cleanVersion(current);
  if (!avail || !cur || avail === "\u2014") return false;
  if (/pacotes/i.test(avail)) return true;
  if (avail === cur) return false;
  return compareVersion(avail, cur) > 0;
}

// shared/brand.ts
var APP_VERSION = "0.1.13.01";
var APP_IMAGE_VERSION = imageBase(APP_VERSION);
var UPDATE_REPO = "fviudes/ham-cockpit";

// server/updates.ts
init_const();
var execFileAsync12 = promisify12(execFile13);
var ROOT12 = join14(dirname13(fileURLToPath13(import.meta.url)), "..");
var SHIPPED = join14(ROOT12, "deploy", "station", "versions.json");
function helperPath() {
  for (const p of ["/opt/ham-cockpit/bin/station-upd", "/opt/cat-bridge/bin/station-upd"]) {
    if (existsSync18(p)) return p;
  }
  return "/opt/ham-cockpit/bin/station-upd";
}
function appCurrent() {
  const candidates = [
    join14("/opt/ham-cockpit", "VERSION"),
    join14("/opt/cat-bridge", "VERSION"),
    join14(ROOT12, "VERSION")
  ];
  for (const p of candidates) {
    try {
      if (!existsSync18(p)) continue;
      const v = cleanVersion(readFileSync11(p, "utf8"));
      if (v) return v;
    } catch {
    }
  }
  return cleanVersion(APP_VERSION);
}
var jobs = /* @__PURE__ */ new Map();
function loadShipped() {
  const fallback = {
    app: APP_VERSION,
    os: "Ubuntu Server 24.04 LTS",
    osAvailable: "Ubuntu Server 24.04 LTS",
    ser2net: "4.3.13",
    hamlib: "4.6.5",
    wavelog: "1.9.4",
    wlg: "1.0.0"
  };
  const candidates = [
    join14("/opt/ham-cockpit", "versions.json"),
    join14("/opt/cat-bridge", "versions.json"),
    join14(ROOT12, "versions.json"),
    SHIPPED
  ];
  for (const p of candidates) {
    try {
      if (!existsSync18(p)) continue;
      const raw = JSON.parse(readFileSync11(p, "utf8"));
      return { ...fallback, ...raw };
    } catch {
    }
  }
  return fallback;
}
function wlgShipped() {
  const p = join14(ROOT12, "deploy", "wavelog-gate", "VERSION");
  try {
    if (existsSync18(p)) return readFileSync11(p, "utf8").trim() || "1.0.0";
  } catch {
  }
  return loadShipped().wlg;
}
function newer(available, current) {
  return isNewerVersion(available, current);
}
function jobOf(id) {
  return jobs.get(id);
}
function item(id, current, available, note = "", error3 = "", helperUpdatable) {
  const cur = current || "\u2014";
  const avail = available || cur;
  const job2 = jobOf(id);
  const updatable = typeof helperUpdatable === "boolean" ? helperUpdatable : newer(avail, cur);
  return {
    id,
    current: cur,
    available: avail,
    updatable,
    applying: job2?.status === "running",
    error: job2?.error || error3,
    note,
    progress: job2?.pct ?? 0,
    stage: job2?.stage ?? "",
    determinate: job2?.determinate ?? false,
    bytes: job2?.bytes ?? 0,
    totalBytes: job2?.totalBytes ?? 0,
    etaSec: job2?.etaSec ?? 0
  };
}
async function githubRawVersion(url, ms = 2800) {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), ms);
    const r = await fetch(url, {
      signal: ctrl.signal,
      headers: { "User-Agent": `Ham-Cockpit/${APP_VERSION}` }
    });
    clearTimeout(t);
    if (!r.ok) return "";
    return cleanVersion(await r.text());
  } catch {
    return "";
  }
}
async function githubTag(repo, ms = 2800) {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), ms);
    const r = await fetch(`https://api.github.com/repos/${repo}/releases/latest`, {
      signal: ctrl.signal,
      headers: { Accept: "application/vnd.github+json", "User-Agent": `Ham-Cockpit/${APP_VERSION}` }
    });
    clearTimeout(t);
    if (!r.ok) return "";
    const j = await r.json();
    return cleanVersion(String(j.tag_name || j.name || ""));
  } catch {
    return "";
  }
}
async function githubAppVersion() {
  const headers = { Accept: "application/vnd.github+json", "User-Agent": `Ham-Cockpit/${APP_VERSION}` };
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 3500);
    const r = await fetch(`https://raw.githubusercontent.com/${UPDATE_REPO}/main/update/version.json`, {
      signal: ctrl.signal,
      headers
    });
    clearTimeout(t);
    if (r.ok) {
      const j = await r.json();
      return cleanVersion(String(j.version || ""));
    }
  } catch {
  }
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 3e3);
    const r = await fetch(`https://api.github.com/repos/${UPDATE_REPO}/contents/update?ref=main`, {
      headers,
      signal: ctrl.signal
    });
    clearTimeout(t);
    if (!r.ok) return "";
    const list = await r.json();
    const vers = list.map(
      (x) => String(x.name || "").replace(/\.(json|tgz|tar\.gz)$/i, "").replace(/^ham-cockpit-?/i, "").replace(/^v/i, "")
    ).filter((n) => /^\d+\.\d+/.test(n));
    vers.sort((a, b) => compareVersion(a, b));
    return vers[vers.length - 1] || "";
  } catch {
    return "";
  }
}
function execError(err) {
  const e = err;
  const stderr = String(e.stderr || "").split(/\r?\n/).filter((l) => l.trim() && !l.includes("HC_PROGRESS ")).join("\n").trim();
  if (e.killed) return stderr || "tempo esgotado ao consultar station-upd";
  if (stderr) return stderr.split(/\r?\n/).filter(Boolean).slice(-6).join("\n");
  const msg = String(e.message || err).split(/\r?\n/).filter((l) => l.trim() && !l.includes("HC_PROGRESS ")).join("\n");
  return msg || String(err);
}
async function helper3(cmd, id = "") {
  const bin = helperPath();
  if (process.platform !== "linux" || !existsSync18(bin)) return null;
  try {
    const args = id ? [cmd, id] : [cmd];
    const timeout = cmd === "apply" ? 9e5 : cmd === "refresh" ? 5e4 : 18e3;
    const { stdout } = await execFileAsync12("sudo", ["-n", bin, ...args], {
      timeout,
      windowsHide: true,
      maxBuffer: 2e6
    });
    return parseHelperOut(String(stdout || "").trim());
  } catch (err) {
    return snapshot2(baseline().items, loadShipped().os, false, execError(err));
  }
}
function parseHelperOut(stdout) {
  try {
    const parsed = JSON.parse(lastJsonObject(stdout || "{}"));
    if (!Array.isArray(parsed.items)) return null;
    const byId = new Map(parsed.items.map((row) => [row.id, row]));
    const items = UPDATE_IDS.map((id) => {
      const hit = byId.get(id);
      const helperUp = typeof hit?.updatable === "boolean" ? hit.updatable : id === "os" && /pacotes/i.test(String(hit?.available || "")) ? true : null;
      if (id === "app") {
        const cur = appCurrent() || String(hit?.current || "");
        const avail = String(hit?.available || cur);
        return item(
          "app",
          cur,
          avail,
          String(hit?.note || `github.com/${UPDATE_REPO}/update`),
          String(hit?.error || ""),
          helperUp
        );
      }
      return item(
        id,
        String(hit?.current || ""),
        String(hit?.available || hit?.current || ""),
        String(hit?.note || ""),
        String(hit?.error || ""),
        helperUp
      );
    });
    return snapshot2(items, String(parsed.os || ""), parsed.ok !== false, String(parsed.error || ""));
  } catch {
    return null;
  }
}
function snapshot2(items, os2, ok = true, error3 = "") {
  const decorated = items.map((row) => {
    const job2 = jobOf(row.id);
    if (!job2) return { ...row, applying: false };
    return {
      ...row,
      applying: job2.status === "running",
      error: job2.error || row.error,
      progress: job2.pct,
      stage: job2.stage,
      determinate: job2.determinate,
      bytes: job2.bytes,
      totalBytes: job2.totalBytes,
      etaSec: job2.etaSec
    };
  });
  return {
    ok,
    os: os2,
    pending: decorated.filter((row) => row.updatable).length,
    items: decorated,
    jobs: Array.from(jobs.values()),
    error: error3
  };
}
function baseline() {
  const s = loadShipped();
  const wlg = wlgShipped();
  const app = appCurrent() || s.app;
  const items = [
    item("app", app, app, `github.com/${UPDATE_REPO}/update`),
    item("os", s.os, s.osAvailable, "Ubuntu Server"),
    item("ser2net", s.ser2net, s.ser2net, "apt ser2net"),
    item("hamlib", s.hamlib, s.hamlib, "apt libhamlib-utils"),
    item("wavelog", s.wavelog, s.wavelog, "docker ghcr.io/wavelog/wavelog"),
    item("wlg", wlg, wlg, "WaveLogGate headless")
  ];
  return snapshot2(items, s.os);
}
function looksVersion(v) {
  return /\d/.test(v) && v !== "\u2014";
}
var remotesCache = null;
async function fetchRemotes(force = false) {
  if (!force && remotesCache && Date.now() - remotesCache.at < 3e5) {
    return remotesCache.rem;
  }
  const [app, wavelog, wlg] = await Promise.all([
    githubAppVersion(),
    githubTag("wavelog/wavelog"),
    githubRawVersion(`https://raw.githubusercontent.com/${UPDATE_REPO}/main/deploy/wavelog-gate/VERSION`)
  ]);
  const rem = { app, wavelog, wlg };
  remotesCache = { at: Date.now(), rem };
  return rem;
}
function applyRemotes(base2, rem) {
  const next = base2.items.map((row) => {
    if (row.id === "app") {
      const installed = appCurrent() || row.current;
      const remote = rem.app || row.available || installed;
      return item("app", installed, remote, row.note, row.error);
    }
    if (row.id === "wavelog" && rem.wavelog && looksVersion(row.current)) {
      return item(row.id, row.current, rem.wavelog, row.note, row.error);
    }
    if (row.id === "wlg" && rem.wlg && looksVersion(row.current)) {
      return item(row.id, row.current, rem.wlg, row.note, row.error);
    }
    return row;
  });
  return snapshot2(next, base2.os, base2.ok, base2.error);
}
var cache = null;
function ingestProgress(id, text) {
  const job2 = jobs.get(id);
  if (!job2) return;
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line.startsWith("HC_PROGRESS ")) continue;
    try {
      const j = JSON.parse(line.slice("HC_PROGRESS ".length));
      if (typeof j.pct === "number" && Number.isFinite(j.pct)) job2.pct = Math.max(0, Math.min(100, Math.round(j.pct)));
      if (typeof j.stage === "string" && j.stage) job2.stage = j.stage;
      if (typeof j.determinate === "boolean") job2.determinate = j.determinate;
      if (typeof j.error === "string" && j.error) job2.error = j.error;
      if (typeof j.bytes === "number" && Number.isFinite(j.bytes)) job2.bytes = Math.max(0, Math.round(j.bytes));
      if (typeof j.totalBytes === "number" && Number.isFinite(j.totalBytes)) job2.totalBytes = Math.max(0, Math.round(j.totalBytes));
      if (typeof j.etaSec === "number" && Number.isFinite(j.etaSec)) job2.etaSec = Math.max(0, Math.round(j.etaSec));
    } catch {
    }
  }
}
var inflight = null;
var inflightKind = null;
function runCheck(kind) {
  if (inflight) return inflight;
  inflightKind = kind;
  inflight = (async () => {
    try {
      const [live4, rem] = await Promise.all([helper3(kind), fetchRemotes(kind === "refresh")]);
      const snap5 = applyRemotes(live4 ?? baseline(), rem);
      cache = { at: Date.now(), snap: snap5 };
      return snap5;
    } finally {
      inflight = null;
      inflightKind = null;
    }
  })();
  return inflight;
}
async function updatesStatus(force = false) {
  const running = Array.from(jobs.values()).some((j) => j.status === "running");
  if (running) {
    const base2 = cache?.snap ?? baseline();
    return snapshot2(base2.items, base2.os, true, "");
  }
  if (!force && cache && Date.now() - cache.at < 12e4) {
    return snapshot2(cache.snap.items, cache.snap.os, cache.snap.ok, cache.snap.error);
  }
  if (inflight) {
    if (cache) return snapshot2(cache.snap.items, cache.snap.os, cache.snap.ok, cache.snap.error);
    if (!force) {
      void inflight;
      return baseline();
    }
    return inflight;
  }
  return runCheck("check");
}
async function updatesRefresh() {
  if (inflight && inflightKind === "refresh") return inflight;
  if (inflight) {
    await inflight.catch(() => void 0);
  }
  cache = null;
  remotesCache = null;
  return runCheck("refresh");
}
function lastJsonObject(text) {
  const start = text.lastIndexOf('{"ok"');
  if (start >= 0) return text.slice(start);
  const alt = text.lastIndexOf("{");
  return alt >= 0 ? text.slice(alt) : text;
}
function spawnApply(sid) {
  const bin = helperPath();
  const job2 = {
    id: sid,
    status: "running",
    pct: 2,
    determinate: true,
    stage: "prepare",
    error: "",
    bytes: 0,
    totalBytes: 0,
    etaSec: 0
  };
  jobs.set(sid, job2);
  return new Promise((resolve) => {
    const child2 = spawn11("sudo", ["-n", bin, "apply", sid], {
      windowsHide: true
    });
    let stdout = "";
    let stderr = "";
    const killer = setTimeout(() => child2.kill("SIGTERM"), 9e5);
    child2.stdout?.on("data", (buf) => {
      const chunk = String(buf);
      stdout += chunk;
      ingestProgress(sid, chunk);
    });
    child2.stderr?.on("data", (buf) => {
      const chunk = String(buf);
      stderr += chunk;
      ingestProgress(sid, chunk);
    });
    const finish2 = async (code, errMsg = "") => {
      clearTimeout(killer);
      const parsed = parseHelperOut(lastJsonObject(stdout.trim()));
      const errText = errMsg || stderr.split(/\r?\n/).filter((l) => l.trim() && !l.includes("HC_PROGRESS ")).slice(-8).join("\n");
      if (code === 0 && parsed) {
        job2.status = "ok";
        job2.pct = 100;
        job2.determinate = true;
        job2.stage = "done";
        job2.error = "";
        const over = applyRemotes(parsed, await fetchRemotes());
        cache = {
          at: Date.now(),
          snap: snapshot2(
            over.items.map(
              (row) => row.id === sid ? {
                ...row,
                applying: false,
                progress: 100,
                stage: "done",
                determinate: true,
                updatable: false
              } : row
            ),
            over.os,
            true,
            ""
          )
        };
        setTimeout(() => {
          if (jobs.get(sid)?.status === "ok") jobs.delete(sid);
        }, 2e4);
        resolve(cache.snap);
        return;
      }
      job2.status = "error";
      job2.determinate = true;
      job2.stage = "error";
      job2.error = errText || `falha ao aplicar ${sid} (c\xF3digo ${code == null ? "sinal/timeout" : code})`;
      const cur = cache?.snap ?? await updatesStatus(true);
      const failed = snapshot2(
        cur.items.map((row) => row.id === sid ? { ...row, error: job2.error } : row),
        cur.os,
        false,
        job2.error
      );
      cache = { at: Date.now(), snap: failed };
      setTimeout(() => {
        if (jobs.get(sid)?.status === "error") jobs.delete(sid);
      }, 2e4);
      resolve(failed);
    };
    child2.on("error", (err) => {
      void finish2(1, String(err.message || err));
    });
    child2.on("close", (code, signal) => {
      void finish2(code, signal ? `processo encerrado (${signal})` : "");
    });
  });
}
var applyChain = Promise.resolve();
async function updatesApply(id) {
  if (!UPDATE_IDS.includes(id)) {
    const cur = await updatesStatus();
    return { ...cur, ok: false, error: "componente desconhecido" };
  }
  const sid = id;
  const existing = jobs.get(sid);
  if (existing?.status === "running") {
    const cur = cache?.snap ?? await updatesStatus();
    return snapshot2(cur.items, cur.os, true, "");
  }
  if (process.platform !== "linux" || !existsSync18(helperPath())) {
    const cur = await updatesStatus();
    return {
      ...cur,
      ok: false,
      error: "O aplicativo roda no Ubuntu Server da esta\xE7\xE3o. Neste host s\xF3 a verifica\xE7\xE3o est\xE1 dispon\xEDvel."
    };
  }
  try {
    jobs.set(sid, {
      id: sid,
      status: "running",
      pct: 1,
      determinate: true,
      stage: "queued",
      error: "",
      bytes: 0,
      totalBytes: 0,
      etaSec: 0
    });
    const run6 = applyChain.then(() => spawnApply(sid));
    applyChain = run6.then(
      () => void 0,
      () => void 0
    );
    return await run6;
  } catch (err) {
    const cur = await updatesStatus(true);
    return { ...cur, ok: false, error: String(err) };
  }
}

// server/layouts.ts
import { existsSync as existsSync19, mkdirSync as mkdirSync11, readFileSync as readFileSync12, renameSync as renameSync10, writeFileSync as writeFileSync11 } from "node:fs";
import { dirname as dirname14, join as join15 } from "node:path";
import { fileURLToPath as fileURLToPath14 } from "node:url";
var ROOT13 = join15(dirname14(fileURLToPath14(import.meta.url)), "..");
var OPT_DIR10 = "/opt/ham-cockpit/layouts";
function dataDir10() {
  if (existsSync19("/opt/ham-cockpit")) {
    mkdirSync11(OPT_DIR10, { recursive: true });
    return OPT_DIR10;
  }
  const local = join15(ROOT13, "data", "layouts");
  mkdirSync11(local, { recursive: true });
  return local;
}
function jsonPath8(scope) {
  const file = scope === "digital" ? "digital.json" : "panel.json";
  return join15(dataDir10(), file);
}
function parseScope(raw) {
  return raw === "digital" ? "digital" : "panel";
}
function writeAtomic7(file, body) {
  const tmp = `${file}.${process.pid}.tmp`;
  writeFileSync11(tmp, body, { encoding: "utf8" });
  renameSync10(tmp, file);
}
function sanitizeUser(name) {
  const n = String(name ?? "").trim().replace(/[^a-zA-Z0-9._-]/g, "").slice(0, 32);
  return n || "admin";
}
function loadStore(scope) {
  try {
    const raw = readFileSync12(jsonPath8(scope), "utf8");
    const j = JSON.parse(raw);
    if (!j || typeof j !== "object" || Array.isArray(j)) return {};
    return j;
  } catch {
    return {};
  }
}
function asTile(v) {
  if (!v || typeof v !== "object") return null;
  const o = v;
  const id = String(o.id || "");
  if (!id) return null;
  const x = Math.max(0, Math.min(11, Math.round(Number(o.x) || 0)));
  const y = Math.max(0, Math.min(80, Math.round(Number(o.y) || 0)));
  const w = Math.max(2, Math.min(12, Math.round(Number(o.w) || 4)));
  const h = Math.max(3, Math.min(40, Math.round(Number(o.h) || 6)));
  return { id, x, y, w: Math.min(w, 12 - x), h };
}
function layoutGet(user, scopeRaw) {
  const scope = parseScope(scopeRaw);
  const name = sanitizeUser(user);
  const store = loadStore(scope);
  if (!Object.prototype.hasOwnProperty.call(store, name)) {
    return { ok: true, user: name, tiles: null };
  }
  const tiles = Array.isArray(store[name]) ? store[name].map(asTile).filter(Boolean) : [];
  return { ok: true, user: name, tiles };
}
function layoutSave(user, tiles, scopeRaw) {
  const scope = parseScope(scopeRaw);
  const name = sanitizeUser(user);
  const list = Array.isArray(tiles) ? tiles.map(asTile).filter(Boolean) : [];
  const store = loadStore(scope);
  store[name] = list;
  writeAtomic7(jsonPath8(scope), `${JSON.stringify(store, null, 2)}
`);
  return { ok: true, user: name, scope, tiles: store[name] };
}

// server/vfo-display.ts
import { execFile as execFile14 } from "node:child_process";
import { promisify as promisify13 } from "node:util";
var execFileAsync13 = promisify13(execFile14);
var HELPER7 = "/opt/ham-cockpit/bin/vfo-display-ctl";
function clientIp(req) {
  const forwarded = String(req.headers["x-forwarded-for"] || "").split(",")[0].trim();
  const real = String(req.headers["x-real-ip"] || "").trim();
  return real || forwarded || req.socket.remoteAddress || "";
}
function isLoopback(req) {
  const ip = clientIp(req);
  return ip === "127.0.0.1" || ip === "::1" || ip === "::ffff:127.0.0.1" || ip.endsWith("127.0.0.1");
}
async function vfoDisplayExit() {
  try {
    await execFileAsync13("sudo", ["-n", HELPER7, "exit"], { timeout: 8e3 });
    return { ok: true };
  } catch (err) {
    return { ok: false, error: String(err) };
  }
}

// server/index.ts
init_ldg();
init_lp100a();
init_spe();

// server/backup.ts
import { execFile as execFile15, spawn as spawn12 } from "node:child_process";
import { randomBytes as randomBytes4 } from "node:crypto";
import {
  accessSync,
  chmodSync as chmodSync3,
  closeSync as closeSync2,
  constants,
  cpSync,
  createWriteStream,
  existsSync as existsSync20,
  mkdirSync as mkdirSync12,
  openSync as openSync2,
  readdirSync,
  readFileSync as readFileSync13,
  readSync as readSync2,
  rmSync,
  statSync as statSync2,
  unlinkSync as unlinkSync2,
  writeFileSync as writeFileSync12
} from "node:fs";
import { tmpdir as tmpdir3 } from "node:os";
import { basename, dirname as dirname15, join as join16 } from "node:path";
import { fileURLToPath as fileURLToPath15 } from "node:url";
import { promisify as promisify14 } from "node:util";
var execFileAsync14 = promisify14(execFile15);
var ROOT14 = join16(dirname15(fileURLToPath15(import.meta.url)), "..");
var ID_RE = /^(?:hamcockpit|catbridge)-\d{8}-\d{6}-[a-f0-9]{8}$/;
var HELPER8 = "/opt/ham-cockpit/bin/station-backup";
var WAVELG_OPT_FILES = [".env", "docker-compose.yml", "wavelog-ctl.sh"];
function linux2() {
  return process.platform === "linux";
}
function backupDir() {
  if (linux2()) {
    for (const dir of ["/backup", "/opt/ham-cockpit/backup"]) {
      try {
        mkdirSync12(dir, { recursive: true });
        const probe2 = join16(dir, ".w");
        writeFileSync12(probe2, "1");
        unlinkSync2(probe2);
        return dir;
      } catch {
      }
    }
  }
  const local = join16(ROOT14, "data", "backup");
  mkdirSync12(local, { recursive: true });
  return local;
}
function stationSources() {
  const local = (name) => join16(ROOT14, "data", name);
  const cat = existsSync20("/opt/ham-cockpit");
  return [
    { key: "ser2net", dir: existsSync20("/opt/ser2net") ? "/opt/ser2net" : local("ser2net") },
    {
      key: "radios",
      dir: cat ? existsSync20("/opt/radios") && !existsSync20("/opt/ham-cockpit/radios") ? "/opt/radios" : "/opt/ham-cockpit/radios" : local("radios")
    },
    { key: "equipment", dir: cat ? "/opt/ham-cockpit/equipment" : local("equipment") },
    { key: "layouts", dir: cat ? "/opt/ham-cockpit/layouts" : local("layouts") },
    { key: "ldg", dir: cat ? "/opt/ham-cockpit/ldg" : local("ldg") },
    { key: "lp100a", dir: cat ? "/opt/ham-cockpit/lp100a" : local("lp100a") },
    { key: "net", dir: cat ? "/opt/ham-cockpit/net" : local("net") },
    { key: "services", dir: cat ? "/opt/ham-cockpit/services" : local("services") },
    { key: "lextel", dir: existsSync20("/opt/lextel") ? "/opt/lextel" : local("lextel") },
    { key: "mmdvm", dir: existsSync20("/opt/ham-cockpit/mmdvm") ? "/opt/ham-cockpit/mmdvm" : local("mmdvm") }
  ];
}
function wlgDir() {
  if (existsSync20("/opt/wavelog-gate")) return "/opt/wavelog-gate";
  return join16(ROOT14, "deploy", "wavelog-gate");
}
function wavelogDir() {
  if (existsSync20("/opt/wavelog")) return "/opt/wavelog";
  return join16(ROOT14, "deploy", "wavelog");
}
function stamp(d = /* @__PURE__ */ new Date()) {
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}
function skipName(base2) {
  if (base2 === "node_modules" || base2 === "capture.bin") return true;
  if (base2.endsWith(".lock")) return true;
  return false;
}
function isEacces(err) {
  return Boolean(err && typeof err === "object" && "code" in err && err.code === "EACCES");
}
function readable(path5) {
  try {
    accessSync(path5, constants.R_OK);
    return true;
  } catch {
    return false;
  }
}
function writableTarget(path5) {
  try {
    if (existsSync20(path5)) {
      accessSync(path5, constants.W_OK);
      return true;
    }
    accessSync(dirname15(path5), constants.W_OK);
    return true;
  } catch {
    return false;
  }
}
function run5(cmd, args, opts) {
  return new Promise((resolve, reject) => {
    const child2 = spawn12(cmd, args, {
      cwd: opts?.cwd,
      windowsHide: true,
      stdio: ["pipe", "pipe", "pipe"]
    });
    let stdout = "";
    let stderr = "";
    const timer = setTimeout(() => {
      child2.kill();
    }, opts?.timeout ?? 12e4);
    child2.stdout.on("data", (d) => {
      stdout += d.toString("utf8");
    });
    child2.stderr.on("data", (d) => {
      stderr += d.toString("utf8");
    });
    child2.on("error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
    child2.on("close", (code) => {
      clearTimeout(timer);
      resolve({ code: code ?? 1, stdout, stderr });
    });
    if (opts?.input !== void 0) child2.stdin.write(opts.input);
    child2.stdin.end();
  });
}
async function helper4(args, timeout = 15e3) {
  if (!linux2() || !existsSync20(HELPER8)) return { ok: false, stdout: "", stderr: "helper ausente" };
  try {
    const r = await run5("sudo", ["-n", HELPER8, ...args], { timeout });
    return { ok: r.code === 0, stdout: r.stdout, stderr: r.stderr };
  } catch (err) {
    return { ok: false, stdout: "", stderr: err instanceof Error ? err.message : String(err) };
  }
}
async function ensureWavelogEnvPerms(warnings) {
  if (!linux2() || !existsSync20(join16(wavelogDir(), ".env"))) return;
  if (readable(join16(wavelogDir(), ".env"))) return;
  const r = await helper4(["ensure-env"]);
  if (!r.ok) {
    warnings.push(`permiss\xF5es do Wavelog .env: ${r.stderr.trim() || "sudo/station-backup indispon\xEDvel"}`);
  }
}
async function copyPrivilegedFile(src, dest, warnings, label) {
  if (!existsSync20(src)) return false;
  mkdirSync12(dirname15(dest), { recursive: true });
  if (readable(src)) {
    try {
      cpSync(src, dest);
      return true;
    } catch (err) {
      if (!isEacces(err)) {
        warnings.push(`${label}: ${err instanceof Error ? err.message : String(err)}`);
        return false;
      }
    }
  }
  const r = await helper4(["copy", src, dest]);
  if (r.ok && existsSync20(dest)) return true;
  warnings.push(`${label}: sem permiss\xE3o para ler ${src}`);
  return false;
}
async function installPrivilegedFile(src, dest, warnings, label) {
  if (!existsSync20(src)) return false;
  mkdirSync12(dirname15(dest), { recursive: true });
  if (writableTarget(dest)) {
    try {
      cpSync(src, dest);
      return true;
    } catch (err) {
      if (!isEacces(err)) {
        warnings.push(`${label}: ${err instanceof Error ? err.message : String(err)}`);
        return false;
      }
    }
  }
  const r = await helper4(["install", src, dest]);
  if (r.ok) return true;
  warnings.push(`${label}: sem permiss\xE3o para gravar ${dest}`);
  return false;
}
function copyTree(src, dest, warnings, label) {
  if (!existsSync20(src)) return false;
  let any = false;
  const walk = (from, to) => {
    let st;
    try {
      st = statSync2(from);
    } catch (err) {
      if (isEacces(err)) warnings.push(`${label}: sem permiss\xE3o para acessar ${from}`);
      else warnings.push(`${label}: ${err instanceof Error ? err.message : String(err)}`);
      return;
    }
    if (st.isFile()) {
      if (skipName(basename(from))) return;
      try {
        mkdirSync12(dirname15(to), { recursive: true });
        cpSync(from, to);
        any = true;
      } catch (err) {
        if (isEacces(err)) warnings.push(`${label}: sem permiss\xE3o para copiar ${from}`);
        else warnings.push(`${label}: ${err instanceof Error ? err.message : String(err)}`);
      }
      return;
    }
    try {
      mkdirSync12(to, { recursive: true });
      for (const name of readdirSync(from)) {
        if (skipName(name)) continue;
        walk(join16(from, name), join16(to, name));
      }
      any = true;
    } catch (err) {
      if (isEacces(err)) warnings.push(`${label}: sem permiss\xE3o para listar ${from}`);
      else warnings.push(`${label}: ${err instanceof Error ? err.message : String(err)}`);
    }
  };
  walk(src, dest);
  return any;
}
function envValueFromText2(text, key) {
  const line = text.split(/\r?\n/).find((l) => l.startsWith(`${key}=`));
  return line ? line.slice(key.length + 1).trim().replace(/^["']|["']$/g, "") : "";
}
async function readEnvValue(file, key, warnings) {
  if (!existsSync20(file)) return "";
  if (readable(file)) {
    try {
      return envValueFromText2(readFileSync13(file, "utf8"), key);
    } catch (err) {
      if (!isEacces(err)) {
        warnings.push(`.env: ${err instanceof Error ? err.message : String(err)}`);
        return "";
      }
    }
  }
  const r = await helper4(["cat", file]);
  if (r.ok) return envValueFromText2(r.stdout, key);
  warnings.push(`sem permiss\xE3o para ler ${file}`);
  return "";
}
async function dumpWavelog(dest, warnings, parts) {
  mkdirSync12(dest, { recursive: true });
  const home = wavelogDir();
  let copiedOpt = false;
  for (const name of WAVELG_OPT_FILES) {
    const src = join16(home, name);
    if (!existsSync20(src)) continue;
    const ok = await copyPrivilegedFile(src, join16(dest, "opt", name), warnings, `wavelog:${name}`);
    if (ok) copiedOpt = true;
  }
  if (copiedOpt) parts.push("wavelog:opt");
  try {
    const { stdout } = await execFileAsync14("docker", ["volume", "ls", "-q"], { timeout: 15e3, windowsHide: true });
    const vols = stdout.split(/\r?\n/).map((v) => v.trim()).filter((v) => /wavelog/i.test(v) && !/dbdata/i.test(v));
    for (const vol of vols) {
      const out = join16(dest, `${vol}.tgz`);
      const r = await run5("docker", ["run", "--rm", "-v", `${vol}:/from:ro`, "-v", `${dest}:/to`, "alpine:3.20", "tar", "czf", `/to/${basename(out)}`, "-C", "/from", "."], {
        timeout: 18e4
      });
      if (r.code === 0 && existsSync20(out)) parts.push(`wavelog:${vol}`);
      else warnings.push(`volume ${vol}: ${r.stderr.trim() || r.code}`);
    }
  } catch (err) {
    warnings.push(`docker volumes: ${err instanceof Error ? err.message : String(err)}`);
  }
  const pass = await readEnvValue(join16(home, ".env"), "WAVELOG_DB_PASSWORD", warnings);
  if (!pass) {
    warnings.push("WAVELOG_DB_PASSWORD ausente \u2014 dump SQL do Wavelog n\xE3o feito");
    return;
  }
  try {
    const r = await run5("docker", ["exec", "wavelog-db", "mariadb-dump", `-uwavelog`, `-p${pass}`, "--single-transaction", "wavelog"], {
      timeout: 18e4
    });
    if (r.code === 0 && r.stdout.includes("CREATE TABLE")) {
      writeFileSync12(join16(dest, "wavelog.sql"), r.stdout);
      parts.push("wavelog-db");
    } else {
      warnings.push(`mariadb-dump: ${r.stderr.trim() || r.code}`);
    }
  } catch (err) {
    warnings.push(`mariadb-dump: ${err instanceof Error ? err.message : String(err)}`);
  }
}
async function restoreWavelog(src, warnings) {
  const home = wavelogDir();
  const opt = join16(src, "opt");
  if (existsSync20(opt)) {
    mkdirSync12(home, { recursive: true });
    for (const name of readdirSync(opt)) {
      const from = join16(opt, name);
      const to = join16(home, name);
      if (WAVELG_OPT_FILES.includes(name) || name.endsWith(".env")) {
        await installPrivilegedFile(from, to, warnings, `restore wavelog:${name}`);
      } else {
        try {
          cpSync(from, to);
        } catch (err) {
          warnings.push(
            isEacces(err) ? `restore wavelog:${name}: sem permiss\xE3o` : `restore wavelog:${name}: ${err instanceof Error ? err.message : String(err)}`
          );
        }
      }
    }
  }
  const tgz = existsSync20(src) ? readdirSync(src).filter((n) => n.endsWith(".tgz")) : [];
  for (const file of tgz) {
    const vol = file.replace(/\.tgz$/, "");
    const r = await run5(
      "docker",
      ["run", "--rm", "-v", `${vol}:/to`, "-v", `${src}:/from:ro`, "alpine:3.20", "sh", "-c", `rm -rf /to/* /to/.[!.]*; tar xzf /from/${file} -C /to`],
      { timeout: 18e4 }
    );
    if (r.code !== 0) warnings.push(`restore ${vol}: ${r.stderr.trim() || r.code}`);
  }
  const sql = join16(src, "wavelog.sql");
  const pass = await readEnvValue(join16(home, ".env"), "WAVELOG_DB_PASSWORD", warnings);
  if (existsSync20(sql) && pass) {
    try {
      const dump = readFileSync13(sql);
      const r = await run5("docker", ["exec", "-i", "wavelog-db", "mariadb", `-uwavelog`, `-p${pass}`, "wavelog"], {
        timeout: 18e4,
        input: dump
      });
      if (r.code !== 0) warnings.push(`mariadb restore: ${r.stderr.trim() || r.code}`);
    } catch (err) {
      warnings.push(`mariadb restore: ${err instanceof Error ? err.message : String(err)}`);
    }
  }
}
function sidecarPath(dir, id) {
  return join16(dir, `${id}.json`);
}
function archivePath(dir, id) {
  return join16(dir, `${id}.tgz`);
}
function readSidecar(dir, id) {
  try {
    const j = JSON.parse(readFileSync13(sidecarPath(dir, id), "utf8"));
    if (j && j.id === id) return j;
  } catch {
  }
  return null;
}
function toItem(dir, id) {
  const file = archivePath(dir, id);
  if (!existsSync20(file)) return null;
  const size = statSync2(file).size;
  const sc = readSidecar(dir, id);
  const st = statSync2(file);
  return {
    id,
    user: sc?.user || "admin",
    createdAt: sc?.createdAt || st.mtime.toISOString(),
    size,
    parts: sc?.parts || [],
    warnings: sc?.warnings || []
  };
}
function backupList() {
  const dir = backupDir();
  const ids = readdirSync(dir).filter((n) => n.endsWith(".tgz")).map((n) => n.replace(/\.tgz$/, "")).filter((id) => ID_RE.test(id));
  const items = ids.map((id) => toItem(dir, id)).filter((x) => Boolean(x)).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return { ok: true, folder: dir, items };
}
var jobs2 = /* @__PURE__ */ new Map();
function jobId(kind) {
  return `bk-${kind}-${Date.now().toString(36)}-${randomBytes4(3).toString("hex")}`;
}
function setProg(job2, pct, stage) {
  job2.pct = Math.max(0, Math.min(99, Math.round(pct)));
  job2.stage = stage;
}
function backupJobGet(id) {
  return jobs2.get(id) ?? null;
}
async function backupCreate(user, onProgress) {
  const who = String(user || "admin").replace(/[^a-zA-Z0-9._-]/g, "").slice(0, 32) || "admin";
  const dir = backupDir();
  const now = /* @__PURE__ */ new Date();
  const id = `hamcockpit-${stamp(now)}-${randomBytes4(4).toString("hex")}`;
  const staging = join16(tmpdir3(), id);
  mkdirSync12(join16(staging, "station"), { recursive: true });
  const parts = [];
  const warnings = [];
  const prog = onProgress ?? (() => void 0);
  try {
    prog(5, "prepare");
    await ensureWavelogEnvPerms(warnings);
    prog(15, "station");
    for (const src of stationSources()) {
      if (copyTree(src.dir, join16(staging, "station", src.key), warnings, `station:${src.key}`)) {
        parts.push(`station:${src.key}`);
      }
    }
    try {
      const users = await listUsers();
      writeFileSync12(join16(staging, "station", "linux-users.json"), `${JSON.stringify({ users }, null, 2)}
`);
      parts.push("station:users");
    } catch (err) {
      warnings.push(`users: ${err instanceof Error ? err.message : String(err)}`);
    }
    prog(35, "wlg");
    if (copyTree(wlgDir(), join16(staging, "wlg"), warnings, "wlg")) parts.push("wlg");
    prog(45, "wavelog");
    await dumpWavelog(join16(staging, "wavelog"), warnings, parts);
    prog(75, "archive");
    writeFileSync12(
      join16(staging, "manifest.json"),
      `${JSON.stringify({ version: 1, id, user: who, createdAt: now.toISOString(), parts, warnings }, null, 2)}
`
    );
    const dest = archivePath(dir, id);
    const tar = await run5("tar", ["-czf", dest, "-C", staging, "."], { timeout: 18e4 });
    if (tar.code !== 0 || !existsSync20(dest)) {
      return { ok: false, error: tar.stderr.trim() || "tar" };
    }
    try {
      chmodSync3(dest, 416);
    } catch {
    }
    prog(95, "finalize");
    const sc = { version: 1, id, user: who, createdAt: now.toISOString(), parts, warnings };
    writeFileSync12(sidecarPath(dir, id), `${JSON.stringify(sc, null, 2)}
`);
    const item2 = toItem(dir, id);
    return item2 ? { ok: true, item: item2, folder: dir } : { ok: false, error: "stat" };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : String(err) };
  } finally {
    rmSync(staging, { recursive: true, force: true });
  }
}
function backupCreateStart(user) {
  const id = jobId("create");
  const job2 = { id, kind: "create", status: "running", pct: 2, stage: "prepare", error: "" };
  jobs2.set(id, job2);
  void backupCreate(user, (pct, stage) => setProg(job2, pct, stage)).then((r) => {
    if (r.ok) {
      job2.status = "ok";
      job2.pct = 100;
      job2.stage = "done";
      job2.item = r.item;
      job2.folder = r.folder;
    } else {
      job2.status = "error";
      job2.stage = "error";
      job2.error = r.error || "backup";
    }
  }).catch((err) => {
    job2.status = "error";
    job2.stage = "error";
    job2.error = err instanceof Error ? err.message : String(err);
  }).finally(() => {
    setTimeout(() => {
      if (jobs2.get(id)?.status !== "running") jobs2.delete(id);
    }, 6e4);
  });
  return { ok: true, jobId: id };
}
function backupDelete(id) {
  if (!ID_RE.test(id)) return { ok: false, error: "id" };
  const dir = backupDir();
  const file = archivePath(dir, id);
  if (!existsSync20(file)) return { ok: false, error: "missing" };
  unlinkSync2(file);
  if (existsSync20(sidecarPath(dir, id))) unlinkSync2(sidecarPath(dir, id));
  return { ok: true };
}
async function restoreArchive(file, onProgress) {
  const staging = join16(tmpdir3(), `restore-${randomBytes4(6).toString("hex")}`);
  mkdirSync12(staging, { recursive: true });
  const warnings = [];
  const prog = onProgress ?? (() => void 0);
  try {
    prog(5, "prepare");
    prog(15, "archive");
    const tar = await run5("tar", ["-xzf", file, "-C", staging], { timeout: 18e4 });
    if (tar.code !== 0) return { ok: false, error: tar.stderr.trim() || "tar" };
    prog(35, "station");
    const station = join16(staging, "station");
    if (existsSync20(station)) {
      for (const src of stationSources()) {
        const from = join16(station, src.key);
        if (!existsSync20(from)) continue;
        mkdirSync12(src.dir, { recursive: true });
        copyTree(from, src.dir, warnings, `restore station:${src.key}`);
      }
    }
    prog(55, "wlg");
    const wlg = join16(staging, "wlg");
    if (existsSync20(wlg)) {
      const gateEnv = join16(wlg, "wavelog-gate.env");
      const destEnv = join16(wlgDir(), "wavelog-gate.env");
      copyTree(wlg, wlgDir(), warnings, "restore wlg");
      if (existsSync20(gateEnv)) {
        await installPrivilegedFile(gateEnv, destEnv, warnings, "restore wlg:env");
      }
    }
    prog(70, "wavelog");
    const wav = join16(staging, "wavelog");
    if (existsSync20(wav)) await restoreWavelog(wav, warnings);
    prog(92, "finalize");
    await ensureWavelogEnvPerms(warnings);
    return { ok: true, warnings };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : String(err) };
  } finally {
    rmSync(staging, { recursive: true, force: true });
  }
}
async function backupRestore(id, confirm, onProgress) {
  if (!confirm) return { ok: false, error: "confirm" };
  if (!ID_RE.test(id)) return { ok: false, error: "id" };
  const file = archivePath(backupDir(), id);
  if (!existsSync20(file)) return { ok: false, error: "missing" };
  return restoreArchive(file, onProgress);
}
function backupRestoreStart(id, confirm) {
  if (!confirm) return { ok: false, error: "confirm" };
  if (!ID_RE.test(id)) return { ok: false, error: "id" };
  const jobKey = jobId("restore");
  const job2 = { id: jobKey, kind: "restore", status: "running", pct: 2, stage: "prepare", error: "" };
  jobs2.set(jobKey, job2);
  void backupRestore(id, true, (pct, stage) => setProg(job2, pct, stage)).then((r) => {
    if (r.ok) {
      job2.status = "ok";
      job2.pct = 100;
      job2.stage = "done";
      job2.warnings = r.warnings;
    } else {
      job2.status = "error";
      job2.stage = "error";
      job2.error = r.error || "restore";
    }
  }).catch((err) => {
    job2.status = "error";
    job2.stage = "error";
    job2.error = err instanceof Error ? err.message : String(err);
  }).finally(() => {
    setTimeout(() => {
      if (jobs2.get(jobKey)?.status !== "running") jobs2.delete(jobKey);
    }, 6e4);
  });
  return { ok: true, jobId: jobKey };
}
var BACKUP_UPLOAD_MAX = 1024 * 1024 * 1024;
var UPLOAD_SLACK = 2 * 1024 * 1024;
var FORMAT_ERR = "O arquivo n\xE3o \xE9 um backup .tgz gerado por esta esta\xE7\xE3o.";
function backupArchiveFile(id) {
  if (!ID_RE.test(id)) return { ok: false, error: "id" };
  const file = archivePath(backupDir(), id);
  if (!existsSync20(file)) return { ok: false, error: "missing" };
  return { ok: true, path: file, filename: `${id}.tgz` };
}
function backupDropUpload(path5) {
  try {
    rmSync(path5, { force: true });
  } catch {
  }
}
function headerOne(req, name) {
  const v = req.headers[name];
  return (Array.isArray(v) ? v.join(";") : v || "").trim();
}
function multipartBoundary(contentType) {
  const m = /boundary=(?:"([^"]+)"|([^;\s]+))/i.exec(contentType);
  const b = (m?.[1] || m?.[2] || "").trim();
  return b || null;
}
function dispositionOf(headerBlock) {
  const disp = headerBlock.split(/\r?\n/).find((l) => l.toLowerCase().startsWith("content-disposition"));
  if (!disp) return { name: "", filename: "" };
  const name = /(?:^|;)\s*name="([^"]*)"/i.exec(disp)?.[1] || "";
  const star = /filename\*=UTF-8''([^;\r\n]+)/i.exec(disp)?.[1];
  const quoted = /filename="([^"]*)"/i.exec(disp)?.[1];
  let filename = "";
  if (star) {
    try {
      filename = decodeURIComponent(star.trim());
    } catch {
      filename = star.trim();
    }
  } else if (quoted) filename = quoted;
  filename = basename(filename.replace(/\\/g, "/"));
  return { name, filename };
}
function backupReadUpload(req) {
  const boundary = multipartBoundary(headerOne(req, "content-type"));
  if (!boundary) return Promise.resolve({ ok: false, error: "Envie o backup como arquivo .tgz." });
  const declared = Number(headerOne(req, "content-length") || "0");
  if (Number.isFinite(declared) && declared > BACKUP_UPLOAD_MAX + UPLOAD_SLACK) {
    req.resume?.();
    req.on("data", () => void 0);
    return Promise.resolve({ ok: false, error: "Arquivo grande demais (limite de 1 GB)." });
  }
  const openDelim = Buffer.from(`--${boundary}`);
  const nextDelim = Buffer.from(`\r
--${boundary}`);
  const headerSep = Buffer.from("\r\n\r\n");
  const keep = nextDelim.length + 4;
  return new Promise((resolve) => {
    let buf = Buffer.alloc(0);
    let mode = "start";
    let fileOut = null;
    let tmpPath = "";
    let filename = "";
    let confirm = false;
    let currentName = "";
    let fileBytes = 0;
    let total = 0;
    let done = false;
    let fieldChunks = [];
    let closed = Promise.resolve();
    let closing = false;
    const finish2 = (result) => {
      if (done) return;
      done = true;
      resolve(result);
    };
    const fail = (error3) => {
      if (done) return;
      try {
        fileOut?.destroy();
      } catch {
      }
      fileOut = null;
      if (tmpPath) backupDropUpload(tmpPath);
      tmpPath = "";
      finish2({ ok: false, error: error3 });
    };
    const writeBody = (chunk) => {
      if (!chunk.length || done) return;
      if (fileOut) {
        fileBytes += chunk.length;
        if (fileBytes > BACKUP_UPLOAD_MAX) {
          fail("Arquivo grande demais (limite de 1 GB).");
          return;
        }
        const stream2 = fileOut;
        const ok = stream2.write(chunk);
        if (!ok) {
          req.pause?.();
          stream2.once("drain", () => req.resume?.());
        }
        return;
      }
      fieldChunks.push(chunk);
      if (fieldChunks.reduce((n, c) => n + c.length, 0) > 64) fail("Campo de formul\xE1rio inv\xE1lido.");
    };
    const closePart = () => {
      if (fileOut) {
        const stream2 = fileOut;
        fileOut = null;
        closed = new Promise((res, rej) => {
          stream2.on("error", rej);
          stream2.end(() => res());
        });
      } else if (currentName === "confirm") {
        confirm = Buffer.concat(fieldChunks).toString("utf8").trim() === "true";
      }
      currentName = "";
      fieldChunks = [];
    };
    const openPart = (headerText) => {
      const d = dispositionOf(headerText);
      currentName = d.name;
      fieldChunks = [];
      if (!d.filename) return;
      if (filename) {
        fail("Envie apenas um arquivo.");
        return;
      }
      if (!/^[^\\/:*?"<>|]+\.tgz$/i.test(d.filename)) {
        fail("Use um arquivo .tgz gerado pelo backup desta esta\xE7\xE3o.");
        return;
      }
      filename = d.filename;
      tmpPath = join16(tmpdir3(), `hc-restore-${randomBytes4(8).toString("hex")}.tgz`);
      fileOut = createWriteStream(tmpPath);
      fileOut.on("error", () => fail("N\xE3o foi poss\xEDvel gravar o arquivo enviado."));
    };
    const pump3 = () => {
      for (; ; ) {
        if (done) return;
        if (mode === "start") {
          const at2 = buf.indexOf(openDelim);
          if (at2 < 0) {
            if (buf.length > openDelim.length + 64) buf = buf.subarray(buf.length - (openDelim.length + 64));
            return;
          }
          const after = at2 + openDelim.length;
          if (buf.length < after + 2) return;
          const mark = buf.subarray(after, after + 2).toString("utf8");
          if (mark === "--") {
            closing = true;
            buf = Buffer.alloc(0);
            closePart();
            void closed.then(() => {
              if (!filename || !tmpPath) {
                finish2({ ok: false, error: "Nenhum arquivo enviado." });
                return;
              }
              finish2({ ok: true, path: tmpPath, filename, confirm });
            }).catch(() => finish2({ ok: false, error: "N\xE3o foi poss\xEDvel gravar o arquivo enviado." }));
            return;
          }
          if (mark !== "\r\n") {
            fail("Envio multipart inv\xE1lido.");
            return;
          }
          buf = buf.subarray(after + 2);
          mode = "headers";
          continue;
        }
        if (mode === "headers") {
          const at2 = buf.indexOf(headerSep);
          if (at2 < 0) {
            if (buf.length > 64 * 1024) fail("Cabe\xE7alho do envio grande demais.");
            return;
          }
          const headerText = buf.subarray(0, at2).toString("utf8");
          buf = buf.subarray(at2 + 4);
          mode = "body";
          openPart(headerText);
          continue;
        }
        const at = buf.indexOf(nextDelim);
        if (at < 0) {
          const safe = buf.length - keep;
          if (safe > 0) {
            const chunk = buf.subarray(0, safe);
            buf = buf.subarray(safe);
            writeBody(chunk);
          }
          return;
        }
        writeBody(buf.subarray(0, at));
        if (done) return;
        closePart();
        buf = buf.subarray(at + 2);
        mode = "start";
      }
    };
    req.on("data", (chunk) => {
      if (done || !chunk || chunk instanceof Error) return;
      total += chunk.length;
      if (total > BACKUP_UPLOAD_MAX + UPLOAD_SLACK) {
        fail("Arquivo grande demais (limite de 1 GB).");
        return;
      }
      buf = Buffer.concat([buf, chunk]);
      pump3();
    });
    req.on("end", () => {
      if (done || closing) return;
      pump3();
      if (!done && !closing) fail("Envio multipart incompleto.");
    });
    req.on("error", () => fail("N\xE3o foi poss\xEDvel ler o arquivo enviado."));
  });
}
function unsafeMember(name) {
  const n = name.replace(/\\/g, "/").trim();
  if (!n || n.startsWith("/") || /^[a-zA-Z]:/.test(n)) return true;
  return n.split("/").some((part) => part === "..");
}
function rootManifestMember(listing) {
  for (const raw of listing.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line) continue;
    if (unsafeMember(line)) return null;
    if (line.replace(/^\.\//, "") === "manifest.json") return line;
  }
  return null;
}
async function backupValidateUpload(file, originalName) {
  const base2 = basename(originalName);
  if (!/^[^\\/:*?"<>|]+\.tgz$/i.test(base2)) {
    return { ok: false, error: "Use um arquivo .tgz gerado pelo backup desta esta\xE7\xE3o." };
  }
  let size = 0;
  try {
    size = statSync2(file).size;
  } catch {
    return { ok: false, error: FORMAT_ERR };
  }
  if (size <= 0) return { ok: false, error: FORMAT_ERR };
  if (size > BACKUP_UPLOAD_MAX) return { ok: false, error: "Arquivo grande demais (limite de 1 GB)." };
  const fh = openSync2(file, "r");
  const magic = Buffer.alloc(2);
  try {
    if (readSync2(fh, magic, 0, 2, 0) < 2) return { ok: false, error: FORMAT_ERR };
  } finally {
    closeSync2(fh);
  }
  if (magic[0] !== 31 || magic[1] !== 139) return { ok: false, error: FORMAT_ERR };
  const listed = await run5("tar", ["-tzf", file], { timeout: 12e4 });
  if (listed.code !== 0) return { ok: false, error: FORMAT_ERR };
  if (listed.stdout.split(/\r?\n/).some((line) => line.trim() && unsafeMember(line.trim()))) {
    return { ok: false, error: FORMAT_ERR };
  }
  const member = rootManifestMember(listed.stdout);
  if (!member) return { ok: false, error: FORMAT_ERR };
  const manifest = await run5("tar", ["-xOf", file, member], { timeout: 6e4 });
  if (manifest.code !== 0 || !manifest.stdout.trim()) return { ok: false, error: FORMAT_ERR };
  let parsed;
  try {
    parsed = JSON.parse(manifest.stdout);
  } catch {
    return { ok: false, error: FORMAT_ERR };
  }
  if (parsed.version !== 1 || typeof parsed.id !== "string" || !ID_RE.test(parsed.id)) {
    return { ok: false, error: FORMAT_ERR };
  }
  return { ok: true };
}
function backupRestoreFileStart(filePath, confirm) {
  if (!confirm || !existsSync20(filePath)) {
    backupDropUpload(filePath);
    return {
      ok: false,
      error: confirm ? "missing" : "Confirme a restaura\xE7\xE3o antes de continuar."
    };
  }
  const jobKey = jobId("restore");
  const job2 = { id: jobKey, kind: "restore", status: "running", pct: 2, stage: "prepare", error: "" };
  jobs2.set(jobKey, job2);
  void restoreArchive(filePath, (pct, stage) => setProg(job2, pct, stage)).then((r) => {
    if (r.ok) {
      job2.status = "ok";
      job2.pct = 100;
      job2.stage = "done";
      job2.warnings = r.warnings;
    } else {
      job2.status = "error";
      job2.stage = "error";
      job2.error = r.error || "restore";
    }
  }).catch((err) => {
    job2.status = "error";
    job2.stage = "error";
    job2.error = err instanceof Error ? err.message : String(err);
  }).finally(() => {
    backupDropUpload(filePath);
    setTimeout(() => {
      if (jobs2.get(jobKey)?.status !== "running") jobs2.delete(jobKey);
    }, 6e4);
  });
  return { ok: true, jobId: jobKey };
}

// server/host-status.ts
import { execFile as execFile16 } from "node:child_process";
import { existsSync as existsSync22, readdirSync as readdirSync2, readFileSync as readFileSync15, statfsSync } from "node:fs";
import { dirname as dirname16, join as join17 } from "node:path";
import { fileURLToPath as fileURLToPath16 } from "node:url";
import os from "node:os";
import { promisify as promisify15 } from "node:util";

// shared/license-keys.ts
var LICENSE_KEYRING = [
  { kid: "d8GApVW5", label: "k1", env: "prod", pub: "d8GApVW51biDApMLOm-IkMmJJDvNJXZBCrBeaZy7-o4", status: "active" },
  { kid: "yZZtM_MM", label: "k2", env: "prod", pub: "yZZtM_MMa0KhA-ePm9Sa2pe4GqnzNdST-qMEALsiQyo", status: "standby" }
];

// shared/license.ts
var TOKEN_PREFIX = "HCL1";
var PROVISIONAL_DAYS = 7;
var ROLLBACK_TOLERANCE_S = 36 * 3600;
var HONOR_PORTAL_POLICY = false;
function b64urlDecode(text) {
  if (!/^[A-Za-z0-9_-]*$/.test(text)) throw new Error("base64url inv\xE1lido");
  const pad = text.length % 4 === 0 ? "" : "=".repeat(4 - text.length % 4);
  const bin = atob(text.replace(/-/g, "+").replace(/_/g, "/") + pad);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
var enc = new TextEncoder();
var dec = new TextDecoder();
function concatBytes(a, b) {
  const out = new Uint8Array(a.length + b.length);
  out.set(a, 0);
  out.set(b, a.length);
  return out;
}
function normalizeSerial(raw) {
  const hex = String(raw ?? "").trim().toLowerCase().replace(/[^0-9a-f]/g, "");
  if (hex.length < 16) return null;
  const s = hex.slice(-16);
  return /^0{16}$/.test(s) ? null : s;
}
async function serialCheck(serial) {
  const d = new Uint8Array(await crypto.subtle.digest("SHA-256", enc.encode(`hc1:${serial}`)));
  return d[0].toString(16).padStart(2, "0").toUpperCase();
}
async function serialDisplay(serial) {
  const groups = serial.toUpperCase().match(/.{4}/g) ?? [];
  return `${groups.join("-")}-${await serialCheck(serial)}`;
}
function serialFromCpuinfo(cpuinfo, deviceTree) {
  if (cpuinfo) {
    const m = cpuinfo.match(/^Serial\s*:\s*([0-9a-fA-F]+)\s*$/m);
    if (m) {
      const s = normalizeSerial(m[1]);
      if (s) return s;
    }
  }
  if (deviceTree) {
    const s = normalizeSerial(deviceTree.replace(/\0+$/g, ""));
    if (s) return s;
  }
  return null;
}
function normalizeCallsign(raw) {
  const base2 = String(raw ?? "").trim().toUpperCase().replace(/[^A-Z0-9/]/g, "").split("/")[0];
  return base2 || "";
}
function isValidCallsign(raw) {
  const c = normalizeCallsign(raw);
  if (c.length < 3 || c.length > 10) return false;
  if (c === "N0CALL" || c === "NOCALL") return false;
  if (!/[A-Z]/.test(c) || !/[0-9]/.test(c)) return false;
  return /^[A-Z0-9]{1,3}[0-9][A-Z0-9]{0,3}[A-Z]$/.test(c);
}
function normalizeEmail(raw) {
  return String(raw ?? "").trim().toLowerCase().slice(0, 120);
}
function isValidEmail(raw) {
  const e = normalizeEmail(raw);
  if (e.length < 5 || e.length > 120) return false;
  return /^[^\s@]{1,64}@[^\s@]{1,200}\.[^\s@]{2,24}$/.test(e);
}
var pubCache = /* @__PURE__ */ new Map();
async function importPublic(pub) {
  let k = pubCache.get(pub);
  if (!k) {
    k = await crypto.subtle.importKey("raw", b64urlDecode(pub), { name: "Ed25519" }, false, ["verify"]);
    pubCache.set(pub, k);
  }
  return k;
}
function cleanToken(text) {
  return String(text ?? "").replace(/\s+/g, "");
}
async function verifyBlob(prefix, text, keyring = LICENSE_KEYRING) {
  const t = cleanToken(text);
  const parts = t.split(".");
  if (parts.length !== 3 || parts[0] !== prefix || !parts[1] || !parts[2]) return { ok: false, error: "invalid_format" };
  let payloadBytes;
  let sig;
  let payload;
  try {
    payloadBytes = b64urlDecode(parts[1]);
    sig = b64urlDecode(parts[2]);
    payload = JSON.parse(dec.decode(payloadBytes));
  } catch {
    return { ok: false, error: "invalid_format" };
  }
  if (!payload || typeof payload !== "object" || payload.v !== 1 || typeof payload.kid !== "string") {
    return { ok: false, error: "invalid_format" };
  }
  const entry = keyring.find((k) => k.kid === payload.kid && k.status !== "revoked");
  if (!entry) return { ok: false, error: "unknown_kid" };
  if (sig.length !== 64) return { ok: false, error: "bad_signature" };
  const msg = concatBytes(enc.encode(`${prefix}
`), payloadBytes);
  let ok = false;
  try {
    ok = await crypto.subtle.verify({ name: "Ed25519" }, await importPublic(entry.pub), sig, msg);
  } catch {
    ok = false;
  }
  return ok ? { ok: true, payload, kid: entry.kid } : { ok: false, error: "bad_signature" };
}
async function verifyLicenseToken(token, serial, keyring = LICENSE_KEYRING) {
  const r = await verifyBlob(TOKEN_PREFIX, token, keyring);
  if (!r.ok) return r;
  const p = r.payload;
  const okShape = typeof p.lid === "string" && typeof p.serial === "string" && (p.type === "trial" || p.type === "definitive") && Number.isFinite(p.iat) && (p.exp === null || Number.isFinite(p.exp)) && typeof p.line === "string" && Number.isFinite(p.st);
  if (!okShape) return { ok: false, error: "invalid_payload" };
  if (!serial || p.serial !== serial) return { ok: false, error: "serial_mismatch" };
  return { ok: true, payload: p };
}
var EMPTY_CLOCK_STATE = { maxSeen: 0, checkpointUptime: 0, maxServerTime: 0 };
function effectiveNow(state, c, floor = 0) {
  const base2 = c.uptime >= state.checkpointUptime ? state.checkpointUptime : 0;
  const provable = state.maxSeen + Math.max(0, c.uptime - base2);
  const wallTrusted = c.ntpSynced ? c.wall : Math.min(c.wall, provable + ROLLBACK_TOLERANCE_S);
  const now = Math.floor(Math.max(wallTrusted, provable, c.witness, state.maxServerTime, floor));
  const suspect = state.maxSeen > 0 && c.wall < state.maxSeen - ROLLBACK_TOLERANCE_S;
  return {
    now,
    suspect,
    next: {
      maxSeen: Math.max(state.maxSeen, now),
      checkpointUptime: c.uptime,
      maxServerTime: state.maxServerTime
    }
  };
}
function anchorServerTime(state, st) {
  return { ...state, maxServerTime: Math.max(state.maxServerTime, Number.isFinite(st) ? st : 0) };
}
function licenseGateOf(state) {
  if (state === "ativa") return "licensed";
  if (state === "trial") return "trial";
  if (state === "expirada") return "trial_expired";
  return "unlicensed";
}
function lineCovers(line, appVersion) {
  if (!appVersion) return true;
  const major = appVersion.split(".")[0];
  return line === "*" || line === major;
}
function evaluateLicense(i) {
  const blank = {
    state: "sem_licenca",
    type: null,
    licenseId: null,
    issuedAt: null,
    expiresAt: null,
    daysLeft: null,
    provisionalEndsAt: null,
    allowed: false,
    reason: null,
    clockSuspect: !!i.clockSuspect
  };
  if (!i.serial) return { ...blank, state: "sem_serial", allowed: true, reason: "serial_unavailable" };
  const provDays = i.provisionalDays ?? PROVISIONAL_DAYS;
  const provEnd = i.firstSeen + provDays * 86400;
  const inProvisional = i.now < provEnd;
  const noTokenVerdict = (reason, invalid) => {
    if (inProvisional) {
      return { ...blank, state: invalid ? "invalida" : "provisional", provisionalEndsAt: provEnd, allowed: true, reason };
    }
    return { ...blank, state: "sem_licenca", provisionalEndsAt: provEnd, allowed: false, reason: reason ?? "no_license" };
  };
  if (!i.token) return noTokenVerdict(null, false);
  if (!i.token.ok) return noTokenVerdict(i.token.error, true);
  const p = i.token.payload;
  const common = { type: p.type, licenseId: p.lid, issuedAt: p.iat, expiresAt: p.exp, provisionalEndsAt: null };
  if (!lineCovers(p.line, i.appVersion)) return noTokenVerdict("line_not_covered", true);
  if (i.revoked?.has(p.lid)) return { ...blank, ...common, state: "revogada", allowed: false, reason: "revoked" };
  if (p.exp !== null && i.now >= p.exp) {
    return { ...blank, ...common, state: "expirada", daysLeft: 0, allowed: false, reason: "expired" };
  }
  return {
    ...blank,
    ...common,
    state: p.type === "definitive" ? "ativa" : "trial",
    daysLeft: p.exp === null ? null : Math.max(0, Math.ceil((p.exp - i.now) / 86400)),
    allowed: true,
    reason: null
  };
}

// server/license.ts
import { existsSync as existsSync21, mkdirSync as mkdirSync13, readFileSync as readFileSync14, writeFileSync as writeFileSync13 } from "node:fs";
import { homedir } from "node:os";
import path3 from "node:path";
var PORTAL_ORIGIN = process.env.HAMCOCKPIT_PORTAL_URL || "https://ham-cockpit.pages.dev";
var DATA_DIR = process.env.HAMCOCKPIT_LICENSE_DIR || (process.platform === "win32" ? path3.join(homedir(), "AppData", "Local", "hamcockpit", "license") : "/var/lib/hamcockpit/license");
var RUN_DIR = process.env.HAMCOCKPIT_LICENSE_RUN || (process.platform === "win32" ? path3.join(DATA_DIR, "run") : "/run/ham-cockpit");
function emptyStore(now = Math.floor(Date.now() / 1e3)) {
  return {
    firstSeen: now,
    token: null,
    receipt: null,
    lastSync: null,
    clock: { ...EMPTY_CLOCK_STATE },
    enforceLocal: false,
    crlVersion: 0,
    revoked: [],
    callsign: null,
    email: null
  };
}
function ensureDataDir() {
  mkdirSync13(DATA_DIR, { recursive: true });
}
function tryEnsureRunDir() {
  try {
    mkdirSync13(RUN_DIR, { recursive: true });
    return true;
  } catch {
    return false;
  }
}
function storePath() {
  return path3.join(DATA_DIR, "state.json");
}
function readStore() {
  ensureDataDir();
  const p = storePath();
  if (!existsSync21(p)) {
    const s = emptyStore();
    writeFileSync13(p, JSON.stringify(s, null, 2) + "\n");
    return s;
  }
  try {
    const raw = JSON.parse(readFileSync14(p, "utf8"));
    return {
      ...emptyStore(typeof raw.firstSeen === "number" ? raw.firstSeen : void 0),
      ...raw,
      callsign: typeof raw.callsign === "string" && raw.callsign ? normalizeCallsign(raw.callsign) || null : null,
      email: typeof raw.email === "string" && raw.email && isValidEmail(raw.email) ? normalizeEmail(raw.email) : null,
      clock: raw.clock ? { ...EMPTY_CLOCK_STATE, ...raw.clock } : { ...EMPTY_CLOCK_STATE },
      revoked: Array.isArray(raw.revoked) ? raw.revoked.map(String) : []
    };
  } catch {
    return emptyStore();
  }
}
function writeStore(s) {
  ensureDataDir();
  writeFileSync13(storePath(), JSON.stringify(s, null, 2) + "\n");
}
function readDeviceSerial() {
  if (process.env.HAMCOCKPIT_SERIAL) return serialFromCpuinfo(null, process.env.HAMCOCKPIT_SERIAL);
  try {
    if (existsSync21("/proc/cpuinfo")) {
      const cpu = readFileSync14("/proc/cpuinfo", "utf8");
      const dt = existsSync21("/proc/device-tree/serial-number") ? readFileSync14("/proc/device-tree/serial-number", "utf8") : null;
      return serialFromCpuinfo(cpu, dt);
    }
  } catch {
  }
  return null;
}
function uptimeSec() {
  try {
    if (existsSync21("/proc/uptime")) {
      const n = Number.parseFloat(readFileSync14("/proc/uptime", "utf8").split(" ")[0] || "0");
      return Number.isFinite(n) ? Math.floor(n) : 0;
    }
  } catch {
  }
  return Math.floor(process.uptime());
}
function ntpSynced() {
  return false;
}
async function computeVerdict(store, serial) {
  const clockIn = {
    wall: Math.floor(Date.now() / 1e3),
    uptime: uptimeSec(),
    ntpSynced: ntpSynced(),
    witness: 0
  };
  const eff = effectiveNow(store.clock, clockIn, store.firstSeen);
  const token = store.token ? await verifyLicenseToken(store.token, serial) : null;
  const verdict = evaluateLicense({
    serial,
    token,
    revoked: new Set(store.revoked),
    now: eff.now,
    firstSeen: store.firstSeen,
    provisionalDays: PROVISIONAL_DAYS,
    appVersion: APP_VERSION,
    clockSuspect: eff.suspect
  });
  return { verdict, clockSuspect: eff.suspect, now: eff.now, nextClock: eff.next };
}
function lockedFor(verdict, store) {
  if (!store.enforceLocal) return false;
  if (!HONOR_PORTAL_POLICY) return false;
  return !verdict.allowed;
}
async function toApi(store, online = null) {
  const serial = readDeviceSerial();
  const { verdict, clockSuspect, nextClock } = await computeVerdict(store, serial);
  store.clock = nextClock;
  writeStore(store);
  const display = serial ? await serialDisplay(serial) : null;
  const buyUrl = display ? `${PORTAL_ORIGIN}/comprar?serial=${encodeURIComponent(display)}` : null;
  const body = {
    serial,
    serialDisplay: display,
    callsign: store.callsign,
    email: store.email,
    state: verdict.state,
    gate: licenseGateOf(verdict.state),
    type: verdict.type,
    licenseId: verdict.licenseId,
    issuedAt: verdict.issuedAt,
    expiresAt: verdict.expiresAt,
    daysLeft: verdict.daysLeft,
    provisionalEndsAt: verdict.provisionalEndsAt,
    locked: lockedFor(verdict, store),
    observationOnly: !store.enforceLocal || !HONOR_PORTAL_POLICY,
    clock: { suspect: clockSuspect, ntpSynced: ntpSynced() },
    lastSync: store.lastSync,
    online,
    buyUrl,
    reason: verdict.reason,
    portalUrl: PORTAL_ORIGIN
  };
  try {
    if (tryEnsureRunDir()) {
      writeFileSync13(path3.join(RUN_DIR, "license.json"), JSON.stringify({ ...body, at: Math.floor(Date.now() / 1e3) }, null, 2) + "\n");
    }
  } catch {
  }
  return body;
}
async function applyPortalResponse(store, serial, j) {
  if (j.token) {
    const check = await verifyLicenseToken(j.token, serial);
    if (check.ok) store.token = cleanToken(j.token);
  }
  if (j.receipt) {
    const r = await verifyBlob("HCR1", j.receipt);
    if (r.ok) {
      store.receipt = cleanToken(j.receipt);
      store.clock = anchorServerTime(store.clock, r.payload.st);
    }
  }
  if (typeof j.crlVersion === "number") store.crlVersion = j.crlVersion;
  store.lastSync = Math.floor(Date.now() / 1e3);
  writeStore(store);
}
async function activateWithPortal(opts = {}) {
  const store = readStore();
  const serial = readDeviceSerial();
  if (!serial) return { ok: false, body: await toApi(store, false), error: "serial_unavailable" };
  const callsign = normalizeCallsign(opts.callsign ?? store.callsign ?? "");
  if (!isValidCallsign(callsign)) {
    return { ok: false, body: await toApi(store, null), error: "callsign_required" };
  }
  const email = normalizeEmail(opts.email ?? store.email ?? "");
  if (!isValidEmail(email)) {
    return { ok: false, body: await toApi(store, null), error: "email_required" };
  }
  store.callsign = callsign;
  store.email = email;
  writeStore(store);
  try {
    const r = await fetch(`${PORTAL_ORIGIN}/api/lic/activate`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        serial,
        appVersion: APP_VERSION,
        nonce: crypto.randomUUID(),
        callsign,
        prefix: callsign,
        email
      }),
      signal: AbortSignal.timeout(15e3)
    });
    const j = await r.json();
    if (!r.ok) return { ok: false, body: await toApi(store, true), error: j.message || j.error || "portal_error" };
    await applyPortalResponse(store, serial, { token: j.license?.token, receipt: j.receipt, status: j.status, crlVersion: j.crlVersion });
    return { ok: true, body: await toApi(store, true) };
  } catch {
    return { ok: false, body: await toApi(store, false), error: "portal_unreachable" };
  }
}
async function importLicenseToken(raw) {
  const store = readStore();
  const serial = readDeviceSerial();
  const token = cleanToken(raw);
  const check = await verifyLicenseToken(token, serial);
  if (!check.ok) return { ok: false, body: await toApi(store, null), error: check.error };
  if (store.token) {
    const cur = await verifyLicenseToken(store.token, serial);
    if (cur.ok && check.ok && check.payload.st < cur.payload.st) {
      return { ok: false, body: await toApi(store, null), error: "older_than_current" };
    }
  }
  store.token = token;
  store.lastSync = Math.floor(Date.now() / 1e3);
  writeStore(store);
  return { ok: true, body: await toApi(store, null) };
}
function registerLicenseRoutes(app) {
  app.get("/api/license", async (_req, res) => {
    try {
      res.json(await toApi(readStore(), null));
    } catch (err) {
      const serial = readDeviceSerial();
      let serialDisp = null;
      try {
        serialDisp = serial ? await serialDisplay(serial) : null;
      } catch {
        serialDisp = serial;
      }
      const state = serial ? "sem_licenca" : "sem_serial";
      res.status(500).json({
        ok: false,
        error: String(err),
        serial,
        serialDisplay: serialDisp,
        callsign: null,
        email: null,
        state,
        gate: licenseGateOf(state)
      });
    }
  });
  app.post("/api/license/activate", async (req, res) => {
    try {
      const callsign = typeof req.body?.callsign === "string" ? req.body.callsign : typeof req.body?.prefix === "string" ? req.body.prefix : void 0;
      const email = typeof req.body?.email === "string" ? req.body.email : void 0;
      const r = await activateWithPortal({ callsign, email });
      const status = r.ok ? 200 : r.error === "portal_unreachable" ? 502 : 400;
      res.status(status).json(r);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/license/import", async (req, res) => {
    try {
      const raw = typeof req.body === "string" ? req.body : typeof req.body?.token === "string" ? req.body.token : "";
      if (!raw.trim()) {
        res.status(400).json({ ok: false, error: "invalid_format" });
        return;
      }
      const r = await importLicenseToken(raw);
      res.status(r.ok ? 200 : 400).json(r);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.get("/api/license/request", async (_req, res) => {
    try {
      const serial = readDeviceSerial();
      if (!serial) {
        res.status(400).json({ ok: false, error: "serial_unavailable" });
        return;
      }
      const display = await serialDisplay(serial);
      const chk = display.slice(-2);
      const store = readStore();
      res.json({
        serial,
        display,
        chk,
        callsign: store.callsign,
        email: store.email,
        appVersion: APP_VERSION,
        portalUrl: PORTAL_ORIGIN,
        buyUrl: `${PORTAL_ORIGIN}/comprar?serial=${encodeURIComponent(display)}`,
        licenseUrl: `${PORTAL_ORIGIN}/licenca?serial=${encodeURIComponent(display)}`
      });
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
}

// server/host-status.ts
var HOST_ROOT = join17(dirname16(fileURLToPath16(import.meta.url)), "..");
function installedAppVersion() {
  for (const p of [
    join17("/opt/ham-cockpit", "VERSION"),
    join17("/opt/cat-bridge", "VERSION"),
    join17(HOST_ROOT, "VERSION")
  ]) {
    try {
      if (!existsSync22(p)) continue;
      const v = cleanVersion(readFileSync15(p, "utf8"));
      if (v) return v;
    } catch {
    }
  }
  return cleanVersion(APP_VERSION);
}
var execFileAsync15 = promisify15(execFile16);
var HOST_SAMPLE_MS = 5e3;
var HOST_WINDOW_MS = 5 * 60 * 1e3;
var MAX_SAMPLES = Math.ceil(HOST_WINDOW_MS / HOST_SAMPLE_MS) + 4;
var samples = [];
var cpuPrev = null;
var netPrev = null;
var sampler = null;
var sampling = false;
var identity = null;
var PI_TYPE = {
  0: "Raspberry Pi A",
  1: "Raspberry Pi B",
  2: "Raspberry Pi A+",
  3: "Raspberry Pi B+",
  4: "Raspberry Pi 2 Model B",
  6: "Raspberry Pi Compute Module 1",
  8: "Raspberry Pi 3 Model B",
  9: "Raspberry Pi Zero",
  10: "Raspberry Pi Compute Module 3",
  12: "Raspberry Pi Zero W",
  13: "Raspberry Pi 3 Model B Plus",
  14: "Raspberry Pi 3 Model A Plus",
  16: "Raspberry Pi Compute Module 3+",
  17: "Raspberry Pi 4 Model B",
  18: "Raspberry Pi Zero 2 W",
  19: "Raspberry Pi 400",
  20: "Raspberry Pi Compute Module 4",
  21: "Raspberry Pi Compute Module 4S",
  23: "Raspberry Pi 5",
  24: "Raspberry Pi Compute Module 5",
  25: "Raspberry Pi 500",
  26: "Raspberry Pi Compute Module 5 Lite"
};
var PI_SOC = {
  0: "BCM2835",
  1: "BCM2835",
  2: "BCM2835",
  3: "BCM2835",
  4: "BCM2836",
  6: "BCM2835",
  8: "BCM2837",
  9: "BCM2835",
  10: "BCM2837",
  12: "BCM2835",
  13: "BCM2837B0",
  14: "BCM2837B0",
  16: "BCM2837B0",
  17: "BCM2711",
  18: "BCM2710A1",
  19: "BCM2711",
  20: "BCM2711",
  21: "BCM2711",
  23: "BCM2712",
  24: "BCM2712",
  25: "BCM2712",
  26: "BCM2712"
};
function readText(path5) {
  const raw = readFileSync15(path5);
  return raw.toString("utf8").replace(/\0/g, "").trim();
}
function readDtModel() {
  for (const p of ["/sys/firmware/devicetree/base/model", "/proc/device-tree/model"]) {
    try {
      if (!existsSync22(p)) continue;
      const s = readText(p);
      if (s) return s;
    } catch {
    }
  }
  return "";
}
function parseCpuinfo() {
  const out = { hardware: "", revision: "", model: "" };
  try {
    if (!existsSync22("/proc/cpuinfo")) return out;
    const text = readFileSync15("/proc/cpuinfo", "utf8");
    for (const line of text.split(/\r?\n/)) {
      const i = line.indexOf(":");
      if (i < 0) continue;
      const k = line.slice(0, i).trim().toLowerCase();
      const v = line.slice(i + 1).trim();
      if (k === "hardware") out.hardware = v;
      else if (k === "revision") out.revision = v;
      else if (k === "model") out.model = v;
    }
  } catch {
  }
  return out;
}
function decodePiRevision(raw) {
  const n = Number.parseInt(raw.replace(/^0x/i, ""), 16);
  if (!Number.isFinite(n) || n <= 0) return null;
  if (!(n >> 23 & 1)) return null;
  const type = n >> 4 & 255;
  const rev = n & 15;
  const name = PI_TYPE[type];
  if (!name) return { model: `Raspberry Pi (rev ${raw})`, soc: PI_SOC[type] || "" };
  return { model: `${name} Rev 1.${rev}`, soc: PI_SOC[type] || "" };
}
function readOsRelease() {
  const map = {};
  try {
    if (!existsSync22("/etc/os-release")) return map;
    for (const line of readFileSync15("/etc/os-release", "utf8").split(/\r?\n/)) {
      const i = line.indexOf("=");
      if (i < 0) continue;
      const k = line.slice(0, i).trim();
      let v = line.slice(i + 1).trim();
      if (v.startsWith('"') && v.endsWith('"') || v.startsWith("'") && v.endsWith("'")) v = v.slice(1, -1);
      map[k] = v;
    }
  } catch {
  }
  return map;
}
function formatOsPretty(rel) {
  const pretty = rel.PRETTY_NAME || "";
  const variant = (rel.VARIANT || rel.VARIANT_ID || "").toLowerCase();
  if (pretty) {
    const serverHint = variant.includes("server") || existsSync22("/usr/share/doc/ubuntu-server") || existsSync22("/var/lib/dpkg/info/ubuntu-server.list") || existsSync22("/proc/device-tree/model");
    if (/ubuntu/i.test(pretty) && !/server/i.test(pretty) && serverHint) {
      return pretty.replace(/Ubuntu/i, "Ubuntu Server");
    }
    return pretty;
  }
  const name = rel.NAME || "";
  const ver = rel.VERSION || rel.VERSION_ID || "";
  return [name, ver].filter(Boolean).join(" ").trim();
}
function cpuTimes() {
  let idle = 0;
  let total = 0;
  for (const c of os.cpus()) {
    const t = c.times;
    idle += t.idle;
    total += t.user + t.nice + t.sys + t.idle + t.irq;
  }
  return { idle, total };
}
function cpuPctFromDelta() {
  const cur = cpuTimes();
  const prev = cpuPrev;
  cpuPrev = cur;
  if (!prev) return null;
  const dTotal = cur.total - prev.total;
  const dIdle = cur.idle - prev.idle;
  if (dTotal <= 0) return null;
  const pct = (1 - dIdle / dTotal) * 100;
  if (!Number.isFinite(pct)) return null;
  return Math.round(Math.max(0, Math.min(100, pct)) * 10) / 10;
}
function readRam() {
  try {
    if (existsSync22("/proc/meminfo")) {
      const text = readFileSync15("/proc/meminfo", "utf8");
      const grab = (key) => {
        const m = text.match(new RegExp(`^${key}:\\s+(\\d+)`, "m"));
        return m ? Number(m[1]) * 1024 : 0;
      };
      const total2 = grab("MemTotal");
      let avail = grab("MemAvailable");
      if (!avail) avail = grab("MemFree") + grab("Buffers") + grab("Cached");
      if (total2 > 0) {
        const used2 = Math.max(0, total2 - avail);
        return { total: total2, used: used2, pct: Math.round(used2 / total2 * 1e3) / 10 };
      }
    }
  } catch {
  }
  const total = os.totalmem();
  const free = os.freemem();
  const used = Math.max(0, total - free);
  const pct = total > 0 ? Math.round(used / total * 1e3) / 10 : null;
  return { total, used, pct };
}
function readThermalZoneC() {
  const root = "/sys/class/thermal";
  if (!existsSync22(root)) return null;
  try {
    const zones = readdirSync2(root).filter((n) => n.startsWith("thermal_zone"));
    let best = null;
    for (const z of zones) {
      const typePath = `${root}/${z}/type`;
      const tempPath = `${root}/${z}/temp`;
      if (!existsSync22(tempPath)) continue;
      let prefer = false;
      try {
        const type = readFileSync15(typePath, "utf8").trim().toLowerCase();
        prefer = type.includes("cpu") || type.includes("soc") || type === "x86_pkg_temp" || type === "cpu-thermal";
      } catch {
      }
      const raw = Number(readFileSync15(tempPath, "utf8").trim());
      if (!Number.isFinite(raw) || raw <= 0) continue;
      const c = raw > 1e3 ? raw / 1e3 : raw;
      if (prefer) return Math.round(c * 10) / 10;
      if (best == null || c > best) best = c;
    }
    return best == null ? null : Math.round(best * 10) / 10;
  } catch {
    return null;
  }
}
async function readVcgencmdTempC() {
  try {
    const { stdout } = await execFileAsync15("vcgencmd", ["measure_temp"], { timeout: 2e3 });
    const m = stdout.match(/temp=([\d.]+)/i);
    if (!m) return null;
    const c = Number(m[1]);
    return Number.isFinite(c) ? Math.round(c * 10) / 10 : null;
  } catch {
    return null;
  }
}
var windowsTempTried = false;
var windowsTempOk = false;
async function readWindowsTempC() {
  if (process.platform !== "win32") return null;
  if (windowsTempTried && !windowsTempOk) return null;
  try {
    const { stdout } = await execFileAsync15(
      "powershell",
      [
        "-NoProfile",
        "-Command",
        "(Get-CimInstance Win32_PerfFormattedData_Counters_ThermalZoneInformation -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty Temperature)"
      ],
      { timeout: 4e3, windowsHide: true }
    );
    windowsTempTried = true;
    const kelvin = Number(String(stdout).trim());
    if (!Number.isFinite(kelvin) || kelvin < 200) return null;
    windowsTempOk = true;
    return Math.round((kelvin - 273.15) * 10) / 10;
  } catch {
    windowsTempTried = true;
    return null;
  }
}
async function readCpuTempC() {
  let cpuTempC = readThermalZoneC();
  if (cpuTempC == null) cpuTempC = await readVcgencmdTempC();
  if (cpuTempC == null) cpuTempC = await readWindowsTempC();
  return cpuTempC;
}
function diskRoots() {
  if (process.platform === "win32") {
    const home = process.env.SystemDrive || "C:";
    return [`${home}\\`];
  }
  return ["/", "/data", "/opt"];
}
function readDisk() {
  for (const p of diskRoots()) {
    try {
      if (!existsSync22(p)) continue;
      const s = statfsSync(p);
      const total = Number(s.bsize) * Number(s.blocks);
      const free = Number(s.bsize) * Number(s.bavail ?? s.bfree);
      if (total > 0) return { total, free, path: p };
    } catch {
    }
  }
  return { total: 0, free: 0, path: process.platform === "win32" ? "C:\\" : "/" };
}
function formatCpuModel(model, n) {
  const mhz = os.cpus()[0]?.speed;
  const hz = mhz && mhz > 0 ? ` \xB7 ${n}\xD7${mhz >= 1e3 ? `${(mhz / 1e3).toFixed(1)} GHz` : `${mhz} MHz`}` : n > 1 ? ` \xB7 ${n} n\xFAcleos` : "";
  return `${model}${hz}`;
}
function readNetTotals() {
  if (process.platform !== "linux" || !existsSync22("/proc/net/dev")) return { rx: 0, tx: 0 };
  try {
    let rx3 = 0;
    let tx = 0;
    const text = readFileSync15("/proc/net/dev", "utf8");
    for (const line of text.split(/\r?\n/)) {
      const m = line.match(/^\s*([^:]+):\s*(.+)$/);
      if (!m) continue;
      const name = m[1].trim();
      if (name === "lo" || name.startsWith("veth") || name.startsWith("br-") || name === "docker0") continue;
      const cols = m[2].trim().split(/\s+/);
      rx3 += Number(cols[0]) || 0;
      tx += Number(cols[8]) || 0;
    }
    return { rx: rx3, tx };
  } catch {
    return { rx: 0, tx: 0 };
  }
}
function netBpsFromDelta() {
  const now = Date.now();
  const cur = readNetTotals();
  const prev = netPrev;
  netPrev = { t: now, rx: cur.rx, tx: cur.tx };
  if (!prev || now <= prev.t) return { rx: null, tx: null };
  const dt = (now - prev.t) / 1e3;
  if (dt <= 0) return { rx: null, tx: null };
  const rx3 = Math.max(0, (cur.rx - prev.rx) / dt);
  const tx = Math.max(0, (cur.tx - prev.tx) / dt);
  return { rx: rx3, tx };
}
function linuxHardware() {
  const dt = readDtModel();
  const info = parseCpuinfo();
  const decoded = info.revision ? decodePiRevision(info.revision) : null;
  const hardware = dt || info.model || decoded?.model || os.hostname() || "Raspberry Pi";
  const socFromRev = decoded?.soc || "";
  const n = os.cpus().length || 1;
  let soc = "";
  if (socFromRev) soc = formatCpuModel(socFromRev, n);
  else if (info.hardware) soc = formatCpuModel(info.hardware, n);
  else {
    const m = os.cpus()[0]?.model?.trim();
    if (m) soc = formatCpuModel(m, n);
    else soc = formatCpuModel("ARM", n);
  }
  return { hardware, soc };
}
function parseRegSzMap(stdout) {
  const map = {};
  for (const line of stdout.split(/\r?\n/)) {
    const m = line.trim().match(/^(\S+)\s+REG_SZ\s+(.+)$/i);
    if (m) map[m[1]] = m[2].trim();
  }
  return map;
}
function windowsIdentityQuick() {
  const n = os.cpus().length || 1;
  const cpu = os.cpus()[0]?.model?.trim() || "";
  return {
    hardware: os.hostname(),
    soc: cpu ? formatCpuModel(cpu, n) : "",
    osPretty: `Windows ${os.release()}`
  };
}
var windowsEnrichStarted = false;
function enrichWindowsIdentity() {
  if (windowsEnrichStarted) return;
  windowsEnrichStarted = true;
  void (async () => {
    let hardware = identity?.hardware || "";
    let osPretty = identity?.osPretty || "";
    try {
      const { stdout } = await execFileAsync15("reg", ["query", "HKLM\\HARDWARE\\DESCRIPTION\\System\\BIOS"], {
        timeout: 8e3,
        windowsHide: true
      });
      const bios = parseRegSzMap(stdout);
      const mfr = bios.SystemManufacturer || "";
      const ver = bios.SystemVersion || "";
      const family = bios.SystemFamily || "";
      const product = bios.SystemProductName || "";
      const found = [mfr, ver || family || product].filter(Boolean).join(" ").trim();
      if (found) hardware = found;
    } catch {
    }
    try {
      const { stdout } = await execFileAsync15("reg", ["query", "HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion"], {
        timeout: 8e3,
        windowsHide: true
      });
      const nt = parseRegSzMap(stdout);
      const pretty = [nt.ProductName, nt.DisplayVersion].filter(Boolean).join(" ").trim();
      if (pretty) osPretty = pretty;
    } catch {
    }
    if (identity) identity = { ...identity, hardware, osPretty };
  })();
}
async function windowsIdentity() {
  const quick = windowsIdentityQuick();
  enrichWindowsIdentity();
  return quick;
}
async function readSerialFields() {
  try {
    const serial = readDeviceSerial();
    if (!serial) {
      const cpu = existsSync22("/proc/cpuinfo") ? readFileSync15("/proc/cpuinfo", "utf8") : null;
      const dt = existsSync22("/proc/device-tree/serial-number") ? readFileSync15("/proc/device-tree/serial-number", "utf8") : null;
      const s = serialFromCpuinfo(cpu, dt);
      if (!s) return { serial: null, serialDisplay: null };
      return { serial: s, serialDisplay: await serialDisplay(s) };
    }
    return { serial, serialDisplay: await serialDisplay(serial) };
  } catch {
    return { serial: null, serialDisplay: null };
  }
}
async function readIdentity() {
  if (identity) return identity;
  if (process.platform === "win32") {
    const base2 = await windowsIdentity();
    identity = { ...base2, serial: null, serialDisplay: null };
    return identity;
  }
  const hw = linuxHardware();
  const osPretty = formatOsPretty(readOsRelease());
  const ser = await readSerialFields();
  identity = {
    hardware: hw.hardware,
    soc: hw.soc,
    osPretty: osPretty || `${os.type()} ${os.release()}`,
    serial: ser.serial,
    serialDisplay: ser.serialDisplay
  };
  return identity;
}
function pruneSamples(now) {
  const cut = now - HOST_WINDOW_MS;
  while (samples.length && samples[0].t < cut) samples.shift();
  while (samples.length > MAX_SAMPLES) samples.shift();
}
async function sampleOnce() {
  const t = Date.now();
  const ram = readRam();
  const cpuPct = cpuPctFromDelta();
  const cpuTempC = await readCpuTempC();
  const net4 = netBpsFromDelta();
  const row = {
    t,
    cpuPct,
    ramPct: ram.pct,
    ramUsedBytes: ram.used,
    ramTotalBytes: ram.total,
    cpuTempC,
    netRxBps: net4.rx,
    netTxBps: net4.tx
  };
  samples.push(row);
  pruneSamples(t);
  return row;
}
function startHostSampler() {
  if (sampler) return;
  void (async () => {
    if (sampling) return;
    sampling = true;
    try {
      await sampleOnce();
    } finally {
      sampling = false;
    }
  })();
  sampler = setInterval(() => {
    if (sampling) return;
    sampling = true;
    void sampleOnce().finally(() => {
      sampling = false;
    });
  }, HOST_SAMPLE_MS);
  sampler.unref?.();
}
function emptyStatus(error3) {
  return {
    ok: false,
    cpuTempC: null,
    diskTotalBytes: 0,
    diskFreeBytes: 0,
    diskUsedBytes: 0,
    diskPath: "/",
    error: error3,
    hardware: "",
    soc: "",
    osPretty: "",
    appVersion: installedAppVersion(),
    serial: null,
    serialDisplay: null,
    uptimeSec: Math.floor(os.uptime()),
    cpuPct: null,
    ramPct: null,
    ramUsedBytes: 0,
    ramTotalBytes: 0,
    netRxBps: null,
    netTxBps: null,
    sampleMs: HOST_SAMPLE_MS,
    windowMs: HOST_WINDOW_MS,
    samples: []
  };
}
async function hostStatus() {
  startHostSampler();
  try {
    const now = Date.now();
    const last = samples[samples.length - 1];
    if (!last || now - last.t > HOST_SAMPLE_MS * 1.5) {
      if (!sampling) {
        sampling = true;
        try {
          await sampleOnce();
        } finally {
          sampling = false;
        }
      }
    }
    const [id, disk] = await Promise.all([readIdentity(), Promise.resolve(readDisk())]);
    const used = Math.max(0, disk.total - disk.free);
    const ram = readRam();
    const row = samples[samples.length - 1];
    pruneSamples(Date.now());
    return {
      ok: true,
      cpuTempC: row?.cpuTempC ?? null,
      diskTotalBytes: disk.total,
      diskFreeBytes: disk.free,
      diskUsedBytes: used,
      diskPath: disk.path,
      error: "",
      hardware: id.hardware,
      soc: id.soc,
      osPretty: id.osPretty,
      appVersion: installedAppVersion(),
      serial: id.serial,
      serialDisplay: id.serialDisplay,
      uptimeSec: Math.floor(os.uptime()),
      cpuPct: row?.cpuPct ?? null,
      ramPct: ram.pct,
      ramUsedBytes: ram.used,
      ramTotalBytes: ram.total,
      netRxBps: row?.netRxBps ?? null,
      netTxBps: row?.netTxBps ?? null,
      sampleMs: HOST_SAMPLE_MS,
      windowMs: HOST_WINDOW_MS,
      samples: samples.slice()
    };
  } catch (err) {
    return emptyStatus(String(err));
  }
}
startHostSampler();

// server/mmdvm.ts
import { execFile as execFile17 } from "node:child_process";
import { copyFileSync, existsSync as existsSync23, mkdirSync as mkdirSync14, readdirSync as readdirSync3, readFileSync as readFileSync16, renameSync as renameSync11, statSync as statSync3, unlinkSync as unlinkSync3, writeFileSync as writeFileSync14 } from "node:fs";
import { dirname as dirname17, join as join18 } from "node:path";
import { fileURLToPath as fileURLToPath17 } from "node:url";
import { promisify as promisify16 } from "node:util";
import { createConnection } from "node:net";
import { networkInterfaces } from "node:os";
var execFileAsync16 = promisify16(execFile17);
var ROOT15 = join18(dirname17(fileURLToPath17(import.meta.url)), "..");
var HELPER9 = "/opt/ham-cockpit/bin/mmdvm-ctl";
var MMDVM_MODES = ["dstar", "dmr", "ysf", "p25", "nxdn", "m17", "pocsag"];
var MMDVM_BOARD_PRESETS = [
  { id: "custom", label: "Personalizado (porta/baud manuais)", port: "", uartSpeed: 0, duplex: null, slot1: null },
  { id: "mmdvmhshat", label: "MMDVM_HS_Hat (DB9MAT & DF2ET) GPIO", port: "/dev/ttyAMA0", uartSpeed: 115200, duplex: false, slot1: false },
  // WPSD Hardware=mmdvmhsdualhatgpio → MMDVM_HS_Dual_Hat (ADF7021 duplex) @ 115200 / ttyAMA0.
  // Cartão WPSD conhecido (PY2MED) era Hardware=dvmpis + Port=/dev/ttyACM0 + Duplex=0 — outro perfil; não copiar para este preset.
  { id: "mmdvmhsdualhatgpio", label: "MMDVM HS Dual (v1.3 / HAT)", port: "/dev/ttyAMA0", uartSpeed: 115200, duplex: true, slot1: true },
  { id: "mmdvmhsdualbandgpio", label: "MMDVM_HS_Dual_Band GPIO", port: "/dev/ttyAMA0", uartSpeed: 115200, duplex: false, slot1: false },
  { id: "zumspotgpio", label: "ZUMspot HAT simplex GPIO", port: "/dev/ttyAMA0", uartSpeed: 115200, duplex: false, slot1: false },
  { id: "zumspotduplexgpio", label: "ZUMspot HAT duplex GPIO", port: "/dev/ttyAMA0", uartSpeed: 115200, duplex: true, slot1: true },
  { id: "zumspotusb", label: "ZUMspot USB Stick", port: "/dev/ttyACM0", uartSpeed: 115200, duplex: false, slot1: false },
  { id: "zumspotlibre", label: "ZUMspot Libre (USB)", port: "/dev/ttyACM0", uartSpeed: 115200, duplex: false, slot1: false },
  // WPSD/Pi-Star Hardware=dvmpis → DVMEGA/STM32 GPIO simplex (Port padrão ttyAMA0; alguns hats USB usam ttyACM0).
  { id: "dvmpis", label: "DVMEGA / STM32-DVM Pi (dvmpis)", port: "/dev/ttyAMA0", uartSpeed: 115200, duplex: false, slot1: false },
  { id: "stm32dvm", label: "STM32-DVM / MMDVM_HS HAT GPIO", port: "/dev/ttyAMA0", uartSpeed: 115200, duplex: null, slot1: null },
  { id: "stm32usb", label: "STM32-DVM (USB)", port: "/dev/ttyUSB0", uartSpeed: 115200, duplex: null, slot1: null },
  { id: "nanodv", label: "NanoDV / NanoPi AIR GPIO", port: "/dev/ttyAMA0", uartSpeed: 115200, duplex: false, slot1: false },
  { id: "rptrbldrv3v4v5", label: "Repeater Builder v3/v4/v5 115200 GPIO", port: "/dev/ttyAMA0", uartSpeed: 115200, duplex: false, slot1: false },
  { id: "rptrbldrv3v4v5hs", label: "Repeater Builder v3/v4/v5 460800 GPIO", port: "/dev/ttyAMA0", uartSpeed: 460800, duplex: false, slot1: false },
  { id: "opengd77", label: "OpenGD77 hotspot (USB)", port: "/dev/ttyACM0", uartSpeed: 115200, duplex: false, slot1: false }
];
var MODE_INI = {
  dstar: { section: "D-Star", net: "D-Star Network" },
  dmr: { section: "DMR", net: "DMR Network" },
  ysf: { section: "System Fusion", net: "System Fusion Network" },
  p25: { section: "P25", net: "P25 Network" },
  nxdn: { section: "NXDN", net: "NXDN Network" },
  m17: { section: "M17", net: "M17 Network" },
  pocsag: { section: "POCSAG", net: "POCSAG Network" }
};
function linux3() {
  return process.platform === "linux";
}
function dataDir11() {
  if (existsSync23("/opt/ham-cockpit")) {
    const dir = "/opt/ham-cockpit/mmdvm";
    mkdirSync14(dir, { recursive: true });
    return dir;
  }
  const local = join18(ROOT15, "data", "mmdvm");
  mkdirSync14(local, { recursive: true });
  return local;
}
function shippedHostIni() {
  return join18(ROOT15, "deploy", "mmdvm", "mmdvmhost.ini");
}
function shippedGwIni() {
  return join18(ROOT15, "deploy", "mmdvm", "dmrgateway.ini");
}
function shippedYsfIni() {
  return join18(ROOT15, "deploy", "mmdvm", "ysfgateway.ini");
}
function shippedDstarConf() {
  return join18(ROOT15, "deploy", "mmdvm", "ircddbgateway.conf");
}
function firstExisting(paths2) {
  return paths2.find((p) => existsSync23(p)) ?? "";
}
function editablePath(etcPath, localName, shipped) {
  if (existsSync23(etcPath)) return etcPath;
  const local = join18(dataDir11(), localName);
  if (!existsSync23(local) && existsSync23(shipped)) {
    mkdirSync14(dataDir11(), { recursive: true });
    writeFileSync14(local, readFileSync16(shipped, "utf8"), "utf8");
  }
  return local;
}
function hostIniPath() {
  return editablePath("/etc/mmdvmhost", "mmdvmhost.ini", shippedHostIni());
}
function gatewayIniPath() {
  return editablePath("/etc/dmrgateway", "dmrgateway.ini", shippedGwIni());
}
function ysfIniPath() {
  return editablePath("/etc/ysfgateway", "ysfgateway.ini", shippedYsfIni());
}
function dstarIniPath() {
  if (existsSync23("/etc/ircddbgateway")) return "/etc/ircddbgateway";
  const dir = dataDir11();
  const noext = join18(dir, "ircddbgateway");
  const conf = join18(dir, "ircddbgateway.conf");
  if (!existsSync23(noext) && !existsSync23(conf) && existsSync23(shippedDstarConf())) {
    mkdirSync14(dir, { recursive: true });
    writeFileSync14(conf, readFileSync16(shippedDstarConf(), "utf8"), "utf8");
  }
  if (existsSync23(conf) && !existsSync23(noext)) {
    try {
      copyFileSync(conf, noext);
    } catch {
      try {
        writeFileSync14(noext, readFileSync16(conf, "utf8"), "utf8");
      } catch {
      }
    }
  }
  if (existsSync23(noext)) return noext;
  return editablePath("/etc/ircddbgateway", "ircddbgateway.conf", shippedDstarConf());
}
function hostBinary() {
  return firstExisting(["/usr/local/bin/MMDVMHost", "/usr/bin/MMDVMHost", "/opt/MMDVMHost/MMDVMHost"]);
}
function gatewayBinary() {
  return firstExisting(["/usr/local/bin/DMRGateway", "/usr/bin/DMRGateway", "/opt/DMRGateway/DMRGateway"]);
}
function ysfBinary() {
  return firstExisting(["/usr/local/bin/YSFGateway", "/usr/bin/YSFGateway"]);
}
function dstarBinary() {
  return firstExisting(["/usr/local/bin/ircddbgatewayd", "/usr/bin/ircddbgatewayd", "/usr/local/bin/ircDDBGateway"]);
}
function nextionBinary() {
  return firstExisting(["/usr/local/bin/NextionDriver", "/usr/bin/NextionDriver", "/opt/NextionDriver/NextionDriver"]);
}
function parseConf(text) {
  const out = {};
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith("#") || line.startsWith(";")) continue;
    const eq = line.indexOf("=");
    if (eq < 1) continue;
    out[line.slice(0, eq).trim()] = line.slice(eq + 1).trim();
  }
  return out;
}
function parseConfFile(path5) {
  try {
    if (!existsSync23(path5)) return {};
    return parseConf(readFileSync16(path5, "utf8"));
  } catch {
    return {};
  }
}
function stringifyConf(conf, header = "") {
  const lines = [];
  if (header) lines.push(header, "");
  for (const [k, v] of Object.entries(conf)) lines.push(`${k}=${v}`);
  return `${lines.join("\n").trimEnd()}
`;
}
function localNameForDest(dest) {
  if (dest.includes("ysf")) return "ysfgateway.ini";
  if (dest.includes("ircddb") || dest.includes("dstar")) return "ircddbgateway.conf";
  if (dest.includes("dmr")) return "dmrgateway.ini";
  return "mmdvmhost.ini";
}
function logDir() {
  const fromIni = parseIniFile(hostIniPath())["Log"]?.FilePath?.replace(/^"|"$/g, "") ?? "";
  return firstExisting([fromIni, "/var/log/pi-star", "/var/log/mmdvm", join18(dataDir11(), "logs")]) || join18(dataDir11(), "logs");
}
function parseIni(text) {
  const out = {};
  let section = "";
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith(";") || line.startsWith("#")) continue;
    const sec = line.match(/^\[(.+)\]$/);
    if (sec) {
      section = sec[1];
      if (!out[section]) out[section] = {};
      continue;
    }
    const eq = line.indexOf("=");
    if (eq < 1 || !section) continue;
    const key = line.slice(0, eq).trim();
    let value = line.slice(eq + 1).trim();
    if (value.startsWith('"') && value.endsWith('"') || value.startsWith("'") && value.endsWith("'")) {
      value = value.slice(1, -1);
    }
    if (!out[section]) out[section] = {};
    out[section][key] = value;
  }
  return out;
}
function parseIniFile(path5) {
  try {
    if (!existsSync23(path5)) return {};
    return parseIni(readFileSync16(path5, "utf8"));
  } catch {
    return {};
  }
}
function stringifyIni(ini) {
  const lines = [
    "; Ham Cockpit MMDVM \u2014 layout WPSD / Pi-Star (MMDVMHost + DMRGateway).",
    "; Canonical stack: https://wpsd.radio  \xB7  g4klx/MMDVMHost  \xB7  g4klx/DMRGateway",
    ""
  ];
  for (const [section, kv] of Object.entries(ini)) {
    lines.push(`[${section}]`);
    for (const [k, v] of Object.entries(kv)) {
      const needsQuote = /[\s#;]/.test(v) && !/^".*"$/.test(v);
      lines.push(`${k}=${needsQuote ? `"${v}"` : v}`);
    }
    lines.push("");
  }
  return `${lines.join("\n").trimEnd()}
`;
}
function iniGet(ini, section, key, fallback = "") {
  return ini[section]?.[key] ?? fallback;
}
function iniNum(ini, section, key, fallback) {
  const n = Number(iniGet(ini, section, key, String(fallback)));
  return Number.isFinite(n) ? n : fallback;
}
function iniOn(ini, section, key = "Enable") {
  return iniGet(ini, section, key, "0") === "1";
}
function setKv(ini, section, key, value) {
  if (!ini[section]) ini[section] = {};
  ini[section][key] = value;
}
function defaultConfig() {
  return {
    callsign: "N0CALL",
    dmrId: "0000000",
    duplex: false,
    rxHz: 433475e3,
    txHz: 433475e3,
    colorCode: 1,
    latitude: "0.0",
    longitude: "0.0",
    location: "Ham Cockpit",
    modemBoard: "mmdvmhshat",
    modemPort: "/dev/ttyAMA0",
    uartSpeed: 115200,
    remotePort: 7642,
    dstarReflector: "",
    dstarModule: "B",
    ysfStartup: "",
    displayType: "Nextion",
    displayPort: "modem",
    screenLayout: 4,
    brightness: 50,
    idleBrightness: 20,
    nextionDriver: true,
    oledType: 3,
    modes: { dstar: false, dmr: true, ysf: false, p25: false, nxdn: false, m17: false, pocsag: false },
    networks: [
      { id: "bm", section: "DMR Network 1", name: "BrandMeister", enabled: true, address: "3101.repeater.net", port: 62031, password: "passw0rd" },
      { id: "dmrplus", section: "DMR Network 2", name: "DMR+", enabled: false, address: "94.198.196.128", port: 8880, password: "passw0rd" },
      { id: "tgif", section: "DMR Network 3", name: "TGIF", enabled: false, address: "tgif.network", port: 62031, password: "passw0rd" },
      { id: "xlx", section: "XLX Network", name: "XLX", enabled: false, address: "xlx.example.net", port: 62030, password: "" }
    ]
  };
}
function configFromFiles() {
  const host2 = parseIniFile(hostIniPath());
  const gw = parseIniFile(gatewayIniPath());
  const ysf = parseIniFile(ysfIniPath());
  const dstar = parseConfFile(dstarIniPath());
  const base2 = defaultConfig();
  const modemPort = iniGet(host2, "Modem", "UARTPort") || iniGet(host2, "Modem", "Port") || base2.modemPort;
  const nets = base2.networks.map((n) => {
    const sec = gw[n.section] ?? {};
    return {
      ...n,
      name: sec.Name || n.name,
      enabled: (sec.Enabled ?? sec.Enable ?? "0") === "1",
      address: sec.Address || n.address,
      port: Number(sec.Port) || n.port,
      password: sec.Password || n.password
    };
  });
  const modes = { ...base2.modes };
  for (const mode of MMDVM_MODES) {
    modes[mode] = iniOn(host2, MODE_INI[mode].section);
  }
  const module = iniGet(host2, "D-Star", "Module", base2.dstarModule) || dstar.module || base2.dstarModule;
  return {
    callsign: iniGet(host2, "General", "Callsign", base2.callsign),
    dmrId: iniGet(host2, "General", "Id", base2.dmrId),
    duplex: iniGet(host2, "General", "Duplex", "0") === "1",
    rxHz: iniNum(host2, "Info", "RXFrequency", base2.rxHz),
    txHz: iniNum(host2, "Info", "TXFrequency", base2.txHz),
    colorCode: iniNum(host2, "DMR", "ColorCode", base2.colorCode),
    latitude: iniGet(host2, "Info", "Latitude", base2.latitude),
    longitude: iniGet(host2, "Info", "Longitude", base2.longitude),
    location: iniGet(host2, "Info", "Location", base2.location).replace(/^"|"$/g, ""),
    modemBoard: readModemBoard(),
    modemPort,
    uartSpeed: iniNum(host2, "Modem", "UARTSpeed", base2.uartSpeed),
    remotePort: iniNum(host2, "Remote Control", "Port", base2.remotePort),
    dstarReflector: (dstar.reflector1 || "").toUpperCase(),
    dstarModule: String(module || "B").toUpperCase().slice(0, 1),
    ysfStartup: iniGet(ysf, "Network", "Startup", base2.ysfStartup),
    displayType: (() => {
      const d = iniGet(host2, "General", "Display", base2.displayType);
      if (d === "Nextion" || d === "OLED" || d === "None") return d;
      return base2.displayType;
    })(),
    displayPort: (() => {
      const drv = iniGet(host2, "NextionDriver", "Port", "");
      const nx = iniGet(host2, "Nextion", "Port", "");
      if (drv && drv !== "/dev/ttyNextionDriver") return drv;
      if (nx && nx !== "/dev/ttyNextionDriver") return nx;
      return base2.displayPort;
    })(),
    screenLayout: iniNum(host2, "Nextion", "ScreenLayout", base2.screenLayout),
    brightness: iniNum(host2, "Nextion", "Brightness", base2.brightness),
    idleBrightness: iniNum(host2, "Nextion", "IdleBrightness", base2.idleBrightness),
    nextionDriver: iniGet(host2, "NextionDriver", "Enable", "") === "1" || iniGet(host2, "Nextion", "Port", "").includes("ttyNextionDriver"),
    oledType: iniNum(host2, "OLED", "Type", base2.oledType),
    modes,
    networks: nets
  };
}
function applyConfig(host2, gw, ysf, dstar, cfg) {
  const cur = { ...defaultConfig(), ...configFromFiles(), ...cfg };
  const rawCall = String(cfg.callsign ?? cur.callsign ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8);
  const call = rawCall || cur.callsign.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8) || "N0CALL";
  const id = cur.dmrId.replace(/\D/g, "").slice(0, 9) || "0000000";
  const mod = (cur.dstarModule || "B").toUpperCase().replace(/[^A-Z]/g, "").slice(0, 1) || "B";
  const rxHz = Number.isFinite(cur.rxHz) && cur.rxHz > 0 ? Math.round(cur.rxHz) : 433475e3;
  const txHz = Number.isFinite(cur.txHz) && cur.txHz > 0 ? Math.round(cur.txHz) : rxHz;
  setKv(host2, "General", "Callsign", call);
  setKv(host2, "General", "Id", id);
  setKv(host2, "General", "Duplex", cur.duplex ? "1" : "0");
  setKv(host2, "Info", "RXFrequency", String(rxHz));
  setKv(host2, "Info", "TXFrequency", String(txHz));
  setKv(host2, "Info", "Latitude", cur.latitude);
  setKv(host2, "Info", "Longitude", cur.longitude);
  setKv(host2, "Info", "Location", cur.location);
  setKv(host2, "DMR", "Id", id);
  setKv(host2, "DMR", "ColorCode", String(Math.min(15, Math.max(0, cur.colorCode))));
  setKv(host2, "D-Star", "Module", mod);
  const board = boardPreset(cur.modemBoard || "custom");
  writeModemBoard(board.id);
  let modemPort = cur.modemPort || "/dev/ttyAMA0";
  let uartSpeed = cur.uartSpeed || 115200;
  if (board.id !== "custom") {
    if (board.port) modemPort = board.port;
    if (board.uartSpeed > 0) uartSpeed = board.uartSpeed;
    if (board.duplex !== null) {
      setKv(host2, "General", "Duplex", board.duplex ? "1" : "0");
    }
    if (board.slot1 === false) setKv(host2, "DMR Network", "Slot1", "0");
    if (board.slot1 === true) setKv(host2, "DMR Network", "Slot1", "1");
  }
  setKv(host2, "Modem", "Port", modemPort);
  setKv(host2, "Modem", "UARTPort", modemPort);
  setKv(host2, "Modem", "Protocol", "uart");
  setKv(host2, "Modem", "UARTSpeed", String(uartSpeed));
  if (!iniGet(host2, "Modem", "TXInvert")) setKv(host2, "Modem", "TXInvert", "1");
  if (!iniGet(host2, "Modem", "RXInvert")) setKv(host2, "Modem", "RXInvert", "0");
  if (!iniGet(host2, "Modem", "PTTInvert")) setKv(host2, "Modem", "PTTInvert", "0");
  if (!iniGet(host2, "Modem", "Trace")) setKv(host2, "Modem", "Trace", "0");
  setKv(host2, "Remote Control", "Enable", "1");
  setKv(host2, "Remote Control", "Port", String(cur.remotePort || 7642));
  setKv(host2, "DMR Network", "Type", "Gateway");
  setKv(host2, "DMR Network", "Address", "127.0.0.1");
  setKv(host2, "DMR Network", "Port", "62031");
  setKv(host2, "DMR Network", "Local", "62032");
  setKv(host2, "DMR Network", "RemoteAddress", "127.0.0.1");
  setKv(host2, "DMR Network", "RemotePort", "62031");
  setKv(host2, "DMR Network", "LocalPort", "62032");
  setKv(host2, "D-Star Network", "GatewayAddress", "127.0.0.1");
  setKv(host2, "D-Star Network", "GatewayPort", "20010");
  setKv(host2, "D-Star Network", "LocalPort", "20011");
  setKv(host2, "System Fusion Network", "LocalAddress", "127.0.0.1");
  setKv(host2, "System Fusion Network", "LocalPort", "3200");
  setKv(host2, "System Fusion Network", "GatewayAddress", "127.0.0.1");
  setKv(host2, "System Fusion Network", "GatewayPort", "4200");
  for (const mode of MMDVM_MODES) {
    const on = cur.modes[mode] ? "1" : "0";
    setKv(host2, MODE_INI[mode].section, "Enable", on);
    setKv(host2, MODE_INI[mode].net, "Enable", on);
  }
  setKv(gw, "General", "Callsign", call);
  setKv(gw, "General", "Id", id);
  setKv(gw, "General", "RptAddress", "127.0.0.1");
  setKv(gw, "General", "RptPort", "62032");
  setKv(gw, "General", "LocalAddress", "127.0.0.1");
  setKv(gw, "General", "LocalPort", "62031");
  const nets = cfg.networks ?? cur.networks;
  for (const n of nets) {
    setKv(gw, n.section, "Enabled", n.enabled ? "1" : "0");
    setKv(gw, n.section, "Name", n.name);
    setKv(gw, n.section, "Address", n.address);
    setKv(gw, n.section, "Port", String(n.port));
    if (n.password !== void 0) setKv(gw, n.section, "Password", n.password);
    if (n.id !== "xlx") setKv(gw, n.section, "Id", id);
  }
  setKv(ysf, "General", "Callsign", call);
  setKv(ysf, "General", "Id", id);
  setKv(ysf, "General", "RptAddress", "127.0.0.1");
  setKv(ysf, "General", "RptPort", "3200");
  setKv(ysf, "General", "LocalAddress", "127.0.0.1");
  setKv(ysf, "General", "LocalPort", "4200");
  setKv(ysf, "Info", "RXFrequency", String(rxHz));
  setKv(ysf, "Info", "TXFrequency", String(txHz));
  setKv(ysf, "Info", "Latitude", cur.latitude);
  setKv(ysf, "Info", "Longitude", cur.longitude);
  setKv(ysf, "Info", "Name", cur.location || "Ham Cockpit");
  setKv(ysf, "Network", "Startup", cur.ysfStartup || "");
  setKv(ysf, "Remote Commands", "Enable", "1");
  setKv(ysf, "Remote Commands", "Port", "6073");
  dstar.gatewayCallsign = call;
  dstar.dplusLogin = call;
  dstar.gatewayAddress = "0.0.0.0";
  dstar.localAddress = "0.0.0.0";
  dstar.dplusEnabled = "1";
  dstar.latitude = cur.latitude;
  dstar.longitude = cur.longitude;
  dstar.latitude1 = cur.latitude;
  dstar.longitude1 = cur.longitude;
  dstar.frequency1 = (rxHz / 1e6).toFixed(6);
  dstar.reflector1 = (cur.dstarReflector || "").toUpperCase().slice(0, 8);
  dstar.atStartup1 = cur.dstarReflector ? "1" : "0";
  dstar.reconnect1 = cur.dstarReflector ? "2" : "0";
  dstar.name = cur.location || "Ham Cockpit";
  dstar.remoteEnabled = "1";
  dstar.remotePort = "7643";
  dstar.logPath = "/var/log/mmdvm";
  const dtype = cur.displayType || "None";
  setKv(host2, "General", "Display", dtype);
  const physPort = (cur.displayPort || "modem").trim() || "modem";
  const useDriver = dtype === "Nextion" && cur.nextionDriver;
  const nextionHostPort = useDriver ? "/dev/ttyNextionDriver" : physPort === "modem" ? "modem" : physPort;
  setKv(host2, "Nextion", "Port", nextionHostPort);
  setKv(host2, "Nextion", "Brightness", String(Math.min(100, Math.max(0, cur.brightness ?? 50))));
  setKv(host2, "Nextion", "IdleBrightness", String(Math.min(100, Math.max(0, cur.idleBrightness ?? 20))));
  setKv(host2, "Nextion", "ScreenLayout", String(cur.screenLayout ?? 4));
  setKv(host2, "Nextion", "DisplayClock", "1");
  setKv(host2, "Nextion", "UTC", "0");
  setKv(host2, "OLED", "Type", String(cur.oledType ?? 3));
  setKv(host2, "OLED", "Scroll", "1");
  setKv(host2, "OLED", "LogoScreensaver", "1");
  const transparent = useDriver && (physPort === "modem" || physPort === "/dev/ttyNextionDriver");
  setKv(host2, "Transparent Data", "Enable", transparent || dtype === "Nextion" && physPort === "modem" ? "1" : "0");
  setKv(host2, "Transparent Data", "RemoteAddress", "127.0.0.1");
  setKv(host2, "Transparent Data", "RemotePort", "40094");
  setKv(host2, "Transparent Data", "LocalPort", "40095");
  setKv(host2, "Transparent Data", "SendFrameType", "1");
  setKv(host2, "NextionDriver", "Enable", useDriver ? "1" : "0");
  setKv(host2, "NextionDriver", "Port", useDriver ? physPort === "/dev/ttyNextionDriver" ? "modem" : physPort : physPort);
  setKv(host2, "NextionDriver", "DataFilesPath", "/usr/local/etc/");
  setKv(host2, "NextionDriver", "LogLevel", "2");
  setKv(host2, "NextionDriver", "GroupsFile", "groups.txt");
  setKv(host2, "NextionDriver", "DMRidFile", "users.csv");
  setKv(host2, "NextionDriver", "WaitForLan", "0");
  setKv(host2, "TFT Serial", "Port", physPort === "modem" ? "modem" : physPort);
}
async function helper5(cmd, ...args) {
  if (!existsSync23(HELPER9)) return "";
  try {
    if (cmd === "start" || cmd === "stop" || cmd === "restart") unitCache = null;
    const { stdout } = await execFileAsync16("sudo", ["-n", HELPER9, cmd, ...args], {
      timeout: cmd === "is-active-all" || cmd === "is-active" ? 8e3 : 9e4,
      windowsHide: true
    });
    if (cmd === "start" || cmd === "stop" || cmd === "restart") unitCache = null;
    return String(stdout || "").trim();
  } catch {
    return "";
  }
}
var UNIT_NAMES = ["mmdvmhost", "dmrgateway", "ysfgateway", "ircddbgateway", "nextiondriver"];
var unitCache = null;
var unitInflight = null;
async function unitStates2() {
  if (unitCache && Date.now() - unitCache.at < 2500) return unitCache.map;
  if (unitInflight) return unitInflight;
  unitInflight = (async () => {
    const map = {};
    const out = await helper5("is-active-all");
    for (const line of out.split(/\r?\n/)) {
      const m = line.match(/^(\w+)=(\S+)/);
      if (m) map[m[1]] = m[2];
    }
    if (!UNIT_NAMES.every((n) => n in map)) {
      try {
        const { stdout } = await execFileAsync16(
          "systemctl",
          ["is-active", ...UNIT_NAMES.map((n) => `${n}.service`)],
          { timeout: 4e3, windowsHide: true }
        );
        String(stdout).split(/\r?\n/).forEach((v, i) => {
          if (UNIT_NAMES[i] && v.trim()) map[UNIT_NAMES[i]] = v.trim();
        });
      } catch (err) {
        const out2 = String(err.stdout || "");
        out2.split(/\r?\n/).forEach((v, i) => {
          if (UNIT_NAMES[i] && v.trim()) map[UNIT_NAMES[i]] = v.trim();
        });
      }
    }
    unitCache = { at: Date.now(), map };
    return map;
  })().finally(() => {
    unitInflight = null;
  });
  return unitInflight;
}
async function unitActive(unit) {
  if (!linux3()) return false;
  return (await unitStates2())[unit] === "active";
}
function logDate(offsetSec = 0) {
  const d = new Date(Date.now() - offsetSec * 1e3);
  const y = d.getUTCFullYear();
  const m = String(d.getUTCMonth() + 1).padStart(2, "0");
  const day = String(d.getUTCDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}
function readLogTail(dir, prefix, maxBytes = 4e5) {
  const names = [`${prefix}-${logDate()}.log`, `${prefix}-${logDate(86340)}.log`];
  let buf = "";
  for (const name of names) {
    const path5 = join18(dir, name);
    if (!existsSync23(path5)) continue;
    try {
      const raw = readFileSync16(path5, "utf8");
      buf += raw.length > maxBytes ? raw.slice(-maxBytes) : raw;
      buf += "\n";
    } catch {
    }
  }
  if (buf) return buf;
  try {
    const files = readdirSync3(dir).filter((f) => f.startsWith(`${prefix}-`) && f.endsWith(".log")).sort();
    const last = files[files.length - 1];
    if (!last) return "";
    const raw = readFileSync16(join18(dir, last), "utf8");
    return raw.length > maxBytes ? raw.slice(-maxBytes) : raw;
  } catch {
    return "";
  }
}
function pausedPath() {
  return join18(dataDir11(), "paused-modes.json");
}
function boardPath() {
  return join18(dataDir11(), "modem-board.json");
}
function readModemBoard() {
  try {
    const raw = JSON.parse(readFileSync16(boardPath(), "utf8"));
    const id = String(raw.board || "");
    if (MMDVM_BOARD_PRESETS.some((p) => p.id === id)) return id;
  } catch {
  }
  return "mmdvmhshat";
}
function writeModemBoard(board) {
  mkdirSync14(dataDir11(), { recursive: true });
  writeFileSync14(boardPath(), `${JSON.stringify({ board }, null, 2)}
`, "utf8");
}
function boardPreset(id) {
  return MMDVM_BOARD_PRESETS.find((p) => p.id === id) ?? MMDVM_BOARD_PRESETS[0];
}
function emptyPaused() {
  return { dstar: false, dmr: false, ysf: false, p25: false, nxdn: false, m17: false, pocsag: false };
}
function readPaused() {
  const out = emptyPaused();
  try {
    const raw = JSON.parse(readFileSync16(pausedPath(), "utf8"));
    for (const mode of MMDVM_MODES) {
      if (typeof raw[mode] === "boolean") out[mode] = raw[mode];
    }
  } catch {
  }
  return out;
}
function writePaused(paused) {
  mkdirSync14(dataDir11(), { recursive: true });
  writeFileSync14(pausedPath(), `${JSON.stringify(paused, null, 2)}
`, "utf8");
}
function modeGatewayTarget(mode) {
  if (mode === "dmr") return "dmrgateway";
  if (mode === "ysf") return "ysfgateway";
  if (mode === "dstar") return "ircddbgateway";
  return "host";
}
function parseLastHeard(logText, limit = 40) {
  const rows = [];
  const seen = /* @__PURE__ */ new Map();
  const lines = logText.split(/\r?\n/).reverse();
  const skip = /BS_Dwn_Act|invalid access|packet received from an invalid source|received RF header for wrong repeater|unable to decode the network CSBK|overflow in the DMR slot RF queue|overflow in the System Fusion RF queue|non repeater RF header|Embedded Talker Alias|DMR Talker Alias|CSBK Preamble|Preamble CSBK|Downlink/i;
  for (const line of lines) {
    if (!line.startsWith("M:")) continue;
    if (skip.test(line)) continue;
    if (!/\bfrom\b/i.test(line) || !/\bto\b/i.test(line)) continue;
    const m = line.match(
      /^M:\s+(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\.\d+\s+([^,]+),\s+received\s+(RF|network)\b.+?\bfrom\s+(.+?)\s+to\s+(.+)$/i
    );
    if (!m) continue;
    const mode = m[2].trim();
    const src = m[3].toLowerCase() === "rf" ? "RF" : "Net";
    let callsign = m[4].trim();
    if (callsign.includes("/")) callsign = callsign.split("/").pop().trim();
    const extra = m[5].trim().split(",").map((s) => s.trim());
    const target = (extra[0] ?? "").replace(/\s+via\s+.*$/i, "").trim();
    let duration = "";
    let loss = "";
    let ber = "";
    let rssi = "";
    for (const part of extra.slice(1)) {
      if (/seconds/i.test(part)) duration = part.replace(/\s*seconds.*/i, "").trim();
      else if (/RSSI/i.test(part)) rssi = part.replace(/^RSSI:\s*/i, "").trim();
      else if (/loss/i.test(part) || /packet loss/i.test(part)) loss = part.replace(/\s*packet loss.*/i, "").trim();
      else if (/BER/i.test(part)) ber = part.replace(/^BER:\s*/i, "").trim();
    }
    const kind = mode.startsWith("DMR") || mode.startsWith("D-Star") || mode.startsWith("YSF") || mode.startsWith("P25") || mode.startsWith("NXDN") || mode.startsWith("M17") || mode.startsWith("POCSAG");
    if (!kind || !callsign || callsign === "??????") continue;
    const uuid = `${callsign}#${mode}#${src}`;
    const row = { timeUtc: m[1], mode, callsign, target, src, duration, loss, ber, rssi };
    const prev = seen.get(uuid);
    if (!prev || !prev.duration && row.duration) seen.set(uuid, row);
    if (seen.size >= limit * 2) break;
  }
  for (const row of Array.from(seen.values())) {
    rows.push(row);
    if (rows.length >= limit) break;
  }
  return rows;
}
function currentTx(rows) {
  return rows.some((r) => !r.duration);
}
function lanIpv4() {
  const ifs = networkInterfaces();
  const preferred = ["eth0", "enp0s3", "enp1s0", "wlan0", "wlp2s0", "Ethernet", "Wi-Fi"];
  const skip = /^(lo|docker|br-|veth|virbr|tailscale|vmnet|vEthernet)/i;
  const pick = (name) => {
    for (const a of ifs[name] ?? []) {
      const family = String(a.family);
      if ((family === "IPv4" || family === "4") && !a.internal) return a.address;
    }
    return "";
  };
  for (const name of preferred) {
    const ip = pick(name);
    if (ip) return ip;
  }
  for (const [name, addrs] of Object.entries(ifs)) {
    if (skip.test(name)) continue;
    for (const a of addrs ?? []) {
      const family = String(a.family);
      if ((family === "IPv4" || family === "4") && !a.internal) return a.address;
    }
  }
  return "";
}
var lutCache = /* @__PURE__ */ new Map();
var LUT_MAX_BYTES = 12 * 1024 * 1024;
function lutPaths() {
  const host2 = existsSync23(hostIniPath()) ? parseIniFile(hostIniPath()) : {};
  const raw = iniGet(host2, "NextionDriver", "DataFilesPath", "/usr/local/etc/");
  const dir = raw.replace(/[/\\]+$/, "") || "/usr/local/etc";
  return [dir, "/usr/local/etc", join18(dataDir11()), join18(ROOT15, "deploy", "mmdvm")];
}
function findLutFile(name) {
  for (const dir of lutPaths()) {
    const p = join18(dir, name);
    if (existsSync23(p)) return p;
  }
  return "";
}
function loadLut(path5, kind) {
  const st = statSync3(path5);
  const prev = lutCache.get(path5);
  if (prev && prev.mtime === st.mtimeMs && prev.size === st.size) return prev;
  const byId = /* @__PURE__ */ new Map();
  const byCall = /* @__PURE__ */ new Map();
  if (st.size > 0 && st.size <= LUT_MAX_BYTES) {
    const text = readFileSync16(path5, "utf8");
    for (const line of text.split(/\r?\n/)) {
      if (!line || line.startsWith("#")) continue;
      const cols = line.split(/[,;\t]/);
      const id = (cols[0] ?? "").trim();
      if (!id || !/^\d+$/.test(id)) continue;
      if (kind === "groups") {
        const name2 = (cols[1] ?? "").trim();
        if (name2) byId.set(id, name2);
        continue;
      }
      const call = (cols[1] ?? "").trim().toUpperCase();
      const name = (cols[2] ?? "").trim();
      if (name) byId.set(id, name);
      if (call && name) byCall.set(call, name);
    }
  }
  const next = { mtime: st.mtimeMs, size: st.size, byId, byCall };
  lutCache.set(path5, next);
  return next;
}
function lookupUser(callOrId) {
  const path5 = findLutFile("users.csv");
  if (!path5) return "";
  try {
    const lut = loadLut(path5, "users");
    const raw = callOrId.trim();
    if (/^\d+$/.test(raw)) return lut.byId.get(raw) ?? "";
    return lut.byCall.get(raw.toUpperCase()) ?? "";
  } catch {
    return "";
  }
}
function lookupGroup(target) {
  const path5 = findLutFile("groups.txt");
  if (!path5) return "";
  const id = (target.match(/\d{2,}/) ?? [])[0] ?? "";
  if (!id) return "";
  try {
    return loadLut(path5, "groups").byId.get(id) ?? "";
  } catch {
    return "";
  }
}
function heardPage(mode) {
  const m = mode.toUpperCase();
  if (m.startsWith("DMR")) return "dmr";
  if (m.startsWith("D-STAR") || m.startsWith("DSTAR")) return "dstar";
  if (m.startsWith("YSF") || m.includes("FUSION")) return "ysf";
  if (m.startsWith("P25")) return "p25";
  if (m.startsWith("NXDN")) return "nxdn";
  if (m.startsWith("M17")) return "m17";
  if (m.startsWith("POCSAG")) return "pocsag";
  return "idle";
}
function heardSlot(mode) {
  const m = mode.match(/slot\s+(\d)/i);
  return m ? Number(m[1]) : null;
}
function toQso(row) {
  return {
    mode: row.mode,
    slot: heardSlot(row.mode),
    src: row.src,
    callsign: row.callsign,
    name: lookupUser(row.callsign),
    target: row.target,
    tgName: lookupGroup(row.target),
    ber: row.ber,
    rssi: row.rssi,
    loss: row.loss
  };
}
async function buildNextion(cfg, heard, hostRunning) {
  const live4 = heard.filter((r) => !r.duration).slice(0, 2);
  const page = hostRunning && live4[0] ? heardPage(live4[0].mode) : "idle";
  let status = "MMDVM IDLE";
  if (!hostRunning) status = "MMDVM IDLE";
  else if (live4[0]) status = `${live4[0].src === "RF" ? "RF" : "net"} ${live4[0].callsign}`;
  let cpuTempC = null;
  let diskFreePct = null;
  if (linux3()) {
    try {
      const hs = await hostStatus();
      cpuTempC = hs.cpuTempC;
      if (hs.diskTotalBytes > 0) diskFreePct = Math.round(hs.diskFreeBytes / hs.diskTotalBytes * 100);
    } catch {
    }
  }
  return {
    page,
    status,
    callsign: cfg.callsign,
    dmrId: cfg.dmrId,
    ip: lanIpv4(),
    location: cfg.location,
    rxHz: cfg.rxHz,
    txHz: cfg.txHz,
    cpuTempC,
    diskFreePct,
    duplex: cfg.duplex,
    qso: live4.map(toQso)
  };
}
async function writeProtected(dest, body) {
  const dir = dataDir11();
  mkdirSync14(dir, { recursive: true });
  const localName = localNameForDest(dest);
  let target = dest;
  if (dest.includes("deploy\\mmdvm") || dest.includes("deploy/mmdvm")) {
    target = join18(dir, localName);
  }
  const tmp = join18(dir, `.${localName}.${process.pid}.tmp`);
  writeFileSync14(tmp, body, "utf8");
  if (linux3() && target.startsWith("/etc/") && existsSync23(HELPER9)) {
    const out = await helper5("install-ini", tmp, target);
    if (!out) {
      try {
        writeFileSync14(target, body, "utf8");
      } catch {
        renameSync11(tmp, join18(dir, localName));
        return;
      }
    }
    try {
      writeFileSync14(join18(dir, localName), body, "utf8");
    } catch {
    }
    try {
      if (existsSync23(tmp)) unlinkSync3(tmp);
    } catch {
    }
    return;
  }
  mkdirSync14(dirname17(target), { recursive: true });
  renameSync11(tmp, target);
}
async function writeDstarConf(primary, body) {
  await writeProtected(primary, body);
  const noext = primary.endsWith(".conf") ? primary.slice(0, -5) : primary;
  const withConf = primary.endsWith(".conf") ? primary : `${primary}.conf`;
  for (const extra of [noext, withConf]) {
    if (extra === primary) continue;
    try {
      writeFileSync14(extra, body, "utf8");
    } catch {
    }
  }
}
function upgradeHostDisplaySections(hostPath) {
  if (!existsSync23(hostPath) || !existsSync23(shippedHostIni())) return;
  const host2 = parseIniFile(hostPath);
  const shipped = parseIniFile(shippedHostIni());
  let changed = false;
  for (const sec of ["Nextion", "OLED", "Transparent Data", "NextionDriver", "TFT Serial", "HD44780", "LCDproc"]) {
    if (!host2[sec] && shipped[sec]) {
      host2[sec] = { ...shipped[sec] };
      changed = true;
    }
  }
  const display = host2.General?.Display ?? "";
  if ((!display || display === "None") && (host2.Nextion || shipped.Nextion)) {
    if (!host2.General) host2.General = {};
    host2.General.Display = "Nextion";
    if (!host2.Nextion && shipped.Nextion) host2.Nextion = { ...shipped.Nextion };
    if (!host2.NextionDriver && shipped.NextionDriver) host2.NextionDriver = { ...shipped.NextionDriver };
    if (!host2["Transparent Data"] && shipped["Transparent Data"]) host2["Transparent Data"] = { ...shipped["Transparent Data"] };
    if (host2.NextionDriver) host2.NextionDriver.Enable = "1";
    if (host2["Transparent Data"]) host2["Transparent Data"].Enable = "1";
    changed = true;
  }
  if (changed) writeFileSync14(hostPath, stringifyIni(host2), "utf8");
}
function seedIfMissing() {
  const dir = dataDir11();
  mkdirSync14(dir, { recursive: true });
  const seeds = [
    ["/etc/mmdvmhost", "mmdvmhost.ini", shippedHostIni()],
    ["/etc/dmrgateway", "dmrgateway.ini", shippedGwIni()],
    ["/etc/ysfgateway", "ysfgateway.ini", shippedYsfIni()],
    ["/etc/ircddbgateway", "ircddbgateway.conf", shippedDstarConf()]
  ];
  for (const [etc, name, shipped] of seeds) {
    if (!existsSync23(etc) && !existsSync23(join18(dir, name)) && existsSync23(shipped)) {
      writeFileSync14(join18(dir, name), readFileSync16(shipped, "utf8"), "utf8");
    }
  }
  const dstarConf = join18(dir, "ircddbgateway.conf");
  const dstarNoext = join18(dir, "ircddbgateway");
  if (existsSync23(dstarConf) && !existsSync23(dstarNoext)) {
    try {
      copyFileSync(dstarConf, dstarNoext);
    } catch {
    }
  }
  const hostPath = hostIniPath();
  if (!hostPath.includes(`${join18("deploy", "mmdvm")}`)) upgradeHostDisplaySections(hostPath);
}
async function mmdvmStatus() {
  seedIfMissing();
  const cfg = configFromFiles();
  const hostBin = hostBinary();
  const gwBin = gatewayBinary();
  const ysfBin = ysfBinary();
  const dstarBin = dstarBinary();
  const nxBin = nextionBinary();
  const hostIni = hostIniPath();
  const gwIni = gatewayIniPath();
  const ysfIni = ysfIniPath();
  const dstarIni = dstarIniPath();
  const logs = logDir();
  const heard = parseLastHeard(readLogTail(logs, "MMDVM"));
  const hostRunning = await unitActive("mmdvmhost");
  const gatewayRunning = await unitActive("dmrgateway");
  const ysfRunning = await unitActive("ysfgateway");
  const dstarRunning = await unitActive("ircddbgateway");
  const nextionRunning = await unitActive("nextiondriver");
  const paused = readPaused();
  const onAppliance = linux3();
  const installed = Boolean(hostBin) || existsSync23(hostIni);
  const nextion = await buildNextion(cfg, heard, hostRunning);
  return {
    ...cfg,
    ok: hostRunning,
    installed,
    appliance: onAppliance,
    hostRunning,
    gatewayRunning,
    ysfRunning,
    dstarRunning,
    nextionRunning,
    hostBinary: hostBin,
    gatewayBinary: gwBin,
    ysfBinary: ysfBin,
    dstarBinary: dstarBin,
    nextionBinary: nxBin,
    hostIni,
    gatewayIni: gwIni,
    ysfIni,
    dstarIni,
    logDir: logs,
    tx: currentTx(heard),
    currentMode: heard[0]?.mode ?? "",
    lastHeard: heard,
    nextion,
    paused,
    // Só alerta de binário ausente no Pi; no Windows/dev a console edita INI sem Host local.
    error: hostBin || !onAppliance ? "" : "MMDVM Host n\xE3o est\xE1 neste host \u2014 instale o bin\xE1rio WPSD/g4klx em /usr/local/bin/MMDVMHost"
  };
}
function pickConfig(body) {
  const cur = configFromFiles();
  const str = (k, fb) => typeof body[k] === "string" ? String(body[k]) : fb;
  const num2 = (k, fb) => {
    const n = Number(body[k]);
    return Number.isFinite(n) ? n : fb;
  };
  const modes = { ...cur.modes };
  if (body.modes && typeof body.modes === "object") {
    for (const mode of MMDVM_MODES) {
      const v = body.modes[mode];
      if (typeof v === "boolean") modes[mode] = v;
    }
  }
  let networks = cur.networks;
  if (Array.isArray(body.networks)) {
    networks = cur.networks.map((n) => {
      const hit = body.networks.find((x) => x && (x.id === n.id || x.section === n.section));
      if (!hit) return n;
      return {
        ...n,
        name: typeof hit.name === "string" ? hit.name : n.name,
        enabled: typeof hit.enabled === "boolean" ? hit.enabled : n.enabled,
        address: typeof hit.address === "string" ? hit.address : n.address,
        port: Number.isFinite(Number(hit.port)) ? Number(hit.port) : n.port,
        password: typeof hit.password === "string" ? hit.password : n.password
      };
    });
  }
  return {
    callsign: str("callsign", cur.callsign),
    dmrId: str("dmrId", cur.dmrId),
    duplex: typeof body.duplex === "boolean" ? body.duplex : cur.duplex,
    rxHz: num2("rxHz", cur.rxHz),
    txHz: num2("txHz", cur.txHz),
    colorCode: num2("colorCode", cur.colorCode),
    latitude: str("latitude", cur.latitude),
    longitude: str("longitude", cur.longitude),
    location: str("location", cur.location),
    modemBoard: (() => {
      const id = str("modemBoard", cur.modemBoard);
      return MMDVM_BOARD_PRESETS.some((p) => p.id === id) ? id : cur.modemBoard;
    })(),
    modemPort: str("modemPort", cur.modemPort),
    uartSpeed: num2("uartSpeed", cur.uartSpeed),
    remotePort: num2("remotePort", cur.remotePort),
    dstarReflector: str("dstarReflector", cur.dstarReflector).toUpperCase(),
    dstarModule: str("dstarModule", cur.dstarModule).toUpperCase().slice(0, 1) || "B",
    ysfStartup: str("ysfStartup", cur.ysfStartup),
    displayType: (() => {
      const d = str("displayType", cur.displayType);
      if (d === "Nextion" || d === "OLED" || d === "None") return d;
      return cur.displayType;
    })(),
    displayPort: str("displayPort", cur.displayPort),
    screenLayout: num2("screenLayout", cur.screenLayout),
    brightness: num2("brightness", cur.brightness),
    idleBrightness: num2("idleBrightness", cur.idleBrightness),
    nextionDriver: typeof body.nextionDriver === "boolean" ? body.nextionDriver : cur.nextionDriver,
    oledType: num2("oledType", cur.oledType),
    modes,
    networks
  };
}
async function mmdvmSave(body) {
  seedIfMissing();
  const hostPath = hostIniPath();
  const gwPath = gatewayIniPath();
  const ysfPath = ysfIniPath();
  const dstarPath = dstarIniPath();
  const host2 = parseIniFile(existsSync23(hostPath) ? hostPath : shippedHostIni());
  const gw = parseIniFile(existsSync23(gwPath) ? gwPath : shippedGwIni());
  const ysf = parseIniFile(existsSync23(ysfPath) ? ysfPath : shippedYsfIni());
  const dstar = parseConfFile(existsSync23(dstarPath) ? dstarPath : shippedDstarConf());
  const cfg = pickConfig(body);
  const call = String(cfg.callsign ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8);
  if (!call) {
    const st = await mmdvmStatus();
    return { ...st, error: "Informe um indicativo" };
  }
  cfg.callsign = call;
  const idNum = Number(String(cfg.dmrId ?? "").replace(/\D/g, "") || "0");
  if (!Number.isFinite(idNum) || idNum <= 1e3) {
    const st = await mmdvmStatus();
    return { ...st, error: "Id DMR deve ser maior que 1000 (n\xE3o use 0 / 0000000)" };
  }
  applyConfig(host2, gw, ysf, dstar, cfg);
  await writeProtected(hostPath, stringifyIni(host2));
  await writeProtected(gwPath, stringifyIni(gw));
  await writeProtected(ysfPath, stringifyIni(ysf));
  await writeDstarConf(dstarPath, stringifyConf(dstar, "# Ham Cockpit ircDDBGateway"));
  if (linux3()) {
    if (cfg.displayType === "Nextion" && cfg.nextionDriver) await controlUnit("restart", "nextiondriver");
    else await controlUnit("stop", "nextiondriver");
  }
  return mmdvmStatus();
}
async function mmdvmControl(action) {
  if (linux3()) {
    const out = await helper5(action, "all");
    if (!out) await controlUnit(action, "all");
  }
  if (action === "start" || action === "restart") writePaused(emptyPaused());
  return mmdvmStatus();
}
async function controlUnit(action, target) {
  if (!linux3()) return;
  const map = {
    host: "host",
    mmdvmhost: "host",
    dmrgateway: "dmr",
    ysfgateway: "ysf",
    ircddbgateway: "dstar",
    nextiondriver: "nextion",
    all: "all"
  };
  const out = await helper5(action, map[target] || "all");
  if (out) return;
  const units = target === "all" ? [
    "nextiondriver.service",
    "mmdvmhost.service",
    "dmrgateway.service",
    "ysfgateway.service",
    "ircddbgateway.service"
  ] : target === "host" ? ["mmdvmhost.service"] : [`${target}.service`];
  for (const u of units) {
    try {
      await execFileAsync16("systemctl", [action, u], { timeout: 15e3, windowsHide: true });
    } catch {
    }
  }
}
async function mmdvmModePause(mode, pause) {
  const id = mode.toLowerCase();
  if (!MMDVM_MODES.includes(id)) {
    const st = await mmdvmStatus();
    return { ...st, error: `modo inv\xE1lido: ${mode}` };
  }
  seedIfMissing();
  const paused = readPaused();
  paused[id] = pause;
  writePaused(paused);
  const target = modeGatewayTarget(id);
  if (target !== "host") {
    await controlUnit(pause ? "stop" : "start", target);
  } else {
    const hostPath = hostIniPath();
    const host2 = parseIniFile(existsSync23(hostPath) ? hostPath : shippedHostIni());
    const permanent = configFromFiles().modes[id];
    const value = pause ? "0" : permanent ? "1" : "0";
    setKv(host2, MODE_INI[id].section, "Enable", value);
    setKv(host2, MODE_INI[id].net, "Enable", value);
    await writeProtected(hostPath, stringifyIni(host2));
    await controlUnit("restart", "host");
  }
  return mmdvmStatus();
}
async function mmdvmModeResumeAll() {
  const paused = readPaused();
  for (const mode of MMDVM_MODES) {
    if (paused[mode]) await mmdvmModePause(mode, false);
  }
  writePaused(emptyPaused());
  return mmdvmStatus();
}
async function mmdvmNetworkSet(body) {
  seedIfMissing();
  const gwPath = gatewayIniPath();
  const gw = parseIniFile(existsSync23(gwPath) ? gwPath : shippedGwIni());
  const cur = configFromFiles();
  const hit = cur.networks.find((n) => n.id === body.id || n.section === body.section);
  if (!hit) {
    const st = await mmdvmStatus();
    return { ...st, error: "rede DMR desconhecida" };
  }
  if (typeof body.enabled !== "boolean") {
    const st = await mmdvmStatus();
    return { ...st, error: "enabled obrigat\xF3rio" };
  }
  setKv(gw, hit.section, "Enabled", body.enabled ? "1" : "0");
  await writeProtected(
    gwPath.startsWith("/etc/") ? "/etc/dmrgateway" : join18(dataDir11(), "dmrgateway.ini"),
    stringifyIni(gw)
  );
  await controlUnit("restart", "dmrgateway");
  return mmdvmStatus();
}
async function mmdvmLink(body) {
  seedIfMissing();
  const mode = String(body.mode || "").toLowerCase();
  const target = String(body.target || "").trim();
  if (mode === "ysf") {
    const ysfPath = ysfIniPath();
    const ysf = parseIniFile(existsSync23(ysfPath) ? ysfPath : shippedYsfIni());
    setKv(ysf, "Network", "Startup", target);
    await writeProtected(ysfPath, stringifyIni(ysf));
    await controlUnit("restart", "ysfgateway");
    return mmdvmStatus();
  }
  if (mode === "dstar") {
    const dstarPath = dstarIniPath();
    const dstar = parseConfFile(existsSync23(dstarPath) ? dstarPath : shippedDstarConf());
    const mod = String(body.module || configFromFiles().dstarModule || "B").toUpperCase().replace(/[^A-Z]/g, "").slice(0, 1) || "B";
    const reflector = target.toUpperCase().slice(0, 8);
    dstar.reflector1 = reflector;
    dstar.atStartup1 = reflector ? "1" : "0";
    dstar.reconnect1 = reflector ? "2" : "0";
    const hostPath = hostIniPath();
    const host2 = parseIniFile(existsSync23(hostPath) ? hostPath : shippedHostIni());
    setKv(host2, "D-Star", "Module", mod);
    await writeProtected(hostPath, stringifyIni(host2));
    await writeDstarConf(dstarPath, stringifyConf(dstar, "# Ham Cockpit ircDDBGateway"));
    await controlUnit("restart", "ircddbgateway");
    if (reflector) {
      await remoteTcp(7643, `link ${reflector} ${mod}`).catch(() => void 0);
    }
    return mmdvmStatus();
  }
  const st = await mmdvmStatus();
  return { ...st, error: "mode deve ser ysf ou dstar" };
}
function remoteTcp(port, line) {
  return new Promise((resolve) => {
    const sock3 = createConnection({ host: "127.0.0.1", port, timeout: 2500 });
    let reply = "";
    let settled = false;
    const done = (ok, error3) => {
      if (settled) return;
      settled = true;
      try {
        sock3.destroy();
      } catch {
      }
      resolve({ ok, reply: reply.trim(), error: error3 });
    };
    sock3.on("data", (d) => {
      reply += d.toString("utf8");
    });
    sock3.on("connect", () => {
      sock3.write(`${line}
`);
      setTimeout(() => done(true), 500);
    });
    sock3.on("error", (err) => done(false, err.message));
    sock3.on("timeout", () => done(Boolean(reply.trim()), reply.trim() ? void 0 : "timeout"));
  });
}
async function mmdvmRemote(cmd) {
  const port = configFromFiles().remotePort || 7642;
  let line = cmd.replace(/[\r\n]/g, " ").trim();
  if (!line) return { ok: false, reply: "", error: "comando vazio" };
  const tgOnly = line.match(/^tg(?:\s+|:)(\d{1,8})(?:\s+(\d))?$/i);
  const talkgroup = line.match(/^talkgroup\s+(\d)\s+(\d{1,8})$/i);
  if (tgOnly) {
    const slot = tgOnly[2] || "2";
    line = `talkgroup ${slot} ${tgOnly[1]}`;
  } else if (talkgroup) {
    line = `talkgroup ${talkgroup[1]} ${talkgroup[2]}`;
  } else if (/^page\s+/i.test(line)) {
  }
  return remoteTcp(port, line);
}

// server/index.ts
init_icom_lan();

// server/support-vpn.ts
import { execFile as execFile18 } from "node:child_process";
import { existsSync as existsSync24, mkdirSync as mkdirSync15, readFileSync as readFileSync17, readdirSync as readdirSync4, writeFileSync as writeFileSync15 } from "node:fs";
import { networkInterfaces as networkInterfaces2 } from "node:os";
import { dirname as dirname18, join as join19 } from "node:path";
import { fileURLToPath as fileURLToPath18 } from "node:url";
import { promisify as promisify17 } from "node:util";
var execFileAsync17 = promisify17(execFile18);
var ROOT16 = join19(dirname18(fileURLToPath18(import.meta.url)), "..");
var HELPER10 = "/opt/ham-cockpit/bin/station-support-vpn";
var STATE_OPT = "/opt/ham-cockpit/support-vpn.json";
var AP_IP = "192.168.4.1";
var IPV4 = /^(?:\d{1,3}\.){3}\d{1,3}$/;
var SKIP_IFACE = /^(lo|docker|br-|veth|vEthernet|virbr|tailscale|vmnet|vbox|zt|tun|tap|wg|npcap|Loopback|Bluetooth)/i;
var lastSample = null;
var armAt = 0;
function isIpv4(value) {
  if (!IPV4.test(value)) return false;
  return value.split(".").every((part) => {
    const n = Number(part);
    return n >= 0 && n <= 255;
  });
}
function isTunnelIface(name) {
  return SKIP_IFACE.test(name);
}
function isLinkLocal(ip) {
  return ip.startsWith("169.254.");
}
function hostIp(header) {
  const trimmed = header.trim().replace(/^https?:\/\//i, "");
  const noPath = trimmed.split("/")[0] || "";
  if (noPath.startsWith("[")) return "";
  return noPath.replace(/:\d+$/, "");
}
function bestLan(ifaces) {
  const candidates = ifaces.filter(
    (row) => isIpv4(row.address) && !isTunnelIface(row.name) && row.address !== "127.0.0.1" && !isLinkLocal(row.address)
  );
  const rank = (name) => {
    if (/^(eth|enp|eno|ens|Ethernet)/i.test(name)) return 0;
    if (/^(wlan|wlp|wlx|Wi-Fi|wifi)/i.test(name)) return 1;
    return 2;
  };
  const ranked = [...candidates].sort((a, b) => rank(a.name) - rank(b.name) || a.name.localeCompare(b.name));
  const house = ranked.find((row) => row.address !== AP_IP);
  return (house || ranked[0])?.address || "";
}
function chooseOriginalIp(saved6, hostHeader, ifaces) {
  const lan = bestLan(ifaces);
  if (isIpv4(saved6)) {
    const onTunnel = ifaces.some((row) => row.address === saved6 && isTunnelIface(row.name));
    if (!onTunnel) {
      if (saved6 === AP_IP && lan && lan !== AP_IP) return lan;
      return saved6;
    }
  }
  const host2 = hostIp(hostHeader);
  if (isIpv4(host2) && host2 !== "127.0.0.1" && host2 !== AP_IP && !isLinkLocal(host2)) {
    const hit = ifaces.find((row) => row.address === host2 && !isTunnelIface(row.name));
    if (hit) return hit.address;
  }
  return lan;
}
function parseTunAddr(text) {
  const local = text.match(/\binet\s+(\d+\.\d+\.\d+\.\d+)/);
  const peer = text.match(/\bpeer\s+(\d+\.\d+\.\d+\.\d+)/);
  return {
    local: local && isIpv4(local[1]) ? local[1] : void 0,
    peer: peer && isIpv4(peer[1]) ? peer[1] : void 0
  };
}
function parseVia(text) {
  const via = text.match(/\bvia\s+(\d+\.\d+\.\d+\.\d+)/);
  return via && isIpv4(via[1]) ? via[1] : void 0;
}
function parsePingMs(text) {
  const match = text.match(/time[=<]\s*([0-9]+(?:[.,][0-9]+)?)\s*ms/i);
  if (!match) return void 0;
  const n = Number(match[1].replace(",", "."));
  if (!Number.isFinite(n) || n < 0) return void 0;
  return Math.round(n * 10) / 10;
}
function bytesPerSec(prev, now, iface, rx3, tx) {
  const sample = { iface, t: now, rx: rx3, tx };
  if (!prev || prev.iface !== iface) return { sample };
  const dt = (now - prev.t) / 1e3;
  if (dt < 0.4 || dt > 60) return { sample };
  const rxBps = (rx3 - prev.rx) / dt;
  const txBps = (tx - prev.tx) / dt;
  if (!Number.isFinite(rxBps) || !Number.isFinite(txBps) || rxBps < 0 || txBps < 0) return { sample };
  return { rxBps: Math.round(rxBps), txBps: Math.round(txBps), sample };
}
function publicVpnError(raw) {
  const clean = raw.replace(/\s+/g, " ").trim();
  if (!clean) return "Falha ao subir a VPN de suporte.";
  if (/BEGIN |PRIVATE KEY|<ca>|<cert>|<key>|auth\.txt/i.test(clean)) return "Falha ao subir a VPN de suporte.";
  return clean.slice(0, 240);
}
function statePath() {
  if (existsSync24("/opt/ham-cockpit")) return STATE_OPT;
  return join19(ROOT16, "data", "support-vpn.json");
}
function readState() {
  try {
    const raw = JSON.parse(readFileSync17(statePath(), "utf8"));
    return {
      enabled: raw.enabled === true,
      originalIp: typeof raw.originalIp === "string" && isIpv4(raw.originalIp) ? raw.originalIp : ""
    };
  } catch {
    return { enabled: false, originalIp: "" };
  }
}
function writeState(state) {
  const path5 = statePath();
  mkdirSync15(dirname18(path5), { recursive: true });
  const body = JSON.stringify({ enabled: state.enabled, originalIp: state.originalIp }, null, 2) + "\n";
  writeFileSync15(path5, body, { mode: 420 });
}
function liveIfaces() {
  const out = [];
  const table = networkInterfaces2();
  for (const [name, addrs] of Object.entries(table)) {
    for (const addr of addrs ?? []) {
      const family = String(addr.family);
      if ((family === "IPv4" || family === "4") && !addr.internal) out.push({ name, address: addr.address });
    }
  }
  return out;
}
function rememberOriginal(hostHeader) {
  const state = readState();
  const originalIp = chooseOriginalIp(state.originalIp, hostHeader, liveIfaces());
  if (originalIp !== state.originalIp) {
    const next = { ...state, originalIp };
    writeState(next);
    return next;
  }
  return state;
}
function linux4() {
  return process.platform === "linux";
}
async function runHelper2(cmd) {
  if (!existsSync24(HELPER10)) return { code: 127, stdout: "", stderr: "helper ausente" };
  try {
    const { stdout, stderr } = await execFileAsync17("sudo", ["-n", HELPER10, cmd], { timeout: 2e4, windowsHide: true });
    return { code: 0, stdout: String(stdout || ""), stderr: String(stderr || "") };
  } catch (err) {
    const e = err;
    return {
      code: typeof e.code === "number" ? e.code : 1,
      stdout: typeof e.stdout === "string" ? e.stdout : "",
      stderr: typeof e.stderr === "string" ? e.stderr : typeof e.message === "string" ? e.message : ""
    };
  }
}
function tunNames() {
  if (!existsSync24("/sys/class/net")) return [];
  try {
    return readdirSync4("/sys/class/net").filter((name) => /^tun\d+$/.test(name)).sort();
  } catch {
    return [];
  }
}
function counter(iface, which) {
  try {
    const n = Number(readFileSync17(`/sys/class/net/${iface}/statistics/${which}`, "utf8").trim());
    return Number.isFinite(n) && n >= 0 ? n : void 0;
  } catch {
    return void 0;
  }
}
async function tunInfo(iface) {
  try {
    const { stdout } = await execFileAsync17("ip", ["-4", "-o", "addr", "show", "dev", iface], { timeout: 3e3, windowsHide: true });
    const addr = parseTunAddr(String(stdout || ""));
    if (addr.peer) return addr;
    const route = await execFileAsync17("ip", ["-4", "route", "show", "dev", iface], { timeout: 3e3, windowsHide: true });
    return { local: addr.local, peer: parseVia(String(route.stdout || "")) };
  } catch {
    return {};
  }
}
async function pingMs(ip) {
  if (!isIpv4(ip)) return void 0;
  try {
    const { stdout } = await execFileAsync17("ping", ["-c", "1", "-W", "2", ip], { timeout: 4e3, windowsHide: true });
    return parsePingMs(String(stdout || ""));
  } catch (err) {
    const e = err;
    return parsePingMs(`${typeof e.stdout === "string" ? e.stdout : ""}
${typeof e.stderr === "string" ? e.stderr : ""}`);
  }
}
function base(state, phase3, extra = {}) {
  return {
    ok: phase3 !== "error",
    state: phase3,
    enabled: state.enabled,
    originalIp: state.originalIp,
    ...extra
  };
}
async function measure(iface) {
  const info = await tunInfo(iface);
  const rx3 = counter(iface, "rx_bytes");
  const tx = counter(iface, "tx_bytes");
  const out = { tunnelIface: iface };
  if (info.local) out.tunnelIp = info.local;
  if (rx3 !== void 0) out.rxBytes = rx3;
  if (tx !== void 0) out.txBytes = tx;
  if (rx3 !== void 0 && tx !== void 0) {
    const rate = bytesPerSec(lastSample, Date.now(), iface, rx3, tx);
    lastSample = rate.sample;
    if (rate.rxBps !== void 0) out.rxBps = rate.rxBps;
    if (rate.txBps !== void 0) out.txBps = rate.txBps;
  }
  if (info.peer) {
    const ms = await pingMs(info.peer);
    if (ms !== void 0) out.pingMs = ms;
  }
  return out;
}
async function activeState() {
  const r = await runHelper2("is-active");
  const line = (r.stdout || r.stderr).trim().split(/\s+/)[0] || "";
  if (line === "active" || line === "activating" || line === "failed" || line === "inactive" || line === "deactivating") return line;
  return "inactive";
}
async function supportVpnStatus(hostHeader = "") {
  const state = rememberOriginal(hostHeader);
  if (!state.enabled) {
    lastSample = null;
    return base(state, "off");
  }
  if (!linux4() || !existsSync24(HELPER10)) {
    return base(state, "error", {
      error: "A VPN de suporte s\xF3 sobe na esta\xE7\xE3o Linux, com OpenVPN e o servi\xE7o instalados."
    });
  }
  const active = await activeState();
  if (active === "activating" || active === "deactivating") return base(state, "connecting");
  if (active === "failed") {
    return base(state, "error", { error: "O OpenVPN n\xE3o conseguiu estabelecer o t\xFAnel." });
  }
  if (active !== "active") {
    if (armAt && Date.now() - armAt < 15e3) return base(state, "connecting");
    return base(state, "error", { error: "O servi\xE7o da VPN n\xE3o est\xE1 em execu\xE7\xE3o." });
  }
  const names = tunNames();
  for (const iface of names) {
    const info = await tunInfo(iface);
    if (!info.local) continue;
    const metrics = await measure(iface);
    return base(state, "on", metrics);
  }
  return base(state, "connecting");
}
async function supportVpnSet(enabled, hostHeader = "") {
  const state = rememberOriginal(hostHeader);
  if (!enabled) {
    armAt = 0;
    lastSample = null;
    if (linux4() && existsSync24(HELPER10)) {
      const stopped = await runHelper2("stop");
      if (stopped.code !== 0 && !/inactive|not loaded|could not be found/i.test(stopped.stderr)) {
        writeState({ ...state, enabled: false });
        return base({ ...state, enabled: false }, "error", { error: publicVpnError(stopped.stderr || stopped.stdout) });
      }
    }
    const next2 = { ...state, enabled: false };
    writeState(next2);
    return base(next2, "off");
  }
  if (!linux4() || !existsSync24(HELPER10)) {
    const next2 = { ...state, enabled: false };
    writeState(next2);
    return base(next2, "error", {
      error: "A VPN de suporte s\xF3 sobe na esta\xE7\xE3o Linux, com OpenVPN e o servi\xE7o instalados."
    });
  }
  const next = { ...state, enabled: true };
  writeState(next);
  armAt = Date.now();
  const started = await runHelper2("start");
  if (started.code !== 0) {
    armAt = 0;
    const failed = { ...next, enabled: false };
    writeState(failed);
    return base(failed, "error", { error: publicVpnError(started.stderr || started.stdout) });
  }
  return supportVpnStatus(hostHeader);
}

// server/index.ts
var __filename = fileURLToPath19(import.meta.url);
var __dirname = path4.dirname(__filename);
async function startServer() {
  const app = express();
  const server = createServer3(app);
  app.use(express.json({ limit: "32kb" }));
  attachTerminal(server);
  attachRadioAudio(server);
  attachScopeWs(server);
  registerLicenseRoutes(app);
  const staticPath = process.env.NODE_ENV === "production" ? path4.resolve(__dirname, "public") : path4.resolve(__dirname, "..", "dist", "public");
  app.get("/api/ser2net", async (_req, res) => {
    try {
      res.json(await loadSer2net());
    } catch (err) {
      res.status(500).json({ ok: false, services: [], error: String(err) });
    }
  });
  app.put("/api/ser2net", async (req, res) => {
    try {
      const body = await saveSer2net(req.body ?? {});
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, services: [], error: String(err) });
    }
  });
  app.post("/api/ser2net/hamlib", async (req, res) => {
    try {
      const action = String(req.body?.action || "").trim();
      if (action !== "start" && action !== "stop") {
        res.status(400).json({ ok: false, error: "action start|stop" });
        return;
      }
      const applied = await hamlibCtl(action);
      if (action === "start") await new Promise((r) => setTimeout(r, 700));
      const hamlibRunning = action === "stop" ? false : await probeHamlibNet();
      res.json({ ok: applied || hamlibRunning, hamlibRunning, applied });
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.get("/api/ldg", async (_req, res) => {
    try {
      res.json(await ldgPeek());
    } catch {
      res.json(ldgStatus());
    }
  });
  app.put("/api/ldg", async (req, res) => {
    try {
      res.json(await ldgSave(req.body ?? {}));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/ldg/connect", async (req, res) => {
    try {
      const body = await ldgConnect(req.body ?? {});
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/ldg/disconnect", async (_req, res) => {
    try {
      res.json(await ldgDisconnect());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/ldg/cmd", async (req, res) => {
    try {
      res.json(await ldgCmd(String(req.body?.cmd || "")));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.get("/api/lp100a", async (_req, res) => {
    try {
      res.json(await lp100aPeek());
    } catch {
      res.json(lp100aStatus());
    }
  });
  app.put("/api/lp100a", async (req, res) => {
    try {
      res.json(await lp100aSave(req.body ?? {}));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/lp100a/connect", async (_req, res) => {
    try {
      const body = await lp100aConnect();
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/lp100a/disconnect", async (_req, res) => {
    try {
      res.json(await lp100aDisconnect());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/lp100a/cmd", async (req, res) => {
    try {
      res.json(await lp100aCmd(String(req.body?.cmd || "")));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.get("/api/spe", async (_req, res) => {
    try {
      res.json(await spePeek());
    } catch {
      res.json(speStatus());
    }
  });
  app.put("/api/spe", async (req, res) => {
    try {
      res.json(await speSave(req.body ?? {}));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/spe/connect", async (_req, res) => {
    try {
      const body = await speConnect();
      res.status(body.ok && body.connected ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/spe/disconnect", async (_req, res) => {
    try {
      res.json(await speDisconnect());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/spe/cmd", async (req, res) => {
    try {
      res.json(await speCmd(String(req.body?.cmd || "")));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/spe/poweron", async (_req, res) => {
    try {
      res.json(await spePowerOn());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.get("/api/lextel", (_req, res) => {
    res.json(lextelStatus());
  });
  app.put("/api/lextel", async (req, res) => {
    try {
      res.json(await lextelSave(req.body ?? {}));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/lextel/scan", async (req, res) => {
    try {
      res.json(await lextelScan(Number(req.body?.seconds) || 12));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/lextel/connect", async (req, res) => {
    try {
      const body = await lextelConnect(req.body ?? {});
      res.status(body.ok && body.phase !== "error" ? 200 : 503).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/lextel/disconnect", async (_req, res) => {
    try {
      res.json(await lextelDisconnect());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/lextel/keepalive", async (_req, res) => {
    try {
      res.json(await lextelKeepalive());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/lextel/learn", async (_req, res) => {
    try {
      res.json(await lextelLearn());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/lextel/bluetooth", async (_req, res) => {
    try {
      res.json(await lextelOpenBluetooth());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.get("/api/radios", async (_req, res) => {
    try {
      res.json(await radiosStatus());
    } catch (err) {
      res.status(500).json({ ok: false, radios: [], error: String(err) });
    }
  });
  app.put("/api/radios", async (req, res) => {
    try {
      res.json(await radiosSave(req.body ?? {}));
    } catch (err) {
      res.status(500).json({ ok: false, radios: [], error: String(err) });
    }
  });
  app.post("/api/radios", async (req, res) => {
    try {
      res.json(await radiosUpsert(req.body ?? {}));
    } catch (err) {
      res.status(500).json({ ok: false, radios: [], error: String(err) });
    }
  });
  app.post("/api/radios/connect", async (req, res) => {
    try {
      const body = await radiosConnect(req.body ?? {});
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, radios: [], error: String(err) });
    }
  });
  app.post("/api/radios/primary", async (req, res) => {
    try {
      res.json(await radiosSetPrimary(String(req.body?.id ?? "")));
    } catch (err) {
      res.status(500).json({ ok: false, radios: [], error: String(err) });
    }
  });
  app.post("/api/radios/disconnect", async (req, res) => {
    try {
      res.json(await radiosDisconnect(String(req.body?.id ?? "")));
    } catch (err) {
      res.status(500).json({ ok: false, radios: [], error: String(err) });
    }
  });
  app.post("/api/radios/ble", async (req, res) => {
    try {
      res.json(
        await radiosMarkBle(String(req.body?.id ?? ""), Boolean(req.body?.connected), req.body?.name, req.body?.error)
      );
    } catch (err) {
      res.status(500).json({ ok: false, radios: [], error: String(err) });
    }
  });
  app.get("/api/radios/lan", (_req, res) => {
    try {
      res.json(icomLanStatus());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/radios/civ", async (req, res) => {
    try {
      const cmd = String(req.body?.cmd ?? req.body?.command ?? "");
      if (!cmd.trim()) {
        res.status(400).json({ ok: false, error: "cmd obrigat\xF3rio" });
        return;
      }
      const out = await icomLanCmd(cmd, req.body ?? {});
      if (cmd === "smeter") {
        res.status(200).json(out);
        return;
      }
      res.status(out.ok ? 200 : 502).json(out);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.delete("/api/radios/:id", async (req, res) => {
    try {
      res.json(await radiosRemove(req.params.id));
    } catch (err) {
      res.status(500).json({ ok: false, radios: [], error: String(err) });
    }
  });
  app.get("/api/equipment", (_req, res) => {
    try {
      const maker = typeof _req.query.maker === "string" ? _req.query.maker : void 0;
      res.json(hubCatalog(maker));
    } catch (err) {
      res.status(500).json({ ok: false, equipment: [], error: String(err) });
    }
  });
  app.get("/api/hamlib", (_req, res) => {
    try {
      res.json(hubStatus());
    } catch (err) {
      res.status(500).json({ ok: false, bindings: [], plans: [], error: String(err) });
    }
  });
  app.put("/api/hamlib/bindings", (req, res) => {
    try {
      res.json(hubSaveBindings(req.body ?? {}));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/hamlib/bindings", (req, res) => {
    try {
      const body = hubUpsertBinding(req.body ?? {});
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.delete("/api/hamlib/bindings/:id", (req, res) => {
    try {
      res.json(hubRemoveBinding(req.params.id));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/hamlib/plan", (req, res) => {
    try {
      const body = hubPlanOne(req.body ?? {});
      res.status(body.ok || body.plan ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/hamlib/cmd", async (req, res) => {
    try {
      const port2 = Number(req.body?.port ?? 4532);
      const host2 = String(req.body?.host ?? "127.0.0.1");
      let command = String(req.body?.command ?? "");
      if (port2 === 4532) {
        const row = currentSerialHamlib();
        command = rewriteIc705PowerOn(command, row);
      }
      if (!command.trim()) {
        res.status(400).json({ ok: false, error: "command obrigat\xF3rio" });
        return;
      }
      const out = await hubRigctl(port2, command, host2, 900);
      const queued = out.error === "ocupado" || out.error === "timeout" || out.error === "fila cheia";
      res.status(out.ok || queued ? 200 : 502).json(out);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post(
    "/api/digital/decode",
    express.raw({ type: "application/octet-stream", limit: "1mb" }),
    async (req, res) => {
      if (!consoleSessionOk(req.headers.cookie)) {
        res.status(401).json({ ok: false, ran: false, lines: [] });
        return;
      }
      const mode = req.query.mode === "FT4" ? "FT4" : req.query.mode === "FT8" ? "FT8" : "";
      const pcm = Buffer.isBuffer(req.body) ? req.body : Buffer.alloc(0);
      const expect = mode === "FT4" ? 9e4 * 2 : mode === "FT8" ? 18e4 * 2 : 0;
      if (!mode || pcm.length !== expect) {
        res.status(400).json({ ok: false, ran: false, lines: [] });
        return;
      }
      try {
        const out = await decodeSlot(mode, pcm);
        res.json({ ok: true, ran: out.ran, lines: out.lines });
      } catch (err) {
        res.status(200).json({ ok: true, ran: false, lines: [], error: String(err) });
      }
    }
  );
  app.get("/api/digital/rx", (req, res) => {
    if (!consoleSessionOk(req.headers.cookie)) {
      res.status(401).json({ ok: false, enabled: false, rows: [] });
      return;
    }
    res.json(digitalRxSnapshot());
  });
  app.post("/api/digital/rx", async (req, res) => {
    if (!consoleSessionOk(req.headers.cookie)) {
      res.status(401).json({ ok: false, enabled: false, rows: [] });
      return;
    }
    const out = await digitalRxCommand({
      op: String(req.body?.op ?? ""),
      mode: String(req.body?.mode ?? ""),
      hz: Number(req.body?.hz),
      band: String(req.body?.band ?? ""),
      dialId: String(req.body?.dialId ?? ""),
      n: Number(req.body?.n)
    });
    res.status(out.ok ? 200 : 409).json(out);
  });
  app.get("/api/digital/waterfall", (req, res) => {
    if (!consoleSessionOk(req.headers.cookie)) {
      res.status(401).json({ ok: false, gen: 0, stripes: [] });
      return;
    }
    const after = Number(req.query.after);
    res.json(digitalWaterfallSince(Number.isFinite(after) ? after : 0));
  });
  app.get("/api/digital/clock", (req, res) => {
    if (!consoleSessionOk(req.headers.cookie)) {
      res.status(401).json({ ok: false });
      return;
    }
    res.json({ ok: true, now: Date.now() });
  });
  app.post("/api/digital/tx", async (req, res) => {
    if (!consoleSessionOk(req.headers.cookie)) {
      res.status(401).json({ ok: false, error: "auth" });
      return;
    }
    const mode = req.body?.mode === "FT4" ? "FT4" : req.body?.mode === "FT8" ? "FT8" : "";
    if (!mode) {
      res.status(400).json({ ok: false, error: "modo" });
      return;
    }
    const out = await scheduleDigitalTx({
      mode,
      message: String(req.body?.message ?? ""),
      audioHz: Number(req.body?.audioHz),
      even: Boolean(req.body?.even),
      port: Number(req.body?.port ?? 4532),
      level: Number(req.body?.level ?? 0.5)
    });
    res.status(out.ok ? 200 : 409).json(out);
  });
  app.get("/api/digital/tx", (req, res) => {
    if (!consoleSessionOk(req.headers.cookie)) {
      res.status(401).json({ ok: false, phase: "idle" });
      return;
    }
    res.json({ ok: true, ...txSnapshot() });
  });
  app.post("/api/digital/halt", async (req, res) => {
    if (!consoleSessionOk(req.headers.cookie)) {
      res.status(401).json({ ok: false });
      return;
    }
    await haltDigitalTx();
    res.json({ ok: true, ...txSnapshot() });
  });
  app.post("/api/hamlib/smeter", async (req, res) => {
    try {
      const port2 = Number(req.body?.port ?? 4532);
      const host2 = String(req.body?.host ?? "127.0.0.1");
      if (!Number.isFinite(port2) || port2 <= 0) {
        res.status(200).json({ ok: false, reply: "", error: "porta inv\xE1lida" });
        return;
      }
      const out = await hubRigctl(port2, "\\get_level STRENGTH", host2, 200);
      res.status(200).json(out);
    } catch (err) {
      res.status(200).json({ ok: false, reply: "", error: String(err) });
    }
  });
  app.get("/api/net", async (_req, res) => {
    try {
      res.json(await netStatus());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.put("/api/net", async (req, res) => {
    try {
      res.json(await netSave(req.body ?? {}));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/net/scan", async (_req, res) => {
    try {
      res.json(await netScan());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/net/connect", async (req, res) => {
    try {
      const body = await netConnect(req.body ?? {});
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/net/forget", async (req, res) => {
    try {
      res.json(await netForget(String(req.body?.ssid ?? "")));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/net/link", async (req, res) => {
    try {
      res.json(await netSetLink(req.body?.link === "ethernet" ? "ethernet" : "wifi"));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/net/ip", async (req, res) => {
    try {
      const body = await netSetIp(req.body ?? {});
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/net/hostname", async (req, res) => {
    try {
      const body = await netSetHostname(String(req.body?.hostname ?? ""));
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/net/ap", async (req, res) => {
    try {
      const body = await netSetAp(req.body ?? {});
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.get("/api/services", async (_req, res) => {
    try {
      res.json(await servicesStatus());
    } catch (err) {
      res.status(500).json({ ok: false, items: [], error: String(err) });
    }
  });
  app.post("/api/services", async (req, res) => {
    try {
      const body = await servicesSetAutostart(String(req.body?.id ?? ""), Boolean(req.body?.autostart));
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, items: [], error: String(err) });
    }
  });
  app.post("/api/services/power", async (req, res) => {
    try {
      res.setTimeout(3e5);
      const body = await servicesPower(String(req.body?.id ?? ""), Boolean(req.body?.on));
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, items: [], error: String(err) });
    }
  });
  app.get("/api/processes", async (_req, res) => {
    try {
      const body = await processesList();
      res.status(body.ok ? 200 : 500).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, available: false, items: [], error: String(err) });
    }
  });
  app.post("/api/processes", async (req, res) => {
    try {
      res.setTimeout(6e4);
      const action = String(req.body?.action ?? "");
      const unit = String(req.body?.unit ?? "");
      const body = await processesAction(unit, action);
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, unit: "", action: "", error: String(err) });
    }
  });
  app.get("/api/updates", async (_req, res) => {
    try {
      res.json(await updatesStatus());
    } catch (err) {
      res.status(500).json({ ok: false, items: [], pending: 0, error: String(err) });
    }
  });
  app.post("/api/updates/check", async (_req, res) => {
    try {
      res.json(await updatesRefresh());
    } catch (err) {
      res.status(500).json({ ok: false, items: [], pending: 0, error: String(err) });
    }
  });
  app.post("/api/updates", async (req, res) => {
    try {
      const body = await updatesApply(String(req.body?.id ?? ""));
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, items: [], pending: 0, error: String(err) });
    }
  });
  app.get("/api/serials", async (_req, res) => {
    try {
      res.json({ devices: await listSerialDevices() });
    } catch (err) {
      res.status(500).json({ devices: [], error: String(err) });
    }
  });
  app.get("/api/wavelog/status", async (_req, res) => {
    try {
      res.json(await wavelogStatus());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/wavelog/up", async (_req, res) => {
    try {
      const body = await wavelogUp();
      res.status(body.ok ? 200 : 503).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/wavelog/down", async (_req, res) => {
    try {
      res.json(await wavelogDown());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.get("/api/wavelog/database", async (_req, res) => {
    try {
      res.json(await wavelogDatabase());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.get("/api/wavelog/database/password", async (_req, res) => {
    try {
      const out = await wavelogDbPassword();
      res.status(out.password ? 200 : 404).json({ ok: Boolean(out.password), ...out });
    } catch (err) {
      res.status(500).json({ ok: false, password: "", error: String(err) });
    }
  });
  app.post("/api/wavelog/db/up", async (_req, res) => {
    try {
      res.setTimeout(3e5);
      res.json(await wavelogDbUp());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/wavelog/db/down", async (_req, res) => {
    try {
      res.setTimeout(12e4);
      res.json(await wavelogDbDown());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/wavelog/db-update", async (_req, res) => {
    try {
      res.setTimeout(3e5);
      const body = await wavelogDbUpdate();
      res.status(body.updated ? 200 : 503).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.get("/api/wlg/status", async (_req, res) => {
    try {
      res.json(await wlgStatus());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/wlg/up", async (_req, res) => {
    try {
      const body = await wlgUp();
      res.status(body.ok ? 200 : 503).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/wlg/down", async (_req, res) => {
    try {
      res.json(await wlgDown());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.get("/api/mmdvm", async (_req, res) => {
    try {
      res.json(await mmdvmStatus());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.put("/api/mmdvm", async (req, res) => {
    try {
      res.json(await mmdvmSave(req.body ?? {}));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/mmdvm/up", async (_req, res) => {
    try {
      const body = await mmdvmControl("start");
      res.status(body.hostRunning || body.installed ? 200 : 503).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/mmdvm/down", async (_req, res) => {
    try {
      res.json(await mmdvmControl("stop"));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/mmdvm/restart", async (_req, res) => {
    try {
      res.json(await mmdvmControl("restart"));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/mmdvm/remote", async (req, res) => {
    try {
      const body = await mmdvmRemote(String(req.body?.cmd || ""));
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/mmdvm/mode/:mode/pause", async (req, res) => {
    try {
      res.json(await mmdvmModePause(String(req.params.mode || ""), true));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/mmdvm/mode/:mode/resume", async (req, res) => {
    try {
      res.json(await mmdvmModePause(String(req.params.mode || ""), false));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/mmdvm/modes/resume-all", async (_req, res) => {
    try {
      res.json(await mmdvmModeResumeAll());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/mmdvm/network", async (req, res) => {
    try {
      res.json(await mmdvmNetworkSet(req.body ?? {}));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/mmdvm/link", async (req, res) => {
    try {
      res.json(await mmdvmLink(req.body ?? {}));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.get("/api/layout", (req, res) => {
    try {
      res.json(layoutGet(String(req.query.user || "admin"), req.query.scope));
    } catch (err) {
      res.status(500).json({ ok: false, tiles: [], error: String(err) });
    }
  });
  app.put("/api/layout", (req, res) => {
    try {
      res.json(layoutSave(req.body?.user, req.body?.tiles, req.body?.scope));
    } catch (err) {
      res.status(500).json({ ok: false, tiles: [], error: String(err) });
    }
  });
  app.post("/api/console/session", (req, res) => {
    const token = consoleSessionToken(String(req.body?.user ?? ""), String(req.body?.password ?? ""));
    if (!token) {
      res.status(401).json({ ok: false, error: "auth" });
      return;
    }
    res.setHeader("Set-Cookie", consoleSessionCookie(token));
    res.json({ ok: true });
  });
  app.get("/api/console/session", (req, res) => {
    if (!consoleSessionOk(req.headers.cookie)) {
      res.status(401).json({ ok: false });
      return;
    }
    res.json({ ok: true });
  });
  app.delete("/api/console/session", (_req, res) => {
    res.setHeader("Set-Cookie", consoleSessionClearCookie());
    res.json({ ok: true });
  });
  const supportDenied = (req, res) => {
    if (consoleSessionOk(req.headers.cookie)) return false;
    res.status(401).json({ ok: false, error: "auth" });
    return true;
  };
  app.get("/api/support/vpn", async (req, res) => {
    if (supportDenied(req, res)) return;
    try {
      res.json(await supportVpnStatus(String(req.headers.host || "")));
    } catch {
      res.status(500).json({ ok: false, state: "error", error: "Falha ao falar com a VPN de suporte." });
    }
  });
  app.post("/api/support/vpn", async (req, res) => {
    if (supportDenied(req, res)) return;
    if (typeof req.body?.enabled !== "boolean") {
      res.status(400).json({ ok: false, state: "error", error: "enabled" });
      return;
    }
    try {
      res.json(await supportVpnSet(req.body.enabled, String(req.headers.host || "")));
    } catch {
      res.status(500).json({ ok: false, state: "error", error: "Falha ao falar com a VPN de suporte." });
    }
  });
  app.get("/api/users", async (_req, res) => {
    try {
      const [users, ssh] = await Promise.all([listUsers(), sshStatus()]);
      res.json({ users, ssh });
    } catch (err) {
      res.status(500).json({ users: [], error: String(err) });
    }
  });
  app.post("/api/users", async (req, res) => {
    try {
      const name = String(req.body?.name ?? "");
      const password = String(req.body?.password ?? "");
      const body = await createUser(name, password);
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.delete("/api/users/:name", async (req, res) => {
    try {
      const body = await deleteUser(req.params.name);
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.get("/api/host", async (_req, res) => {
    try {
      res.json(await hostStatus());
    } catch (err) {
      res.status(500).json({
        ok: false,
        cpuTempC: null,
        diskTotalBytes: 0,
        diskFreeBytes: 0,
        diskUsedBytes: 0,
        diskPath: "/",
        error: String(err),
        hardware: "",
        soc: "",
        osPretty: "",
        appVersion: "",
        uptimeSec: 0,
        cpuPct: null,
        ramPct: null,
        ramUsedBytes: 0,
        ramTotalBytes: 0,
        netRxBps: null,
        netTxBps: null,
        sampleMs: 5e3,
        windowMs: 3e5,
        samples: []
      });
    }
  });
  app.get("/api/backup", (_req, res) => {
    try {
      res.json(backupList());
    } catch (err) {
      res.status(500).json({ ok: false, items: [], error: String(err) });
    }
  });
  app.get("/api/backup/jobs/:id", (req, res) => {
    const job2 = backupJobGet(req.params.id);
    if (!job2) {
      res.status(404).json({ ok: false, error: "job_not_found" });
      return;
    }
    res.json({ ok: true, job: job2 });
  });
  app.get("/api/backup/:id/file", (req, res) => {
    if (!consoleSessionOk(req.headers.cookie)) {
      res.status(401).json({ ok: false, error: "Sess\xE3o expirada. Entre de novo." });
      return;
    }
    try {
      const found = backupArchiveFile(req.params.id);
      if (!found.ok) {
        res.status(found.error === "missing" ? 404 : 400).json(found);
        return;
      }
      res.setHeader("Content-Type", "application/gzip");
      res.setHeader("Content-Disposition", `attachment; filename="${found.filename}"`);
      res.setHeader("Cache-Control", "no-store");
      createReadStream2(found.path).pipe(res);
    } catch (err) {
      if (!res.headersSent) res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/backup/restore-file", async (req, res) => {
    if (!consoleSessionOk(req.headers.cookie)) {
      res.status(401).json({ ok: false, error: "Sess\xE3o expirada. Entre de novo." });
      return;
    }
    let uploaded = "";
    try {
      const upload = await backupReadUpload(req);
      if (!upload.ok) {
        res.status(400).json(upload);
        return;
      }
      uploaded = upload.path;
      const valid = await backupValidateUpload(upload.path, upload.filename);
      if (!valid.ok) {
        backupDropUpload(uploaded);
        uploaded = "";
        res.status(400).json(valid);
        return;
      }
      const started = backupRestoreFileStart(upload.path, upload.confirm);
      uploaded = "";
      res.status(started.ok ? 200 : 400).json(started);
    } catch (err) {
      if (uploaded) backupDropUpload(uploaded);
      if (!res.headersSent) res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/backup", (req, res) => {
    try {
      res.json(backupCreateStart(String(req.body?.user ?? "admin")));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.delete("/api/backup/:id", (req, res) => {
    try {
      const body = backupDelete(req.params.id);
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/backup/:id/restore", (req, res) => {
    try {
      const body = backupRestoreStart(req.params.id, Boolean(req.body?.confirm));
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/vfo-display/exit", async (req, res) => {
    if (!isLoopback(req)) {
      res.status(403).json({ ok: false, error: "local" });
      return;
    }
    try {
      res.json(await vfoDisplayExit());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.use(express.static(staticPath));
  app.use("/api", (_req, res) => {
    res.status(404).json({ ok: false, error: "API n\xE3o encontrada" });
  });
  app.get("*", (_req, res) => {
    res.sendFile(path4.join(staticPath, "index.html"));
  });
  const port = process.env.PORT || 3e3;
  setBeforeHamlibRestart(async () => {
    await prepareSerialScopeTap();
  });
  void radiosResumeIcomLan().catch(() => void 0);
  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
    void syncSerialScopeTap();
    void servicesApplyBoot();
  });
}
startServer().catch(console.error);
