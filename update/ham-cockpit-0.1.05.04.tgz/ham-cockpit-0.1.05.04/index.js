var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// server/lextel-parse.ts
function round(n, d) {
  const p = 10 ** d;
  return Math.round(n * p) / p;
}
function alarmsOf(r, flags = 0) {
  const alarms = {
    vLow: r.vdc > 0 && r.vdc < 10.5,
    vHigh: r.vdc > 28,
    swrHigh: r.swr >= 2,
    antFault: r.swr >= 3 || Boolean(flags & 8),
    pwrHigh: r.pep > 2e3 || Boolean(flags & 16)
  };
  if (flags & 1) alarms.vHigh = true;
  if (flags & 2) alarms.vLow = true;
  if (flags & 4) alarms.swrHigh = true;
  const labels = [];
  if (alarms.vHigh) labels.push("vHigh");
  if (alarms.vLow) labels.push("vLow");
  if (alarms.swrHigh) labels.push("swrHigh");
  if (alarms.antFault) labels.push("antFault");
  if (alarms.pwrHigh) labels.push("pwrHigh");
  return { alarms, labels };
}
function finish(partial, flags = 0) {
  const base = {
    pep: round(Math.max(0, partial.pep ?? 0), 3),
    avg: round(Math.max(0, partial.avg ?? 0), 3),
    ref: round(Math.max(0, partial.ref ?? 0), 3),
    swr: round(Math.min(9.9, Math.max(1, partial.swr ?? 1)), 2),
    vdc: round(Math.max(0, partial.vdc ?? 0), 2),
    z: round(Math.max(0, partial.z ?? 0), 1),
    mod: round(Math.min(150, Math.max(0, partial.mod ?? 0)), 1)
  };
  return { ...base, ...alarmsOf(base, flags) };
}
function plausible(r, idleOk = true) {
  let s = 0;
  if (r.vdc >= 10 && r.vdc <= 30) s += 3;
  else if (r.vdc === 0 && idleOk) s += 0;
  if (r.z >= 5 && r.z <= 500) s += 2;
  if (r.swr >= 1 && r.swr <= 9.9) s += 2;
  if (r.pep >= 0 && r.pep <= 2400) s += 1;
  if (r.avg >= 0 && r.avg <= 2400 && r.avg <= r.pep + 80) s += 1;
  if (r.ref >= 0 && r.ref <= 2400 && r.ref <= r.pep + 80) s += 1;
  if (r.mod >= 0 && r.mod <= 150) s += 1;
  return s;
}
function num(v) {
  if (v == null || v === "") return void 0;
  const n = Number(v.replace(",", "."));
  return Number.isFinite(n) ? n : void 0;
}
function wattsField(n) {
  if (n == null || !Number.isFinite(n)) return 0;
  return n / 1e3;
}
function readingFromLetters(L) {
  if (L.A == null && L.E == null) return null;
  if (L.D == null && L.E == null && L.A == null) return null;
  const f = L.F;
  return finish({
    pep: wattsField(L.A),
    avg: wattsField(L.B),
    ref: wattsField(L.C),
    swr: L.D ?? 1,
    vdc: L.E ?? 0,
    // F on the MS-2000 is band in MHz (7 = 40 m), not Z and not AM %.
    z: f != null && f > 150 && f <= 500 ? f : 0,
    mod: 0
  });
}
function parseLetterBlock(text) {
  const L = {};
  const re = /(?:^|\r?\n)([A-F]):\s*([\d.,]+)/gi;
  let m;
  let last = null;
  while (m = re.exec(text)) {
    L[m[1].toUpperCase()] = Number(m[2].replace(",", "."));
    if (L.A != null && L.D != null && L.E != null && L.F != null) {
      last = readingFromLetters(L);
    }
  }
  return last ?? readingFromLetters(L);
}
function parseAsciiLine(line) {
  const t = line.trim();
  if (!t) return null;
  const letter = t.match(/^([A-F]):\s*([\d.,]+)$/i);
  if (letter) {
    const one = { [letter[1].toUpperCase()]: Number(letter[2].replace(",", ".")) };
    const fromOne = readingFromLetters(one);
    if (fromOne && letter[1].toUpperCase() === "E") return fromOne;
  }
  if (t.startsWith("{") && t.endsWith("}")) {
    try {
      const j = JSON.parse(t);
      const pick = (...keys) => {
        for (const k of keys) {
          const v = j[k];
          if (typeof v === "number" && Number.isFinite(v)) return v;
          if (typeof v === "string") {
            const n = Number(v);
            if (Number.isFinite(n)) return n;
          }
        }
        return void 0;
      };
      const pep = pick("pep", "PEP", "p", "fwd", "peak");
      if (pep == null && pick("v", "vdc", "volt", "voltage") == null) return null;
      return finish({
        pep,
        avg: pick("avg", "average", "rms", "pavg", "media"),
        ref: pick("ref", "refl", "pr", "reflected"),
        swr: pick("swr", "roe", "vswr"),
        vdc: pick("vdc", "volt", "voltage", "v", "psu"),
        z: pick("z", "ohm", "r", "zant"),
        mod: pick("mod", "am", "modulation")
      });
    } catch {
    }
  }
  const kv = {};
  const re = /(PEP|PEAK|AVG|MEDIA|MÉDIA|SWR|ROE|VSWR|VDC|VOLT|V|REF|REFL|MOD|AM|Z|OHM|RANT)\s*[:=]\s*([\d.,]+)/gi;
  let m;
  while (m = re.exec(t)) {
    kv[m[1].toUpperCase()] = Number(m[2].replace(",", "."));
  }
  if (kv.PEP != null || kv.PEAK != null || kv.SWR != null || kv.ROE != null || kv.VDC != null) {
    return finish({
      pep: kv.PEP ?? kv.PEAK,
      avg: kv.AVG ?? kv.MEDIA ?? kv.M\u00C9DIA,
      ref: kv.REF ?? kv.REFL,
      swr: kv.SWR ?? kv.ROE ?? kv.VSWR,
      vdc: kv.VDC ?? kv.VOLT ?? kv.V,
      z: kv.Z ?? kv.OHM ?? kv.RANT,
      mod: kv.MOD ?? kv.AM
    });
  }
  const parts = t.split(/[;,\s]+/).map((x) => x.trim()).filter(Boolean);
  const nums = parts.map((p) => num(p)).filter((n) => n != null);
  if (nums.length >= 5 && nums.length <= 10) {
    const cand = finish({
      pep: nums[0],
      avg: nums[1],
      ref: nums[2],
      swr: nums[3] < 20 ? nums[3] : nums[3] / 10,
      vdc: nums[4] > 30 ? nums[4] / 10 : nums[4],
      z: nums[5],
      mod: nums[6]
    });
    if (plausible(cand) >= 6) return cand;
  }
  return null;
}
function uInt(buf, off, size, le) {
  if (size === 1) return buf[off] ?? 0;
  if (off + 1 >= buf.length) return 0;
  return le ? buf.readUInt16LE(off) : buf.readUInt16BE(off);
}
function applyMap(frame, layout) {
  if (!layout.map) return null;
  const le = layout.endian !== "be";
  const get = (key, fallback = 0) => {
    const f = layout.map?.[key];
    if (!f) return fallback;
    return uInt(frame, f.off, f.size, le) * f.scale;
  };
  const flags = layout.map.flags ? uInt(frame, layout.map.flags.off, layout.map.flags.size, le) : 0;
  const pep = get("pep");
  const swrRaw = get("swr", 1);
  const vdcRaw = get("vdc");
  return finish(
    {
      pep,
      avg: get("avg"),
      ref: get("ref"),
      swr: swrRaw < 1 ? 1 : swrRaw > 20 ? swrRaw / (swrRaw > 200 ? 100 : 10) : swrRaw,
      vdc: vdcRaw > 40 ? vdcRaw / (vdcRaw > 400 ? 100 : 10) : vdcRaw,
      z: get("z"),
      mod: get("mod")
    },
    flags
  );
}
function tryBin16(frame, le) {
  if (frame.length < 14) return null;
  const g = (off) => le ? frame.readUInt16LE(off) : frame.readUInt16BE(off);
  const pep = g(0);
  const avg = g(2);
  const ref = g(4);
  let swr = g(6);
  let vdc = g(8);
  const z = g(10);
  const mod = frame[12] ?? 0;
  const flags = frame[13] ?? 0;
  if (swr > 20) swr = swr / (swr > 200 ? 100 : 10);
  if (vdc > 40) vdc = vdc / (vdc > 400 ? 100 : 10);
  const pepW = pep > 2400 ? pep / 10 : pep;
  const avgW = avg > 2400 ? avg / 10 : avg;
  const refW = ref > 2400 ? ref / 10 : ref;
  const cand = finish({ pep: pepW, avg: avgW, ref: refW, swr, vdc, z, mod }, flags);
  return plausible(cand) >= 7 ? cand : null;
}
function scaleFits(raw, min, max) {
  for (const s of [1, 0.1, 0.01]) {
    const v = raw * s;
    if (v >= min && v <= max) return s;
  }
  return null;
}
function learnLayout(buf) {
  if (buf.length < 64) return null;
  let best = null;
  for (let period = 8; period <= 32; period++) {
    const frames = [];
    for (let i = 0; i + period <= buf.length && frames.length < 12; i += period) {
      frames.push(buf.subarray(i, i + period));
    }
    if (frames.length < 5) continue;
    for (const endian of ["le", "be"]) {
      const le = endian === "le";
      const map = {};
      const assign = (key, min, max, prefer2 = true) => {
        let hit = null;
        let hitScore = 0;
        const maxOff = period - 1;
        for (let off = 0; off <= maxOff; off++) {
          for (const size of prefer2 ? [2, 1] : [1, 2]) {
            if (off + size > period) continue;
            const used = Object.values(map).some((f) => f && !(off + size <= f.off || f.off + f.size <= off));
            if (used) continue;
            const vals = frames.map((f) => uInt(f, off, size, le));
            const median = vals.slice().sort((a, b) => a - b)[Math.floor(vals.length / 2)] ?? 0;
            const scale = scaleFits(median, min, max);
            if (scale == null) continue;
            const stable = vals.filter((v) => {
              const x = v * scale;
              return x >= min * 0.5 && x <= max * 1.2;
            }).length;
            if (stable < frames.length - 1) continue;
            if (stable > hitScore) {
              hitScore = stable;
              hit = { off, size, scale };
            }
          }
        }
        if (hit) map[key] = hit;
      };
      assign("vdc", 10, 30);
      assign("z", 5, 500);
      assign("swr", 1, 9.9);
      assign("pep", 0, 2400);
      assign("avg", 0, 2400);
      assign("ref", 0, 2400);
      assign("mod", 0, 150, false);
      if (!map.vdc && !map.pep) continue;
      const layout = { kind: "learned", period, endian, map };
      const reading2 = applyMap(frames[frames.length - 1], layout);
      if (!reading2) continue;
      const score = plausible(reading2) + Object.keys(map).length;
      if (!best || score > best.score) best = { score, layout, reading: reading2 };
    }
  }
  if (best && best.score >= 8) return { layout: best.layout, reading: best.reading };
  return null;
}
function toHex(buf, max = 64) {
  const slice = buf.subarray(Math.max(0, buf.length - max));
  return Array.from(slice, (b) => b.toString(16).padStart(2, "0")).join(" ");
}
function guessPeriod(buf) {
  if (buf.length < 48) return null;
  let bestLag = 0;
  let best = 0;
  const n = Math.min(buf.length, 512);
  for (let lag = 8; lag <= 32; lag++) {
    let hit = 0;
    let tot = 0;
    for (let i = 0; i + lag < n; i++) {
      tot += 1;
      if (buf[i] === buf[i + lag]) hit += 1;
    }
    const score = tot ? hit / tot : 0;
    if (score > best) {
      best = score;
      bestLag = lag;
    }
  }
  return best >= 0.18 ? bestLag : null;
}
function inspectCapture(buf) {
  const printable = buf.reduce((n, b) => n + (b === 9 || b === 10 || b === 13 || b >= 32 && b < 127 ? 1 : 0), 0);
  const ratio = buf.length ? printable / buf.length : 0;
  let start = 0;
  while (start < buf.length && buf[start] === 0) start += 1;
  const slice = buf.subarray(start);
  const ascii = slice.toString("latin1").replace(/[^\t\r\n\x20-\x7e]/g, ".").slice(0, 480);
  const hexHead = toHex(buf.subarray(0, Math.min(buf.length, 96)), 96);
  const period = guessPeriod(buf);
  const dec = new LextelDecoder();
  const reading2 = buf.length ? dec.push(buf) : null;
  let note = "aguardando bytes";
  if (!buf.length) note = "sem captura";
  else if (ratio > 0.75 || dec.layout?.kind === "ascii") note = "ASCII A-F (PEP/AVG/REF mW /1000 = W, ROE, V, F)";
  else if (dec.layout) note = `quadro ${dec.layout.kind}${period ? ` \xB7 per\xEDodo ~${period} B` : ""}`;
  else if (period) note = `bin\xE1rio repetindo a cada ~${period} B \u2014 ainda mapeando campos`;
  else note = `${buf.length} B recebidos \xB7 ${Math.round(ratio * 100)}% imprim\xEDveis`;
  return {
    ascii,
    printable: ratio,
    period,
    hexHead,
    note,
    layout: dec.layout,
    reading: reading2
  };
}
var MAX_BUF, LextelDecoder;
var init_lextel_parse = __esm({
  "server/lextel-parse.ts"() {
    "use strict";
    MAX_BUF = 2048;
    LextelDecoder = class {
      buf = Buffer.alloc(0);
      ascii = "";
      letters = {};
      layout = null;
      lastHex = "";
      bytes = 0;
      constructor(saved5) {
        this.layout = saved5 ?? null;
      }
      reset(saved5) {
        this.buf = Buffer.alloc(0);
        this.ascii = "";
        this.letters = {};
        this.layout = saved5 ?? null;
        this.lastHex = "";
        this.bytes = 0;
      }
      push(chunk) {
        if (!chunk.length) return null;
        this.bytes += chunk.length;
        this.buf = Buffer.concat([this.buf, chunk]);
        if (this.buf.length > MAX_BUF) this.buf = this.buf.subarray(this.buf.length - MAX_BUF);
        this.lastHex = toHex(this.buf);
        this.ascii += chunk.toString("latin1");
        if (this.ascii.length > MAX_BUF) this.ascii = this.ascii.slice(-MAX_BUF);
        const block = parseLetterBlock(this.ascii);
        if (block && (plausible(block) >= 4 || this.layout?.kind === "ascii" || block.vdc >= 10)) {
          this.layout = { kind: "ascii" };
          return block;
        }
        const nl = this.ascii.lastIndexOf("\n");
        const cr = this.ascii.lastIndexOf("\r");
        const cut = Math.max(nl, cr);
        if (cut > 0) {
          const lines = this.ascii.slice(0, cut).split(/\r\n|\n|\r/);
          this.ascii = this.ascii.slice(cut + 1);
          for (const line of lines) {
            const lettr = line.trim().match(/^([A-F]):\s*([\d.,]+)$/i);
            if (lettr) {
              this.letters[lettr[1].toUpperCase()] = Number(lettr[2].replace(",", "."));
              if (this.letters.A != null && this.letters.E != null) {
                const got = readingFromLetters(this.letters);
                if (got && (plausible(got) >= 4 || this.layout?.kind === "ascii" || got.vdc >= 10)) {
                  this.layout = { kind: "ascii" };
                  return got;
                }
              }
            }
          }
          for (let i = lines.length - 1; i >= 0; i--) {
            const got = parseAsciiLine(lines[i] ?? "");
            if (got && plausible(got) >= 5) {
              this.layout = { kind: lines[i]?.trim().startsWith("{") ? "json" : /[;,]/.test(lines[i] ?? "") ? "csv" : "ascii" };
              return got;
            }
          }
        }
        const aa = this.buf.lastIndexOf(170);
        if (aa >= 0 && aa + 1 < this.buf.length && this.buf[aa + 1] === 85 && aa + 16 <= this.buf.length) {
          const frame = this.buf.subarray(aa, aa + 16);
          const le = tryBin16(frame.subarray(2), true);
          const be = tryBin16(frame.subarray(2), false);
          const hit = (le && plausible(le) >= 7 ? le : null) || (be && plausible(be) >= 7 ? be : null);
          if (hit) {
            this.layout = { kind: "aa55", period: 16, endian: le && plausible(le) >= 7 ? "le" : "be" };
            return hit;
          }
        }
        const stx = this.buf.lastIndexOf(2);
        const etx = this.buf.lastIndexOf(3);
        if (stx >= 0 && etx > stx + 8 && etx - stx <= 40) {
          const frame = this.buf.subarray(stx + 1, etx);
          const hit = tryBin16(frame, true) || tryBin16(frame, false);
          if (hit) {
            this.layout = { kind: "stx", period: etx - stx + 1 };
            return hit;
          }
        }
        if (this.layout?.kind === "learned" || this.layout?.kind === "bin16") {
          const period = this.layout.period ?? 16;
          if (this.buf.length >= period) {
            const frame = this.buf.subarray(this.buf.length - period);
            const hit = this.layout.map ? applyMap(frame, this.layout) : tryBin16(frame, this.layout.endian !== "be");
            if (hit && plausible(hit) >= 5) return hit;
          }
        }
        if (this.buf.length >= 16) {
          const tail = this.buf.subarray(this.buf.length - 16);
          const hit = tryBin16(tail, true) || tryBin16(tail, false);
          if (hit) {
            this.layout = { kind: "bin16", period: 16, endian: tryBin16(tail, true) ? "le" : "be" };
            return hit;
          }
        }
        if (!this.layout && this.buf.length >= 96) {
          const learned = learnLayout(this.buf);
          if (learned) {
            this.layout = learned.layout;
            return learned.reading;
          }
        }
        return null;
      }
    };
  }
});

// server/list-serials.ts
import { execFile } from "node:child_process";
import { readdir } from "node:fs/promises";
import { join } from "node:path";
import { promisify } from "node:util";
async function listSerialDevices() {
  const found = process.platform === "win32" ? await listWindows() : await listUnix();
  const uniq = /* @__PURE__ */ new Map();
  for (const d of found) uniq.set(d.path, d);
  return Array.from(uniq.values()).sort((a, b) => a.path.localeCompare(b.path));
}
async function listUnix() {
  const out = [];
  const byId = "/dev/serial/by-id";
  try {
    const names = await readdir(byId);
    for (const name of names) {
      out.push({ path: `${byId}/${name}`, label: name, kind: "usb" });
    }
  } catch {
  }
  for (const dir of ["/dev"]) {
    let names = [];
    try {
      names = await readdir(dir);
    } catch {
      continue;
    }
    for (const name of names) {
      if (!/^(ttyUSB|ttyACM|ttyAMA|ttyS)\d+$/.test(name)) continue;
      const path2 = join(dir, name);
      if (out.some((d) => d.path === path2)) continue;
      const kind = name.startsWith("ttyUSB") || name.startsWith("ttyACM") ? "usb" : "serial";
      out.push({ path: path2, label: name, kind });
    }
  }
  return out;
}
async function listWindows() {
  const script = [
    "$ports = @()",
    "try { [System.IO.Ports.SerialPort]::GetPortNames() | ForEach-Object { $ports += [pscustomobject]@{ path = $_; label = $_; kind = 'serial' } } } catch {}",
    "Get-CimInstance Win32_SerialPort -ErrorAction SilentlyContinue | ForEach-Object { $ports += [pscustomobject]@{ path = $_.DeviceID; label = $_.Name; kind = 'serial' } }",
    "Get-PnpDevice -Class Ports -Status OK -ErrorAction SilentlyContinue | ForEach-Object { $name = $_.FriendlyName; if ($name) { $com = [regex]::Match($name,'COM\\d+').Value; $path = if ($com) { $com } else { $name }; $ports += [pscustomobject]@{ path = $path; label = $name; kind = 'usb' } } }",
    "$ports | ConvertTo-Json -Compress"
  ].join("; ");
  try {
    const { stdout } = await execFileAsync(
      "powershell.exe",
      ["-NoProfile", "-NonInteractive", "-Command", script],
      { windowsHide: true, timeout: 8e3 }
    );
    const raw = stdout.trim();
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    const rows = Array.isArray(parsed) ? parsed : [parsed];
    return rows.filter((r) => r?.path).map((r) => ({
      path: String(r.path),
      label: String(r.label || r.path),
      kind: r.kind === "usb" ? "usb" : "serial"
    }));
  } catch {
    return [];
  }
}
var execFileAsync;
var init_list_serials = __esm({
  "server/list-serials.ts"() {
    "use strict";
    execFileAsync = promisify(execFile);
  }
});

// shared/const.ts
function asSer2netDevice(v) {
  if (v === SER2NET_RADIO_ID) return SER2NET_RADIO_ID;
  return SER2NET_ACC_IDS.includes(v) ? v : "";
}
var ONE_YEAR_MS, SERVICE_IDS, UPDATE_IDS, SER2NET_ACC_IDS, SER2NET_RADIO_ID;
var init_const = __esm({
  "shared/const.ts"() {
    "use strict";
    ONE_YEAR_MS = 1e3 * 60 * 60 * 24 * 365;
    SERVICE_IDS = [
      "ser2net",
      "wavelog",
      "wlg",
      "mmdvm",
      "radio",
      "spe",
      "hamplus",
      "palstar",
      "ldg",
      "lp100a",
      "acom",
      "lextel",
      "wifi",
      "bluetooth",
      "dhcp",
      "web"
    ];
    UPDATE_IDS = ["app", "os", "ser2net", "hamlib", "wavelog", "wlg"];
    SER2NET_ACC_IDS = ["spe", "hamplus", "palstar", "ldg", "lp100a", "acom"];
    SER2NET_RADIO_ID = "radio";
  }
});

// shared/equipment/types.ts
var EQUIPMENT_MAKERS;
var init_types = __esm({
  "shared/equipment/types.ts"() {
    "use strict";
    EQUIPMENT_MAKERS = [
      "icom",
      "kenwood",
      "yaesu",
      "flex",
      "tentec",
      "xiegu",
      "hermes",
      "anan"
    ];
  }
});

// shared/equipment/catalog.ts
function getEquipment(id) {
  return EQUIPMENT_CATALOG.find((e) => e.id === id);
}
function listHamlibReady() {
  return EQUIPMENT_CATALOG.filter(
    (e) => e.hamlibModel != null && e.connections.some((c) => c.hamlibReady)
  );
}
var CAP_BASIC, CAP_SDR, EQUIPMENT_CATALOG;
var init_catalog = __esm({
  "shared/equipment/catalog.ts"() {
    "use strict";
    CAP_BASIC = { vfo: true, ptt: true, mode: true, meter: true, split: true };
    CAP_SDR = {
      vfo: true,
      ptt: true,
      mode: true,
      meter: true,
      split: true,
      panadapter: true,
      audioNet: true
    };
    EQUIPMENT_CATALOG = [
      // ── Icom ──────────────────────────────────────────────────────────
      {
        id: "icom-ic-705",
        maker: "icom",
        family: "IC-705",
        label: "Icom IC-705",
        protocol: "civ",
        hamlibModel: 3085,
        hamlibBackend: "ser2net",
        civAddr: "0xA4",
        defaultBaud: 115200,
        connections: [
          {
            kind: "bluetooth-gatt",
            preferred: true,
            auth: "none",
            hamlibReady: false,
            notes: "Web Bluetooth GATT no Chrome; CI-V no navegador. Hamlib usa o caminho USB/ser2net."
          },
          {
            kind: "usb-serial",
            auth: "none",
            defaultBaud: 115200,
            hamlibReady: true,
            notes: "USB CI-V \u2192 ser2net \u2192 rigctld -m 3085."
          },
          {
            kind: "icom-lan-udp",
            auth: "network-user",
            ports: { control: 50001, serial: 50002, audio: 50003 },
            hamlibReady: true,
            notes: "WLAN Network Control (UDP). O gateway autentica e exp\xF5e CI-V em 127.0.0.1:45002 \u2192 rigctld :4532."
          }
        ],
        capabilities: { ...CAP_BASIC, audioNet: true },
        notes: "Endere\xE7o CI-V padr\xE3o 0xA4. Pairing Reception na 1.\xAA vez no GATT."
      },
      {
        id: "icom-ic-7300",
        maker: "icom",
        family: "IC-7300",
        label: "Icom IC-7300",
        protocol: "civ",
        hamlibModel: 3073,
        hamlibBackend: "ser2net",
        civAddr: "0x94",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP_BASIC
      },
      {
        id: "icom-ic-7610",
        maker: "icom",
        family: "IC-7610",
        label: "Icom IC-7610",
        protocol: "civ",
        hamlibModel: 3078,
        hamlibBackend: "ser2net",
        civAddr: "0x76",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true },
          {
            kind: "icom-lan-udp",
            auth: "network-user",
            ports: { control: 50001, serial: 50002, audio: 50003 },
            hamlibReady: true,
            notes: "Ethernet Network Control (UDP). Gateway \u2192 127.0.0.1:45002 \u2192 rigctld."
          }
        ],
        capabilities: { ...CAP_BASIC, panadapter: true, audioNet: true }
      },
      {
        id: "icom-ic-9700",
        maker: "icom",
        family: "IC-9700",
        label: "Icom IC-9700",
        protocol: "civ",
        hamlibModel: 3081,
        hamlibBackend: "ser2net",
        civAddr: "0x88",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true },
          {
            kind: "icom-lan-udp",
            auth: "network-user",
            ports: { control: 50001, serial: 50002, audio: 50003 },
            hamlibReady: true,
            notes: "Ethernet Network Control (UDP). Gateway \u2192 127.0.0.1:45002 \u2192 rigctld."
          }
        ],
        capabilities: { ...CAP_BASIC, panadapter: true, audioNet: true }
      },
      {
        id: "icom-ic-7100",
        maker: "icom",
        family: "IC-7100",
        label: "Icom IC-7100",
        protocol: "civ",
        hamlibModel: 3070,
        hamlibBackend: "ser2net",
        civAddr: "0x18",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP_BASIC
      },
      {
        id: "icom-ic-7300mk2",
        maker: "icom",
        family: "IC-7300MK2",
        label: "Icom IC-7300MK2",
        protocol: "civ",
        hamlibModel: 3073,
        hamlibBackend: "ser2net",
        civAddr: "0x94",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true },
          {
            kind: "icom-lan-udp",
            auth: "network-user",
            ports: { control: 50001, serial: 50002, audio: 50003 },
            hamlibReady: true,
            notes: "Ethernet no MK2. Gateway \u2192 127.0.0.1:45002 \u2192 rigctld (modelo 3073)."
          }
        ],
        capabilities: { ...CAP_BASIC, audioNet: true }
      },
      // ── Kenwood ───────────────────────────────────────────────────────
      {
        id: "kenwood-ts-590sg",
        maker: "kenwood",
        family: "TS-590",
        label: "Kenwood TS-590SG",
        protocol: "cat",
        hamlibModel: 2033,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP_BASIC
      },
      {
        id: "kenwood-ts-890s",
        maker: "kenwood",
        family: "TS-890",
        label: "Kenwood TS-890S",
        protocol: "cat",
        hamlibModel: 2036,
        hamlibBackend: "ser2net",
        defaultBaud: 115200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 115200, hamlibReady: true }
        ],
        capabilities: { ...CAP_BASIC, panadapter: true }
      },
      {
        id: "kenwood-ts-990s",
        maker: "kenwood",
        family: "TS-990",
        label: "Kenwood TS-990S",
        protocol: "cat",
        hamlibModel: 2037,
        hamlibBackend: "ser2net",
        defaultBaud: 115200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 115200, hamlibReady: true }
        ],
        capabilities: CAP_BASIC
      },
      // ── Yaesu ─────────────────────────────────────────────────────────
      {
        id: "yaesu-ft-991a",
        maker: "yaesu",
        family: "FT-991",
        label: "Yaesu FT-991A",
        protocol: "cat",
        hamlibModel: 1035,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP_BASIC
      },
      {
        id: "yaesu-ftdx10",
        maker: "yaesu",
        family: "FTDX10",
        label: "Yaesu FTDX10",
        protocol: "cat",
        hamlibModel: 1042,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: { ...CAP_BASIC, panadapter: true }
      },
      {
        id: "yaesu-ftdx101d",
        maker: "yaesu",
        family: "FTDX101",
        label: "Yaesu FTDX101D",
        protocol: "cat",
        hamlibModel: 1041,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: { ...CAP_BASIC, panadapter: true }
      },
      {
        id: "yaesu-ft-710",
        maker: "yaesu",
        family: "FT-710",
        label: "Yaesu FT-710",
        protocol: "cat",
        hamlibModel: 1043,
        hamlibBackend: "ser2net",
        defaultBaud: 38400,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 38400, hamlibReady: true }
        ],
        capabilities: CAP_BASIC,
        notes: "Confirme o n\xFAmero Hamlib na vers\xE3o instalada (libhamlib-utils)."
      },
      // ── FlexRadio ─────────────────────────────────────────────────────
      {
        id: "flex-6400",
        maker: "flex",
        family: "FLEX-6000",
        label: "FlexRadio FLEX-6400",
        protocol: "smartsdr",
        hamlibModel: null,
        hamlibBackend: "none",
        connections: [
          {
            kind: "flex-tcp",
            preferred: true,
            auth: "none",
            ports: { control: 4992, discover: 4992, stream: 4991 },
            hamlibReady: false,
            notes: "SmartSDR TCP 4992 + discovery UDP 4992 + VITA UDP 4991. Driver nativo futuro."
          },
          {
            kind: "sdr-cat-proxy",
            auth: "none",
            ports: { cat: 13013, hamlibListen: 4532 },
            via: "smartsdr-cat|third-party",
            hamlibReady: true,
            notes: "Se um proxy CAT/Hamlib estiver na LAN, use cat-proxy."
          }
        ],
        capabilities: { ...CAP_SDR },
        notes: "Fam\xEDlia Signature 6000. Hub Hamlib s\xF3 via proxy CAT at\xE9 o driver SmartSDR."
      },
      {
        id: "flex-6600",
        maker: "flex",
        family: "FLEX-6000",
        label: "FlexRadio FLEX-6600",
        protocol: "smartsdr",
        hamlibModel: null,
        hamlibBackend: "none",
        connections: [
          {
            kind: "flex-tcp",
            preferred: true,
            auth: "none",
            ports: { control: 4992, discover: 4992, stream: 4991 },
            hamlibReady: false
          },
          {
            kind: "sdr-cat-proxy",
            auth: "none",
            ports: { cat: 13013 },
            via: "smartsdr-cat|third-party",
            hamlibReady: true
          }
        ],
        capabilities: CAP_SDR
      },
      {
        id: "flex-8600",
        maker: "flex",
        family: "FLEX-8000",
        label: "FlexRadio FLEX-8600",
        protocol: "smartsdr",
        hamlibModel: null,
        hamlibBackend: "none",
        connections: [
          {
            kind: "flex-tcp",
            preferred: true,
            auth: "none",
            ports: { control: 4992, discover: 4992, stream: 4991 },
            hamlibReady: false
          },
          {
            kind: "sdr-cat-proxy",
            auth: "none",
            ports: { cat: 13013 },
            via: "smartsdr-cat|third-party",
            hamlibReady: true
          }
        ],
        capabilities: CAP_SDR
      },
      // ── Ten-Tec ───────────────────────────────────────────────────────
      {
        id: "tentec-omniiii",
        maker: "tentec",
        family: "Omni",
        label: "Ten-Tec Omni VII / Orion (CAT)",
        protocol: "cat",
        hamlibModel: 1601,
        hamlibBackend: "ser2net",
        defaultBaud: 57600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 57600, hamlibReady: true }
        ],
        capabilities: CAP_BASIC,
        notes: "Ajuste o modelo Hamlib conforme a unidade (Omni / Orion / Eagle)."
      },
      {
        id: "tentec-eagle",
        maker: "tentec",
        family: "Eagle",
        label: "Ten-Tec Eagle",
        protocol: "cat",
        hamlibModel: 1608,
        hamlibBackend: "ser2net",
        defaultBaud: 57600,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 57600, hamlibReady: true }
        ],
        capabilities: CAP_BASIC
      },
      // ── Xiegu ─────────────────────────────────────────────────────────
      {
        id: "xiegu-x6100",
        maker: "xiegu",
        family: "X6100",
        label: "Xiegu X6100",
        protocol: "civ",
        hamlibModel: 3073,
        hamlibBackend: "ser2net",
        defaultBaud: 19200,
        connections: [
          {
            kind: "usb-serial",
            preferred: true,
            auth: "none",
            defaultBaud: 19200,
            hamlibReady: true,
            notes: "DEV USB SERIAL-B a 19200. Modelo Hamlib: confirme Xiegu vs G90/CI-V gen\xE9rico."
          },
          {
            kind: "bluetooth-spp",
            auth: "none",
            hamlibReady: false,
            notes: "BT no X6100 \xE9 sobretudo perif\xE9rico; CAT est\xE1vel = USB."
          }
        ],
        capabilities: CAP_BASIC
      },
      {
        id: "xiegu-x6200",
        maker: "xiegu",
        family: "X6200",
        label: "Xiegu X6200",
        protocol: "civ",
        hamlibModel: 3073,
        hamlibBackend: "ser2net",
        defaultBaud: 19200,
        connections: [
          {
            kind: "usb-serial",
            preferred: true,
            auth: "none",
            defaultBaud: 19200,
            hamlibReady: true,
            notes: "DEV USB SERIAL-B CI-V 19200 8N1."
          },
          {
            kind: "bluetooth-spp",
            auth: "none",
            hamlibReady: false
          }
        ],
        capabilities: CAP_BASIC
      },
      {
        id: "xiegu-g90",
        maker: "xiegu",
        family: "G90",
        label: "Xiegu G90",
        protocol: "civ",
        hamlibModel: 3073,
        hamlibBackend: "ser2net",
        defaultBaud: 19200,
        connections: [
          { kind: "usb-serial", preferred: true, auth: "none", defaultBaud: 19200, hamlibReady: true }
        ],
        capabilities: CAP_BASIC
      },
      // ── Hermes Lite 2 ─────────────────────────────────────────────────
      {
        id: "hermes-lite-2",
        maker: "hermes",
        family: "Hermes-Lite",
        label: "Hermes Lite 2",
        protocol: "openhpsdr-p1",
        hamlibModel: 2054,
        hamlibBackend: "cat-proxy",
        connections: [
          {
            kind: "openhpsdr-p1",
            auth: "none",
            ports: { control: 1024, discover: 1025 },
            hamlibReady: false,
            notes: "Metis Protocol 1 UDP. Sem CAT no hardware \u2014 precisa de app SDR."
          },
          {
            kind: "sdr-cat-proxy",
            preferred: true,
            auth: "none",
            ports: { cat: 13013, hamlibListen: 4532 },
            via: "thetis",
            hamlibReady: true,
            notes: "Thetis CAT TCP 13013 \u2192 rigctld -m 2054 -r host:13013."
          },
          {
            kind: "sdr-cat-proxy",
            auth: "none",
            ports: { cat: 19090, hamlibListen: 4532 },
            via: "pihpsdr",
            hamlibReady: true,
            notes: "piHPSDR CAT TCP 19090 \u2192 Hamlib model 2040."
          },
          {
            kind: "tci",
            auth: "none",
            ports: { tci: 40001 },
            via: "pihpsdr|spark",
            hamlibReady: false,
            notes: "TCI do app SDR. Bridge TCI\u2192Hamlib futura; por ora use sdr-cat-proxy."
          }
        ],
        capabilities: CAP_SDR,
        notes: "Hub Hamlib aponta ao CAT do Thetis/piHPSDR, n\xE3o ao UDP 1024 do HL2."
      },
      // ── Anan (Apache Labs) ────────────────────────────────────────────
      {
        id: "anan-10e",
        maker: "anan",
        family: "ANAN-10",
        label: "Apache Labs ANAN-10E",
        protocol: "openhpsdr-p2",
        hamlibModel: 2054,
        hamlibBackend: "cat-proxy",
        connections: [
          {
            kind: "openhpsdr-p2",
            auth: "none",
            ports: { control: 1024 },
            hamlibReady: false,
            notes: "OpenHPSDR Protocol 2. Firmware P2 obrigat\xF3rio."
          },
          {
            kind: "sdr-cat-proxy",
            preferred: true,
            auth: "none",
            ports: { cat: 13013, hamlibListen: 4532 },
            via: "thetis",
            hamlibReady: true
          },
          {
            kind: "sdr-cat-proxy",
            auth: "none",
            ports: { cat: 19090 },
            via: "pihpsdr",
            hamlibReady: true,
            notes: "Hamlib model 2040 para piHPSDR."
          },
          {
            kind: "tci",
            auth: "none",
            ports: { tci: 40001 },
            via: "host-app",
            hamlibReady: false
          }
        ],
        capabilities: { ...CAP_SDR, puresignal: true }
      },
      {
        id: "anan-100d",
        maker: "anan",
        family: "ANAN-100",
        label: "Apache Labs ANAN-100D",
        protocol: "openhpsdr-p2",
        hamlibModel: 2054,
        hamlibBackend: "cat-proxy",
        connections: [
          { kind: "openhpsdr-p2", auth: "none", ports: { control: 1024 }, hamlibReady: false },
          {
            kind: "sdr-cat-proxy",
            preferred: true,
            auth: "none",
            ports: { cat: 13013, hamlibListen: 4532 },
            via: "thetis",
            hamlibReady: true
          },
          {
            kind: "sdr-cat-proxy",
            auth: "none",
            ports: { cat: 19090 },
            via: "pihpsdr",
            hamlibReady: true
          }
        ],
        capabilities: { ...CAP_SDR, puresignal: true }
      },
      {
        id: "anan-7000dle",
        maker: "anan",
        family: "ANAN-7000",
        label: "Apache Labs ANAN-7000DLE",
        protocol: "openhpsdr-p2",
        hamlibModel: 2054,
        hamlibBackend: "cat-proxy",
        connections: [
          { kind: "openhpsdr-p2", auth: "none", ports: { control: 1024 }, hamlibReady: false },
          {
            kind: "sdr-cat-proxy",
            preferred: true,
            auth: "none",
            ports: { cat: 13013, hamlibListen: 4532 },
            via: "thetis",
            hamlibReady: true
          },
          {
            kind: "sdr-cat-proxy",
            auth: "none",
            ports: { cat: 19090 },
            via: "pihpsdr",
            hamlibReady: true
          }
        ],
        capabilities: { ...CAP_SDR, puresignal: true }
      },
      {
        id: "anan-8000dle",
        maker: "anan",
        family: "ANAN-8000",
        label: "Apache Labs ANAN-8000DLE",
        protocol: "openhpsdr-p2",
        hamlibModel: 2054,
        hamlibBackend: "cat-proxy",
        connections: [
          { kind: "openhpsdr-p2", auth: "none", ports: { control: 1024 }, hamlibReady: false },
          {
            kind: "sdr-cat-proxy",
            preferred: true,
            auth: "none",
            ports: { cat: 13013, hamlibListen: 4532 },
            via: "thetis",
            hamlibReady: true
          }
        ],
        capabilities: { ...CAP_SDR, puresignal: true }
      },
      {
        id: "anan-g2",
        maker: "anan",
        family: "ANAN-G2",
        label: "Apache Labs ANAN G2",
        protocol: "openhpsdr-p2",
        hamlibModel: 2054,
        hamlibBackend: "cat-proxy",
        connections: [
          { kind: "openhpsdr-p2", auth: "none", ports: { control: 1024 }, hamlibReady: false },
          {
            kind: "sdr-cat-proxy",
            preferred: true,
            auth: "none",
            ports: { cat: 13013, hamlibListen: 4532 },
            via: "thetis",
            hamlibReady: true
          },
          {
            kind: "sdr-cat-proxy",
            auth: "none",
            ports: { cat: 19090 },
            via: "pihpsdr",
            hamlibReady: true
          },
          {
            kind: "tci",
            auth: "none",
            ports: { tci: 40001 },
            via: "host-app",
            hamlibReady: false
          }
        ],
        capabilities: { ...CAP_SDR, puresignal: true }
      },
      {
        id: "anan-g2e",
        maker: "anan",
        family: "ANAN-G2",
        label: "Apache Labs ANAN G2E",
        protocol: "openhpsdr-p2",
        hamlibModel: 2054,
        hamlibBackend: "cat-proxy",
        connections: [
          { kind: "openhpsdr-p2", auth: "none", ports: { control: 1024 }, hamlibReady: false },
          {
            kind: "sdr-cat-proxy",
            preferred: true,
            auth: "none",
            ports: { cat: 13013, hamlibListen: 4532 },
            via: "thetis",
            hamlibReady: true
          },
          {
            kind: "sdr-cat-proxy",
            auth: "none",
            ports: { cat: 19090 },
            via: "pihpsdr",
            hamlibReady: true
          },
          {
            kind: "tci",
            auth: "none",
            ports: { tci: 40001 },
            via: "host-app",
            hamlibReady: false
          }
        ],
        capabilities: { ...CAP_SDR, puresignal: true }
      }
    ];
  }
});

// shared/equipment/hamlib.ts
function pickConnection(eq, kind) {
  if (kind) {
    const hit = eq.connections.find((c) => c.kind === kind);
    if (hit) return hit;
  }
  return eq.connections.find((c) => c.preferred) || eq.connections.find((c) => c.hamlibReady) || eq.connections[0];
}
function proxyModel(via, fallback) {
  if (!via) return fallback;
  const key = via.split("|")[0]?.trim().toLowerCase() || "";
  if (key && HAMLIB_PROXY_MODELS[key] != null) return HAMLIB_PROXY_MODELS[key];
  return fallback;
}
function resolveBackend(eq, conn) {
  if (conn.kind === "hamlib-net") return "hamlib-net";
  if (conn.kind === "sdr-cat-proxy") return "cat-proxy";
  if (conn.kind === "icom-lan-udp") return "icom-lan";
  if (conn.kind === "usb-serial" && eq.hamlibBackend === "ser2net") return "ser2net";
  if (eq.hamlibBackend !== "none" && conn.hamlibReady) return eq.hamlibBackend;
  return "none";
}
function buildRigDevice(backend, binding, conn) {
  const host2 = (binding.host || "127.0.0.1").trim() || "127.0.0.1";
  if (backend === "ser2net") {
    const port = binding.ser2netPort ?? binding.ports?.control;
    if (!port) {
      return {
        rigDevice: "",
        ready: false,
        deferReason: "Informe ser2netPort (TCP do ser2net, ex. 4001)."
      };
    }
    return { rigDevice: `127.0.0.1:${port}`, ready: true };
  }
  if (backend === "cat-proxy" || backend === "hamlib-net") {
    const cat = binding.ports?.cat ?? binding.ports?.control ?? conn.ports?.cat ?? conn.ports?.control;
    if (!cat) {
      return {
        rigDevice: "",
        ready: false,
        deferReason: "Informe a porta CAT do proxy (Thetis 13013 / piHPSDR 19090)."
      };
    }
    return { rigDevice: `${host2}:${cat}`, ready: true };
  }
  if (backend === "icom-lan") {
    const local = binding.ports?.serial ?? 45002;
    return { rigDevice: `127.0.0.1:${local}`, ready: true };
  }
  return {
    rigDevice: "",
    ready: false,
    deferReason: "Este transporte ainda n\xE3o tem driver no hub Hamlib (GATT, Flex TCP, OpenHPSDR nativo, TCI)."
  };
}
function planHamlib(binding) {
  const eq = getEquipment(binding.equipmentId);
  if (!eq) return null;
  const conn = pickConnection(eq, binding.connectionKind);
  if (!conn) {
    return {
      equipmentId: eq.id,
      label: eq.label,
      maker: eq.maker,
      hamlibModel: 0,
      backend: "none",
      argv: [],
      rigDevice: "",
      listenPort: binding.hamlibListenPort ?? HAMLIB_DEFAULT_LISTEN,
      baud: eq.defaultBaud ?? 0,
      ready: false,
      deferReason: "Nenhuma conex\xE3o no cat\xE1logo para este modelo.",
      connectionKind: binding.connectionKind
    };
  }
  const backend = resolveBackend(eq, conn);
  const model = proxyModel(conn.via, eq.hamlibModel);
  const listenPort = binding.hamlibListenPort ?? binding.ports?.hamlibListen ?? conn.ports?.hamlibListen ?? HAMLIB_DEFAULT_LISTEN;
  const baud = binding.baud ?? conn.defaultBaud ?? eq.defaultBaud ?? 0;
  const civAddr2 = binding.civAddr ?? eq.civAddr;
  const { rigDevice, ready: pathReady, deferReason: pathDefer } = buildRigDevice(backend, binding, conn);
  if (model == null) {
    return {
      equipmentId: eq.id,
      label: eq.label,
      maker: eq.maker,
      hamlibModel: 0,
      backend,
      argv: [],
      rigDevice,
      listenPort,
      baud,
      civAddr: civAddr2,
      ready: false,
      deferReason: "Sem n\xFAmero de modelo Hamlib neste equipamento / via.",
      connectionKind: conn.kind
    };
  }
  if (!pathReady || backend === "none") {
    return {
      equipmentId: eq.id,
      label: eq.label,
      maker: eq.maker,
      hamlibModel: model,
      backend,
      argv: [],
      rigDevice,
      listenPort,
      baud,
      civAddr: civAddr2,
      ready: false,
      deferReason: pathDefer || "Backend Hamlib = none para este transporte.",
      connectionKind: conn.kind
    };
  }
  const argv = ["-m", String(model), "-r", rigDevice, "-t", String(listenPort)];
  if (baud > 0 && backend === "ser2net") argv.push("-s", String(baud));
  if (civAddr2 && eq.protocol === "civ" && (backend === "ser2net" || backend === "icom-lan")) {
    const n = Number.parseInt(civAddr2, 16);
    if (Number.isFinite(n)) argv.push("-c", `0x${n.toString(16).toUpperCase()}`);
  }
  return {
    equipmentId: eq.id,
    label: eq.label,
    maker: eq.maker,
    hamlibModel: model,
    backend,
    argv,
    rigDevice,
    listenPort,
    baud,
    civAddr: civAddr2,
    ready: true,
    connectionKind: conn.kind
  };
}
function formatRigctldCommand(plan, binary = "/usr/bin/rigctld") {
  if (!plan.ready) return `# n\xE3o pronto: ${plan.deferReason || "indefinido"}`;
  return [binary, ...plan.argv].join(" ");
}
var HAMLIB_DEFAULT_LISTEN, HAMLIB_PROXY_MODELS;
var init_hamlib = __esm({
  "shared/equipment/hamlib.ts"() {
    "use strict";
    init_catalog();
    HAMLIB_DEFAULT_LISTEN = 4532;
    HAMLIB_PROXY_MODELS = {
      thetis: 2054,
      pihpsdr: 2040,
      powersdr: 2048,
      "sdr-console": 2056
    };
  }
});

// shared/equipment/labels.ts
var init_labels = __esm({
  "shared/equipment/labels.ts"() {
    "use strict";
  }
});

// shared/equipment/links.ts
var init_links = __esm({
  "shared/equipment/links.ts"() {
    "use strict";
    init_catalog();
    init_labels();
  }
});

// shared/equipment/index.ts
var init_equipment = __esm({
  "shared/equipment/index.ts"() {
    "use strict";
    init_types();
    init_catalog();
    init_hamlib();
    init_labels();
    init_links();
  }
});

// server/icom-lan.ts
import { execFile as execFile2, spawn } from "node:child_process";
import { createServer } from "node:net";
import { promisify as promisify2 } from "node:util";
import { IcomControl } from "icom-wlan-node";
function snap() {
  return {
    ok: phase !== "error",
    phase,
    connected: phase === "ready",
    host,
    controlPort,
    civTcpPort: ICOM_LAN_CIV_TCP_PORT,
    civAddr,
    model: modelLabel,
    radioId,
    deviceName,
    error,
    hamlibPid: rigctld?.pid ?? null
  };
}
function parseCivAddr(raw) {
  const s = String(raw || "0xA4").trim();
  const n = Number.parseInt(s.replace(/^0x/i, ""), 16);
  return Number.isFinite(n) && n >= 0 && n <= 255 ? n : 164;
}
function formatCivAddr(n) {
  return `0x${n.toString(16).toUpperCase().padStart(2, "0")}`;
}
function resolveIcomLanModel(equipmentId, hint) {
  const id = `${equipmentId || ""} ${hint || ""}`.toLowerCase();
  if (id.includes("705")) return "IC-705";
  if (id.includes("905")) return "IC-905";
  if (id.includes("9700")) return "IC-9700";
  if (id.includes("7610")) return "IC-7610";
  if (id.includes("7760")) return "IC-7760";
  if (id.includes("7300mk2") || id.includes("7300-mk2") || id.includes("7300mkii")) return "IC-7300MK2";
  if (id.includes("7300")) return "IC-7300";
  return "auto";
}
function mapUiMode(mode) {
  const key = mode.trim().toUpperCase();
  if (key === "LSB-D") return { mode: "LSB", dataMode: true };
  if (key === "USB-D") return { mode: "USB", dataMode: true };
  if (key === "LSB" || key === "USB" || key === "AM" || key === "CW" || key === "FM" || key === "DV") {
    return { mode: key };
  }
  if (key === "RTTY") return { mode: "RTTY" };
  return { mode: "USB" };
}
function feedTcp(frame) {
  Array.from(tcpClients).forEach((sock2) => {
    if (sock2.destroyed) {
      tcpClients.delete(sock2);
      return;
    }
    try {
      sock2.write(frame);
    } catch {
      try {
        sock2.destroy();
      } catch {
      }
      tcpClients.delete(sock2);
    }
  });
}
function attachCivListeners(control) {
  control.events.on("civFrame", (frame) => {
    feedTcp(Buffer.from(frame));
  });
  control.events.on("connectionLost", () => {
    if (phase === "ready") {
      phase = "error";
      error = "Sess\xE3o Icom LAN perdida";
    }
  });
  control.events.on("error", (err) => {
    if (phase === "connecting" || phase === "ready") {
      error = err?.message || String(err);
    }
  });
}
function ensureTcpBridge() {
  if (tcpServer) return;
  const server = createServer((sock2) => {
    tcpClients.add(sock2);
    let buf = Buffer.alloc(0);
    sock2.on("data", (chunk) => {
      buf = Buffer.concat([buf, chunk]);
      while (true) {
        const start = buf.indexOf(CIV_PRE);
        if (start < 0) {
          buf = Buffer.alloc(0);
          break;
        }
        if (start > 0) buf = buf.subarray(start);
        if (buf.length < 2) break;
        if (buf[1] !== CIV_PRE) {
          buf = buf.subarray(1);
          continue;
        }
        const end = buf.indexOf(CIV_END, 2);
        if (end < 0) break;
        const frame = buf.subarray(0, end + 1);
        buf = buf.subarray(end + 1);
        if (rig && phase === "ready") {
          try {
            rig.sendCiv(Buffer.from(frame));
          } catch {
          }
        }
      }
    });
    sock2.on("close", () => tcpClients.delete(sock2));
    sock2.on("error", () => tcpClients.delete(sock2));
  });
  server.on("error", (err) => {
    error = `TCP CI-V local: ${err.message}`;
  });
  server.listen(ICOM_LAN_CIV_TCP_PORT, "127.0.0.1");
  tcpServer = server;
}
async function stopSystemdHamlib() {
  if (process.platform !== "linux") return;
  try {
    await execFileAsync2("systemctl", ["stop", "rigctld@ic705.service"], {
      timeout: 8e3,
      windowsHide: true
    });
    stoppedSystemdHamlib = true;
  } catch {
    stoppedSystemdHamlib = false;
  }
}
async function startSystemdHamlib() {
  if (process.platform !== "linux" || !stoppedSystemdHamlib) return;
  try {
    await execFileAsync2("systemctl", ["start", "rigctld@ic705.service"], {
      timeout: 8e3,
      windowsHide: true
    });
  } catch {
  }
  stoppedSystemdHamlib = false;
}
function killRigctld() {
  if (!rigctld) return;
  try {
    rigctld.kill("SIGTERM");
  } catch {
  }
  rigctld = null;
}
async function startRigctldChild() {
  killRigctld();
  await stopSystemdHamlib();
  const addr = parseCivAddr(civAddr);
  const args = [
    "-m",
    String(hamlibModel || 3085),
    "-r",
    `127.0.0.1:${ICOM_LAN_CIV_TCP_PORT}`,
    "-t",
    "4532",
    "-c",
    `0x${addr.toString(16).toUpperCase()}`
  ];
  try {
    const child2 = spawn("rigctld", args, {
      stdio: ["ignore", "ignore", "pipe"],
      windowsHide: true
    });
    child2.on("exit", () => {
      if (rigctld === child2) rigctld = null;
    });
    child2.stderr?.on("data", () => {
    });
    rigctld = child2;
  } catch (err) {
    error = `Hamlib (rigctld) n\xE3o iniciado: ${err instanceof Error ? err.message : String(err)}`;
  }
}
function icomLanStatus() {
  return snap();
}
function icomLanLive() {
  return phase === "ready" && Boolean(rig);
}
async function icomLanConnect(opts) {
  const gen = ++connectGen;
  await icomLanDisconnect({ keepRadioMark: true });
  if (gen !== connectGen) return snap();
  radioId = opts.radioId;
  host = String(opts.host || "").trim();
  controlPort = Number(opts.controlPort) > 0 ? Number(opts.controlPort) : 50001;
  civAddr = formatCivAddr(parseCivAddr(opts.civAddr));
  hamlibModel = opts.hamlibModel && opts.hamlibModel > 0 ? opts.hamlibModel : 3085;
  deviceName = String(opts.deviceName || "").trim();
  modelLabel = resolveIcomLanModel(opts.equipmentId, deviceName);
  error = "";
  phase = "connecting";
  if (!host) {
    phase = "error";
    error = "Informe o IP ou hostname do r\xE1dio";
    return snap();
  }
  if (!opts.userName?.trim()) {
    phase = "error";
    error = "Informe o Network User do Icom LAN";
    return snap();
  }
  ensureTcpBridge();
  const control = new IcomControl({
    control: { ip: host, port: controlPort },
    userName: opts.userName.trim().slice(0, 16),
    password: String(opts.password || "").slice(0, 16),
    model: modelLabel === "auto" ? "auto" : modelLabel,
    connectTimeoutMs: 18e3,
    logger: () => {
    }
  });
  attachCivListeners(control);
  let loginHint = "";
  control.events.on("login", (res) => {
    if (!res.ok) {
      loginHint = res.errorCode != null ? `login recusado (c\xF3digo ${res.errorCode}) \u2014 confira Network User/senha e se outro cliente j\xE1 est\xE1 na LAN` : "login recusado \u2014 confira Network User/senha e se outro cliente j\xE1 est\xE1 na LAN";
    }
  });
  rig = control;
  try {
    await control.connect({ timeout: 22e3 });
    if (gen !== connectGen) {
      await control.disconnect().catch(() => void 0);
      return snap();
    }
    phase = "ready";
    error = "";
    try {
      const id = await control.getRadioIdentity({ timeout: 2500 });
      if (id.civAddress != null) civAddr = formatCivAddr(id.civAddress);
      if (id.rigName) deviceName = id.rigName;
      if (id.modelId) modelLabel = id.modelId;
    } catch {
    }
    await startRigctldChild();
    return snap();
  } catch (err) {
    phase = "error";
    const raw = err instanceof Error ? err.message : String(err);
    error = loginHint || raw || "Falha ao autenticar no Icom LAN (UDP 50001). Confira IP, Network User, senha e se o r\xE1dio j\xE1 n\xE3o tem outra sess\xE3o aberta.";
    try {
      await control.disconnect().catch(() => void 0);
    } catch {
    }
    if (rig === control) rig = null;
    return snap();
  }
}
async function withTimeout(p, ms) {
  let timer;
  try {
    return await Promise.race([
      p,
      new Promise((resolve) => {
        timer = setTimeout(() => resolve(void 0), ms);
      })
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}
async function icomLanDisconnect(opts) {
  connectGen += 1;
  phase = "idle";
  error = "";
  killRigctld();
  void startSystemdHamlib();
  const cur = rig;
  rig = null;
  Array.from(tcpClients).forEach((sock2) => {
    try {
      sock2.destroy();
    } catch {
    }
  });
  tcpClients.clear();
  if (cur) {
    try {
      await withTimeout(cur.disconnect().catch(() => void 0), 2500);
    } catch {
    }
  }
  if (!opts?.keepRadioMark) {
    radioId = "";
    host = "";
    deviceName = "";
    modelLabel = "";
  }
  return snap();
}
function civPayload(...body) {
  const to = parseCivAddr(civAddr);
  return Buffer.from([CIV_PRE, CIV_PRE, to, 224, ...body, CIV_END]);
}
async function icomLanCmd(cmd, body = {}) {
  if (!rig || phase !== "ready") {
    return { ok: false, error: "Icom LAN n\xE3o conectado" };
  }
  try {
    switch (cmd) {
      case "freq":
      case "setFreq": {
        const hz = Number(body.hz ?? body.freq);
        if (!Number.isFinite(hz) || hz < 1e3) return { ok: false, error: "frequ\xEAncia inv\xE1lida" };
        await rig.setFrequency(Math.round(hz));
        return { ok: true };
      }
      case "ptt":
      case "setPtt": {
        await rig.setPtt(Boolean(body.on ?? body.ptt));
        return { ok: true };
      }
      case "mode":
      case "setMode": {
        const raw = String(body.mode ?? "USB");
        const mapped = mapUiMode(raw);
        await rig.setMode(mapped.mode, mapped.dataMode ? { dataMode: true } : void 0);
        return { ok: true };
      }
      case "vfo":
      case "setVfo": {
        const which = String(body.vfo ?? body.which ?? "A").toUpperCase() === "B" ? "B" : "A";
        await rig.setVfo(which);
        return { ok: true };
      }
      case "setNr":
      case "nr": {
        await rig.setFunction("NR", Boolean(body.on ?? body.nr));
        return { ok: true };
      }
      case "setNb":
      case "nb": {
        await rig.setFunction("NB", Boolean(body.on ?? body.nb));
        return { ok: true };
      }
      case "setPre":
      case "pre": {
        const v = String(body.pre ?? body.value ?? "OFF").toUpperCase();
        const byte = v === "ON1" || v === "ON2" ? PRE_BYTE[v] : PRE_BYTE.OFF;
        rig.sendCiv(civPayload(22, 2, byte));
        return { ok: true };
      }
      case "setAtt":
      case "att": {
        rig.sendCiv(civPayload(17, Boolean(body.on ?? body.att) ? 32 : 0));
        return { ok: true };
      }
      case "setAgc":
      case "agc": {
        const v = String(body.agc ?? body.value ?? "OFF").toUpperCase();
        const byte = v === "OFF" ? 1 : AGC_BYTE[v] ?? AGC_BYTE.MID;
        rig.sendCiv(civPayload(22, 18, byte));
        return { ok: true };
      }
      case "readFreq": {
        const hz = await rig.readOperatingFrequency();
        return { ok: true, reply: { hz } };
      }
      case "readMode": {
        const mode = await rig.readOperatingMode();
        return { ok: true, reply: { mode } };
      }
      case "civ": {
        const hex = String(body.hex || "").replace(/\s+/g, "");
        if (!/^[0-9a-fA-F]+$/.test(hex) || hex.length < 10) return { ok: false, error: "frame CI-V inv\xE1lido" };
        rig.sendCiv(Buffer.from(hex, "hex"));
        return { ok: true };
      }
      default:
        return { ok: false, error: `comando desconhecido: ${cmd}` };
    }
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : String(err) };
  }
}
var execFileAsync2, ICOM_LAN_CIV_TCP_PORT, CIV_PRE, CIV_END, rig, phase, error, radioId, host, controlPort, civAddr, modelLabel, deviceName, hamlibModel, tcpServer, tcpClients, rigctld, stoppedSystemdHamlib, connectGen, PRE_BYTE, AGC_BYTE;
var init_icom_lan = __esm({
  "server/icom-lan.ts"() {
    "use strict";
    execFileAsync2 = promisify2(execFile2);
    ICOM_LAN_CIV_TCP_PORT = 45002;
    CIV_PRE = 254;
    CIV_END = 253;
    rig = null;
    phase = "idle";
    error = "";
    radioId = "";
    host = "";
    controlPort = 50001;
    civAddr = "0xA4";
    modelLabel = "";
    deviceName = "";
    hamlibModel = 3085;
    tcpServer = null;
    tcpClients = /* @__PURE__ */ new Set();
    rigctld = null;
    stoppedSystemdHamlib = false;
    connectGen = 0;
    PRE_BYTE = { OFF: 0, ON1: 1, ON2: 2 };
    AGC_BYTE = { OFF: 0, FAST: 1, MID: 2, SLOW: 3 };
  }
});

// server/ser2net-store.ts
import { execFile as execFile3 } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from "node:fs";
import { dirname, join as join2 } from "node:path";
import { fileURLToPath } from "node:url";
import { promisify as promisify3 } from "node:util";
import { randomBytes } from "node:crypto";
function dataDir() {
  if (existsSync(OPT_DIR)) return OPT_DIR;
  const local = join2(ROOT, "data", "ser2net");
  mkdirSync(local, { recursive: true });
  return local;
}
function paths() {
  const folder = dataDir();
  return {
    folder,
    jsonPath: join2(folder, "services.json"),
    yamlPath: join2(folder, "ser2net.yaml")
  };
}
function newId() {
  return randomBytes(4).toString("hex");
}
function slug(name, id, used) {
  let base = name.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "");
  if (!/^[a-z]/.test(base)) base = `svc_${base}`;
  if (!base || base === "svc_") base = `svc_${id.replace(/[^a-z0-9]/gi, "").slice(0, 8) || "x"}`;
  base = base.slice(0, 28);
  let a = base;
  let n = 2;
  while (used.has(a)) a = `${base.slice(0, 24)}_${n++}`;
  used.add(a);
  return a;
}
function writeAtomic(file, body) {
  const tmp = `${file}.${process.pid}.tmp`;
  writeFileSync(tmp, body, { encoding: "utf8" });
  renameSync(tmp, file);
}
function renderYaml(bind, services) {
  const used = /* @__PURE__ */ new Set();
  const blocks = services.map((svc) => {
    const a = slug(svc.name, svc.id, used);
    const baud = BAUDS.has(svc.baud) ? svc.baud : 9600;
    return [
      `connection: &${a}`,
      `    accepter: tcp,${bind},${svc.tcpPort}`,
      `    enable: on`,
      `    options:`,
      `      kickolduser: true`,
      `    connector: serialdev,${svc.serial},${baud}n81,local`
    ].join("\n");
  });
  return [
    "%YAML 1.1",
    "---",
    GENERATED,
    "# ser2net 4 \u2014 \xFAnico processo na TTY. R\xE1dio CAT/USB e acess\xF3rios falam TCP (bind:porta); Hamlib usa -r bind:porta.",
    `# Pasta: ${dataDir()}`,
    "",
    ...blocks.length ? blocks : ["# (nenhum servi\xE7o cadastrado)"],
    ""
  ].join("\n");
}
function parseYaml(text) {
  if (!text.includes("Ham Cockpit generated")) return null;
  const out = [];
  const re = /connection:\s*&(\S+)\s+accepter:\s*tcp,([^,]+),(\d+)\s+enable:\s*on[\s\S]*?connector:\s*serialdev,([^,]+),(\d+)n81,local/g;
  let m;
  while (m = re.exec(text)) {
    const tcpPort = Number(m[3]);
    const baud = Number(m[5]);
    if (!tcpPort) continue;
    out.push({
      id: newId(),
      name: m[1].replace(/_/g, " "),
      serial: m[4].trim(),
      tcpPort,
      baud: BAUDS.has(baud) ? baud : 9600,
      device: ""
    });
  }
  return out;
}
function normalizeSvc(raw, seen) {
  if (!raw || typeof raw !== "object") return null;
  const r = raw;
  const name = String(r.name ?? "").trim();
  const serial = String(r.serial ?? "").trim();
  const tcpPort = Number(r.tcpPort);
  const baud = Number(r.baud);
  if (!name || name.length > 48 || /[\r\n]/.test(name)) return null;
  if (!serial || serial.length > 256 || /[\r\n,]/.test(serial)) return null;
  if (!Number.isInteger(tcpPort) || tcpPort < 1024 || tcpPort > 65535) return null;
  if (!BAUDS.has(baud)) return null;
  const key = name.toLowerCase();
  if (seen.name.has(key) || seen.port.has(tcpPort) || seen.serial.has(serial)) return null;
  seen.name.add(key);
  seen.port.add(tcpPort);
  seen.serial.add(serial);
  const id = String(r.id ?? "").replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 16) || newId();
  return { id, name, serial, tcpPort, baud, device: asSer2netDevice(r.device) };
}
function readJson(file) {
  try {
    const j = JSON.parse(readFileSync(file, "utf8"));
    return j && typeof j === "object" ? j : null;
  } catch {
    return null;
  }
}
async function daemonActive() {
  if (process.platform !== "linux") return false;
  try {
    const { stdout } = await execFileAsync3("systemctl", ["is-active", "ser2net.service"], {
      timeout: 5e3,
      windowsHide: true
    });
    return stdout.trim() === "active";
  } catch {
    return false;
  }
}
async function reloadDaemon() {
  if (process.platform !== "linux") return false;
  try {
    if (existsSync(HELPER)) {
      await execFileAsync3("sudo", ["-n", HELPER, "reload-or-restart"], { timeout: 15e3, windowsHide: true });
    } else {
      await execFileAsync3("systemctl", ["reload-or-restart", "ser2net.service"], {
        timeout: 15e3,
        windowsHide: true
      });
    }
    return true;
  } catch {
    return false;
  }
}
async function loadSer2net() {
  const { folder, jsonPath: jsonPath8, yamlPath } = paths();
  let bind = "127.0.0.1";
  let services = [];
  const json = existsSync(jsonPath8) ? readJson(jsonPath8) : null;
  if (json) {
    if (typeof json.bind === "string" && BIND_RE.test(json.bind.trim())) bind = json.bind.trim();
    const seen = { name: /* @__PURE__ */ new Set(), port: /* @__PURE__ */ new Set(), serial: /* @__PURE__ */ new Set() };
    if (Array.isArray(json.services)) {
      for (const row of json.services) {
        const svc = normalizeSvc(row, seen);
        if (svc) services.push(svc);
      }
    }
  } else if (existsSync(yamlPath)) {
    try {
      const parsed = parseYaml(readFileSync(yamlPath, "utf8"));
      if (parsed) services = parsed;
    } catch {
    }
  }
  return {
    ok: true,
    folder,
    bind,
    services,
    yamlPath,
    jsonPath: jsonPath8,
    running: await daemonActive()
  };
}
async function saveSer2net(input) {
  const current = await loadSer2net();
  const bind = typeof input.bind === "string" && BIND_RE.test(input.bind.trim()) ? input.bind.trim() : current.bind;
  if (!Array.isArray(input.services)) {
    return { ...current, ok: false, error: "services" };
  }
  if (input.services.length > 32) {
    return { ...current, ok: false, error: "limit" };
  }
  const seen = { name: /* @__PURE__ */ new Set(), port: /* @__PURE__ */ new Set(), serial: /* @__PURE__ */ new Set() };
  const services = [];
  for (const row of input.services) {
    const svc = normalizeSvc(row, seen);
    if (!svc) return { ...current, ok: false, error: "invalid" };
    services.push(svc);
  }
  const taken = /* @__PURE__ */ new Set();
  for (const svc of services) {
    if (!svc.device) continue;
    if (taken.has(svc.device)) svc.device = "";
    else taken.add(svc.device);
  }
  const { folder, jsonPath: jsonPath8, yamlPath } = paths();
  mkdirSync(folder, { recursive: true });
  const payload = JSON.stringify({ bind, folder, services }, null, 2);
  writeAtomic(jsonPath8, `${payload}
`);
  writeAtomic(yamlPath, renderYaml(bind, services));
  await reloadDaemon();
  return {
    ok: true,
    folder,
    bind,
    services,
    yamlPath,
    jsonPath: jsonPath8,
    running: await daemonActive()
  };
}
var execFileAsync3, ROOT, OPT_DIR, HELPER, GENERATED, BAUDS, BIND_RE;
var init_ser2net_store = __esm({
  "server/ser2net-store.ts"() {
    "use strict";
    init_const();
    execFileAsync3 = promisify3(execFile3);
    ROOT = join2(dirname(fileURLToPath(import.meta.url)), "..");
    OPT_DIR = "/opt/ser2net";
    HELPER = "/opt/ham-cockpit/bin/ser2net-ctl";
    GENERATED = "# Ham Cockpit generated \u2014 do not edit";
    BAUDS = /* @__PURE__ */ new Set([1200, 9600, 19200, 38400, 57600, 115200]);
    BIND_RE = /^(127\.0\.0\.1|0\.0\.0\.0|localhost|(\d{1,3}\.){3}\d{1,3})$/;
  }
});

// server/radios.ts
var radios_exports = {};
__export(radios_exports, {
  radiosConnect: () => radiosConnect,
  radiosDisconnect: () => radiosDisconnect,
  radiosMarkBle: () => radiosMarkBle,
  radiosRemove: () => radiosRemove,
  radiosResumeIcomLan: () => radiosResumeIcomLan,
  radiosSave: () => radiosSave,
  radiosSetPrimary: () => radiosSetPrimary,
  radiosStatus: () => radiosStatus,
  radiosUpsert: () => radiosUpsert
});
import { execFile as execFile4 } from "node:child_process";
import { chmodSync, existsSync as existsSync2, mkdirSync as mkdirSync2, readFileSync as readFileSync2, renameSync as renameSync2, writeFileSync as writeFileSync2 } from "node:fs";
import { dirname as dirname2, join as join3 } from "node:path";
import { fileURLToPath as fileURLToPath2 } from "node:url";
import { promisify as promisify4 } from "node:util";
import { randomBytes as randomBytes2 } from "node:crypto";
function dataDir2() {
  if (existsSync2("/opt/ham-cockpit")) {
    if (existsSync2(LEGACY_DIR) && !existsSync2(OPT_DIR2)) return LEGACY_DIR;
    mkdirSync2(OPT_DIR2, { recursive: true });
    return OPT_DIR2;
  }
  const local = join3(ROOT2, "data", "radios");
  mkdirSync2(local, { recursive: true });
  return local;
}
function jsonPath() {
  return join3(dataDir2(), "radios.json");
}
function newId2() {
  return randomBytes2(4).toString("hex");
}
function writeAtomic2(file, body) {
  const tmp = `${file}.${process.pid}.tmp`;
  writeFileSync2(tmp, body, { encoding: "utf8" });
  renameSync2(tmp, file);
  try {
    chmodSync(file, 384);
  } catch {
  }
}
function publicRadio(r) {
  const { netPassword, ...rest } = r;
  if (r.link !== "network") return rest;
  return {
    ...rest,
    ...netPassword ? { hasNetPassword: true } : {}
  };
}
function publicList(list) {
  return list.map(publicRadio);
}
function isIcomLan(row) {
  if (row.link !== "network" || row.maker !== "icom") return false;
  if (row.netProfile?.startsWith("icom-lan-udp")) return true;
  return !row.netProfile || row.netProfile.includes("icom");
}
function hamlibModelFor(row) {
  if (row.equipmentId) {
    const eq = getEquipment(row.equipmentId);
    if (eq?.hamlibModel) return eq.hamlibModel;
  }
  const model = resolveIcomLanModel(row.equipmentId, `${row.name} ${row.deviceName}`);
  if (model === "IC-705") return 3085;
  if (model === "IC-9700") return 3081;
  if (model === "IC-7610") return 3078;
  if (model === "IC-7300" || model === "IC-7300MK2") return 3073;
  return 3085;
}
function asMaker(v) {
  return MAKERS.includes(v) ? v : "icom";
}
function asLink(v) {
  if (v === "bluetooth") return "bluetooth";
  if (v === "network") return "network";
  return "usb";
}
function asProto(maker, v) {
  if (maker === "icom" || maker === "xiegu") return v === "cat" ? "cat" : "civ";
  return "cat";
}
function asBaud(v, fallback) {
  const n = Number(v);
  if (n === 0) return 0;
  return BAUDS2.has(n) ? n : fallback;
}
function defaultBaud(maker, link) {
  if (link === "bluetooth" && maker !== "icom") return 9600;
  if (maker === "kenwood" || maker === "yaesu") return 38400;
  if (maker === "tentec") return 57600;
  if (maker === "xiegu") return 19200;
  return 115200;
}
function defaultName(maker, deviceName2) {
  const brand = {
    icom: "Icom",
    kenwood: "Kenwood",
    yaesu: "Yaesu",
    flex: "Flex",
    tentec: "Ten-Tec",
    xiegu: "Xiegu",
    hermes: "Hermes Lite",
    anan: "Anan"
  };
  return deviceName2.trim() || brand[maker];
}
function sanitize(raw, fallback) {
  const maker = asMaker(raw.maker ?? fallback?.maker);
  const link = asLink(raw.link ?? fallback?.link);
  const proto = asProto(maker, raw.proto ?? fallback?.proto);
  const baud = link === "network" ? 0 : asBaud(raw.baud ?? fallback?.baud, defaultBaud(maker, link));
  const device = String(raw.device ?? fallback?.device ?? "").trim();
  const deviceName2 = String(raw.deviceName ?? fallback?.deviceName ?? "").trim();
  const host2 = String(raw.host ?? fallback?.host ?? "").trim();
  const netProfile = String(raw.netProfile ?? fallback?.netProfile ?? "").trim();
  const netUser = String(raw.netUser ?? fallback?.netUser ?? "").trim();
  const incomingPass = raw.netPassword;
  const netPassword = incomingPass === void 0 || incomingPass === null ? String(fallback?.netPassword ?? "") : String(incomingPass) === "" && fallback?.netPassword ? String(fallback.netPassword) : String(incomingPass);
  const port = link === "network" ? String(raw.port ?? fallback?.port ?? "").trim() : String(raw.port ?? fallback?.port ?? device).trim() || device;
  const civAddr2 = String(raw.civAddr ?? fallback?.civAddr ?? "0xA4").trim() || "0xA4";
  const endpoint = link === "network" && host2 ? `${host2}${port ? `:${port}` : ""}` : "";
  const name = String(raw.name ?? fallback?.name ?? "").trim() || defaultName(maker, deviceName2 || endpoint || port || device);
  const hsUuid = String(raw.hsUuid ?? fallback?.hsUuid ?? "").trim().toUpperCase();
  const equipmentId = String(raw.equipmentId ?? fallback?.equipmentId ?? "").trim();
  return {
    id: String(raw.id ?? fallback?.id ?? newId2()),
    name,
    maker,
    link,
    device: link === "network" ? host2 || device : device,
    deviceName: link === "network" ? deviceName2 || endpoint || host2 : deviceName2,
    proto,
    port,
    baud,
    civAddr: /^0x[0-9A-Fa-f]{2}$/.test(civAddr2) ? civAddr2.toUpperCase().replace("0X", "0x") : "0xA4",
    hsUuid: /^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}$/.test(hsUuid) ? hsUuid : "",
    paired: Boolean(raw.paired ?? fallback?.paired),
    connected: Boolean(raw.connected ?? fallback?.connected),
    primary: Boolean(raw.primary ?? fallback?.primary),
    error: String(raw.error ?? fallback?.error ?? ""),
    ...equipmentId ? { equipmentId } : {},
    ...link === "network" ? {
      host: host2,
      ...netProfile ? { netProfile } : {},
      ...netUser ? { netUser } : {},
      ...netPassword ? { netPassword } : {}
    } : {}
  };
}
function normalizePrimary() {
  const hits = radios.filter((r) => r.primary);
  if (hits.length === 1) return;
  if (hits.length === 0 && radios.length === 1) {
    radios[0] = { ...radios[0], primary: true };
    return;
  }
  if (hits.length > 1) {
    const keep = hits[hits.length - 1].id;
    radios = radios.map((r) => ({ ...r, primary: r.id === keep }));
  }
}
function persist() {
  writeAtomic2(jsonPath(), `${JSON.stringify({ radios }, null, 2)}
`);
}
function load() {
  try {
    const raw = JSON.parse(readFileSync2(jsonPath(), "utf8"));
    if (Array.isArray(raw.radios)) radios = raw.radios.map((r) => sanitize(r));
    const before = radios.map((r) => `${r.id}:${r.primary}:${r.connected}`).join();
    normalizePrimary();
    radios = radios.map(
      (r) => r.link === "bluetooth" && r.proto === "civ" && r.connected ? { ...r, connected: false } : r
    );
    const after = radios.map((r) => `${r.id}:${r.primary}:${r.connected}`).join();
    if (before !== after) persist();
  } catch {
    radios = [];
  }
}
async function listBluetooth() {
  const out = [];
  if (process.platform === "win32") {
    try {
      const { stdout } = await execFileAsync4(
        "reg",
        ["query", "HKLM\\SYSTEM\\CurrentControlSet\\Services\\BTHPORT\\Parameters\\Devices"],
        { windowsHide: true, timeout: 8e3 }
      );
      const keys = stdout.split(/\r?\n/).map((l) => l.trim()).filter((l) => /\\Devices\\[0-9a-fA-F]{12}$/.test(l));
      for (const key of keys) {
        const hex = (key.split("\\").pop() || "").toUpperCase();
        if (!hex || hex === "000000000000") continue;
        const addr = hex.match(/.{2}/g)?.join(":") ?? hex;
        let name = "Bluetooth";
        try {
          const { stdout: det } = await execFileAsync4("reg", ["query", key, "/v", "Name"], { windowsHide: true, timeout: 4e3 });
          const m = det.match(/Name\s+REG_BINARY\s+([0-9A-Fa-f ]+)/i);
          if (m) {
            const raw = Buffer.from(m[1].replace(/\s+/g, ""), "hex");
            name = raw.toString("ascii").replace(/\0/g, "").trim() || raw.toString("utf16le").replace(/\0/g, "").trim() || name;
          }
        } catch {
        }
        out.push({ id: addr, path: addr, label: `${name} (${addr})`, kind: "bluetooth" });
      }
    } catch {
    }
    try {
      const script = [
        "Get-PnpDevice -Class Ports -Status OK -ErrorAction SilentlyContinue | ForEach-Object {",
        "  $com = [regex]::Match($_.FriendlyName,'COM\\d+').Value",
        "  if (-not $com -or $_.InstanceId -notmatch 'BTHENUM') { return }",
        "  $m = [regex]::Match($_.InstanceId, '([0-9A-Fa-f]{12})_')",
        "  $hex = if ($m.Success) { $m.Groups[1].Value.ToUpper() } else { '' }",
        "  if ($hex -eq '000000000000' -or $hex -eq '') { return }",
        '  "$com`t$hex`t$($_.FriendlyName)"',
        "}"
      ].join(" ");
      const { stdout } = await execFileAsync4("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", script], {
        windowsHide: true,
        timeout: 8e3
      });
      for (const line of stdout.split(/\r?\n/).map((l) => l.trim()).filter(Boolean)) {
        const [com, hex, friendly] = line.split("	");
        if (!com) continue;
        const addr = (hex || "").match(/.{2}/g)?.join(":") ?? hex ?? "";
        const label = `${com} \xB7 ${friendly || addr}`;
        if (!out.some((d) => d.path === com)) out.push({ id: com, path: com, label, kind: "bluetooth" });
        const byMac = out.find((d) => d.path === addr);
        if (byMac && !byMac.label.includes(com)) byMac.label = `${byMac.label} \xB7 ${com}`;
      }
    } catch {
    }
  }
  if (process.platform === "linux") {
    try {
      const { stdout } = await execFileAsync4("bluetoothctl", ["devices"], { timeout: 8e3, windowsHide: true });
      for (const line of stdout.split(/\r?\n/)) {
        const m = line.match(/^Device\s+([0-9A-Fa-f:]{11,17})\s+(.*)$/);
        if (!m) continue;
        const addr = m[1].toUpperCase();
        const name = m[2].trim() || addr;
        out.push({ id: addr, path: addr, label: `${name} (${addr})`, kind: "bluetooth" });
      }
    } catch {
    }
  }
  const uniq = /* @__PURE__ */ new Map();
  for (const d of out) uniq.set(d.path, d);
  return Array.from(uniq.values()).sort((a, b) => a.label.localeCompare(b.label));
}
async function listUsb() {
  const list = await listSerialDevices();
  return list.map((d) => ({
    id: d.path,
    path: d.path,
    label: d.label || d.path,
    kind: "usb"
  }));
}
function lanOverlay(list) {
  const lan = icomLanStatus();
  return list.map((r) => {
    if (!isIcomLan(r)) return r;
    if (lan.connected && lan.radioId === r.id) {
      return { ...r, connected: true, error: "", ...lan.civAddr ? { civAddr: lan.civAddr } : {} };
    }
    if (lan.connected && lan.radioId && lan.radioId !== r.id) {
      return { ...r, connected: false };
    }
    if (!lan.connected && r.connected && !icomLanLive()) {
      return { ...r, connected: false };
    }
    return r;
  });
}
function radiosSnapshotFast() {
  return { ok: true, folder: dataDir2(), radios: publicList(lanOverlay(radios)) };
}
async function radiosStatus() {
  let usb = [];
  let bluetooth = [];
  try {
    usb = await listUsb();
  } catch {
    usb = [];
  }
  try {
    bluetooth = await listBluetooth();
  } catch {
    bluetooth = [];
  }
  return { ok: true, folder: dataDir2(), radios: publicList(lanOverlay(radios)), usb, bluetooth };
}
async function radiosSave(body) {
  if (Array.isArray(body.radios)) {
    radios = body.radios.map((r) => sanitize(r));
    normalizePrimary();
    persist();
  }
  return radiosStatus();
}
async function radiosUpsert(raw) {
  const next = sanitize(raw, radios.find((r) => r.id === raw.id));
  if (next.primary) radios = radios.map((r) => ({ ...r, primary: r.id === next.id }));
  else if (!radios.some((r) => r.primary && r.id !== next.id)) next.primary = radios.length === 0 || radios.every((r) => r.id === next.id);
  const idx = radios.findIndex((r) => r.id === next.id);
  if (idx >= 0) radios[idx] = { ...radios[idx], ...next, id: radios[idx].id };
  else radios.push(next);
  normalizePrimary();
  persist();
  return radiosStatus();
}
async function radiosSetPrimary(id) {
  if (!id || !radios.some((r) => r.id === id)) return radiosStatus();
  radios = radios.map((r) => ({ ...r, primary: r.id === id }));
  persist();
  return radiosStatus();
}
function findRadio(id) {
  return radios.find((r) => r.id === id);
}
async function radiosRemove(id) {
  const row = findRadio(id);
  radios = radios.map((r) => r.id === id ? { ...r, connected: false } : r).filter((r) => r.id !== id);
  normalizePrimary();
  persist();
  if (row && (isIcomLan(row) || icomLanStatus().radioId === id)) {
    try {
      await icomLanDisconnect();
    } catch {
    }
  }
  return radiosSnapshotFast();
}
async function radiosConnect(raw) {
  const next = sanitize(raw, radios.find((r) => r.id === raw.id));
  next.error = "";
  const ble = next.link === "bluetooth" && next.maker === "icom" && next.proto === "civ";
  if (next.link === "network") {
    if (!next.host) {
      next.connected = false;
      next.error = "Informe o IP ou hostname do r\xE1dio / proxy CAT";
    } else if (!next.port || !/^\d{1,5}$/.test(next.port) || Number(next.port) < 1 || Number(next.port) > 65535) {
      next.connected = false;
      next.error = "Informe a porta de rede (1\u201365535)";
    } else if (isIcomLan(next) && !next.netUser) {
      next.connected = false;
      next.error = "Informe o Network User do Icom LAN";
    } else if (isIcomLan(next)) {
      next.device = next.host;
      next.deviceName = next.deviceName || `${next.host}:${next.port}`;
      const lan = await icomLanConnect({
        radioId: next.id,
        host: next.host,
        controlPort: Number(next.port) || 50001,
        userName: next.netUser || "",
        password: next.netPassword || "",
        civAddr: next.civAddr,
        hamlibModel: hamlibModelFor(next),
        equipmentId: next.equipmentId,
        deviceName: next.deviceName || next.name
      });
      if (lan.connected) {
        next.connected = true;
        next.error = "";
        if (lan.civAddr) next.civAddr = lan.civAddr;
        if (lan.deviceName) next.deviceName = lan.deviceName;
        radios = radios.map((r) => r.id === next.id ? r : { ...r, connected: false });
      } else {
        next.connected = false;
        next.error = lan.error || "Falha ao autenticar no Icom LAN (UDP 50001)";
      }
    } else {
      next.device = next.host;
      next.deviceName = next.deviceName || `${next.host}:${next.port}`;
      next.connected = true;
      next.error = "";
    }
    const idx2 = radios.findIndex((r) => r.id === next.id);
    if (idx2 >= 0) radios[idx2] = next;
    else radios.push(next);
    persist();
    const snap5 = await radiosStatus();
    if (next.error) {
      snap5.ok = false;
      snap5.error = next.error;
    }
    return snap5;
  }
  if (!next.device && !next.port && !ble) {
    next.connected = false;
    next.error = next.link === "usb" ? "Selecione uma conex\xE3o ser2net" : "Selecione o dispositivo Bluetooth";
    const idx2 = radios.findIndex((r) => r.id === next.id);
    if (idx2 >= 0) radios[idx2] = next;
    else radios.push(next);
    persist();
    const snap5 = await radiosStatus();
    snap5.ok = false;
    snap5.error = next.error;
    return snap5;
  }
  if (ble) {
    next.connected = false;
    const idx2 = radios.findIndex((r) => r.id === next.id);
    if (idx2 >= 0) radios[idx2] = next;
    else radios.push(next);
    persist();
    const snap5 = await radiosStatus();
    snap5.needBle = true;
    snap5.bleAddr = next.civAddr;
    return snap5;
  }
  if (next.link === "usb") {
    const cfg = await loadSer2net();
    const svc = cfg.services.find((x) => x.id === next.device) || cfg.services.find((x) => `${cfg.bind}:${x.tcpPort}` === next.port) || cfg.services.find((x) => x.device === SER2NET_RADIO_ID);
    const taken = Boolean(svc?.device && svc.device !== SER2NET_RADIO_ID);
    if (!svc || taken) {
      next.error = "Selecione uma conex\xE3o ser2net (IP/porta/serial) j\xE1 cadastrada";
      next.connected = false;
    } else {
      next.device = svc.id;
      next.deviceName = svc.name || next.deviceName;
      next.port = `${cfg.bind}:${svc.tcpPort}`;
      next.baud = svc.baud;
      next.connected = true;
      radios = radios.map((r) => r.id === next.id ? r : { ...r, connected: r.link === "usb" ? false : r.connected });
      if (svc.device !== SER2NET_RADIO_ID) {
        await saveSer2net({
          bind: cfg.bind,
          folder: cfg.folder,
          services: cfg.services.map((x) => ({
            ...x,
            device: x.id === svc.id ? SER2NET_RADIO_ID : x.device === SER2NET_RADIO_ID ? "" : x.device
          }))
        });
      }
    }
  } else {
    next.connected = true;
  }
  const idx = radios.findIndex((r) => r.id === next.id);
  if (idx >= 0) radios[idx] = next;
  else radios.push(next);
  persist();
  const snap4 = await radiosStatus();
  if (next.error) {
    snap4.ok = false;
    snap4.error = next.error;
  }
  return snap4;
}
async function radiosDisconnect(id) {
  const row = findRadio(id);
  if (!row) return radiosSnapshotFast();
  row.connected = false;
  row.error = "";
  persist();
  if (isIcomLan(row) || icomLanStatus().radioId === id) {
    try {
      await icomLanDisconnect();
    } catch {
    }
  }
  if (row.link === "usb") {
    try {
      const cfg = await loadSer2net();
      const hit = cfg.services.find((x) => x.id === row.device || x.device === SER2NET_RADIO_ID);
      if (hit?.device === SER2NET_RADIO_ID) {
        await saveSer2net({
          bind: cfg.bind,
          folder: cfg.folder,
          services: cfg.services.map((x) => ({
            ...x,
            device: x.device === SER2NET_RADIO_ID ? "" : x.device
          }))
        });
      }
    } catch {
    }
  }
  return radiosSnapshotFast();
}
async function radiosResumeIcomLan() {
  const row = radios.find((r) => r.primary && isIcomLan(r)) || radios.find((r) => r.connected && isIcomLan(r));
  if (!row?.host || !row.netUser) return;
  const lan = await icomLanConnect({
    radioId: row.id,
    host: row.host,
    controlPort: Number(row.port) || 50001,
    userName: row.netUser,
    password: row.netPassword || "",
    civAddr: row.civAddr,
    hamlibModel: hamlibModelFor(row),
    equipmentId: row.equipmentId,
    deviceName: row.deviceName || row.name
  });
  const idx = radios.findIndex((r) => r.id === row.id);
  if (idx < 0) return;
  if (lan.connected) {
    radios[idx] = {
      ...radios[idx],
      connected: true,
      error: "",
      ...lan.civAddr ? { civAddr: lan.civAddr } : {},
      ...lan.deviceName ? { deviceName: lan.deviceName } : {}
    };
  } else {
    radios[idx] = { ...radios[idx], connected: false, error: lan.error || "Icom LAN offline no boot" };
  }
  persist();
}
async function radiosMarkBle(id, connected, name, error3) {
  const row = findRadio(id);
  if (row) {
    row.connected = connected;
    if (name) row.deviceName = name;
    row.error = error3 || "";
    persist();
  }
  return radiosStatus();
}
var execFileAsync4, ROOT2, OPT_DIR2, LEGACY_DIR, BAUDS2, MAKERS, radios;
var init_radios = __esm({
  "server/radios.ts"() {
    "use strict";
    init_const();
    init_equipment();
    init_icom_lan();
    init_list_serials();
    init_ser2net_store();
    execFileAsync4 = promisify4(execFile4);
    ROOT2 = join3(dirname2(fileURLToPath2(import.meta.url)), "..");
    OPT_DIR2 = "/opt/ham-cockpit/radios";
    LEGACY_DIR = "/opt/radios";
    BAUDS2 = /* @__PURE__ */ new Set([1200, 4800, 9600, 19200, 38400, 57600, 115200, 230400]);
    MAKERS = [...EQUIPMENT_MAKERS];
    radios = [];
    load();
  }
});

// server/wavelog-status.ts
var wavelog_status_exports = {};
__export(wavelog_status_exports, {
  probeWavelog: () => probeWavelog,
  wavelogDatabase: () => wavelogDatabase,
  wavelogDbUpdate: () => wavelogDbUpdate,
  wavelogDown: () => wavelogDown,
  wavelogStatus: () => wavelogStatus,
  wavelogUp: () => wavelogUp
});
import { execFile as execFile5 } from "node:child_process";
import { access, copyFile, readFile } from "node:fs/promises";
import { request as httpRequest } from "node:http";
import { dirname as dirname3, join as join4 } from "node:path";
import { fileURLToPath as fileURLToPath3 } from "node:url";
import { promisify as promisify5 } from "node:util";
async function composeDir() {
  if (process.env.WAVELOG_DIR) return process.env.WAVELOG_DIR;
  const pi = "/opt/wavelog";
  if (await fileExists(join4(pi, "docker-compose.yml"))) return pi;
  return join4(ROOT3, "deploy", "wavelog");
}
async function stationSvc(action, id) {
  if (!await fileExists(STATION_SVC)) return "";
  try {
    const { stdout } = await execFileAsync5("sudo", ["-n", STATION_SVC, action, id], {
      timeout: 18e4,
      windowsHide: true
    });
    return String(stdout || "").trim();
  } catch {
    return "";
  }
}
async function systemctlWavelog(action) {
  const viaHelper = await stationSvc(action, "wavelog");
  if (viaHelper === "started" || viaHelper === "stopped" || viaHelper === "enabled") return true;
  try {
    await execFileAsync5("systemctl", [action, "wavelog.service"], {
      timeout: 12e4,
      windowsHide: true
    });
    return true;
  } catch {
    return false;
  }
}
function probeWavelog(port = 8086, host2 = "127.0.0.1") {
  const url = `http://${host2}:${port}/`;
  return new Promise((resolve) => {
    const req = httpRequest(url, { method: "GET", timeout: 2500 }, (res) => {
      res.resume();
      const httpStatus = res.statusCode ?? 0;
      resolve({ ok: httpStatus > 0 && httpStatus < 500, httpStatus, url });
    });
    req.on("timeout", () => {
      req.destroy();
      resolve({ ok: false, error: "timeout", url });
    });
    req.on("error", (err) => resolve({ ok: false, error: err.message, url }));
    req.end();
  });
}
async function dockerBinaryPresent() {
  for (const p of ["/usr/bin/docker", "/bin/docker"]) {
    if (await fileExists(p)) return true;
  }
  try {
    await execFileAsync5("docker", ["--version"], { timeout: 3e3, windowsHide: true });
    return true;
  } catch {
    return false;
  }
}
async function dockerDaemonUp() {
  try {
    await execFileAsync5("docker", ["info", "--format", "{{.ServerVersion}}"], {
      timeout: 5e3,
      windowsHide: true
    });
    return true;
  } catch {
    const active = await stationSvc("is-active", "docker");
    return active === "active";
  }
}
async function fileExists(path2) {
  try {
    await access(path2);
    return true;
  } catch {
    return false;
  }
}
async function wavelogStatus(port = 8086) {
  const compose = await composeDir();
  const url = `http://127.0.0.1:${port}/`;
  const hasBin = await dockerBinaryPresent();
  const daemon = hasBin ? await dockerDaemonUp() : false;
  const docker = hasBin && daemon;
  const hasCompose = await fileExists(join4(compose, "docker-compose.yml"));
  const probe2 = await probeWavelog(port);
  if (probe2.ok) {
    return { ok: true, url, port, docker: hasBin, compose, reason: "ok", httpStatus: probe2.httpStatus };
  }
  if (!hasCompose) {
    return { ok: false, url, port, docker: hasBin, compose, reason: "no-compose", error: probe2.error };
  }
  if (!hasBin) {
    return { ok: false, url, port, docker: false, compose, reason: "no-docker", error: probe2.error };
  }
  if (!daemon) {
    return {
      ok: false,
      url,
      port,
      docker: false,
      compose,
      reason: "docker-down",
      error: probe2.error
    };
  }
  return { ok: false, url, port, docker: true, compose, reason: "down", error: probe2.error };
}
async function ensureEnv(dir) {
  const env = join4(dir, ".env");
  if (await fileExists(env)) return;
  const example = join4(dir, ".env.example");
  if (await fileExists(example)) await copyFile(example, env);
}
async function wavelogUp(port = 8086) {
  const status = await wavelogStatus(port);
  if (status.ok) return status;
  if (status.reason === "no-docker") return status;
  if (status.reason === "no-compose") return status;
  try {
    await ensureEnv(status.compose);
    const viaSystemd = await systemctlWavelog("enable") && await systemctlWavelog("start");
    if (!viaSystemd) {
      await stationSvc("start", "docker");
      await execFileAsync5("docker", ["compose", "up", "-d"], {
        cwd: status.compose,
        timeout: 12e4,
        windowsHide: true
      });
    }
  } catch (err) {
    return { ...status, reason: "error", error: err instanceof Error ? err.message : String(err) };
  }
  const after = await wavelogStatus(port);
  return after.ok ? after : { ...after, reason: after.reason === "ok" ? "down" : after.reason };
}
async function wavelogDown(port = 8086) {
  const stopped = await systemctlWavelog("stop");
  if (!stopped && await dockerDaemonUp()) {
    try {
      await execFileAsync5("docker", ["compose", "stop"], {
        cwd: await composeDir(),
        timeout: 6e4,
        windowsHide: true
      });
    } catch {
    }
  }
  return wavelogStatus(port);
}
function envValueFromText(text, key) {
  const line = text.split(/\r?\n/).find((l) => l.startsWith(`${key}=`));
  return line ? line.slice(key.length + 1).trim().replace(/^["']|["']$/g, "") : "";
}
function scrubSecret(msg, secret) {
  if (!secret) return msg;
  return msg.split(secret).join("***");
}
async function readEnvFile(file) {
  try {
    return await readFile(file, "utf8");
  } catch (err) {
    const code = err && typeof err === "object" && "code" in err ? String(err.code) : "";
    if (code !== "EACCES" && code !== "EPERM") return "";
  }
  try {
    const { stdout } = await execFileAsync5("sudo", ["-n", STATION_BACKUP, "cat", file], {
      timeout: 8e3,
      windowsHide: true
    });
    return String(stdout || "");
  } catch {
    return "";
  }
}
async function readDbPassword(dir) {
  const envFile = join4(dir, ".env");
  if (!await fileExists(envFile)) return { password: "", envFile, source: "missing" };
  const text = await readEnvFile(envFile);
  const password = envValueFromText(text, "WAVELOG_DB_PASSWORD");
  return { password, envFile, source: password ? "env" : "missing" };
}
async function dockerInspectDb() {
  try {
    const { stdout } = await execFileAsync5(
      "docker",
      [
        "inspect",
        "--format",
        "{{.State.Running}}|{{if .State.Health}}{{.State.Health.Status}}{{end}}|{{.Config.Image}}",
        DB_CONTAINER
      ],
      { timeout: 5e3, windowsHide: true }
    );
    const [runningS, healthS, imageS] = stdout.trim().split("|");
    const running = runningS === "true";
    const health = healthS || (running ? "running" : "exited");
    return { running, health, image: imageS || "" };
  } catch {
    return { running: false, health: "missing", image: "" };
  }
}
function shSingleQuote(s) {
  return `'${s.replace(/'/g, `'\\''`)}'`;
}
async function mariadbQueryUser(sql) {
  const inner = `mariadb -uwavelog -p"$MARIADB_PASSWORD" -N -B -e ${shSingleQuote(sql)}`;
  const { stdout } = await execFileAsync5("docker", ["exec", DB_CONTAINER, "sh", "-c", inner], {
    timeout: 12e3,
    windowsHide: true
  });
  return stdout.trim();
}
async function mariadbQueryRoot(sql) {
  const { stdout } = await execFileAsync5(
    "docker",
    ["exec", DB_CONTAINER, "mariadb", "-uroot", "--protocol=tcp", "-h127.0.0.1", "--skip-password", "-N", "-B", "-e", sql],
    { timeout: 12e3, windowsHide: true }
  );
  return stdout.trim();
}
async function mariadbVersionFallback() {
  try {
    const { stdout } = await execFileAsync5("docker", ["exec", DB_CONTAINER, "mariadbd", "--version"], {
      timeout: 8e3,
      windowsHide: true
    });
    const m = stdout.match(/Ver\s+(\S+)/);
    return m?.[1] || stdout.trim();
  } catch {
    return "";
  }
}
function parseStats(row) {
  const cols = row.split("	");
  return {
    version: cols[0] || "",
    charset: cols[1] || "",
    collation: cols[2] || "",
    tables: Number(cols[3] || 0) || 0,
    sizeBytes: Number(cols[4] || 0) || 0,
    engine: cols[5] || ""
  };
}
async function wavelogDatabase(httpPort = 8086) {
  const compose = await composeDir();
  const { password, envFile, source } = await readDbPassword(compose);
  const inspect2 = await dockerInspectDb();
  const base = {
    ok: false,
    running: inspect2.running,
    connected: false,
    health: inspect2.health,
    deploy: "docker",
    compose,
    envFile,
    passwordSource: source,
    queryVia: "none",
    host: DB_HOST,
    port: DB_PORT,
    published: false,
    name: DB_NAME,
    user: DB_USER,
    password,
    version: "",
    charset: "",
    collation: "",
    engine: "",
    tables: 0,
    sizeBytes: 0,
    url: `http://127.0.0.1:${httpPort}/`,
    network: "wavelog",
    volume: "wavelog-dbdata",
    image: inspect2.image
  };
  if (!password) {
    return { ...base, error: "WAVELOG_DB_PASSWORD ausente em .env" };
  }
  if (!inspect2.running) {
    return { ...base, error: inspect2.health === "missing" ? "container wavelog-db ausente" : "MariaDB parado" };
  }
  try {
    const stats = parseStats(await mariadbQueryUser(DB_STATS_SQL));
    return { ...base, ...stats, ok: true, connected: true, queryVia: "user" };
  } catch (userErr) {
    const userMsg = scrubSecret(userErr instanceof Error ? userErr.message : String(userErr), password);
    try {
      const stats = parseStats(await mariadbQueryRoot(DB_STATS_SQL));
      return {
        ...base,
        ...stats,
        ok: true,
        connected: false,
        queryVia: "root-socket",
        error: "Usu\xE1rio/banco wavelog ainda n\xE3o existem neste volume. Credenciais do .env s\xE3o as do instalador web."
      };
    } catch {
      const version = await mariadbVersionFallback();
      return {
        ...base,
        version,
        error: userMsg || "falha ao consultar o MariaDB no container"
      };
    }
  }
}
async function wavelogDbUpdate(httpPort = 8086) {
  const compose = await composeDir();
  await ensureEnv(compose);
  await stationSvc("start", "wavelog");
  const ctl = join4(compose, "wavelog-ctl.sh");
  try {
    if (await fileExists(ctl)) {
      await execFileAsync5("bash", [ctl, "pull"], { cwd: compose, timeout: 24e4, windowsHide: true });
    } else {
      await execFileAsync5("docker", ["compose", "pull"], { cwd: compose, timeout: 18e4, windowsHide: true });
      await execFileAsync5("docker", ["compose", "up", "-d", "--remove-orphans"], {
        cwd: compose,
        timeout: 12e4,
        windowsHide: true
      });
    }
  } catch (err) {
    const db2 = await wavelogDatabase(httpPort);
    return {
      ...db2,
      updated: false,
      error: scrubSecret(err instanceof Error ? err.message : String(err), db2.password)
    };
  }
  await probeWavelog(httpPort);
  const db = await wavelogDatabase(httpPort);
  return { ...db, updated: true };
}
var execFileAsync5, ROOT3, STATION_SVC, STATION_BACKUP, DB_CONTAINER, DB_NAME, DB_USER, DB_HOST, DB_PORT, DB_STATS_SQL;
var init_wavelog_status = __esm({
  "server/wavelog-status.ts"() {
    "use strict";
    execFileAsync5 = promisify5(execFile5);
    ROOT3 = join4(dirname3(fileURLToPath3(import.meta.url)), "..");
    STATION_SVC = "/opt/ham-cockpit/bin/station-svc";
    STATION_BACKUP = "/opt/ham-cockpit/bin/station-backup";
    DB_CONTAINER = "wavelog-db";
    DB_NAME = "wavelog";
    DB_USER = "wavelog";
    DB_HOST = "wavelog-db";
    DB_PORT = 3306;
    DB_STATS_SQL = "SELECT VERSION(), @@character_set_server, @@collation_server, (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = 'wavelog' AND TABLE_TYPE = 'BASE TABLE'), (SELECT IFNULL(SUM(DATA_LENGTH + INDEX_LENGTH), 0) FROM information_schema.TABLES WHERE TABLE_SCHEMA = 'wavelog'), (SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA = 'wavelog' AND ENGINE IS NOT NULL ORDER BY DATA_LENGTH DESC LIMIT 1);";
  }
});

// server/wlg-status.ts
var wlg_status_exports = {};
__export(wlg_status_exports, {
  wlgDown: () => wlgDown,
  wlgStatus: () => wlgStatus,
  wlgUp: () => wlgUp
});
import { execFile as execFile6, spawn as spawn2 } from "node:child_process";
import { existsSync as existsSync3 } from "node:fs";
import { request as httpRequest2 } from "node:http";
import { dirname as dirname4, join as join5 } from "node:path";
import { fileURLToPath as fileURLToPath4 } from "node:url";
import { promisify as promisify6 } from "node:util";
function probe(port) {
  return new Promise((resolve) => {
    const req = httpRequest2(`http://127.0.0.1:${port}/status`, { method: "GET", timeout: 1500 }, (res) => {
      res.resume();
      resolve((res.statusCode ?? 0) >= 200 && (res.statusCode ?? 0) < 500);
    });
    req.on("timeout", () => {
      req.destroy();
      resolve(false);
    });
    req.on("error", () => resolve(false));
    req.end();
  });
}
async function systemctl(action) {
  try {
    const { stdout } = await execFileAsync6("systemctl", [action, "waveloggate.service"], {
      timeout: 2e4,
      windowsHide: true
    });
    if (action === "is-active") return stdout.trim() === "active";
    return true;
  } catch {
    return false;
  }
}
async function wlgStatus(udpPort = 2333, qsyPort = 54321) {
  const ok = await probe(qsyPort);
  if (ok) return { ok: true, udpPort, qsyPort, reason: "ok" };
  const unit = process.platform === "linux" ? await systemctl("is-active") : Boolean(child && !child.killed);
  return {
    ok: unit,
    udpPort,
    qsyPort,
    reason: unit ? "ok" : "down"
  };
}
async function wlgUp(udpPort = 2333, qsyPort = 54321) {
  const already = await wlgStatus(udpPort, qsyPort);
  if (already.ok) return already;
  if (process.platform === "linux") {
    await systemctl("enable");
    await systemctl("start");
  } else if (!child || child.killed) {
    child = spawn2(process.execPath, [SCRIPT], {
      cwd: dirname4(SCRIPT),
      detached: false,
      stdio: "ignore",
      windowsHide: true
    });
    child.on("exit", () => {
      child = null;
    });
  }
  await new Promise((r) => setTimeout(r, 800));
  return wlgStatus(udpPort, qsyPort);
}
async function wlgDown(udpPort = 2333, qsyPort = 54321) {
  if (process.platform === "linux") {
    await systemctl("stop");
  } else if (child) {
    child.kill();
    child = null;
  }
  await new Promise((r) => setTimeout(r, 400));
  return wlgStatus(udpPort, qsyPort);
}
var execFileAsync6, ROOT4, SCRIPT, child;
var init_wlg_status = __esm({
  "server/wlg-status.ts"() {
    "use strict";
    execFileAsync6 = promisify6(execFile6);
    ROOT4 = join5(dirname4(fileURLToPath4(import.meta.url)), "..");
    SCRIPT = existsSync3("/opt/wavelog-gate/wavelog-gate.mjs") ? "/opt/wavelog-gate/wavelog-gate.mjs" : join5(ROOT4, "deploy", "wavelog-gate", "wavelog-gate.mjs");
    child = null;
  }
});

// shared/version.ts
function pad2(n) {
  return String(Math.max(0, Math.floor(n))).padStart(2, "0");
}
function cleanVersion(raw) {
  return String(raw || "").trim().replace(/^v/i, "");
}
function parseVersion(raw) {
  const m = cleanVersion(raw).match(VERSION_RE);
  if (!m) return null;
  return {
    major: Number(m[1]) || 0,
    minor: Number(m[2]) || 0,
    patch: Number(m[3]) || 0,
    ota: m[4] != null ? Number(m[4]) || 0 : 0
  };
}
function imageBase(raw) {
  const p = parseVersion(raw);
  if (!p) return cleanVersion(raw);
  return `${p.major}.${p.minor}.${pad2(p.patch)}`;
}
function versionNums(raw) {
  return cleanVersion(raw).replace(/^[^\d]+/, "").split(/[^\d]+/).filter(Boolean).map((n) => Number(n) || 0);
}
function compareVersion(a, b) {
  const pa = parseVersion(a);
  const pb = parseVersion(b);
  if (pa && pb) {
    if (pa.major !== pb.major) return pa.major > pb.major ? 1 : -1;
    if (pa.minor !== pb.minor) return pa.minor > pb.minor ? 1 : -1;
    if (pa.patch !== pb.patch) return pa.patch > pb.patch ? 1 : -1;
    if (pa.ota !== pb.ota) return pa.ota > pb.ota ? 1 : -1;
    return 0;
  }
  const aa = versionNums(a);
  const bb = versionNums(b);
  const n = Math.max(aa.length, bb.length);
  for (let i = 0; i < n; i++) {
    const x = aa[i] || 0;
    const y = bb[i] || 0;
    if (x > y) return 1;
    if (x < y) return -1;
  }
  return 0;
}
function isNewerVersion(available, current) {
  const avail = cleanVersion(available);
  const cur = cleanVersion(current);
  if (!avail || !cur || avail === "\u2014") return false;
  if (/pacotes/i.test(avail)) return true;
  if (avail === cur) return false;
  return compareVersion(avail, cur) > 0;
}
var VERSION_RE;
var init_version = __esm({
  "shared/version.ts"() {
    "use strict";
    VERSION_RE = /^v?(\d+)\.(\d+)\.(\d+)(?:\.(\d{1,2}))?$/i;
  }
});

// shared/brand.ts
var APP_VERSION, APP_IMAGE_VERSION, UPDATE_REPO;
var init_brand = __esm({
  "shared/brand.ts"() {
    "use strict";
    init_version();
    APP_VERSION = "0.1.05.04";
    APP_IMAGE_VERSION = imageBase(APP_VERSION);
    UPDATE_REPO = "fviudes/ham-cockpit";
  }
});

// server/host-status.ts
import { execFile as execFile7 } from "node:child_process";
import { existsSync as existsSync4, readdirSync, readFileSync as readFileSync3, statfsSync } from "node:fs";
import os from "node:os";
import { promisify as promisify7 } from "node:util";
function readText(path2) {
  const raw = readFileSync3(path2);
  return raw.toString("utf8").replace(/\0/g, "").trim();
}
function readDtModel() {
  for (const p of ["/sys/firmware/devicetree/base/model", "/proc/device-tree/model"]) {
    try {
      if (!existsSync4(p)) continue;
      const s = readText(p);
      if (s) return s;
    } catch {
    }
  }
  return "";
}
function parseCpuinfo() {
  const out = { hardware: "", revision: "", model: "" };
  try {
    if (!existsSync4("/proc/cpuinfo")) return out;
    const text = readFileSync3("/proc/cpuinfo", "utf8");
    for (const line of text.split(/\r?\n/)) {
      const i = line.indexOf(":");
      if (i < 0) continue;
      const k = line.slice(0, i).trim().toLowerCase();
      const v = line.slice(i + 1).trim();
      if (k === "hardware") out.hardware = v;
      else if (k === "revision") out.revision = v;
      else if (k === "model") out.model = v;
    }
  } catch {
  }
  return out;
}
function decodePiRevision(raw) {
  const n = Number.parseInt(raw.replace(/^0x/i, ""), 16);
  if (!Number.isFinite(n) || n <= 0) return null;
  if (!(n >> 23 & 1)) return null;
  const type = n >> 4 & 255;
  const rev = n & 15;
  const name = PI_TYPE[type];
  if (!name) return { model: `Raspberry Pi (rev ${raw})`, soc: PI_SOC[type] || "" };
  return { model: `${name} Rev 1.${rev}`, soc: PI_SOC[type] || "" };
}
function readOsRelease() {
  const map = {};
  try {
    if (!existsSync4("/etc/os-release")) return map;
    for (const line of readFileSync3("/etc/os-release", "utf8").split(/\r?\n/)) {
      const i = line.indexOf("=");
      if (i < 0) continue;
      const k = line.slice(0, i).trim();
      let v = line.slice(i + 1).trim();
      if (v.startsWith('"') && v.endsWith('"') || v.startsWith("'") && v.endsWith("'")) v = v.slice(1, -1);
      map[k] = v;
    }
  } catch {
  }
  return map;
}
function formatOsPretty(rel) {
  const pretty = rel.PRETTY_NAME || "";
  const variant = (rel.VARIANT || rel.VARIANT_ID || "").toLowerCase();
  if (pretty) {
    const serverHint = variant.includes("server") || existsSync4("/usr/share/doc/ubuntu-server") || existsSync4("/var/lib/dpkg/info/ubuntu-server.list") || existsSync4("/proc/device-tree/model");
    if (/ubuntu/i.test(pretty) && !/server/i.test(pretty) && serverHint) {
      return pretty.replace(/Ubuntu/i, "Ubuntu Server");
    }
    return pretty;
  }
  const name = rel.NAME || "";
  const ver = rel.VERSION || rel.VERSION_ID || "";
  return [name, ver].filter(Boolean).join(" ").trim();
}
function cpuTimes() {
  let idle = 0;
  let total = 0;
  for (const c of os.cpus()) {
    const t = c.times;
    idle += t.idle;
    total += t.user + t.nice + t.sys + t.idle + t.irq;
  }
  return { idle, total };
}
function cpuPctFromDelta() {
  const cur = cpuTimes();
  const prev = cpuPrev;
  cpuPrev = cur;
  if (!prev) return null;
  const dTotal = cur.total - prev.total;
  const dIdle = cur.idle - prev.idle;
  if (dTotal <= 0) return null;
  const pct = (1 - dIdle / dTotal) * 100;
  if (!Number.isFinite(pct)) return null;
  return Math.round(Math.max(0, Math.min(100, pct)) * 10) / 10;
}
function readRam() {
  try {
    if (existsSync4("/proc/meminfo")) {
      const text = readFileSync3("/proc/meminfo", "utf8");
      const grab = (key) => {
        const m = text.match(new RegExp(`^${key}:\\s+(\\d+)`, "m"));
        return m ? Number(m[1]) * 1024 : 0;
      };
      const total2 = grab("MemTotal");
      let avail = grab("MemAvailable");
      if (!avail) avail = grab("MemFree") + grab("Buffers") + grab("Cached");
      if (total2 > 0) {
        const used2 = Math.max(0, total2 - avail);
        return { total: total2, used: used2, pct: Math.round(used2 / total2 * 1e3) / 10 };
      }
    }
  } catch {
  }
  const total = os.totalmem();
  const free = os.freemem();
  const used = Math.max(0, total - free);
  const pct = total > 0 ? Math.round(used / total * 1e3) / 10 : null;
  return { total, used, pct };
}
function readThermalZoneC() {
  const root = "/sys/class/thermal";
  if (!existsSync4(root)) return null;
  try {
    const zones = readdirSync(root).filter((n) => n.startsWith("thermal_zone"));
    let best = null;
    for (const z of zones) {
      const typePath = `${root}/${z}/type`;
      const tempPath = `${root}/${z}/temp`;
      if (!existsSync4(tempPath)) continue;
      let prefer = false;
      try {
        const type = readFileSync3(typePath, "utf8").trim().toLowerCase();
        prefer = type.includes("cpu") || type.includes("soc") || type === "x86_pkg_temp" || type === "cpu-thermal";
      } catch {
      }
      const raw = Number(readFileSync3(tempPath, "utf8").trim());
      if (!Number.isFinite(raw) || raw <= 0) continue;
      const c = raw > 1e3 ? raw / 1e3 : raw;
      if (prefer) return Math.round(c * 10) / 10;
      if (best == null || c > best) best = c;
    }
    return best == null ? null : Math.round(best * 10) / 10;
  } catch {
    return null;
  }
}
async function readVcgencmdTempC() {
  try {
    const { stdout } = await execFileAsync7("vcgencmd", ["measure_temp"], { timeout: 2e3 });
    const m = stdout.match(/temp=([\d.]+)/i);
    if (!m) return null;
    const c = Number(m[1]);
    return Number.isFinite(c) ? Math.round(c * 10) / 10 : null;
  } catch {
    return null;
  }
}
async function readWindowsTempC() {
  if (process.platform !== "win32") return null;
  if (windowsTempTried && !windowsTempOk) return null;
  try {
    const { stdout } = await execFileAsync7(
      "powershell",
      [
        "-NoProfile",
        "-Command",
        "(Get-CimInstance Win32_PerfFormattedData_Counters_ThermalZoneInformation -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty Temperature)"
      ],
      { timeout: 4e3, windowsHide: true }
    );
    windowsTempTried = true;
    const kelvin = Number(String(stdout).trim());
    if (!Number.isFinite(kelvin) || kelvin < 200) return null;
    windowsTempOk = true;
    return Math.round((kelvin - 273.15) * 10) / 10;
  } catch {
    windowsTempTried = true;
    return null;
  }
}
async function readCpuTempC() {
  let cpuTempC = readThermalZoneC();
  if (cpuTempC == null) cpuTempC = await readVcgencmdTempC();
  if (cpuTempC == null) cpuTempC = await readWindowsTempC();
  return cpuTempC;
}
function diskRoots() {
  if (process.platform === "win32") {
    const home = process.env.SystemDrive || "C:";
    return [`${home}\\`];
  }
  return ["/", "/data", "/opt"];
}
function readDisk() {
  for (const p of diskRoots()) {
    try {
      if (!existsSync4(p)) continue;
      const s = statfsSync(p);
      const total = Number(s.bsize) * Number(s.blocks);
      const free = Number(s.bsize) * Number(s.bavail ?? s.bfree);
      if (total > 0) return { total, free, path: p };
    } catch {
    }
  }
  return { total: 0, free: 0, path: process.platform === "win32" ? "C:\\" : "/" };
}
function formatCpuModel(model, n) {
  const mhz = os.cpus()[0]?.speed;
  const hz = mhz && mhz > 0 ? ` \xB7 ${n}\xD7${mhz >= 1e3 ? `${(mhz / 1e3).toFixed(1)} GHz` : `${mhz} MHz`}` : n > 1 ? ` \xB7 ${n} n\xFAcleos` : "";
  return `${model}${hz}`;
}
function readNetTotals() {
  if (process.platform !== "linux" || !existsSync4("/proc/net/dev")) return { rx: 0, tx: 0 };
  try {
    let rx2 = 0;
    let tx = 0;
    const text = readFileSync3("/proc/net/dev", "utf8");
    for (const line of text.split(/\r?\n/)) {
      const m = line.match(/^\s*([^:]+):\s*(.+)$/);
      if (!m) continue;
      const name = m[1].trim();
      if (name === "lo" || name.startsWith("veth") || name.startsWith("br-") || name === "docker0") continue;
      const cols = m[2].trim().split(/\s+/);
      rx2 += Number(cols[0]) || 0;
      tx += Number(cols[8]) || 0;
    }
    return { rx: rx2, tx };
  } catch {
    return { rx: 0, tx: 0 };
  }
}
function netBpsFromDelta() {
  const now = Date.now();
  const cur = readNetTotals();
  const prev = netPrev;
  netPrev = { t: now, rx: cur.rx, tx: cur.tx };
  if (!prev || now <= prev.t) return { rx: null, tx: null };
  const dt = (now - prev.t) / 1e3;
  if (dt <= 0) return { rx: null, tx: null };
  const rx2 = Math.max(0, (cur.rx - prev.rx) / dt);
  const tx = Math.max(0, (cur.tx - prev.tx) / dt);
  return { rx: rx2, tx };
}
function linuxHardware() {
  const dt = readDtModel();
  const info = parseCpuinfo();
  const decoded = info.revision ? decodePiRevision(info.revision) : null;
  const hardware = dt || info.model || decoded?.model || os.hostname() || "Raspberry Pi";
  const socFromRev = decoded?.soc || "";
  const n = os.cpus().length || 1;
  let soc = "";
  if (socFromRev) soc = formatCpuModel(socFromRev, n);
  else if (info.hardware) soc = formatCpuModel(info.hardware, n);
  else {
    const m = os.cpus()[0]?.model?.trim();
    if (m) soc = formatCpuModel(m, n);
    else soc = formatCpuModel("ARM", n);
  }
  return { hardware, soc };
}
function parseRegSzMap(stdout) {
  const map = {};
  for (const line of stdout.split(/\r?\n/)) {
    const m = line.trim().match(/^(\S+)\s+REG_SZ\s+(.+)$/i);
    if (m) map[m[1]] = m[2].trim();
  }
  return map;
}
function windowsIdentityQuick() {
  const n = os.cpus().length || 1;
  const cpu = os.cpus()[0]?.model?.trim() || "";
  return {
    hardware: os.hostname(),
    soc: cpu ? formatCpuModel(cpu, n) : "",
    osPretty: `Windows ${os.release()}`
  };
}
function enrichWindowsIdentity() {
  if (windowsEnrichStarted) return;
  windowsEnrichStarted = true;
  void (async () => {
    let hardware = identity?.hardware || "";
    let osPretty = identity?.osPretty || "";
    try {
      const { stdout } = await execFileAsync7("reg", ["query", "HKLM\\HARDWARE\\DESCRIPTION\\System\\BIOS"], {
        timeout: 8e3,
        windowsHide: true
      });
      const bios = parseRegSzMap(stdout);
      const mfr = bios.SystemManufacturer || "";
      const ver = bios.SystemVersion || "";
      const family = bios.SystemFamily || "";
      const product = bios.SystemProductName || "";
      const found = [mfr, ver || family || product].filter(Boolean).join(" ").trim();
      if (found) hardware = found;
    } catch {
    }
    try {
      const { stdout } = await execFileAsync7("reg", ["query", "HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion"], {
        timeout: 8e3,
        windowsHide: true
      });
      const nt = parseRegSzMap(stdout);
      const pretty = [nt.ProductName, nt.DisplayVersion].filter(Boolean).join(" ").trim();
      if (pretty) osPretty = pretty;
    } catch {
    }
    if (identity) identity = { ...identity, hardware, osPretty };
  })();
}
async function windowsIdentity() {
  const quick = windowsIdentityQuick();
  enrichWindowsIdentity();
  return quick;
}
async function readIdentity() {
  if (identity) return identity;
  if (process.platform === "win32") {
    identity = await windowsIdentity();
    return identity;
  }
  const hw = linuxHardware();
  const osPretty = formatOsPretty(readOsRelease());
  identity = {
    hardware: hw.hardware,
    soc: hw.soc,
    osPretty: osPretty || `${os.type()} ${os.release()}`
  };
  return identity;
}
function pruneSamples(now) {
  const cut = now - HOST_WINDOW_MS;
  while (samples.length && samples[0].t < cut) samples.shift();
  while (samples.length > MAX_SAMPLES) samples.shift();
}
async function sampleOnce() {
  const t = Date.now();
  const ram = readRam();
  const cpuPct = cpuPctFromDelta();
  const cpuTempC = await readCpuTempC();
  const net3 = netBpsFromDelta();
  const row = {
    t,
    cpuPct,
    ramPct: ram.pct,
    ramUsedBytes: ram.used,
    ramTotalBytes: ram.total,
    cpuTempC,
    netRxBps: net3.rx,
    netTxBps: net3.tx
  };
  samples.push(row);
  pruneSamples(t);
  return row;
}
function startHostSampler() {
  if (sampler) return;
  void (async () => {
    if (sampling) return;
    sampling = true;
    try {
      await sampleOnce();
    } finally {
      sampling = false;
    }
  })();
  sampler = setInterval(() => {
    if (sampling) return;
    sampling = true;
    void sampleOnce().finally(() => {
      sampling = false;
    });
  }, HOST_SAMPLE_MS);
  sampler.unref?.();
}
function emptyStatus(error3) {
  return {
    ok: false,
    cpuTempC: null,
    diskTotalBytes: 0,
    diskFreeBytes: 0,
    diskUsedBytes: 0,
    diskPath: "/",
    error: error3,
    hardware: "",
    soc: "",
    osPretty: "",
    appVersion: APP_VERSION,
    uptimeSec: Math.floor(os.uptime()),
    cpuPct: null,
    ramPct: null,
    ramUsedBytes: 0,
    ramTotalBytes: 0,
    netRxBps: null,
    netTxBps: null,
    sampleMs: HOST_SAMPLE_MS,
    windowMs: HOST_WINDOW_MS,
    samples: []
  };
}
async function hostStatus() {
  startHostSampler();
  try {
    const now = Date.now();
    const last = samples[samples.length - 1];
    if (!last || now - last.t > HOST_SAMPLE_MS * 1.5) {
      if (!sampling) {
        sampling = true;
        try {
          await sampleOnce();
        } finally {
          sampling = false;
        }
      }
    }
    const [id, disk] = await Promise.all([readIdentity(), Promise.resolve(readDisk())]);
    const used = Math.max(0, disk.total - disk.free);
    const ram = readRam();
    const row = samples[samples.length - 1];
    pruneSamples(Date.now());
    return {
      ok: true,
      cpuTempC: row?.cpuTempC ?? null,
      diskTotalBytes: disk.total,
      diskFreeBytes: disk.free,
      diskUsedBytes: used,
      diskPath: disk.path,
      error: "",
      hardware: id.hardware,
      soc: id.soc,
      osPretty: id.osPretty,
      appVersion: APP_VERSION,
      uptimeSec: Math.floor(os.uptime()),
      cpuPct: row?.cpuPct ?? null,
      ramPct: ram.pct,
      ramUsedBytes: ram.used,
      ramTotalBytes: ram.total,
      netRxBps: row?.netRxBps ?? null,
      netTxBps: row?.netTxBps ?? null,
      sampleMs: HOST_SAMPLE_MS,
      windowMs: HOST_WINDOW_MS,
      samples: samples.slice()
    };
  } catch (err) {
    return emptyStatus(String(err));
  }
}
var execFileAsync7, HOST_SAMPLE_MS, HOST_WINDOW_MS, MAX_SAMPLES, samples, cpuPrev, netPrev, sampler, sampling, identity, PI_TYPE, PI_SOC, windowsTempTried, windowsTempOk, windowsEnrichStarted;
var init_host_status = __esm({
  "server/host-status.ts"() {
    "use strict";
    init_brand();
    execFileAsync7 = promisify7(execFile7);
    HOST_SAMPLE_MS = 5e3;
    HOST_WINDOW_MS = 5 * 60 * 1e3;
    MAX_SAMPLES = Math.ceil(HOST_WINDOW_MS / HOST_SAMPLE_MS) + 4;
    samples = [];
    cpuPrev = null;
    netPrev = null;
    sampler = null;
    sampling = false;
    identity = null;
    PI_TYPE = {
      0: "Raspberry Pi A",
      1: "Raspberry Pi B",
      2: "Raspberry Pi A+",
      3: "Raspberry Pi B+",
      4: "Raspberry Pi 2 Model B",
      6: "Raspberry Pi Compute Module 1",
      8: "Raspberry Pi 3 Model B",
      9: "Raspberry Pi Zero",
      10: "Raspberry Pi Compute Module 3",
      12: "Raspberry Pi Zero W",
      13: "Raspberry Pi 3 Model B Plus",
      14: "Raspberry Pi 3 Model A Plus",
      16: "Raspberry Pi Compute Module 3+",
      17: "Raspberry Pi 4 Model B",
      18: "Raspberry Pi Zero 2 W",
      19: "Raspberry Pi 400",
      20: "Raspberry Pi Compute Module 4",
      21: "Raspberry Pi Compute Module 4S",
      23: "Raspberry Pi 5",
      24: "Raspberry Pi Compute Module 5",
      25: "Raspberry Pi 500",
      26: "Raspberry Pi Compute Module 5 Lite"
    };
    PI_SOC = {
      0: "BCM2835",
      1: "BCM2835",
      2: "BCM2835",
      3: "BCM2835",
      4: "BCM2836",
      6: "BCM2835",
      8: "BCM2837",
      9: "BCM2835",
      10: "BCM2837",
      12: "BCM2835",
      13: "BCM2837B0",
      14: "BCM2837B0",
      16: "BCM2837B0",
      17: "BCM2711",
      18: "BCM2710A1",
      19: "BCM2711",
      20: "BCM2711",
      21: "BCM2711",
      23: "BCM2712",
      24: "BCM2712",
      25: "BCM2712",
      26: "BCM2712"
    };
    windowsTempTried = false;
    windowsTempOk = false;
    windowsEnrichStarted = false;
    startHostSampler();
  }
});

// server/mmdvm.ts
var mmdvm_exports = {};
__export(mmdvm_exports, {
  MMDVM_BOARD_PRESETS: () => MMDVM_BOARD_PRESETS,
  MMDVM_MODES: () => MMDVM_MODES,
  dstarIniPath: () => dstarIniPath,
  gatewayIniPath: () => gatewayIniPath,
  hostIniPath: () => hostIniPath,
  mmdvmControl: () => mmdvmControl,
  mmdvmLink: () => mmdvmLink,
  mmdvmModePause: () => mmdvmModePause,
  mmdvmModeResumeAll: () => mmdvmModeResumeAll,
  mmdvmNetworkSet: () => mmdvmNetworkSet,
  mmdvmRemote: () => mmdvmRemote,
  mmdvmSave: () => mmdvmSave,
  mmdvmStatus: () => mmdvmStatus,
  parseLastHeard: () => parseLastHeard,
  ysfIniPath: () => ysfIniPath
});
import { execFile as execFile8 } from "node:child_process";
import { copyFileSync, existsSync as existsSync5, mkdirSync as mkdirSync3, readdirSync as readdirSync2, readFileSync as readFileSync4, renameSync as renameSync3, statSync, unlinkSync, writeFileSync as writeFileSync3 } from "node:fs";
import { dirname as dirname5, join as join6 } from "node:path";
import { fileURLToPath as fileURLToPath5 } from "node:url";
import { promisify as promisify8 } from "node:util";
import { createConnection } from "node:net";
import { networkInterfaces } from "node:os";
function linux() {
  return process.platform === "linux";
}
function dataDir3() {
  if (existsSync5("/opt/ham-cockpit")) {
    const dir = "/opt/ham-cockpit/mmdvm";
    mkdirSync3(dir, { recursive: true });
    return dir;
  }
  const local = join6(ROOT5, "data", "mmdvm");
  mkdirSync3(local, { recursive: true });
  return local;
}
function shippedHostIni() {
  return join6(ROOT5, "deploy", "mmdvm", "mmdvmhost.ini");
}
function shippedGwIni() {
  return join6(ROOT5, "deploy", "mmdvm", "dmrgateway.ini");
}
function shippedYsfIni() {
  return join6(ROOT5, "deploy", "mmdvm", "ysfgateway.ini");
}
function shippedDstarConf() {
  return join6(ROOT5, "deploy", "mmdvm", "ircddbgateway.conf");
}
function firstExisting(paths2) {
  return paths2.find((p) => existsSync5(p)) ?? "";
}
function editablePath(etcPath, localName, shipped) {
  if (existsSync5(etcPath)) return etcPath;
  const local = join6(dataDir3(), localName);
  if (!existsSync5(local) && existsSync5(shipped)) {
    mkdirSync3(dataDir3(), { recursive: true });
    writeFileSync3(local, readFileSync4(shipped, "utf8"), "utf8");
  }
  return local;
}
function hostIniPath() {
  return editablePath("/etc/mmdvmhost", "mmdvmhost.ini", shippedHostIni());
}
function gatewayIniPath() {
  return editablePath("/etc/dmrgateway", "dmrgateway.ini", shippedGwIni());
}
function ysfIniPath() {
  return editablePath("/etc/ysfgateway", "ysfgateway.ini", shippedYsfIni());
}
function dstarIniPath() {
  if (existsSync5("/etc/ircddbgateway")) return "/etc/ircddbgateway";
  const dir = dataDir3();
  const noext = join6(dir, "ircddbgateway");
  const conf = join6(dir, "ircddbgateway.conf");
  if (!existsSync5(noext) && !existsSync5(conf) && existsSync5(shippedDstarConf())) {
    mkdirSync3(dir, { recursive: true });
    writeFileSync3(conf, readFileSync4(shippedDstarConf(), "utf8"), "utf8");
  }
  if (existsSync5(conf) && !existsSync5(noext)) {
    try {
      copyFileSync(conf, noext);
    } catch {
      try {
        writeFileSync3(noext, readFileSync4(conf, "utf8"), "utf8");
      } catch {
      }
    }
  }
  if (existsSync5(noext)) return noext;
  return editablePath("/etc/ircddbgateway", "ircddbgateway.conf", shippedDstarConf());
}
function hostBinary() {
  return firstExisting(["/usr/local/bin/MMDVMHost", "/usr/bin/MMDVMHost", "/opt/MMDVMHost/MMDVMHost"]);
}
function gatewayBinary() {
  return firstExisting(["/usr/local/bin/DMRGateway", "/usr/bin/DMRGateway", "/opt/DMRGateway/DMRGateway"]);
}
function ysfBinary() {
  return firstExisting(["/usr/local/bin/YSFGateway", "/usr/bin/YSFGateway"]);
}
function dstarBinary() {
  return firstExisting(["/usr/local/bin/ircddbgatewayd", "/usr/bin/ircddbgatewayd", "/usr/local/bin/ircDDBGateway"]);
}
function nextionBinary() {
  return firstExisting(["/usr/local/bin/NextionDriver", "/usr/bin/NextionDriver", "/opt/NextionDriver/NextionDriver"]);
}
function parseConf(text) {
  const out = {};
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith("#") || line.startsWith(";")) continue;
    const eq = line.indexOf("=");
    if (eq < 1) continue;
    out[line.slice(0, eq).trim()] = line.slice(eq + 1).trim();
  }
  return out;
}
function parseConfFile(path2) {
  try {
    if (!existsSync5(path2)) return {};
    return parseConf(readFileSync4(path2, "utf8"));
  } catch {
    return {};
  }
}
function stringifyConf(conf, header = "") {
  const lines = [];
  if (header) lines.push(header, "");
  for (const [k, v] of Object.entries(conf)) lines.push(`${k}=${v}`);
  return `${lines.join("\n").trimEnd()}
`;
}
function localNameForDest(dest) {
  if (dest.includes("ysf")) return "ysfgateway.ini";
  if (dest.includes("ircddb") || dest.includes("dstar")) return "ircddbgateway.conf";
  if (dest.includes("dmr")) return "dmrgateway.ini";
  return "mmdvmhost.ini";
}
function logDir() {
  const fromIni = parseIniFile(hostIniPath())["Log"]?.FilePath?.replace(/^"|"$/g, "") ?? "";
  return firstExisting([fromIni, "/var/log/pi-star", "/var/log/mmdvm", join6(dataDir3(), "logs")]) || join6(dataDir3(), "logs");
}
function parseIni(text) {
  const out = {};
  let section = "";
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith(";") || line.startsWith("#")) continue;
    const sec = line.match(/^\[(.+)\]$/);
    if (sec) {
      section = sec[1];
      if (!out[section]) out[section] = {};
      continue;
    }
    const eq = line.indexOf("=");
    if (eq < 1 || !section) continue;
    const key = line.slice(0, eq).trim();
    let value = line.slice(eq + 1).trim();
    if (value.startsWith('"') && value.endsWith('"') || value.startsWith("'") && value.endsWith("'")) {
      value = value.slice(1, -1);
    }
    if (!out[section]) out[section] = {};
    out[section][key] = value;
  }
  return out;
}
function parseIniFile(path2) {
  try {
    if (!existsSync5(path2)) return {};
    return parseIni(readFileSync4(path2, "utf8"));
  } catch {
    return {};
  }
}
function stringifyIni(ini) {
  const lines = [
    "; Ham Cockpit MMDVM \u2014 layout WPSD / Pi-Star (MMDVMHost + DMRGateway).",
    "; Canonical stack: https://wpsd.radio  \xB7  g4klx/MMDVMHost  \xB7  g4klx/DMRGateway",
    ""
  ];
  for (const [section, kv] of Object.entries(ini)) {
    lines.push(`[${section}]`);
    for (const [k, v] of Object.entries(kv)) {
      const needsQuote = /[\s#;]/.test(v) && !/^".*"$/.test(v);
      lines.push(`${k}=${needsQuote ? `"${v}"` : v}`);
    }
    lines.push("");
  }
  return `${lines.join("\n").trimEnd()}
`;
}
function iniGet(ini, section, key, fallback = "") {
  return ini[section]?.[key] ?? fallback;
}
function iniNum(ini, section, key, fallback) {
  const n = Number(iniGet(ini, section, key, String(fallback)));
  return Number.isFinite(n) ? n : fallback;
}
function iniOn(ini, section, key = "Enable") {
  return iniGet(ini, section, key, "0") === "1";
}
function setKv(ini, section, key, value) {
  if (!ini[section]) ini[section] = {};
  ini[section][key] = value;
}
function defaultConfig() {
  return {
    callsign: "N0CALL",
    dmrId: "0000000",
    duplex: false,
    rxHz: 433475e3,
    txHz: 433475e3,
    colorCode: 1,
    latitude: "0.0",
    longitude: "0.0",
    location: "Ham Cockpit",
    modemBoard: "mmdvmhshat",
    modemPort: "/dev/ttyAMA0",
    uartSpeed: 115200,
    remotePort: 7642,
    dstarReflector: "",
    dstarModule: "B",
    ysfStartup: "",
    displayType: "Nextion",
    displayPort: "modem",
    screenLayout: 4,
    brightness: 50,
    idleBrightness: 20,
    nextionDriver: true,
    oledType: 3,
    modes: { dstar: false, dmr: true, ysf: false, p25: false, nxdn: false, m17: false, pocsag: false },
    networks: [
      { id: "bm", section: "DMR Network 1", name: "BrandMeister", enabled: true, address: "3101.repeater.net", port: 62031, password: "passw0rd" },
      { id: "dmrplus", section: "DMR Network 2", name: "DMR+", enabled: false, address: "94.198.196.128", port: 8880, password: "passw0rd" },
      { id: "tgif", section: "DMR Network 3", name: "TGIF", enabled: false, address: "tgif.network", port: 62031, password: "passw0rd" },
      { id: "xlx", section: "XLX Network", name: "XLX", enabled: false, address: "xlx.example.net", port: 62030, password: "" }
    ]
  };
}
function configFromFiles() {
  const host2 = parseIniFile(hostIniPath());
  const gw = parseIniFile(gatewayIniPath());
  const ysf = parseIniFile(ysfIniPath());
  const dstar = parseConfFile(dstarIniPath());
  const base = defaultConfig();
  const modemPort = iniGet(host2, "Modem", "UARTPort") || iniGet(host2, "Modem", "Port") || base.modemPort;
  const nets = base.networks.map((n) => {
    const sec = gw[n.section] ?? {};
    return {
      ...n,
      name: sec.Name || n.name,
      enabled: (sec.Enabled ?? sec.Enable ?? "0") === "1",
      address: sec.Address || n.address,
      port: Number(sec.Port) || n.port,
      password: sec.Password || n.password
    };
  });
  const modes = { ...base.modes };
  for (const mode of MMDVM_MODES) {
    modes[mode] = iniOn(host2, MODE_INI[mode].section);
  }
  const module = iniGet(host2, "D-Star", "Module", base.dstarModule) || dstar.module || base.dstarModule;
  return {
    callsign: iniGet(host2, "General", "Callsign", base.callsign),
    dmrId: iniGet(host2, "General", "Id", base.dmrId),
    duplex: iniGet(host2, "General", "Duplex", "0") === "1",
    rxHz: iniNum(host2, "Info", "RXFrequency", base.rxHz),
    txHz: iniNum(host2, "Info", "TXFrequency", base.txHz),
    colorCode: iniNum(host2, "DMR", "ColorCode", base.colorCode),
    latitude: iniGet(host2, "Info", "Latitude", base.latitude),
    longitude: iniGet(host2, "Info", "Longitude", base.longitude),
    location: iniGet(host2, "Info", "Location", base.location).replace(/^"|"$/g, ""),
    modemBoard: readModemBoard(),
    modemPort,
    uartSpeed: iniNum(host2, "Modem", "UARTSpeed", base.uartSpeed),
    remotePort: iniNum(host2, "Remote Control", "Port", base.remotePort),
    dstarReflector: (dstar.reflector1 || "").toUpperCase(),
    dstarModule: String(module || "B").toUpperCase().slice(0, 1),
    ysfStartup: iniGet(ysf, "Network", "Startup", base.ysfStartup),
    displayType: (() => {
      const d = iniGet(host2, "General", "Display", base.displayType);
      if (d === "Nextion" || d === "OLED" || d === "None") return d;
      return base.displayType;
    })(),
    displayPort: (() => {
      const drv = iniGet(host2, "NextionDriver", "Port", "");
      const nx = iniGet(host2, "Nextion", "Port", "");
      if (drv && drv !== "/dev/ttyNextionDriver") return drv;
      if (nx && nx !== "/dev/ttyNextionDriver") return nx;
      return base.displayPort;
    })(),
    screenLayout: iniNum(host2, "Nextion", "ScreenLayout", base.screenLayout),
    brightness: iniNum(host2, "Nextion", "Brightness", base.brightness),
    idleBrightness: iniNum(host2, "Nextion", "IdleBrightness", base.idleBrightness),
    nextionDriver: iniGet(host2, "NextionDriver", "Enable", "") === "1" || iniGet(host2, "Nextion", "Port", "").includes("ttyNextionDriver"),
    oledType: iniNum(host2, "OLED", "Type", base.oledType),
    modes,
    networks: nets
  };
}
function applyConfig(host2, gw, ysf, dstar, cfg) {
  const cur = { ...defaultConfig(), ...configFromFiles(), ...cfg };
  const call = cur.callsign.toUpperCase().slice(0, 8);
  const id = cur.dmrId.replace(/\D/g, "").slice(0, 9) || "0000000";
  const mod = (cur.dstarModule || "B").toUpperCase().replace(/[^A-Z]/g, "").slice(0, 1) || "B";
  setKv(host2, "General", "Callsign", call);
  setKv(host2, "General", "Id", id);
  setKv(host2, "General", "Duplex", cur.duplex ? "1" : "0");
  setKv(host2, "Info", "RXFrequency", String(cur.rxHz));
  setKv(host2, "Info", "TXFrequency", String(cur.duplex ? cur.txHz : cur.rxHz));
  setKv(host2, "Info", "Latitude", cur.latitude);
  setKv(host2, "Info", "Longitude", cur.longitude);
  setKv(host2, "Info", "Location", cur.location);
  setKv(host2, "DMR", "Id", id);
  setKv(host2, "DMR", "ColorCode", String(Math.min(15, Math.max(0, cur.colorCode))));
  setKv(host2, "D-Star", "Module", mod);
  const board = boardPreset(cur.modemBoard || "custom");
  writeModemBoard(board.id);
  let modemPort = cur.modemPort || "/dev/ttyAMA0";
  let uartSpeed = cur.uartSpeed || 115200;
  if (board.id !== "custom") {
    if (board.port) modemPort = board.port;
    if (board.uartSpeed > 0) uartSpeed = board.uartSpeed;
    if (board.duplex !== null) {
      setKv(host2, "General", "Duplex", board.duplex ? "1" : "0");
      if (!board.duplex) setKv(host2, "Info", "TXFrequency", String(cur.rxHz));
    }
    if (board.slot1 === false) setKv(host2, "DMR Network", "Slot1", "0");
    if (board.slot1 === true) setKv(host2, "DMR Network", "Slot1", "1");
  }
  setKv(host2, "Modem", "Port", modemPort);
  setKv(host2, "Modem", "UARTPort", modemPort);
  setKv(host2, "Modem", "Protocol", "uart");
  setKv(host2, "Modem", "UARTSpeed", String(uartSpeed));
  if (!iniGet(host2, "Modem", "TXInvert")) setKv(host2, "Modem", "TXInvert", "1");
  if (!iniGet(host2, "Modem", "RXInvert")) setKv(host2, "Modem", "RXInvert", "0");
  if (!iniGet(host2, "Modem", "PTTInvert")) setKv(host2, "Modem", "PTTInvert", "0");
  if (!iniGet(host2, "Modem", "Trace")) setKv(host2, "Modem", "Trace", "0");
  setKv(host2, "Remote Control", "Enable", "1");
  setKv(host2, "Remote Control", "Port", String(cur.remotePort || 7642));
  setKv(host2, "DMR Network", "Type", "Gateway");
  setKv(host2, "DMR Network", "Address", "127.0.0.1");
  setKv(host2, "DMR Network", "Port", "62031");
  setKv(host2, "DMR Network", "Local", "62032");
  setKv(host2, "DMR Network", "RemoteAddress", "127.0.0.1");
  setKv(host2, "DMR Network", "RemotePort", "62031");
  setKv(host2, "DMR Network", "LocalPort", "62032");
  setKv(host2, "D-Star Network", "GatewayAddress", "127.0.0.1");
  setKv(host2, "D-Star Network", "GatewayPort", "20010");
  setKv(host2, "D-Star Network", "LocalPort", "20011");
  setKv(host2, "System Fusion Network", "LocalAddress", "127.0.0.1");
  setKv(host2, "System Fusion Network", "LocalPort", "3200");
  setKv(host2, "System Fusion Network", "GatewayAddress", "127.0.0.1");
  setKv(host2, "System Fusion Network", "GatewayPort", "4200");
  for (const mode of MMDVM_MODES) {
    const on = cur.modes[mode] ? "1" : "0";
    setKv(host2, MODE_INI[mode].section, "Enable", on);
    setKv(host2, MODE_INI[mode].net, "Enable", on);
  }
  setKv(gw, "General", "Callsign", call);
  setKv(gw, "General", "Id", id);
  setKv(gw, "General", "RptAddress", "127.0.0.1");
  setKv(gw, "General", "RptPort", "62032");
  setKv(gw, "General", "LocalAddress", "127.0.0.1");
  setKv(gw, "General", "LocalPort", "62031");
  const nets = cfg.networks ?? cur.networks;
  for (const n of nets) {
    setKv(gw, n.section, "Enabled", n.enabled ? "1" : "0");
    setKv(gw, n.section, "Name", n.name);
    setKv(gw, n.section, "Address", n.address);
    setKv(gw, n.section, "Port", String(n.port));
    if (n.password !== void 0) setKv(gw, n.section, "Password", n.password);
    if (n.id !== "xlx") setKv(gw, n.section, "Id", id);
  }
  setKv(ysf, "General", "Callsign", call);
  setKv(ysf, "General", "Id", id);
  setKv(ysf, "General", "RptAddress", "127.0.0.1");
  setKv(ysf, "General", "RptPort", "3200");
  setKv(ysf, "General", "LocalAddress", "127.0.0.1");
  setKv(ysf, "General", "LocalPort", "4200");
  setKv(ysf, "Info", "RXFrequency", String(cur.rxHz));
  setKv(ysf, "Info", "TXFrequency", String(cur.duplex ? cur.txHz : cur.rxHz));
  setKv(ysf, "Info", "Latitude", cur.latitude);
  setKv(ysf, "Info", "Longitude", cur.longitude);
  setKv(ysf, "Info", "Name", cur.location || "Ham Cockpit");
  setKv(ysf, "Network", "Startup", cur.ysfStartup || "");
  setKv(ysf, "Remote Commands", "Enable", "1");
  setKv(ysf, "Remote Commands", "Port", "6073");
  dstar.gatewayCallsign = call;
  dstar.dplusLogin = call;
  dstar.gatewayAddress = "0.0.0.0";
  dstar.localAddress = "0.0.0.0";
  dstar.dplusEnabled = "1";
  dstar.latitude = cur.latitude;
  dstar.longitude = cur.longitude;
  dstar.latitude1 = cur.latitude;
  dstar.longitude1 = cur.longitude;
  dstar.frequency1 = (cur.rxHz / 1e6).toFixed(6);
  dstar.reflector1 = (cur.dstarReflector || "").toUpperCase().slice(0, 8);
  dstar.atStartup1 = cur.dstarReflector ? "1" : "0";
  dstar.reconnect1 = cur.dstarReflector ? "2" : "0";
  dstar.name = cur.location || "Ham Cockpit";
  dstar.remoteEnabled = "1";
  dstar.remotePort = "7643";
  dstar.logPath = "/var/log/mmdvm";
  const dtype = cur.displayType || "None";
  setKv(host2, "General", "Display", dtype);
  const physPort = (cur.displayPort || "modem").trim() || "modem";
  const useDriver = dtype === "Nextion" && cur.nextionDriver;
  const nextionHostPort = useDriver ? "/dev/ttyNextionDriver" : physPort === "modem" ? "modem" : physPort;
  setKv(host2, "Nextion", "Port", nextionHostPort);
  setKv(host2, "Nextion", "Brightness", String(Math.min(100, Math.max(0, cur.brightness ?? 50))));
  setKv(host2, "Nextion", "IdleBrightness", String(Math.min(100, Math.max(0, cur.idleBrightness ?? 20))));
  setKv(host2, "Nextion", "ScreenLayout", String(cur.screenLayout ?? 4));
  setKv(host2, "Nextion", "DisplayClock", "1");
  setKv(host2, "Nextion", "UTC", "0");
  setKv(host2, "OLED", "Type", String(cur.oledType ?? 3));
  setKv(host2, "OLED", "Scroll", "1");
  setKv(host2, "OLED", "LogoScreensaver", "1");
  const transparent = useDriver && (physPort === "modem" || physPort === "/dev/ttyNextionDriver");
  setKv(host2, "Transparent Data", "Enable", transparent || dtype === "Nextion" && physPort === "modem" ? "1" : "0");
  setKv(host2, "Transparent Data", "RemoteAddress", "127.0.0.1");
  setKv(host2, "Transparent Data", "RemotePort", "40094");
  setKv(host2, "Transparent Data", "LocalPort", "40095");
  setKv(host2, "Transparent Data", "SendFrameType", "1");
  setKv(host2, "NextionDriver", "Enable", useDriver ? "1" : "0");
  setKv(host2, "NextionDriver", "Port", useDriver ? physPort === "/dev/ttyNextionDriver" ? "modem" : physPort : physPort);
  setKv(host2, "NextionDriver", "DataFilesPath", "/usr/local/etc/");
  setKv(host2, "NextionDriver", "LogLevel", "2");
  setKv(host2, "NextionDriver", "GroupsFile", "groups.txt");
  setKv(host2, "NextionDriver", "DMRidFile", "users.csv");
  setKv(host2, "NextionDriver", "WaitForLan", "0");
  setKv(host2, "TFT Serial", "Port", physPort === "modem" ? "modem" : physPort);
}
async function helper(cmd, ...args) {
  if (!existsSync5(HELPER2)) return "";
  try {
    const { stdout } = await execFileAsync8("sudo", ["-n", HELPER2, cmd, ...args], {
      timeout: 2e4,
      windowsHide: true
    });
    return String(stdout || "").trim();
  } catch {
    return "";
  }
}
async function unitActive(unit) {
  if (!linux()) return false;
  const out = await helper("is-active", unit);
  if (out === "active") return true;
  try {
    const { stdout } = await execFileAsync8("systemctl", ["is-active", `${unit}.service`], {
      timeout: 3e3,
      windowsHide: true
    });
    return String(stdout).trim() === "active";
  } catch {
    return false;
  }
}
function logDate(offsetSec = 0) {
  const d = new Date(Date.now() - offsetSec * 1e3);
  const y = d.getUTCFullYear();
  const m = String(d.getUTCMonth() + 1).padStart(2, "0");
  const day = String(d.getUTCDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}
function readLogTail(dir, prefix, maxBytes = 4e5) {
  const names = [`${prefix}-${logDate()}.log`, `${prefix}-${logDate(86340)}.log`];
  let buf = "";
  for (const name of names) {
    const path2 = join6(dir, name);
    if (!existsSync5(path2)) continue;
    try {
      const raw = readFileSync4(path2, "utf8");
      buf += raw.length > maxBytes ? raw.slice(-maxBytes) : raw;
      buf += "\n";
    } catch {
    }
  }
  if (buf) return buf;
  try {
    const files = readdirSync2(dir).filter((f) => f.startsWith(`${prefix}-`) && f.endsWith(".log")).sort();
    const last = files[files.length - 1];
    if (!last) return "";
    const raw = readFileSync4(join6(dir, last), "utf8");
    return raw.length > maxBytes ? raw.slice(-maxBytes) : raw;
  } catch {
    return "";
  }
}
function pausedPath() {
  return join6(dataDir3(), "paused-modes.json");
}
function boardPath() {
  return join6(dataDir3(), "modem-board.json");
}
function readModemBoard() {
  try {
    const raw = JSON.parse(readFileSync4(boardPath(), "utf8"));
    const id = String(raw.board || "");
    if (MMDVM_BOARD_PRESETS.some((p) => p.id === id)) return id;
  } catch {
  }
  return "mmdvmhshat";
}
function writeModemBoard(board) {
  mkdirSync3(dataDir3(), { recursive: true });
  writeFileSync3(boardPath(), `${JSON.stringify({ board }, null, 2)}
`, "utf8");
}
function boardPreset(id) {
  return MMDVM_BOARD_PRESETS.find((p) => p.id === id) ?? MMDVM_BOARD_PRESETS[0];
}
function emptyPaused() {
  return { dstar: false, dmr: false, ysf: false, p25: false, nxdn: false, m17: false, pocsag: false };
}
function readPaused() {
  const out = emptyPaused();
  try {
    const raw = JSON.parse(readFileSync4(pausedPath(), "utf8"));
    for (const mode of MMDVM_MODES) {
      if (typeof raw[mode] === "boolean") out[mode] = raw[mode];
    }
  } catch {
  }
  return out;
}
function writePaused(paused) {
  mkdirSync3(dataDir3(), { recursive: true });
  writeFileSync3(pausedPath(), `${JSON.stringify(paused, null, 2)}
`, "utf8");
}
function modeGatewayTarget(mode) {
  if (mode === "dmr") return "dmrgateway";
  if (mode === "ysf") return "ysfgateway";
  if (mode === "dstar") return "ircddbgateway";
  return "host";
}
function parseLastHeard(logText, limit = 40) {
  const rows = [];
  const seen = /* @__PURE__ */ new Map();
  const lines = logText.split(/\r?\n/).reverse();
  const skip = /BS_Dwn_Act|invalid access|packet received from an invalid source|received RF header for wrong repeater|unable to decode the network CSBK|overflow in the DMR slot RF queue|overflow in the System Fusion RF queue|non repeater RF header|Embedded Talker Alias|DMR Talker Alias|CSBK Preamble|Preamble CSBK|Downlink/i;
  for (const line of lines) {
    if (!line.startsWith("M:")) continue;
    if (skip.test(line)) continue;
    if (!/\bfrom\b/i.test(line) || !/\bto\b/i.test(line)) continue;
    const m = line.match(
      /^M:\s+(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\.\d+\s+([^,]+),\s+received\s+(RF|network)\b.+?\bfrom\s+(.+?)\s+to\s+(.+)$/i
    );
    if (!m) continue;
    const mode = m[2].trim();
    const src = m[3].toLowerCase() === "rf" ? "RF" : "Net";
    let callsign = m[4].trim();
    if (callsign.includes("/")) callsign = callsign.split("/").pop().trim();
    const extra = m[5].trim().split(",").map((s) => s.trim());
    const target = (extra[0] ?? "").replace(/\s+via\s+.*$/i, "").trim();
    let duration = "";
    let loss = "";
    let ber = "";
    let rssi = "";
    for (const part of extra.slice(1)) {
      if (/seconds/i.test(part)) duration = part.replace(/\s*seconds.*/i, "").trim();
      else if (/RSSI/i.test(part)) rssi = part.replace(/^RSSI:\s*/i, "").trim();
      else if (/loss/i.test(part) || /packet loss/i.test(part)) loss = part.replace(/\s*packet loss.*/i, "").trim();
      else if (/BER/i.test(part)) ber = part.replace(/^BER:\s*/i, "").trim();
    }
    const kind = mode.startsWith("DMR") || mode.startsWith("D-Star") || mode.startsWith("YSF") || mode.startsWith("P25") || mode.startsWith("NXDN") || mode.startsWith("M17") || mode.startsWith("POCSAG");
    if (!kind || !callsign || callsign === "??????") continue;
    const uuid = `${callsign}#${mode}#${src}`;
    const row = { timeUtc: m[1], mode, callsign, target, src, duration, loss, ber, rssi };
    const prev = seen.get(uuid);
    if (!prev || !prev.duration && row.duration) seen.set(uuid, row);
    if (seen.size >= limit * 2) break;
  }
  for (const row of Array.from(seen.values())) {
    rows.push(row);
    if (rows.length >= limit) break;
  }
  return rows;
}
function currentTx(rows) {
  return rows.some((r) => !r.duration);
}
function lanIpv4() {
  const ifs = networkInterfaces();
  const preferred = ["eth0", "enp0s3", "enp1s0", "wlan0", "wlp2s0", "Ethernet", "Wi-Fi"];
  const skip = /^(lo|docker|br-|veth|virbr|tailscale|vmnet|vEthernet)/i;
  const pick = (name) => {
    for (const a of ifs[name] ?? []) {
      const family = String(a.family);
      if ((family === "IPv4" || family === "4") && !a.internal) return a.address;
    }
    return "";
  };
  for (const name of preferred) {
    const ip = pick(name);
    if (ip) return ip;
  }
  for (const [name, addrs] of Object.entries(ifs)) {
    if (skip.test(name)) continue;
    for (const a of addrs ?? []) {
      const family = String(a.family);
      if ((family === "IPv4" || family === "4") && !a.internal) return a.address;
    }
  }
  return "";
}
function lutPaths() {
  const host2 = existsSync5(hostIniPath()) ? parseIniFile(hostIniPath()) : {};
  const raw = iniGet(host2, "NextionDriver", "DataFilesPath", "/usr/local/etc/");
  const dir = raw.replace(/[/\\]+$/, "") || "/usr/local/etc";
  return [dir, "/usr/local/etc", join6(dataDir3()), join6(ROOT5, "deploy", "mmdvm")];
}
function findLutFile(name) {
  for (const dir of lutPaths()) {
    const p = join6(dir, name);
    if (existsSync5(p)) return p;
  }
  return "";
}
function loadLut(path2, kind) {
  const st = statSync(path2);
  const prev = lutCache.get(path2);
  if (prev && prev.mtime === st.mtimeMs && prev.size === st.size) return prev;
  const byId = /* @__PURE__ */ new Map();
  const byCall = /* @__PURE__ */ new Map();
  if (st.size > 0 && st.size <= LUT_MAX_BYTES) {
    const text = readFileSync4(path2, "utf8");
    for (const line of text.split(/\r?\n/)) {
      if (!line || line.startsWith("#")) continue;
      const cols = line.split(/[,;\t]/);
      const id = (cols[0] ?? "").trim();
      if (!id || !/^\d+$/.test(id)) continue;
      if (kind === "groups") {
        const name2 = (cols[1] ?? "").trim();
        if (name2) byId.set(id, name2);
        continue;
      }
      const call = (cols[1] ?? "").trim().toUpperCase();
      const name = (cols[2] ?? "").trim();
      if (name) byId.set(id, name);
      if (call && name) byCall.set(call, name);
    }
  }
  const next = { mtime: st.mtimeMs, size: st.size, byId, byCall };
  lutCache.set(path2, next);
  return next;
}
function lookupUser(callOrId) {
  const path2 = findLutFile("users.csv");
  if (!path2) return "";
  try {
    const lut = loadLut(path2, "users");
    const raw = callOrId.trim();
    if (/^\d+$/.test(raw)) return lut.byId.get(raw) ?? "";
    return lut.byCall.get(raw.toUpperCase()) ?? "";
  } catch {
    return "";
  }
}
function lookupGroup(target) {
  const path2 = findLutFile("groups.txt");
  if (!path2) return "";
  const id = (target.match(/\d{2,}/) ?? [])[0] ?? "";
  if (!id) return "";
  try {
    return loadLut(path2, "groups").byId.get(id) ?? "";
  } catch {
    return "";
  }
}
function heardPage(mode) {
  const m = mode.toUpperCase();
  if (m.startsWith("DMR")) return "dmr";
  if (m.startsWith("D-STAR") || m.startsWith("DSTAR")) return "dstar";
  if (m.startsWith("YSF") || m.includes("FUSION")) return "ysf";
  if (m.startsWith("P25")) return "p25";
  if (m.startsWith("NXDN")) return "nxdn";
  if (m.startsWith("M17")) return "m17";
  if (m.startsWith("POCSAG")) return "pocsag";
  return "idle";
}
function heardSlot(mode) {
  const m = mode.match(/slot\s+(\d)/i);
  return m ? Number(m[1]) : null;
}
function toQso(row) {
  return {
    mode: row.mode,
    slot: heardSlot(row.mode),
    src: row.src,
    callsign: row.callsign,
    name: lookupUser(row.callsign),
    target: row.target,
    tgName: lookupGroup(row.target),
    ber: row.ber,
    rssi: row.rssi,
    loss: row.loss
  };
}
async function buildNextion(cfg, heard, hostRunning) {
  const live3 = heard.filter((r) => !r.duration).slice(0, 2);
  const page = hostRunning && live3[0] ? heardPage(live3[0].mode) : "idle";
  let status = "MMDVM IDLE";
  if (!hostRunning) status = "MMDVM IDLE";
  else if (live3[0]) status = `${live3[0].src === "RF" ? "RF" : "net"} ${live3[0].callsign}`;
  let cpuTempC = null;
  let diskFreePct = null;
  if (linux()) {
    try {
      const hs = await hostStatus();
      cpuTempC = hs.cpuTempC;
      if (hs.diskTotalBytes > 0) diskFreePct = Math.round(hs.diskFreeBytes / hs.diskTotalBytes * 100);
    } catch {
    }
  }
  return {
    page,
    status,
    callsign: cfg.callsign,
    dmrId: cfg.dmrId,
    ip: lanIpv4(),
    location: cfg.location,
    rxHz: cfg.rxHz,
    txHz: cfg.txHz,
    cpuTempC,
    diskFreePct,
    duplex: cfg.duplex,
    qso: live3.map(toQso)
  };
}
async function writeProtected(dest, body) {
  const dir = dataDir3();
  mkdirSync3(dir, { recursive: true });
  const localName = localNameForDest(dest);
  let target = dest;
  if (dest.includes("deploy\\mmdvm") || dest.includes("deploy/mmdvm")) {
    target = join6(dir, localName);
  }
  const tmp = join6(dir, `.${localName}.${process.pid}.tmp`);
  writeFileSync3(tmp, body, "utf8");
  if (linux() && target.startsWith("/etc/") && existsSync5(HELPER2)) {
    const out = await helper("install-ini", tmp, target);
    if (!out) {
      try {
        writeFileSync3(target, body, "utf8");
      } catch {
        renameSync3(tmp, join6(dir, localName));
        return;
      }
    }
    try {
      writeFileSync3(join6(dir, localName), body, "utf8");
    } catch {
    }
    try {
      if (existsSync5(tmp)) unlinkSync(tmp);
    } catch {
    }
    return;
  }
  mkdirSync3(dirname5(target), { recursive: true });
  renameSync3(tmp, target);
}
async function writeDstarConf(primary, body) {
  await writeProtected(primary, body);
  const noext = primary.endsWith(".conf") ? primary.slice(0, -5) : primary;
  const withConf = primary.endsWith(".conf") ? primary : `${primary}.conf`;
  for (const extra of [noext, withConf]) {
    if (extra === primary) continue;
    try {
      writeFileSync3(extra, body, "utf8");
    } catch {
    }
  }
}
function upgradeHostDisplaySections(hostPath) {
  if (!existsSync5(hostPath) || !existsSync5(shippedHostIni())) return;
  const host2 = parseIniFile(hostPath);
  const shipped = parseIniFile(shippedHostIni());
  let changed = false;
  for (const sec of ["Nextion", "OLED", "Transparent Data", "NextionDriver", "TFT Serial", "HD44780", "LCDproc"]) {
    if (!host2[sec] && shipped[sec]) {
      host2[sec] = { ...shipped[sec] };
      changed = true;
    }
  }
  const display = host2.General?.Display ?? "";
  if ((!display || display === "None") && (host2.Nextion || shipped.Nextion)) {
    if (!host2.General) host2.General = {};
    host2.General.Display = "Nextion";
    if (!host2.Nextion && shipped.Nextion) host2.Nextion = { ...shipped.Nextion };
    if (!host2.NextionDriver && shipped.NextionDriver) host2.NextionDriver = { ...shipped.NextionDriver };
    if (!host2["Transparent Data"] && shipped["Transparent Data"]) host2["Transparent Data"] = { ...shipped["Transparent Data"] };
    if (host2.NextionDriver) host2.NextionDriver.Enable = "1";
    if (host2["Transparent Data"]) host2["Transparent Data"].Enable = "1";
    changed = true;
  }
  if (changed) writeFileSync3(hostPath, stringifyIni(host2), "utf8");
}
function seedIfMissing() {
  const dir = dataDir3();
  mkdirSync3(dir, { recursive: true });
  const seeds = [
    ["/etc/mmdvmhost", "mmdvmhost.ini", shippedHostIni()],
    ["/etc/dmrgateway", "dmrgateway.ini", shippedGwIni()],
    ["/etc/ysfgateway", "ysfgateway.ini", shippedYsfIni()],
    ["/etc/ircddbgateway", "ircddbgateway.conf", shippedDstarConf()]
  ];
  for (const [etc, name, shipped] of seeds) {
    if (!existsSync5(etc) && !existsSync5(join6(dir, name)) && existsSync5(shipped)) {
      writeFileSync3(join6(dir, name), readFileSync4(shipped, "utf8"), "utf8");
    }
  }
  const dstarConf = join6(dir, "ircddbgateway.conf");
  const dstarNoext = join6(dir, "ircddbgateway");
  if (existsSync5(dstarConf) && !existsSync5(dstarNoext)) {
    try {
      copyFileSync(dstarConf, dstarNoext);
    } catch {
    }
  }
  const hostPath = hostIniPath();
  if (!hostPath.includes(`${join6("deploy", "mmdvm")}`)) upgradeHostDisplaySections(hostPath);
}
async function mmdvmStatus() {
  seedIfMissing();
  const cfg = configFromFiles();
  const hostBin = hostBinary();
  const gwBin = gatewayBinary();
  const ysfBin = ysfBinary();
  const dstarBin = dstarBinary();
  const nxBin = nextionBinary();
  const hostIni = hostIniPath();
  const gwIni = gatewayIniPath();
  const ysfIni = ysfIniPath();
  const dstarIni = dstarIniPath();
  const logs = logDir();
  const heard = parseLastHeard(readLogTail(logs, "MMDVM"));
  const hostRunning = await unitActive("mmdvmhost");
  const gatewayRunning = await unitActive("dmrgateway");
  const ysfRunning = await unitActive("ysfgateway");
  const dstarRunning = await unitActive("ircddbgateway");
  const nextionRunning = await unitActive("nextiondriver");
  const paused = readPaused();
  const onAppliance = linux();
  const installed = Boolean(hostBin) || existsSync5(hostIni);
  const nextion = await buildNextion(cfg, heard, hostRunning);
  return {
    ...cfg,
    ok: hostRunning,
    installed,
    appliance: onAppliance,
    hostRunning,
    gatewayRunning,
    ysfRunning,
    dstarRunning,
    nextionRunning,
    hostBinary: hostBin,
    gatewayBinary: gwBin,
    ysfBinary: ysfBin,
    dstarBinary: dstarBin,
    nextionBinary: nxBin,
    hostIni,
    gatewayIni: gwIni,
    ysfIni,
    dstarIni,
    logDir: logs,
    tx: currentTx(heard),
    currentMode: heard[0]?.mode ?? "",
    lastHeard: heard,
    nextion,
    paused,
    // Só alerta de binário ausente no Pi; no Windows/dev a console edita INI sem Host local.
    error: hostBin || !onAppliance ? "" : "MMDVM Host n\xE3o est\xE1 neste host \u2014 instale o bin\xE1rio WPSD/g4klx em /usr/local/bin/MMDVMHost"
  };
}
function pickConfig(body) {
  const cur = configFromFiles();
  const str = (k, fb) => typeof body[k] === "string" ? String(body[k]) : fb;
  const num2 = (k, fb) => {
    const n = Number(body[k]);
    return Number.isFinite(n) ? n : fb;
  };
  const modes = { ...cur.modes };
  if (body.modes && typeof body.modes === "object") {
    for (const mode of MMDVM_MODES) {
      const v = body.modes[mode];
      if (typeof v === "boolean") modes[mode] = v;
    }
  }
  let networks = cur.networks;
  if (Array.isArray(body.networks)) {
    networks = cur.networks.map((n) => {
      const hit = body.networks.find((x) => x && (x.id === n.id || x.section === n.section));
      if (!hit) return n;
      return {
        ...n,
        name: typeof hit.name === "string" ? hit.name : n.name,
        enabled: typeof hit.enabled === "boolean" ? hit.enabled : n.enabled,
        address: typeof hit.address === "string" ? hit.address : n.address,
        port: Number.isFinite(Number(hit.port)) ? Number(hit.port) : n.port,
        password: typeof hit.password === "string" ? hit.password : n.password
      };
    });
  }
  return {
    callsign: str("callsign", cur.callsign),
    dmrId: str("dmrId", cur.dmrId),
    duplex: typeof body.duplex === "boolean" ? body.duplex : cur.duplex,
    rxHz: num2("rxHz", cur.rxHz),
    txHz: num2("txHz", cur.txHz),
    colorCode: num2("colorCode", cur.colorCode),
    latitude: str("latitude", cur.latitude),
    longitude: str("longitude", cur.longitude),
    location: str("location", cur.location),
    modemBoard: (() => {
      const id = str("modemBoard", cur.modemBoard);
      return MMDVM_BOARD_PRESETS.some((p) => p.id === id) ? id : cur.modemBoard;
    })(),
    modemPort: str("modemPort", cur.modemPort),
    uartSpeed: num2("uartSpeed", cur.uartSpeed),
    remotePort: num2("remotePort", cur.remotePort),
    dstarReflector: str("dstarReflector", cur.dstarReflector).toUpperCase(),
    dstarModule: str("dstarModule", cur.dstarModule).toUpperCase().slice(0, 1) || "B",
    ysfStartup: str("ysfStartup", cur.ysfStartup),
    displayType: (() => {
      const d = str("displayType", cur.displayType);
      if (d === "Nextion" || d === "OLED" || d === "None") return d;
      return cur.displayType;
    })(),
    displayPort: str("displayPort", cur.displayPort),
    screenLayout: num2("screenLayout", cur.screenLayout),
    brightness: num2("brightness", cur.brightness),
    idleBrightness: num2("idleBrightness", cur.idleBrightness),
    nextionDriver: typeof body.nextionDriver === "boolean" ? body.nextionDriver : cur.nextionDriver,
    oledType: num2("oledType", cur.oledType),
    modes,
    networks
  };
}
async function mmdvmSave(body) {
  seedIfMissing();
  const hostPath = hostIniPath();
  const gwPath = gatewayIniPath();
  const ysfPath = ysfIniPath();
  const dstarPath = dstarIniPath();
  const host2 = parseIniFile(existsSync5(hostPath) ? hostPath : shippedHostIni());
  const gw = parseIniFile(existsSync5(gwPath) ? gwPath : shippedGwIni());
  const ysf = parseIniFile(existsSync5(ysfPath) ? ysfPath : shippedYsfIni());
  const dstar = parseConfFile(existsSync5(dstarPath) ? dstarPath : shippedDstarConf());
  const cfg = pickConfig(body);
  const idNum = Number(String(cfg.dmrId ?? "").replace(/\D/g, "") || "0");
  if (!Number.isFinite(idNum) || idNum <= 1e3) {
    const st = await mmdvmStatus();
    return { ...st, error: "Id DMR deve ser maior que 1000 (n\xE3o use 0 / 0000000)" };
  }
  applyConfig(host2, gw, ysf, dstar, cfg);
  await writeProtected(hostPath, stringifyIni(host2));
  await writeProtected(gwPath, stringifyIni(gw));
  await writeProtected(ysfPath, stringifyIni(ysf));
  await writeDstarConf(dstarPath, stringifyConf(dstar, "# Ham Cockpit ircDDBGateway"));
  if (linux()) {
    if (cfg.displayType === "Nextion" && cfg.nextionDriver) await controlUnit("restart", "nextiondriver");
    else await controlUnit("stop", "nextiondriver");
  }
  return mmdvmStatus();
}
async function mmdvmControl(action) {
  if (linux()) {
    const out = await helper(action, "all");
    if (!out) await controlUnit(action, "all");
  }
  if (action === "start" || action === "restart") writePaused(emptyPaused());
  return mmdvmStatus();
}
async function controlUnit(action, target) {
  if (!linux()) return;
  const map = {
    host: "host",
    mmdvmhost: "host",
    dmrgateway: "dmr",
    ysfgateway: "ysf",
    ircddbgateway: "dstar",
    nextiondriver: "nextion",
    all: "all"
  };
  const out = await helper(action, map[target] || "all");
  if (out) return;
  const units = target === "all" ? [
    "nextiondriver.service",
    "mmdvmhost.service",
    "dmrgateway.service",
    "ysfgateway.service",
    "ircddbgateway.service"
  ] : target === "host" ? ["mmdvmhost.service"] : [`${target}.service`];
  for (const u of units) {
    try {
      await execFileAsync8("systemctl", [action, u], { timeout: 15e3, windowsHide: true });
    } catch {
    }
  }
}
async function mmdvmModePause(mode, pause) {
  const id = mode.toLowerCase();
  if (!MMDVM_MODES.includes(id)) {
    const st = await mmdvmStatus();
    return { ...st, error: `modo inv\xE1lido: ${mode}` };
  }
  seedIfMissing();
  const paused = readPaused();
  paused[id] = pause;
  writePaused(paused);
  const target = modeGatewayTarget(id);
  if (target !== "host") {
    await controlUnit(pause ? "stop" : "start", target);
  } else {
    const hostPath = hostIniPath();
    const host2 = parseIniFile(existsSync5(hostPath) ? hostPath : shippedHostIni());
    const permanent = configFromFiles().modes[id];
    const value = pause ? "0" : permanent ? "1" : "0";
    setKv(host2, MODE_INI[id].section, "Enable", value);
    setKv(host2, MODE_INI[id].net, "Enable", value);
    await writeProtected(hostPath, stringifyIni(host2));
    await controlUnit("restart", "host");
  }
  return mmdvmStatus();
}
async function mmdvmModeResumeAll() {
  const paused = readPaused();
  for (const mode of MMDVM_MODES) {
    if (paused[mode]) await mmdvmModePause(mode, false);
  }
  writePaused(emptyPaused());
  return mmdvmStatus();
}
async function mmdvmNetworkSet(body) {
  seedIfMissing();
  const gwPath = gatewayIniPath();
  const gw = parseIniFile(existsSync5(gwPath) ? gwPath : shippedGwIni());
  const cur = configFromFiles();
  const hit = cur.networks.find((n) => n.id === body.id || n.section === body.section);
  if (!hit) {
    const st = await mmdvmStatus();
    return { ...st, error: "rede DMR desconhecida" };
  }
  if (typeof body.enabled !== "boolean") {
    const st = await mmdvmStatus();
    return { ...st, error: "enabled obrigat\xF3rio" };
  }
  setKv(gw, hit.section, "Enabled", body.enabled ? "1" : "0");
  await writeProtected(
    gwPath.startsWith("/etc/") ? "/etc/dmrgateway" : join6(dataDir3(), "dmrgateway.ini"),
    stringifyIni(gw)
  );
  await controlUnit("restart", "dmrgateway");
  return mmdvmStatus();
}
async function mmdvmLink(body) {
  seedIfMissing();
  const mode = String(body.mode || "").toLowerCase();
  const target = String(body.target || "").trim();
  if (mode === "ysf") {
    const ysfPath = ysfIniPath();
    const ysf = parseIniFile(existsSync5(ysfPath) ? ysfPath : shippedYsfIni());
    setKv(ysf, "Network", "Startup", target);
    await writeProtected(ysfPath, stringifyIni(ysf));
    await controlUnit("restart", "ysfgateway");
    return mmdvmStatus();
  }
  if (mode === "dstar") {
    const dstarPath = dstarIniPath();
    const dstar = parseConfFile(existsSync5(dstarPath) ? dstarPath : shippedDstarConf());
    const mod = String(body.module || configFromFiles().dstarModule || "B").toUpperCase().replace(/[^A-Z]/g, "").slice(0, 1) || "B";
    const reflector = target.toUpperCase().slice(0, 8);
    dstar.reflector1 = reflector;
    dstar.atStartup1 = reflector ? "1" : "0";
    dstar.reconnect1 = reflector ? "2" : "0";
    const hostPath = hostIniPath();
    const host2 = parseIniFile(existsSync5(hostPath) ? hostPath : shippedHostIni());
    setKv(host2, "D-Star", "Module", mod);
    await writeProtected(hostPath, stringifyIni(host2));
    await writeDstarConf(dstarPath, stringifyConf(dstar, "# Ham Cockpit ircDDBGateway"));
    await controlUnit("restart", "ircddbgateway");
    if (reflector) {
      await remoteTcp(7643, `link ${reflector} ${mod}`).catch(() => void 0);
    }
    return mmdvmStatus();
  }
  const st = await mmdvmStatus();
  return { ...st, error: "mode deve ser ysf ou dstar" };
}
function remoteTcp(port, line) {
  return new Promise((resolve) => {
    const sock2 = createConnection({ host: "127.0.0.1", port, timeout: 2500 });
    let reply = "";
    let settled = false;
    const done = (ok, error3) => {
      if (settled) return;
      settled = true;
      try {
        sock2.destroy();
      } catch {
      }
      resolve({ ok, reply: reply.trim(), error: error3 });
    };
    sock2.on("data", (d) => {
      reply += d.toString("utf8");
    });
    sock2.on("connect", () => {
      sock2.write(`${line}
`);
      setTimeout(() => done(true), 500);
    });
    sock2.on("error", (err) => done(false, err.message));
    sock2.on("timeout", () => done(Boolean(reply.trim()), reply.trim() ? void 0 : "timeout"));
  });
}
async function mmdvmRemote(cmd) {
  const port = configFromFiles().remotePort || 7642;
  let line = cmd.replace(/[\r\n]/g, " ").trim();
  if (!line) return { ok: false, reply: "", error: "comando vazio" };
  const tgOnly = line.match(/^tg(?:\s+|:)(\d{1,8})(?:\s+(\d))?$/i);
  const talkgroup = line.match(/^talkgroup\s+(\d)\s+(\d{1,8})$/i);
  if (tgOnly) {
    const slot = tgOnly[2] || "2";
    line = `talkgroup ${slot} ${tgOnly[1]}`;
  } else if (talkgroup) {
    line = `talkgroup ${talkgroup[1]} ${talkgroup[2]}`;
  } else if (/^page\s+/i.test(line)) {
  }
  return remoteTcp(port, line);
}
var execFileAsync8, ROOT5, HELPER2, MMDVM_MODES, MMDVM_BOARD_PRESETS, MODE_INI, lutCache, LUT_MAX_BYTES;
var init_mmdvm = __esm({
  "server/mmdvm.ts"() {
    "use strict";
    init_host_status();
    execFileAsync8 = promisify8(execFile8);
    ROOT5 = join6(dirname5(fileURLToPath5(import.meta.url)), "..");
    HELPER2 = "/opt/ham-cockpit/bin/mmdvm-ctl";
    MMDVM_MODES = ["dstar", "dmr", "ysf", "p25", "nxdn", "m17", "pocsag"];
    MMDVM_BOARD_PRESETS = [
      { id: "custom", label: "Personalizado (porta/baud manuais)", port: "", uartSpeed: 0, duplex: null, slot1: null },
      { id: "mmdvmhshat", label: "MMDVM_HS_Hat (DB9MAT & DF2ET) GPIO", port: "/dev/ttyAMA0", uartSpeed: 115200, duplex: false, slot1: false },
      // WPSD Hardware=mmdvmhsdualhatgpio → MMDVM_HS_Dual_Hat (ADF7021 duplex) @ 115200 / ttyAMA0.
      // Cartão WPSD conhecido (PY2MED) era Hardware=dvmpis + Port=/dev/ttyACM0 + Duplex=0 — outro perfil; não copiar para este preset.
      { id: "mmdvmhsdualhatgpio", label: "MMDVM HS Dual (v1.3 / HAT)", port: "/dev/ttyAMA0", uartSpeed: 115200, duplex: true, slot1: true },
      { id: "mmdvmhsdualbandgpio", label: "MMDVM_HS_Dual_Band GPIO", port: "/dev/ttyAMA0", uartSpeed: 115200, duplex: false, slot1: false },
      { id: "zumspotgpio", label: "ZUMspot HAT simplex GPIO", port: "/dev/ttyAMA0", uartSpeed: 115200, duplex: false, slot1: false },
      { id: "zumspotduplexgpio", label: "ZUMspot HAT duplex GPIO", port: "/dev/ttyAMA0", uartSpeed: 115200, duplex: true, slot1: true },
      { id: "zumspotusb", label: "ZUMspot USB Stick", port: "/dev/ttyACM0", uartSpeed: 115200, duplex: false, slot1: false },
      { id: "zumspotlibre", label: "ZUMspot Libre (USB)", port: "/dev/ttyACM0", uartSpeed: 115200, duplex: false, slot1: false },
      // WPSD/Pi-Star Hardware=dvmpis → DVMEGA/STM32 GPIO simplex (Port padrão ttyAMA0; alguns hats USB usam ttyACM0).
      { id: "dvmpis", label: "DVMEGA / STM32-DVM Pi (dvmpis)", port: "/dev/ttyAMA0", uartSpeed: 115200, duplex: false, slot1: false },
      { id: "stm32dvm", label: "STM32-DVM / MMDVM_HS HAT GPIO", port: "/dev/ttyAMA0", uartSpeed: 115200, duplex: null, slot1: null },
      { id: "stm32usb", label: "STM32-DVM (USB)", port: "/dev/ttyUSB0", uartSpeed: 115200, duplex: null, slot1: null },
      { id: "nanodv", label: "NanoDV / NanoPi AIR GPIO", port: "/dev/ttyAMA0", uartSpeed: 115200, duplex: false, slot1: false },
      { id: "rptrbldrv3v4v5", label: "Repeater Builder v3/v4/v5 115200 GPIO", port: "/dev/ttyAMA0", uartSpeed: 115200, duplex: false, slot1: false },
      { id: "rptrbldrv3v4v5hs", label: "Repeater Builder v3/v4/v5 460800 GPIO", port: "/dev/ttyAMA0", uartSpeed: 460800, duplex: false, slot1: false },
      { id: "opengd77", label: "OpenGD77 hotspot (USB)", port: "/dev/ttyACM0", uartSpeed: 115200, duplex: false, slot1: false }
    ];
    MODE_INI = {
      dstar: { section: "D-Star", net: "D-Star Network" },
      dmr: { section: "DMR", net: "DMR Network" },
      ysf: { section: "System Fusion", net: "System Fusion Network" },
      p25: { section: "P25", net: "P25 Network" },
      nxdn: { section: "NXDN", net: "NXDN Network" },
      m17: { section: "M17", net: "M17 Network" },
      pocsag: { section: "POCSAG", net: "POCSAG Network" }
    };
    lutCache = /* @__PURE__ */ new Map();
    LUT_MAX_BYTES = 12 * 1024 * 1024;
  }
});

// server/ldg.ts
var ldg_exports = {};
__export(ldg_exports, {
  LDG_MODELS: () => LDG_MODELS,
  ldgCmd: () => ldgCmd,
  ldgConnect: () => ldgConnect,
  ldgDisconnect: () => ldgDisconnect,
  ldgPeek: () => ldgPeek,
  ldgSave: () => ldgSave,
  ldgStatus: () => ldgStatus
});
import { existsSync as existsSync6, mkdirSync as mkdirSync4, readFileSync as readFileSync5, renameSync as renameSync4, writeFileSync as writeFileSync4 } from "node:fs";
import net from "node:net";
import { dirname as dirname6, join as join7 } from "node:path";
import { fileURLToPath as fileURLToPath6 } from "node:url";
function dataDir4() {
  if (existsSync6("/opt/ham-cockpit")) {
    mkdirSync4(OPT_DIR3, { recursive: true });
    return OPT_DIR3;
  }
  const local = join7(ROOT6, "data", "ldg");
  mkdirSync4(local, { recursive: true });
  return local;
}
function jsonPath2() {
  return join7(dataDir4(), "ldg.json");
}
function writeAtomic3(file, body) {
  const tmp = `${file}.${process.pid}.tmp`;
  writeFileSync4(tmp, body, { encoding: "utf8" });
  renameSync4(tmp, file);
}
function asModel(v) {
  return LDG_MODELS.includes(v) ? v : "at1000pro2";
}
function loadSaved() {
  try {
    const raw = JSON.parse(readFileSync5(jsonPath2(), "utf8"));
    return {
      model: asModel(raw.model),
      port: String(raw.port || ""),
      autoConnect: raw.autoConnect !== false
    };
  } catch {
    return { model: "at1000pro2", port: "", autoConnect: true };
  }
}
function persist2() {
  writeAtomic3(jsonPath2(), `${JSON.stringify({ model: saved.model, port: saved.port, autoConnect: saved.autoConnect }, null, 2)}
`);
}
function swrOf(fwd, ref) {
  if (fwd <= 0.2) return 1;
  const rho = Math.sqrt(Math.max(0, Math.min(0.98, ref / fwd)));
  return (1 + rho) / (1 - rho);
}
function watts(raw, maxW) {
  if (!Number.isFinite(raw) || raw <= 0) return 0;
  if (raw <= maxW * 1.25) return raw;
  return raw / 65535 * maxW;
}
async function resolveEndpoint() {
  const cfg = await loadSer2net();
  const svc = cfg.services.find((x) => x.device === "ldg");
  if (!svc) return null;
  return { host: cfg.bind || "127.0.0.1", port: svc.tcpPort };
}
function tcpSession(host2, port, send, timeoutMs) {
  return new Promise((resolve) => {
    const sock2 = new net.Socket();
    const chunks = [];
    let settled = false;
    const finish2 = (ok, error3) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      sock2.destroy();
      resolve({ ok, buf: Buffer.concat(chunks), error: error3 });
    };
    const timer = setTimeout(() => finish2(true), timeoutMs);
    sock2.once("error", (err) => finish2(false, err.message));
    sock2.on("data", (d) => chunks.push(d));
    sock2.connect(port, host2, () => {
      if (send?.length) sock2.write(send);
    });
  });
}
async function trx(cmdByte, timeoutMs) {
  const ep = await resolveEndpoint();
  if (!ep) return { ok: false, rx: "", buf: Buffer.alloc(0), error: "noport" };
  live.port = `${ep.host}:${ep.port}`;
  const send = cmdByte ? Buffer.from(` ${cmdByte}`, "ascii") : null;
  const r = await tcpSession(ep.host, ep.port, send, timeoutMs);
  const sim = !r.ok && /ECONNREFUSED|ENOTFOUND|EHOSTUNREACH|connect /i.test(r.error || "");
  return {
    ok: r.ok,
    rx: r.buf.toString("latin1"),
    buf: r.buf,
    error: sim ? "sim" : r.error
  };
}
function enqueue(fn) {
  const run4 = chain.then(fn, fn);
  chain = run4.then(
    () => void 0,
    () => void 0
  );
  return run4;
}
function snap2() {
  const meta = META[live.model];
  return {
    ok: true,
    ...live,
    serialOk: meta.serial,
    maxW: meta.maxW,
    label: meta.label,
    folder: dataDir4(),
    baud: 38400
  };
}
function applyLocal(cmd) {
  if (cmd === "ant") live.ant = live.ant === 1 ? 2 : 1;
  if (cmd === "bypass") {
    live.mode = "BYPASS";
    live.match = "";
  }
  if (cmd === "auto") {
    live.mode = "AUTO";
  }
  if (cmd === "manual") {
    live.mode = "MANUAL";
  }
  if (cmd === "mem" || cmd === "full") {
    live.tuning = true;
    live.mode = "AUTO";
    live.match = "";
    live.phase = "tuning";
    if (tuneTimer) clearTimeout(tuneTimer);
    tuneTimer = setTimeout(() => {
      live.tuning = false;
      live.match = "T";
      live.phase = live.connected ? "ready" : "idle";
      live.lastRx = "T";
    }, 1200);
  }
}
function parseReply(cmd, rx2) {
  const t = rx2.replace(/\s+/g, "");
  live.lastRx = t.slice(-24);
  if (cmd === "ant") {
    if (t.includes("2")) live.ant = 2;
    else if (t.includes("1")) live.ant = 1;
  }
  if (cmd === "bypass" && t.includes("P")) live.mode = "BYPASS";
  if (cmd === "auto" && t.includes("A")) live.mode = "AUTO";
  if (cmd === "manual" && /M/.test(t)) live.mode = "MANUAL";
  if (cmd === "mem" || cmd === "full") {
    live.tuning = false;
    live.phase = "ready";
    if (t.includes("F") && !t.endsWith("T")) live.match = t.includes("T") ? "T" : "F";
    const last = t.replace(/[^TMF]/g, "").slice(-1);
    if (last === "T" || last === "M" || last === "F") live.match = last;
    if (live.match && live.match !== "F") live.mode = "AUTO";
  }
  if (cmd === "sync" && t.includes(SYNC_MARK)) {
    live.hardware = true;
    live.phase = "ready";
    live.error = "";
  }
}
function parseFramesBuf(buf) {
  const maxW = META[live.model].maxW;
  for (let i = 0; i + 8 <= buf.length; i++) {
    if (buf[i + 6] !== 59 || buf[i + 7] !== 59) continue;
    const fwd = watts(buf.readUInt16BE(i), maxW);
    const ref = watts(buf.readUInt16BE(i + 2), maxW);
    live.fwd = Math.round(fwd * 10) / 10;
    live.ref = Math.round(ref * 10) / 10;
    live.swr = Math.round(swrOf(live.fwd, live.ref) * 100) / 100;
  }
}
function parseFrames(hexOrAscii) {
  const buf = Buffer.from(hexOrAscii, /[^0-9a-fA-F]/.test(hexOrAscii) ? "latin1" : "hex");
  parseFramesBuf(buf);
}
function ldgStatus() {
  return snap2();
}
async function ldgSave(body) {
  if (typeof body.model === "string") saved.model = asModel(body.model);
  if (typeof body.autoConnect === "boolean") saved.autoConnect = body.autoConnect;
  persist2();
  live.model = saved.model;
  live.autoConnect = saved.autoConnect;
  return snap2();
}
async function ldgConnect(body = {}) {
  return enqueue(async () => {
    if (typeof body.model === "string") saved.model = asModel(body.model);
    persist2();
    live.model = saved.model;
    live.autoConnect = saved.autoConnect;
    live.error = "";
    live.phase = "connecting";
    const meta = META[live.model];
    if (!meta.serial) {
      live.connected = true;
      live.hardware = false;
      live.phase = "ready";
      live.error = "noserial";
      return snap2();
    }
    const r = await trx("Z", 2e3);
    if (live.port) {
      saved.port = live.port;
      persist2();
    }
    if (r.error === "noport") {
      live.connected = false;
      live.hardware = false;
      live.phase = "error";
      live.error = "noport";
      return snap2();
    }
    if (r.ok && r.rx.includes(SYNC_MARK)) {
      live.connected = true;
      live.hardware = true;
      live.phase = "ready";
      live.lastRx = r.rx;
      return snap2();
    }
    live.connected = true;
    live.hardware = false;
    live.phase = "ready";
    live.error = r.error === "sim" || !r.ok ? r.error || "sim" : "sync";
    live.lastRx = r.rx;
    return snap2();
  });
}
async function ldgDisconnect() {
  live.connected = false;
  live.hardware = false;
  live.tuning = false;
  live.phase = "idle";
  live.error = "";
  live.fwd = 0;
  live.ref = 0;
  live.swr = 1;
  return snap2();
}
async function ldgCmd(cmd) {
  const c = cmd;
  if (!CMD_BYTE[c]) {
    live.error = "cmd";
    return snap2();
  }
  return enqueue(async () => {
    applyLocal(c);
    if (!live.connected) live.connected = true;
    if (!live.hardware || !META[live.model].serial) return snap2();
    const timeout = c === "mem" || c === "full" ? 16e3 : 2500;
    if (c === "mem" || c === "full") {
      live.tuning = true;
      live.phase = "tuning";
    }
    const r = await trx(CMD_BYTE[c], timeout);
    if (r.ok && r.rx) parseReply(c, r.rx);
    else if (!r.ok && r.error && r.error !== "sim" && r.error !== "noport") live.error = r.error;
    if (r.buf.length) parseFramesBuf(r.buf);
    return snap2();
  });
}
async function ldgPeek() {
  if (!live.connected || !live.hardware) return snap2();
  const r = await trx(null, 400);
  if (r.ok && r.buf.length) parseFramesBuf(r.buf);
  else if (r.ok && r.rx) parseFrames(r.rx);
  return snap2();
}
var ROOT6, OPT_DIR3, SYNC_MARK, LDG_MODELS, META, CMD_BYTE, saved, live, chain, tuneTimer;
var init_ldg = __esm({
  "server/ldg.ts"() {
    "use strict";
    init_ser2net_store();
    ROOT6 = join7(dirname6(fileURLToPath6(import.meta.url)), "..");
    OPT_DIR3 = "/opt/ham-cockpit/ldg";
    SYNC_MARK = "AzAz";
    LDG_MODELS = ["at100pro2", "at600pro2", "at1000pro2"];
    META = {
      at100pro2: { label: "AT-100ProII", maxW: 125, serial: false },
      at600pro2: { label: "AT-600ProII", maxW: 600, serial: true },
      at1000pro2: { label: "AT-1000ProII", maxW: 1e3, serial: true }
    };
    CMD_BYTE = {
      mem: "T",
      full: "F",
      bypass: "P",
      auto: "C",
      manual: "M",
      ant: "A",
      sync: "Z"
    };
    saved = loadSaved();
    live = {
      model: saved.model,
      port: saved.port,
      baud: 38400,
      autoConnect: saved.autoConnect,
      connected: false,
      hardware: false,
      phase: "idle",
      error: "",
      ant: 1,
      mode: "AUTO",
      match: "",
      tuning: false,
      fwd: 0,
      ref: 0,
      swr: 1,
      lastRx: ""
    };
    chain = Promise.resolve();
    tuneTimer = null;
  }
});

// server/lp100a.ts
var lp100a_exports = {};
__export(lp100a_exports, {
  lp100aAlarmSwr: () => lp100aAlarmSwr,
  lp100aCmd: () => lp100aCmd,
  lp100aConnect: () => lp100aConnect,
  lp100aDisconnect: () => lp100aDisconnect,
  lp100aPeek: () => lp100aPeek,
  lp100aSave: () => lp100aSave,
  lp100aStatus: () => lp100aStatus
});
import { existsSync as existsSync7, mkdirSync as mkdirSync5, readFileSync as readFileSync6, renameSync as renameSync5, writeFileSync as writeFileSync5 } from "node:fs";
import net2 from "node:net";
import { dirname as dirname7, join as join8 } from "node:path";
import { fileURLToPath as fileURLToPath7 } from "node:url";
function dataDir5() {
  if (existsSync7("/opt/ham-cockpit")) {
    mkdirSync5(OPT_DIR4, { recursive: true });
    return OPT_DIR4;
  }
  const local = join8(ROOT7, "data", "lp100a");
  mkdirSync5(local, { recursive: true });
  return local;
}
function jsonPath3() {
  return join8(dataDir5(), "lp100a.json");
}
function writeAtomic4(file, body) {
  const tmp = `${file}.${process.pid}.tmp`;
  writeFileSync5(tmp, body, { encoding: "utf8" });
  renameSync5(tmp, file);
}
function loadSaved2() {
  try {
    const raw = JSON.parse(readFileSync6(jsonPath3(), "utf8"));
    return { autoConnect: raw.autoConnect !== false };
  } catch {
    return { autoConnect: true };
  }
}
function persist3() {
  writeAtomic4(jsonPath3(), `${JSON.stringify({ autoConnect: saved2.autoConnect }, null, 2)}
`);
}
function reflected(fwd, swr) {
  if (!(fwd > 0) || !(swr > 1)) return 0;
  const rho = (swr - 1) / (swr + 1);
  return fwd * rho * rho;
}
function dbmOf(watts2) {
  if (!(watts2 > 0)) return -99;
  return 10 * Math.log10(watts2 * 1e3);
}
async function resolveEndpoint2() {
  const cfg = await loadSer2net();
  const svc = cfg.services.find((x) => x.device === "lp100a");
  if (!svc) return null;
  return { host: cfg.bind || "127.0.0.1", port: svc.tcpPort };
}
function asMeter(n) {
  if (n === 1) return "PEAK";
  if (n === 2) return "TUNE";
  return "AVG";
}
function asRange(n) {
  if (n === 1) return "MID";
  if (n === 2) return "LOW";
  return "HIGH";
}
function parseFrame(raw) {
  const line = raw.replace(/[\r\n]+/g, "").trim();
  if (!line.startsWith(";")) return false;
  const parts = line.slice(1).split(",").map((p) => p.trim());
  if (parts.length < 7) return false;
  const fwd = Number(parts[0]);
  const z = Number(parts[1]);
  const phaseDeg = Number(parts[2]);
  const alarm = Math.trunc(Number(parts[3]));
  const callsign = (parts[4] || "").replace(/\s+$/g, "");
  const rangeN = Math.trunc(Number(parts[5]));
  const meterN = Math.trunc(Number(parts[6]));
  const dbm = parts.length >= 8 ? Number(parts[7]) : dbmOf(fwd);
  const swr = parts.length >= 9 ? Number(parts[8]) : 1;
  if (!Number.isFinite(fwd)) return false;
  live2.fwd = Math.round(fwd * 100) / 100;
  live2.z = Number.isFinite(z) ? Math.round(z * 10) / 10 : 0;
  live2.phaseDeg = Number.isFinite(phaseDeg) ? Math.round(phaseDeg * 10) / 10 : 0;
  live2.alarm = alarm >= 0 && alarm <= 5 ? alarm : 0;
  live2.callsign = callsign.slice(0, 12);
  live2.range = asRange(rangeN);
  live2.meter = asMeter(meterN);
  live2.dbm = Number.isFinite(dbm) ? Math.round(dbm * 10) / 10 : dbmOf(fwd);
  live2.swr = Number.isFinite(swr) && swr > 0 ? Math.round(swr * 100) / 100 : 1;
  live2.ref = Math.round(reflected(live2.fwd, live2.swr) * 100) / 100;
  live2.tx = live2.fwd > 0.2;
  live2.lastRx = line.slice(0, 64);
  live2.hardware = true;
  live2.phase = "ready";
  live2.error = "";
  return true;
}
function consumeRx() {
  for (; ; ) {
    const start = rx.indexOf(";");
    if (start < 0) {
      if (rx.length > 96) rx = rx.slice(-24);
      return;
    }
    if (start > 0) rx = rx.slice(start);
    const next = rx.indexOf(";", 1);
    const chunk = next >= 0 ? rx.slice(0, next) : rx;
    const commas = (chunk.match(/,/g) || []).length;
    if (commas < 6) {
      if (next >= 0) {
        rx = rx.slice(next);
        continue;
      }
      if (chunk.length > 96) rx = "";
      return;
    }
    if (next < 0 && commas < 8 && chunk.length < 52) return;
    parseFrame(chunk);
    if (next < 0) {
      rx = "";
      return;
    }
    rx = rx.slice(next);
  }
}
function enqueue2(fn) {
  const run4 = chain2.then(fn, fn);
  chain2 = run4.then(
    () => void 0,
    () => void 0
  );
  return run4;
}
function snap3() {
  return { ok: true, ...live2, baud: BAUD, folder: dataDir5() };
}
function stopPoll() {
  if (pollTimer) {
    clearInterval(pollTimer);
    pollTimer = null;
  }
}
function dropSock() {
  stopPoll();
  rx = "";
  const s = sock;
  sock = null;
  if (!s) return;
  try {
    s.removeAllListeners();
    s.destroy();
  } catch {
  }
}
function writeCmd(ch) {
  if (!sock || sock.destroyed) return false;
  try {
    sock.write(ch, "ascii");
    return true;
  } catch {
    return false;
  }
}
function startPoll() {
  stopPoll();
  const tick = () => {
    if (!sock || sock.destroyed) return;
    writeCmd("P");
  };
  tick();
  pollTimer = setInterval(tick, POLL_MS);
  pollTimer.unref?.();
}
function attachSock(s, host2, port) {
  dropSock();
  sock = s;
  rx = "";
  live2.port = `${host2}:${port}`;
  live2.connected = true;
  live2.hardware = false;
  live2.phase = "ready";
  live2.error = "";
  s.setNoDelay(true);
  s.on("data", (buf) => {
    rx += buf.toString("latin1");
    consumeRx();
  });
  s.on("error", (err) => {
    live2.error = err.message;
    live2.phase = "error";
    live2.hardware = false;
    live2.connected = false;
    dropSock();
  });
  s.on("close", () => {
    if (sock !== s) return;
    sock = null;
    stopPoll();
    live2.connected = false;
    live2.hardware = false;
    if (live2.phase !== "idle") live2.phase = "error";
  });
  startPoll();
}
function lp100aStatus() {
  return snap3();
}
function lp100aAlarmSwr(idx) {
  return ALARM_SWR[idx] ?? 0;
}
async function lp100aSave(body) {
  if (typeof body.autoConnect === "boolean") saved2.autoConnect = body.autoConnect;
  persist3();
  live2.autoConnect = saved2.autoConnect;
  return snap3();
}
async function lp100aConnect() {
  return enqueue2(async () => {
    live2.error = "";
    live2.phase = "connecting";
    live2.autoConnect = saved2.autoConnect;
    const ep = await resolveEndpoint2();
    if (!ep) {
      live2.connected = false;
      live2.hardware = false;
      live2.phase = "error";
      live2.error = "noport";
      return snap3();
    }
    live2.port = `${ep.host}:${ep.port}`;
    return await new Promise((resolve) => {
      const s = new net2.Socket();
      let settled = false;
      const finish2 = (ok, error3) => {
        if (settled) return;
        settled = true;
        if (!ok) {
          try {
            s.destroy();
          } catch {
          }
          const sim = /ECONNREFUSED|ENOTFOUND|EHOSTUNREACH|connect /i.test(error3 || "");
          live2.connected = true;
          live2.hardware = false;
          live2.phase = "ready";
          live2.error = sim ? "sim" : error3 || "sim";
          resolve(snap3());
          return;
        }
        attachSock(s, ep.host, ep.port);
        resolve(snap3());
      };
      const timer = setTimeout(() => finish2(false, "timeout"), 2500);
      s.once("error", (err) => {
        clearTimeout(timer);
        finish2(false, err.message);
      });
      s.connect(ep.port, ep.host, () => {
        clearTimeout(timer);
        finish2(true);
      });
    });
  });
}
async function lp100aDisconnect() {
  dropSock();
  live2.connected = false;
  live2.hardware = false;
  live2.phase = "idle";
  live2.error = "";
  live2.fwd = 0;
  live2.ref = 0;
  live2.swr = 1;
  live2.tx = false;
  live2.dbm = -99;
  return snap3();
}
async function lp100aCmd(cmd) {
  const c = cmd;
  if (!CMD_BYTE2[c]) {
    live2.error = "cmd";
    return snap3();
  }
  return enqueue2(async () => {
    if (!live2.connected) live2.connected = true;
    if (c === "alarm") live2.alarm = live2.alarm >= 5 ? 0 : live2.alarm + 1;
    if (c === "meter") live2.meter = live2.meter === "AVG" ? "PEAK" : live2.meter === "PEAK" ? "TUNE" : "AVG";
    if (!live2.hardware || !sock) return snap3();
    writeCmd(CMD_BYTE2[c]);
    return snap3();
  });
}
async function lp100aPeek() {
  return snap3();
}
var ROOT7, OPT_DIR4, POLL_MS, BAUD, ALARM_SWR, CMD_BYTE2, saved2, live2, sock, rx, pollTimer, chain2;
var init_lp100a = __esm({
  "server/lp100a.ts"() {
    "use strict";
    init_ser2net_store();
    ROOT7 = join8(dirname7(fileURLToPath7(import.meta.url)), "..");
    OPT_DIR4 = "/opt/ham-cockpit/lp100a";
    POLL_MS = 200;
    BAUD = 115200;
    ALARM_SWR = [0, 1.5, 2, 2.5, 3, 0];
    CMD_BYTE2 = { alarm: "A", meter: "F" };
    saved2 = loadSaved2();
    live2 = {
      port: "",
      autoConnect: saved2.autoConnect,
      connected: false,
      hardware: false,
      phase: "idle",
      error: "",
      fwd: 0,
      ref: 0,
      swr: 1,
      z: 0,
      phaseDeg: 0,
      dbm: -99,
      alarm: 0,
      callsign: "",
      range: "HIGH",
      meter: "AVG",
      tx: false,
      lastRx: ""
    };
    sock = null;
    rx = "";
    pollTimer = null;
    chain2 = Promise.resolve();
  }
});

// server/services.ts
var services_exports = {};
__export(services_exports, {
  isServiceAutostart: () => isServiceAutostart,
  servicesApplyBoot: () => servicesApplyBoot,
  servicesSetAutostart: () => servicesSetAutostart,
  servicesStatus: () => servicesStatus
});
import { execFile as execFile9 } from "node:child_process";
import { existsSync as existsSync8, mkdirSync as mkdirSync6, readFileSync as readFileSync7, renameSync as renameSync6, writeFileSync as writeFileSync6 } from "node:fs";
import { dirname as dirname8, join as join9 } from "node:path";
import { fileURLToPath as fileURLToPath8 } from "node:url";
import { promisify as promisify9 } from "node:util";
function dataDir6() {
  if (existsSync8("/opt/ham-cockpit")) {
    mkdirSync6(OPT_DIR5, { recursive: true });
    return OPT_DIR5;
  }
  const local = join9(ROOT8, "data", "services");
  mkdirSync6(local, { recursive: true });
  return local;
}
function jsonPath4() {
  return join9(dataDir6(), "boot.json");
}
function allOn() {
  return Object.fromEntries(SERVICE_IDS.map((id) => [id, true]));
}
function loadBoot() {
  const base = allOn();
  try {
    const raw = JSON.parse(readFileSync7(jsonPath4(), "utf8"));
    for (const id of SERVICE_IDS) {
      if (typeof raw[id] === "boolean") base[id] = raw[id];
    }
  } catch {
  }
  return base;
}
function persist4() {
  const tmp = `${jsonPath4()}.${process.pid}.tmp`;
  writeFileSync6(tmp, `${JSON.stringify(boot, null, 2)}
`, "utf8");
  renameSync6(tmp, jsonPath4());
}
function isServiceAutostart(id) {
  return boot[id] !== false;
}
async function helper2(cmd, id) {
  if (!existsSync8(HELPER3)) return "";
  const timeout = cmd === "start" || cmd === "stop" ? id === "wavelog" ? 18e4 : 25e3 : 8e3;
  try {
    const { stdout } = await execFileAsync9("sudo", ["-n", HELPER3, cmd, id], {
      timeout,
      windowsHide: true
    });
    return String(stdout || "").trim();
  } catch {
    return "";
  }
}
async function probeRunning(id) {
  if (id === "web") return true;
  if (id === "lextel") {
    try {
      const { lextelStatus: lextelStatus2 } = await Promise.resolve().then(() => (init_lextel(), lextel_exports));
      const st = lextelStatus2();
      return Boolean(st.connected || st.phase === "streaming" || st.phase === "connecting");
    } catch {
      return false;
    }
  }
  if (process.platform === "linux" && UNITS[id]) {
    return await helper2("is-active", id) === "active";
  }
  return false;
}
async function servicesStatus() {
  const running = await Promise.all(SERVICE_IDS.map((id) => probeRunning(id)));
  return {
    ok: true,
    folder: dataDir6(),
    items: SERVICE_IDS.map((id, i) => ({
      id,
      autostart: boot[id] !== false,
      running: Boolean(running[i]),
      unit: UNITS[id]
    })),
    error: ""
  };
}
async function servicesSetAutostart(id, autostart) {
  if (!SERVICE_IDS.includes(id)) {
    return { ...await servicesStatus(), ok: false, error: "servi\xE7o desconhecido" };
  }
  const sid = id;
  boot[sid] = Boolean(autostart);
  persist4();
  if (process.platform === "linux" && UNITS[sid]) {
    await helper2(autostart ? "enable" : "disable", sid);
    if (sid !== "web") {
      await helper2(autostart ? "start" : "stop", sid);
    }
  }
  if (sid === "radio" && autostart) {
    const { radiosResumeIcomLan: radiosResumeIcomLan2 } = await Promise.resolve().then(() => (init_radios(), radios_exports));
    void radiosResumeIcomLan2().catch(() => void 0);
  }
  if (sid === "radio" && !autostart) {
    const { radiosDisconnect: radiosDisconnect2, radiosStatus: radiosStatus2 } = await Promise.resolve().then(() => (init_radios(), radios_exports));
    const snap4 = await radiosStatus2();
    const primary = snap4.radios.find((r) => r.primary) || snap4.radios[0];
    if (primary?.connected) void radiosDisconnect2(primary.id).catch(() => void 0);
  }
  return servicesStatus();
}
async function servicesApplyBoot() {
  if (bootTried) return;
  bootTried = true;
  persist4();
  if (boot.ser2net) void helper2("start", "ser2net");
  else void helper2("stop", "ser2net");
  if (boot.wifi) void helper2("enable", "wifi");
  if (boot.bluetooth) void helper2("start", "bluetooth");
  else void helper2("stop", "bluetooth");
  if (boot.wavelog) {
    const { wavelogUp: wavelogUp2 } = await Promise.resolve().then(() => (init_wavelog_status(), wavelog_status_exports));
    void wavelogUp2().catch(() => void 0);
  }
  if (boot.wlg) {
    const { wlgUp: wlgUp2 } = await Promise.resolve().then(() => (init_wlg_status(), wlg_status_exports));
    void wlgUp2().catch(() => void 0);
  } else {
    void helper2("stop", "wlg");
  }
  if (boot.mmdvm) {
    const { mmdvmControl: mmdvmControl2 } = await Promise.resolve().then(() => (init_mmdvm(), mmdvm_exports));
    void mmdvmControl2("start").catch(() => void 0);
  }
  if (boot.radio) {
    const { radiosResumeIcomLan: radiosResumeIcomLan2 } = await Promise.resolve().then(() => (init_radios(), radios_exports));
    void radiosResumeIcomLan2().catch(() => void 0);
  }
  if (boot.lextel) {
    const { lextelAutoConnect: lextelAutoConnect2 } = await Promise.resolve().then(() => (init_lextel(), lextel_exports));
    void lextelAutoConnect2().catch(() => void 0);
  }
  if (boot.ldg) {
    const { ldgConnect: ldgConnect2, ldgStatus: ldgStatus2 } = await Promise.resolve().then(() => (init_ldg(), ldg_exports));
    const st = ldgStatus2();
    if (st.autoConnect && st.port) void ldgConnect2().catch(() => void 0);
  }
  if (boot.lp100a) {
    const { lp100aConnect: lp100aConnect2, lp100aStatus: lp100aStatus2 } = await Promise.resolve().then(() => (init_lp100a(), lp100a_exports));
    const st = lp100aStatus2();
    if (st.autoConnect && st.port) void lp100aConnect2().catch(() => void 0);
  }
}
var execFileAsync9, ROOT8, OPT_DIR5, HELPER3, UNITS, boot, bootTried;
var init_services = __esm({
  "server/services.ts"() {
    "use strict";
    init_const();
    execFileAsync9 = promisify9(execFile9);
    ROOT8 = join9(dirname8(fileURLToPath8(import.meta.url)), "..");
    OPT_DIR5 = "/opt/ham-cockpit/services";
    HELPER3 = "/opt/ham-cockpit/bin/station-svc";
    UNITS = {
      ser2net: "ser2net.service",
      wavelog: "wavelog.service",
      wlg: "waveloggate.service",
      mmdvm: "mmdvmhost.service",
      radio: "",
      spe: "ampctld@spe.service",
      hamplus: "",
      palstar: "",
      ldg: "",
      lp100a: "",
      acom: "",
      lextel: "",
      wifi: "ham-cockpit-ap.service",
      bluetooth: "bluetooth.service",
      dhcp: "",
      web: "ham-cockpit.service"
    };
    boot = loadBoot();
    bootTried = false;
  }
});

// server/lextel.ts
var lextel_exports = {};
__export(lextel_exports, {
  lextelAutoConnect: () => lextelAutoConnect,
  lextelConnect: () => lextelConnect,
  lextelDisconnect: () => lextelDisconnect,
  lextelKeepalive: () => lextelKeepalive,
  lextelLearn: () => lextelLearn,
  lextelOpenBluetooth: () => lextelOpenBluetooth,
  lextelSave: () => lextelSave,
  lextelScan: () => lextelScan,
  lextelStatus: () => lextelStatus
});
import { execFile as execFile10, spawn as spawn3 } from "node:child_process";
import { appendFileSync, createReadStream, existsSync as existsSync9, mkdirSync as mkdirSync7, readFileSync as readFileSync8, renameSync as renameSync7, unlinkSync as unlinkSync2, writeFileSync as writeFileSync7 } from "node:fs";
import { dirname as dirname9, join as join10 } from "node:path";
import { fileURLToPath as fileURLToPath9 } from "node:url";
import { promisify as promisify10 } from "node:util";
function dataDir7() {
  if (existsSync9(OPT_DIR6)) return OPT_DIR6;
  const local = join10(ROOT9, "data", "lextel");
  mkdirSync7(local, { recursive: true });
  return local;
}
function jsonPath5() {
  return join10(dataDir7(), "config.json");
}
function capturePath() {
  return join10(dataDir7(), "capture.bin");
}
function winSppScript() {
  return join10(ROOT9, "deploy", "lextel", "win-spp.ps1");
}
function loadSaved3() {
  const fallback = { addr: "", name: "", pin: "1234", channel: 1, autoConnect: true, layout: null };
  try {
    const raw = JSON.parse(readFileSync8(jsonPath5(), "utf8"));
    return {
      addr: typeof raw.addr === "string" ? raw.addr : "",
      name: typeof raw.name === "string" ? raw.name : "",
      pin: typeof raw.pin === "string" && raw.pin ? raw.pin : "1234",
      channel: Number(raw.channel) > 0 ? Number(raw.channel) : 1,
      autoConnect: raw.autoConnect !== false,
      layout: raw.layout && typeof raw.layout === "object" ? raw.layout : null
    };
  } catch {
    return fallback;
  }
}
function persist5() {
  const tmp = `${jsonPath5()}.${process.pid}.tmp`;
  writeFileSync7(tmp, JSON.stringify(saved3, null, 2), "utf8");
  renameSync7(tmp, jsonPath5());
}
function helperExists() {
  return existsSync9(HELPER4);
}
async function runHelper(args, timeout = 3e4) {
  if (!helperExists()) {
    const err = new Error("BlueZ helper ausente \u2014 o SPP Classic roda no Raspberry Pi");
    err.code = "NO_BLUEZ";
    throw err;
  }
  const { stdout, stderr } = await execFileAsync10("sudo", ["-n", HELPER4, ...args], {
    timeout,
    windowsHide: true,
    maxBuffer: 1024 * 1024
  });
  return `${stdout}
${stderr}`.trim();
}
function parseDevLines(text) {
  const out = [];
  for (const line of text.split(/\r?\n/)) {
    const m = line.match(/^DEV\s+([0-9A-Fa-f:]{11,17})\s+([01])\s+(.*)$/);
    if (!m) continue;
    const addr = m[1].toUpperCase();
    const name = m[3].trim() || "unknown";
    out.push({ addr, name, paired: m[2] === "1", kind: "bt", likely: NAME_RE.test(name) });
  }
  return out;
}
function winComPath(p) {
  const m = p.match(/COM\d+/i);
  if (!m) return p;
  const n = Number(m[0].slice(3));
  return n >= 10 ? `\\\\.\\${m[0].toUpperCase()}` : m[0].toUpperCase();
}
function pidRunning(pid) {
  if (!Number.isFinite(pid) || pid <= 0) return false;
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}
function sppLockPath(com) {
  return join10(dataDir7(), `spp-${comKey(com) || "port"}.lock`);
}
function acquireSppLock(com) {
  const p = sppLockPath(com);
  try {
    if (existsSync9(p)) {
      const old = Number(readFileSync8(p, "utf8").trim());
      if (old && old !== process.pid && pidRunning(old)) return false;
    }
  } catch {
  }
  try {
    writeFileSync7(p, String(process.pid), "utf8");
    sppLockCom = comKey(com);
    return true;
  } catch {
    return true;
  }
}
function releaseSppLock() {
  if (!sppLockCom) return;
  const p = sppLockPath(sppLockCom);
  sppLockCom = "";
  try {
    if (!existsSync9(p)) return;
    const old = Number(readFileSync8(p, "utf8").trim());
    if (!old || old === process.pid) unlinkSync2(p);
  } catch {
  }
}
function startCaptureWatch() {
  if (captureWatch) clearInterval(captureWatch);
  try {
    if (existsSync9(capturePath())) {
      const all = readFileSync8(capturePath());
      if (!reading && all.length) ingest(all.subarray(Math.max(0, all.length - 2048)), true);
      captureOff = all.length;
    }
  } catch {
  }
  captureWatch = setInterval(() => {
    try {
      if (!existsSync9(capturePath())) return;
      const all = readFileSync8(capturePath());
      if (all.length < captureOff) captureOff = 0;
      if (all.length > captureOff) {
        ingest(all.subarray(captureOff), true);
        captureOff = all.length;
      }
    } catch {
    }
  }, 200);
}
async function winSppPorts() {
  const script = [
    "Get-PnpDevice -Class Ports -Status OK -ErrorAction SilentlyContinue | ForEach-Object {",
    "  $com = [regex]::Match($_.FriendlyName,'COM\\d+').Value",
    "  if (-not $com -or $_.InstanceId -notmatch 'BTHENUM') { return }",
    "  $m = [regex]::Match($_.InstanceId, '([0-9A-Fa-f]{12})_')",
    "  $hex = if ($m.Success) { $m.Groups[1].Value.ToUpper() } else { '' }",
    "  $inc = if ($hex -eq '000000000000' -or $hex -eq '') { '1' } else { '0' }",
    '  "$com`t$inc`t$hex"',
    "}"
  ].join(" ");
  try {
    const { stdout } = await execFileAsync10("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", script], {
      windowsHide: true,
      timeout: 8e3
    });
    const ports = stdout.split(/\r?\n/).map((l) => l.trim()).filter(Boolean).map((l) => {
      const [com, inc, mac] = l.split("	");
      return { com: (com || "").toUpperCase(), incoming: inc === "1", mac: (mac || "").toUpperCase() };
    }).filter((p) => /^COM\d+$/.test(p.com));
    sppPortsCache = ports;
    sppPortsAt = Date.now();
    return ports;
  } catch {
    return sppPortsCache;
  }
}
async function winSppPortsCached() {
  if (sppPortsCache.length && Date.now() - sppPortsAt < 4e3) return sppPortsCache;
  return winSppPorts();
}
async function winComForMac(mac) {
  const hex = mac.replace(/[^0-9A-Fa-f]/g, "").toUpperCase();
  if (hex.length !== 12) return null;
  const ports = await winSppPorts();
  const hit = ports.find((p) => !p.incoming && p.mac === hex) || ports.find((p) => p.mac === hex && !p.incoming);
  return hit?.com ?? null;
}
function isIncomingPort(ports, com) {
  const hit = ports.find((p) => p.com === com);
  if (!hit) return false;
  return hit.incoming || SKIP_SPP_MAC.has(hit.mac);
}
function pickOutgoing(ports, prefer = "") {
  const outgoing = ports.filter((p) => !p.incoming && p.mac && !SKIP_SPP_MAC.has(p.mac));
  if (prefer && outgoing.some((p) => p.com === prefer)) return prefer;
  if (resolvedOutgoing && outgoing.some((p) => p.com === resolvedOutgoing)) return resolvedOutgoing;
  return outgoing[0]?.com || "";
}
async function winPreferOutgoingCom(addr) {
  const want = (addr.match(/COM\d+/i) || [])[0]?.toUpperCase() || "";
  const ports = await winSppPortsCached();
  if (!ports.length) return resolvedOutgoing || want || addr;
  if (want && !isIncomingPort(ports, want) && ports.some((p) => p.com === want && !p.incoming)) {
    resolvedOutgoing = want;
    return want;
  }
  const picked = pickOutgoing(ports, want) || (!want || isIncomingPort(ports, want) ? "" : want);
  if (/^COM\d+$/i.test(picked)) resolvedOutgoing = picked.toUpperCase();
  return picked || want || addr;
}
function colonMac(hex) {
  const h = hex.replace(/[^0-9a-fA-F]/g, "").toUpperCase();
  if (h.length !== 12) return hex.toUpperCase();
  return h.match(/.{2}/g)?.join(":") ?? h;
}
async function winClassicDevices() {
  const out = [];
  try {
    const { stdout } = await execFileAsync10(
      "reg",
      ["query", "HKLM\\SYSTEM\\CurrentControlSet\\Services\\BTHPORT\\Parameters\\Devices"],
      { windowsHide: true, timeout: 8e3 }
    );
    const keys = stdout.split(/\r?\n/).map((l) => l.trim()).filter((l) => /\\Devices\\[0-9a-fA-F]{12}$/.test(l));
    for (const key of keys) {
      const hex = key.split("\\").pop() || "";
      const addr = colonMac(hex);
      let name = "Bluetooth";
      try {
        const { stdout: det } = await execFileAsync10("reg", ["query", key, "/v", "Name"], { windowsHide: true, timeout: 4e3 });
        const m = det.match(/Name\s+REG_BINARY\s+([0-9A-Fa-f ]+)/i);
        if (m) {
          const hex2 = m[1].replace(/\s+/g, "");
          const raw = Buffer.from(hex2, "hex");
          name = raw.toString("ascii").replace(/\0/g, "").trim() || raw.toString("utf16le").replace(/\0/g, "").trim() || name;
        }
      } catch {
      }
      out.push({ addr, name, paired: true, kind: "bt", likely: NAME_RE.test(name) });
    }
  } catch {
  }
  return out;
}
async function lextelLearn() {
  try {
    const buf = existsSync9(capturePath()) ? readFileSync8(capturePath()) : Buffer.alloc(0);
    inspect = inspectCapture(buf);
    if (inspect.reading) reading = inspect.reading;
    if (inspect.layout) {
      decoder.layout = inspect.layout;
      saved3.layout = inspect.layout;
      persist5();
    }
    if (!buf.length) error2 = "Sem dump \u2014 conecte o MS-2000 e deixe o SPP aberto alguns segundos";
    else if (!inspect.reading) error2 = inspect.note;
    else error2 = "";
  } catch (err) {
    error2 = err instanceof Error ? err.message : String(err);
  }
  return lextelStatus();
}
async function lextelOpenBluetooth() {
  if (process.platform === "win32") {
    try {
      await execFileAsync10("cmd.exe", ["/c", "start", "ms-settings:bluetooth"], { windowsHide: true, timeout: 5e3 });
    } catch (err) {
      error2 = err instanceof Error ? err.message : String(err);
    }
  }
  return lextelScan(8);
}
async function serialCandidates() {
  try {
    const list = await listSerialDevices();
    const spp = process.platform === "win32" ? await winSppPorts() : [];
    const incoming = new Set(spp.filter((p) => p.incoming).map((p) => p.com));
    const outgoing = new Set(spp.filter((p) => !p.incoming).map((p) => p.com));
    return list.map((d) => {
      const com = (d.path.match(/COM\d+/i) || [])[0]?.toUpperCase() || "";
      const isIn = incoming.has(com);
      return {
        addr: d.path,
        name: isIn ? `${d.label} (entrada)` : d.label,
        paired: true,
        kind: "serial",
        likely: !isIn && (outgoing.has(com) || NAME_RE.test(`${d.path} ${d.label}`) || /bluetooth|rfcomm|monitor.?station/i.test(`${d.path} ${d.label}`))
      };
    });
  } catch {
    return [];
  }
}
function ingest(buf, alreadyOnDisk = false) {
  if (!buf.length) return;
  bytes += buf.length;
  updatedAt = Date.now();
  const live3 = comKey(pathOpen);
  if (live3 && saved3.addr !== live3) {
    saved3.addr = live3;
    saved3.name = saved3.name.replace(/COM\d+/gi, live3).replace(/\s*\(entrada\)/i, "").trim() || live3;
    persist5();
  }
  if (!alreadyOnDisk) {
    try {
      const cap = capturePath();
      if (existsSync9(cap) && readFileSync8(cap).length > CAPTURE_MAX) writeFileSync7(cap, Buffer.alloc(0));
      appendFileSync(cap, buf);
    } catch {
    }
  }
  const got = decoder.push(buf);
  if (got) {
    reading = got;
    if (error2 && /UnauthorizedAccess|win-spp/i.test(error2)) error2 = "";
    if (decoder.layout && JSON.stringify(decoder.layout) !== JSON.stringify(saved3.layout)) {
      saved3.layout = decoder.layout;
      persist5();
    }
  }
  inspect = {
    ascii: buf.toString("latin1").replace(/[^\t\r\n\x20-\x7e]/g, ".").slice(-480),
    printable: 1,
    period: inspect.period,
    hexHead: decoder.lastHex,
    note: decoder.layout?.kind === "ascii" ? "ASCII A-F (PEP/AVG/REF mW \u2192 W, ROE, V; F = MHz)" : decoder.layout ? `quadro ${decoder.layout.kind}` : inspect.note || "aguardando bytes",
    layout: decoder.layout,
    reading
  };
}
function killPidTree(pid) {
  if (process.platform !== "win32" || !pid) return;
  try {
    const child2 = spawn3("taskkill", ["/F", "/T", "/PID", String(pid)], {
      windowsHide: true,
      stdio: "ignore",
      detached: true
    });
    child2.unref();
  } catch {
  }
}
function linkAlive() {
  return Boolean(stream || sppChild);
}
function comKey(s) {
  const m = s.match(/COM\d+/i);
  if (m) return m[0].toUpperCase();
  return s.replace(/\\/g, "").toUpperCase();
}
function samePort(a, b) {
  if (!a || !b) return false;
  if (a.toUpperCase() === b.toUpperCase()) return true;
  const ca = comKey(a);
  const cb = comKey(b);
  return Boolean(ca && cb && ca === cb);
}
function clearReconnect() {
  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }
}
function scheduleReconnect() {
  if (!wantOpen || recoverBusy || reconnectTimer) return;
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    void recoverLink();
  }, reconnectDelay);
  reconnectDelay = Math.min(1e4, Math.round(reconnectDelay * 1.5));
}
async function remapIfWrongCom() {
  if (process.platform !== "win32" || !wantOpen || recoverBusy) return;
  const now = Date.now();
  if (now - lastRemapAt < 8e3) return;
  lastRemapAt = now;
  const next = await winPreferOutgoingCom(saved3.addr || pathOpen);
  if (!next || samePort(pathOpen, next)) return;
  recoverBusy = true;
  try {
    closeStream();
    saved3.addr = comKey(next) || next;
    saved3.name = saved3.name.replace(/COM\d+/gi, saved3.addr).replace(/\s*\(entrada\)/i, "").trim() || saved3.addr;
    persist5();
    attach(winComPath(next));
  } finally {
    recoverBusy = false;
  }
}
async function recoverLink() {
  if (!wantOpen || recoverBusy) return;
  if (linkAlive()) {
    if (process.platform === "win32" && bytes === 0 && attachedAt && Date.now() - attachedAt > 5e3) {
      await remapIfWrongCom();
    }
    reconnectDelay = 600;
    return;
  }
  if (!saved3.addr) return;
  recoverBusy = true;
  if (phase2 !== "scanning" && phase2 !== "pairing") phase2 = "connecting";
  error2 = "";
  try {
    await lextelConnect({ addr: saved3.addr, pin: saved3.pin, name: saved3.name, channel: saved3.channel });
  } catch {
  } finally {
    recoverBusy = false;
    if (wantOpen && !linkAlive()) scheduleReconnect();
    else reconnectDelay = 600;
  }
}
function killLeftoverWinSpp(_com) {
  if (process.platform !== "win32") return;
  const pid = sppChild?.pid;
  if (pid) killPidTree(pid);
}
function closeStream() {
  if (stream) {
    stream.removeAllListeners();
    stream.destroy();
    stream = null;
  }
  if (captureWatch) {
    clearInterval(captureWatch);
    captureWatch = null;
  }
  captureOff = 0;
  if (sppChild) {
    const pid = sppChild.pid;
    try {
      sppChild.kill();
    } catch {
    }
    sppChild = null;
    killPidTree(pid);
  }
  pathOpen = "";
  releaseSppLock();
  if (!wantOpen && (phase2 === "streaming" || phase2 === "connecting")) phase2 = "idle";
}
function attachFd(path2) {
  const rs = createReadStream(path2, { flags: "r", highWaterMark: 256 });
  stream = rs;
  rs.on("open", () => {
    phase2 = "streaming";
    reconnectDelay = 600;
  });
  rs.on("data", (chunk) => {
    ingest(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
  });
  rs.on("error", (err) => {
    error2 = err.message;
    if (wantOpen) {
      phase2 = "connecting";
      closeStream();
      scheduleReconnect();
      return;
    }
    phase2 = "error";
    closeStream();
  });
  rs.on("close", () => {
    if (pathOpen === path2) {
      stream = null;
      pathOpen = "";
      if (wantOpen) {
        scheduleReconnect();
        return;
      }
      if (phase2 !== "error" && !sppChild) phase2 = "idle";
    }
  });
}
function attachWinSpp(com) {
  const script = winSppScript();
  if (!existsSync9(script)) {
    attachFd(winComPath(com));
    return;
  }
  if (!acquireSppLock(com)) {
    startCaptureWatch();
    phase2 = "connecting";
    error2 = `${com} em uso`;
    scheduleReconnect();
    return;
  }
  killLeftoverWinSpp(com);
  const bauds = [9600];
  const run4 = (baud) => {
    const child2 = spawn3(
      "powershell.exe",
      [
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        script,
        "-Port",
        com,
        "-Baud",
        String(baud),
        "-OutFile",
        capturePath()
      ],
      { windowsHide: true, stdio: ["ignore", "ignore", "pipe"] }
    );
    sppChild = child2;
    startCaptureWatch();
    child2.stderr?.on("data", (chunk) => {
      const msg = chunk.toString("utf8").trim();
      if (msg) error2 = msg.split(/\r?\n/).pop() || msg;
    });
    child2.on("error", (err) => {
      error2 = err.message;
      if (wantOpen) {
        phase2 = "connecting";
        scheduleReconnect();
        return;
      }
      phase2 = "error";
    });
    child2.on("exit", () => {
      if (sppChild !== child2) return;
      sppChild = null;
      const idx = bauds.indexOf(baud);
      const busy = /UnauthorizedAccess|porta em uso|em uso/i.test(error2);
      if (!busy && bytes === 0 && idx >= 0 && idx < bauds.length - 1 && wantOpen && phase2 !== "idle") {
        run4(bauds[idx + 1]);
        return;
      }
      if (wantOpen) {
        phase2 = "connecting";
        scheduleReconnect();
        return;
      }
      if (bytes > 0) {
        phase2 = "streaming";
        return;
      }
      if (phase2 === "streaming" || phase2 === "connecting") {
        phase2 = "error";
        if (!error2) error2 = `N\xE3o abriu ${com} (baud ${baud})`;
      }
    });
    phase2 = "streaming";
  };
  run4(bauds[0]);
}
function attach(path2) {
  if (samePort(pathOpen, path2) && linkAlive()) {
    phase2 = "streaming";
    return;
  }
  closeStream();
  if (!decoder.layout && saved3.layout) decoder.reset(saved3.layout);
  try {
    writeFileSync7(capturePath(), Buffer.alloc(0));
  } catch {
  }
  phase2 = "connecting";
  error2 = "";
  pathOpen = path2;
  attachedAt = Date.now();
  bytes = 0;
  if (process.platform === "win32" && /COM\d+/i.test(path2)) {
    const m = path2.match(/COM\d+/i);
    attachWinSpp(m ? m[0].toUpperCase() : path2);
    return;
  }
  attachFd(path2);
}
function lextelStatus() {
  const r = reading;
  return {
    ok: phase2 !== "error",
    folder: dataDir7(),
    sppUuid: SPP_UUID,
    phase: phase2,
    connected: linkAlive() || wantOpen && (phase2 === "connecting" || phase2 === "streaming"),
    decoded: Boolean(r) || Boolean(decoder.layout && bytes > 0),
    addr: saved3.addr,
    name: saved3.name,
    pin: saved3.pin,
    channel: saved3.channel,
    autoConnect: saved3.autoConnect,
    path: pathOpen,
    error: error2,
    hex: decoder.lastHex,
    layout: decoder.layout?.kind ?? "",
    bytes,
    updatedAt,
    pep: r?.pep ?? 0,
    avg: r?.avg ?? 0,
    ref: r?.ref ?? 0,
    swr: r?.swr ?? 1,
    vdc: r?.vdc ?? 0,
    z: r?.z ?? 0,
    mod: r?.mod ?? 0,
    alarms: r?.labels ?? [],
    devices,
    ascii: inspect.ascii,
    note: inspect.note || error2,
    captureBytes: bytes,
    period: inspect.period
  };
}
async function lextelScan(seconds = 12) {
  phase2 = "scanning";
  error2 = "";
  const serials = await serialCandidates();
  let classic = [];
  if (process.platform === "win32") {
    classic = await winClassicDevices();
  }
  if (process.platform === "linux") {
    try {
      const out = await runHelper(["scan", String(Math.min(20, Math.max(5, seconds)))], 25e3);
      classic = parseDevLines(out);
    } catch (err) {
      error2 = err instanceof Error ? err.message : String(err);
      try {
        const out = await runHelper(["devices"], 8e3);
        classic = parseDevLines(out);
      } catch {
      }
    }
  }
  const seen = /* @__PURE__ */ new Set();
  devices = [...classic, ...serials].filter((d) => {
    if (seen.has(d.addr)) return false;
    seen.add(d.addr);
    return true;
  });
  devices.sort((a, b) => Number(b.likely) - Number(a.likely) || a.name.localeCompare(b.name));
  if (phase2 === "scanning") {
    if (linkAlive()) phase2 = "streaming";
    else if (wantOpen) {
      phase2 = "connecting";
      scheduleReconnect();
    } else phase2 = "idle";
  }
  return lextelStatus();
}
async function lextelSave(body) {
  if (typeof body.addr === "string") saved3.addr = body.addr.trim();
  if (typeof body.name === "string") saved3.name = body.name.trim();
  if (typeof body.pin === "string" && /^\d{4,6}$/.test(body.pin.trim())) saved3.pin = body.pin.trim();
  if (typeof body.channel === "number" && body.channel >= 1 && body.channel <= 30) saved3.channel = Math.round(body.channel);
  if (typeof body.autoConnect === "boolean") saved3.autoConnect = body.autoConnect;
  persist5();
  return lextelStatus();
}
function isSerialPath(addr) {
  return /^(COM\d+|\\\\\.\\COM\d+|\/dev\/)/i.test(addr);
}
async function lextelConnect(body = {}) {
  const addr = String(body.addr || saved3.addr).trim();
  if (!addr) {
    phase2 = "error";
    error2 = "Selecione o MS-2000 no scan";
    return lextelStatus();
  }
  wantOpen = true;
  if (typeof body.pin === "string" && body.pin) saved3.pin = body.pin.trim();
  if (typeof body.name === "string" && body.name) saved3.name = body.name.trim();
  if (typeof body.channel === "number" && body.channel >= 1) saved3.channel = Math.round(body.channel);
  error2 = "";
  if (isSerialPath(addr)) {
    const serial = process.platform === "win32" ? await winPreferOutgoingCom(addr) : addr;
    if (linkAlive() && samePort(pathOpen, serial) && (bytes > 0 || Date.now() - attachedAt < 8e3)) {
      if (phase2 !== "error") phase2 = "streaming";
      saved3.addr = comKey(serial) || serial;
      persist5();
      return lextelStatus();
    }
    if (serial !== saved3.addr) {
      saved3.name = saved3.name.replace(/COM\d+/gi, serial).replace(/\s*\(entrada\)/i, "").trim() || serial;
    }
    saved3.addr = comKey(serial) || serial;
    persist5();
    attach(process.platform === "win32" ? winComPath(serial) : serial);
    return lextelStatus();
  }
  if (process.platform === "win32") {
    const serial = await winComForMac(addr) || await winPreferOutgoingCom(addr);
    if (serial && isSerialPath(serial)) {
      saved3.name = saved3.name || "Monitor Station";
      saved3.addr = serial;
      persist5();
      attach(winComPath(serial));
      return lextelStatus();
    }
    phase2 = "error";
    error2 = "No Windows o MS-2000 precisa estar pareado (PIN 1234 ou 0000). Abra Configura\xE7\xF5es \u2192 Bluetooth, pareie, e o SPP vira um COM. Depois toque em Procurar e Conectar.";
    try {
      await execFileAsync10("cmd.exe", ["/c", "start", "ms-settings:bluetooth"], { windowsHide: true, timeout: 5e3 });
    } catch {
    }
    return lextelStatus();
  }
  if (process.platform !== "linux") {
    phase2 = "error";
    error2 = "Bluetooth Classic SPP precisa do BlueZ no Raspberry Pi";
    return lextelStatus();
  }
  try {
    phase2 = "pairing";
    const listed = devices.find((d) => d.addr.toUpperCase() === addr.toUpperCase());
    if (!listed?.paired) {
      try {
        await runHelper(["pair", addr, saved3.pin], 3e4);
      } catch (err) {
        error2 = `Pareamento: ${err instanceof Error ? err.message : String(err)}`;
      }
    }
    phase2 = "connecting";
    let ch = saved3.channel;
    try {
      const out = await runHelper(["channel", addr], 8e3);
      const n = Number((out.match(/\d+/) || [])[0]);
      if (n >= 1 && n <= 30) ch = n;
    } catch {
    }
    saved3.channel = ch;
    persist5();
    await runHelper(["bind", addr, saved3.pin, String(ch)], 12e3);
    attach(RFCOMM);
  } catch (err) {
    error2 = err instanceof Error ? err.message : String(err);
    closeStream();
    if (wantOpen) {
      phase2 = "connecting";
      scheduleReconnect();
    } else {
      phase2 = "error";
    }
  }
  return lextelStatus();
}
async function lextelKeepalive() {
  if (wantOpen && saved3.addr && !linkAlive()) {
    reconnectDelay = 400;
    clearReconnect();
    void recoverLink();
  }
  return lextelStatus();
}
async function lextelDisconnect() {
  wantOpen = false;
  clearReconnect();
  closeStream();
  if (process.platform === "linux" && helperExists()) {
    try {
      if (saved3.addr && !isSerialPath(saved3.addr)) await runHelper(["disconnect", saved3.addr], 8e3);
      else await runHelper(["release"], 5e3);
    } catch {
    }
  }
  phase2 = "idle";
  error2 = "";
  reading = null;
  return lextelStatus();
}
async function lextelAutoConnect() {
  if (autoTried) return;
  autoTried = true;
  const { isServiceAutostart: isServiceAutostart2 } = await Promise.resolve().then(() => (init_services(), services_exports));
  if (!isServiceAutostart2("lextel")) return;
  if (!saved3.autoConnect || !saved3.addr) return;
  if (process.platform !== "linux" && !isSerialPath(saved3.addr)) return;
  await new Promise((r) => setTimeout(r, 1500));
  try {
    await lextelConnect({ addr: saved3.addr, pin: saved3.pin, name: saved3.name, channel: saved3.channel });
  } catch {
  }
}
var execFileAsync10, ROOT9, OPT_DIR6, HELPER4, RFCOMM, SPP_UUID, NAME_RE, SKIP_SPP_MAC, stream, sppChild, decoder, phase2, error2, pathOpen, reading, devices, bytes, updatedAt, autoTried, inspect, captureWatch, captureOff, wantOpen, recoverBusy, reconnectTimer, reconnectDelay, sppPortsAt, sppPortsCache, sppLockCom, attachedAt, lastRemapAt, CAPTURE_MAX, saved3, resolvedOutgoing, recoverWatch;
var init_lextel = __esm({
  "server/lextel.ts"() {
    "use strict";
    init_lextel_parse();
    init_list_serials();
    execFileAsync10 = promisify10(execFile10);
    ROOT9 = join10(dirname9(fileURLToPath9(import.meta.url)), "..");
    OPT_DIR6 = "/opt/lextel";
    HELPER4 = "/opt/ham-cockpit/bin/lextel-bt";
    RFCOMM = "/dev/rfcomm0";
    SPP_UUID = "00001101-0000-1000-8000-00805f9b34fb";
    NAME_RE = /lextel|ms-?2000|ms-?800|ms-?600|ms-?1000|ms-?1200|ms-?1800|hc-?0[56]|linvor|monitor.?station/i;
    SKIP_SPP_MAC = /* @__PURE__ */ new Set(["000000000000", "30317DBAC263"]);
    stream = null;
    sppChild = null;
    decoder = new LextelDecoder();
    phase2 = "idle";
    error2 = "";
    pathOpen = "";
    reading = null;
    devices = [];
    bytes = 0;
    updatedAt = 0;
    autoTried = false;
    inspect = inspectCapture(Buffer.alloc(0));
    captureWatch = null;
    captureOff = 0;
    wantOpen = false;
    recoverBusy = false;
    reconnectTimer = null;
    reconnectDelay = 600;
    sppPortsAt = 0;
    sppPortsCache = [];
    sppLockCom = "";
    attachedAt = 0;
    lastRemapAt = 0;
    CAPTURE_MAX = 256 * 1024;
    saved3 = loadSaved3();
    decoder = new LextelDecoder(saved3.layout);
    resolvedOutgoing = "";
    recoverWatch = setInterval(() => {
      if (!wantOpen || recoverBusy) return;
      if (phase2 === "scanning" || phase2 === "pairing") return;
      if (linkAlive()) {
        if (process.platform === "win32" && bytes === 0 && attachedAt && Date.now() - attachedAt > 5e3) {
          void remapIfWrongCom();
        }
        return;
      }
      scheduleReconnect();
    }, 2e3);
    recoverWatch.unref();
  }
});

// server/index.ts
init_lextel();
init_list_serials();
init_radios();
init_ser2net_store();
import express from "express";
import { createServer as createServer2 } from "http";
import path from "path";
import { fileURLToPath as fileURLToPath15 } from "url";

// server/term.ts
import { spawn as spawn4 } from "node:child_process";
import { existsSync as existsSync10 } from "node:fs";
import { WebSocket, WebSocketServer } from "ws";
var ROOT_LOGIN = "/opt/ham-cockpit/bin/root-login";
var attached = /* @__PURE__ */ new WeakSet();
function spawnShell() {
  const env = { ...process.env, TERM: "xterm-256color", COLORTERM: "truecolor" };
  if (process.platform === "win32") {
    return spawn4("powershell.exe", ["-NoLogo"], { env, windowsHide: true });
  }
  const cwd = existsSync10("/root") ? "/root" : process.cwd();
  const rootEnv = { ...env, HOME: "/root", USER: "root", LOGNAME: "root" };
  const sudoBin = existsSync10("/usr/bin/sudo") ? "/usr/bin/sudo" : "sudo";
  if (existsSync10(ROOT_LOGIN) && existsSync10("/usr/bin/script")) {
    return spawn4(sudoBin, ["-n", "/usr/bin/script", "-qefc", ROOT_LOGIN, "/dev/null"], { env: rootEnv, cwd });
  }
  if (existsSync10(ROOT_LOGIN)) {
    return spawn4(sudoBin, ["-n", ROOT_LOGIN], { env: rootEnv, cwd });
  }
  return spawn4(sudoBin, ["-n", "/bin/bash", "-l"], { env: rootEnv, cwd });
}
function bindSocket(ws) {
  const proc = spawnShell();
  const send = (data) => {
    if (ws.readyState === WebSocket.OPEN) ws.send(data);
  };
  send(
    process.platform === "win32" ? "Ham Cockpit \xB7 PowerShell (neste PC Windows). No Raspberry Pi isso \xE9 root.\r\n" : "Ham Cockpit \xB7 shell root\r\n"
  );
  proc.stdout.on("data", (d) => send(d.toString("utf8")));
  proc.stderr.on("data", (d) => send(d.toString("utf8")));
  proc.on("error", (err) => send(`\r
${err.message}\r
`));
  proc.on("close", (code) => {
    send(`\r
[exit ${code ?? 0}]\r
`);
    if (ws.readyState === WebSocket.OPEN) ws.close();
  });
  ws.on("message", (raw) => {
    const text = typeof raw === "string" ? raw : Array.isArray(raw) ? Buffer.concat(raw).toString("utf8") : Buffer.from(raw).toString("utf8");
    if (text.startsWith("{")) {
      try {
        const msg = JSON.parse(text);
        if (msg.type === "resize") return;
      } catch {
      }
    }
    const payload = process.platform === "win32" ? text.replace(/\r(?!\n)/g, "\r\n") : text;
    proc.stdin.write(payload);
  });
  ws.on("close", () => {
    proc.kill();
  });
}
function attachTerminal(server) {
  if (attached.has(server)) return;
  attached.add(server);
  const wss = new WebSocketServer({ noServer: true });
  server.on("upgrade", (req, socket, head) => {
    const path2 = req.url?.split("?")[0];
    if (path2 !== "/ws/term") return;
    wss.handleUpgrade(req, socket, head, (ws) => bindSocket(ws));
  });
}

// server/users.ts
import { spawn as spawn5 } from "node:child_process";
import { existsSync as existsSync11 } from "node:fs";
import { promisify as promisify11 } from "node:util";
import { execFile as execFile11 } from "node:child_process";
var execFileAsync11 = promisify11(execFile11);
var HELPER5 = "/opt/ham-cockpit/bin/station-user";
var NAME_RE2 = /^[a-z][a-z0-9_-]{0,31}$/;
var FORBIDDEN = /* @__PURE__ */ new Set(["root", "daemon", "bin", "sys", "sync", "games", "man", "mail", "www-data", "nobody"]);
var mockUsers = [
  { name: "hamcockpit", sudo: true },
  { name: "admin", sudo: true }
];
function linux2() {
  return process.platform === "linux";
}
function run(cmd, args, input) {
  return new Promise((resolve, reject) => {
    const child2 = spawn5(cmd, args, { stdio: ["pipe", "pipe", "pipe"] });
    let stdout = "";
    let stderr = "";
    child2.stdout.on("data", (d) => {
      stdout += d.toString("utf8");
    });
    child2.stderr.on("data", (d) => {
      stderr += d.toString("utf8");
    });
    child2.on("error", reject);
    child2.on("close", (code) => resolve({ code: code ?? 1, stdout, stderr }));
    if (input !== void 0) {
      child2.stdin.write(input);
      child2.stdin.end();
    } else {
      child2.stdin.end();
    }
  });
}
async function listUsers() {
  if (!linux2()) {
    return mockUsers.map((u) => ({ ...u }));
  }
  if (existsSync11(HELPER5)) {
    const r = await run("sudo", ["-n", HELPER5, "list"]);
    if (r.code === 0) {
      const names = r.stdout.split(/[,\n]/).map((n) => n.trim()).filter(Boolean);
      const uniq = Array.from(/* @__PURE__ */ new Set(["hamcockpit", "catbridge", ...names]));
      return uniq.sort().map((name) => ({ name, sudo: true }));
    }
  }
  try {
    const { stdout } = await execFileAsync11("getent", ["group", "sudo"], { timeout: 4e3 });
    const members = stdout.trim().split(":").pop()?.split(",").filter(Boolean) ?? [];
    return Array.from(/* @__PURE__ */ new Set(["hamcockpit", "catbridge", ...members])).sort().map((name) => ({ name, sudo: true }));
  } catch {
    return [{ name: "hamcockpit", sudo: true }];
  }
}
async function createUser(name, password) {
  const user = name.trim().toLowerCase();
  if (!NAME_RE2.test(user) || FORBIDDEN.has(user)) {
    return { ok: false, error: "nome inv\xE1lido" };
  }
  if (!password || password.length < 4) {
    return { ok: false, error: "senha muito curta" };
  }
  if (!linux2()) {
    if (mockUsers.some((u) => u.name === user)) {
      return { ok: false, error: "j\xE1 existe" };
    }
    mockUsers.push({ name: user, sudo: true });
    return { ok: true };
  }
  if (!existsSync11(HELPER5)) {
    return { ok: false, error: "station-user ausente" };
  }
  const r = await run("sudo", ["-n", HELPER5, "add", user], password);
  if (r.code !== 0) {
    return { ok: false, error: (r.stderr || r.stdout || "falha ao criar usu\xE1rio").trim() };
  }
  return { ok: true };
}
async function deleteUser(name) {
  const user = name.trim().toLowerCase();
  if (user === "hamcockpit" || user === "root" || !NAME_RE2.test(user)) {
    return { ok: false, error: "usu\xE1rio protegido" };
  }
  if (!linux2()) {
    const i = mockUsers.findIndex((u) => u.name === user);
    if (i < 0) return { ok: false, error: "n\xE3o encontrado" };
    mockUsers.splice(i, 1);
    return { ok: true };
  }
  if (!existsSync11(HELPER5)) {
    return { ok: false, error: "station-user ausente" };
  }
  const r = await run("sudo", ["-n", HELPER5, "del", user]);
  if (r.code !== 0) {
    return { ok: false, error: (r.stderr || r.stdout || "falha ao remover").trim() };
  }
  return { ok: true };
}
async function sshStatus() {
  if (!linux2()) return { ok: false, unit: "ssh" };
  for (const unit of ["ssh", "sshd"]) {
    try {
      const { stdout } = await execFileAsync11("systemctl", ["is-active", unit], { timeout: 3e3 });
      if (stdout.trim() === "active") return { ok: true, unit };
    } catch {
    }
  }
  return { ok: false, unit: "ssh" };
}

// server/index.ts
init_wavelog_status();
init_wlg_status();

// server/net.ts
import { execFile as execFile12, spawn as spawn6 } from "node:child_process";
import { existsSync as existsSync12, mkdirSync as mkdirSync8, readFileSync as readFileSync9, renameSync as renameSync8, writeFileSync as writeFileSync8 } from "node:fs";
import { hostname as osHostname } from "node:os";
import { dirname as dirname10, join as join11 } from "node:path";
import { fileURLToPath as fileURLToPath10 } from "node:url";
import { promisify as promisify12 } from "node:util";
var execFileAsync12 = promisify12(execFile12);
var ROOT10 = join11(dirname10(fileURLToPath10(import.meta.url)), "..");
var OPT_DIR7 = "/opt/ham-cockpit/net";
var HELPER6 = "/opt/ham-cockpit/bin/station-net";
var HOST_RE = /^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$/;
var IPV4_RE = /^(?:\d{1,3}\.){3}\d{1,3}$/;
function dataDir8() {
  if (existsSync12("/opt/ham-cockpit")) {
    mkdirSync8(OPT_DIR7, { recursive: true });
    return OPT_DIR7;
  }
  const local = join11(ROOT10, "data", "net");
  mkdirSync8(local, { recursive: true });
  return local;
}
function jsonPath6() {
  return join11(dataDir8(), "config.json");
}
function validIp(s) {
  if (!IPV4_RE.test(s)) return false;
  return s.split(".").every((p) => {
    const n = Number(p);
    return n >= 0 && n <= 255;
  });
}
function loadSaved4() {
  const fallback = {
    hostname: "ham-cockpit",
    link: "wifi",
    dhcp: true,
    ip: "",
    mask: "255.255.255.0",
    gw: "",
    dns1: "1.1.1.1",
    dns2: "8.8.8.8",
    staSsid: "",
    staPass: "",
    apSsid: "Ham-Cockpit",
    apPass: "hamcockpit",
    managed: []
  };
  try {
    const raw = JSON.parse(readFileSync9(jsonPath6(), "utf8"));
    return {
      hostname: typeof raw.hostname === "string" && HOST_RE.test(raw.hostname) ? raw.hostname : fallback.hostname,
      link: raw.link === "ethernet" ? "ethernet" : "wifi",
      dhcp: raw.dhcp !== false,
      ip: typeof raw.ip === "string" ? raw.ip : "",
      mask: typeof raw.mask === "string" && raw.mask ? raw.mask : fallback.mask,
      gw: typeof raw.gw === "string" ? raw.gw : "",
      dns1: typeof raw.dns1 === "string" && raw.dns1 ? raw.dns1 : fallback.dns1,
      dns2: typeof raw.dns2 === "string" ? raw.dns2 : fallback.dns2,
      staSsid: typeof raw.staSsid === "string" ? raw.staSsid : "",
      staPass: typeof raw.staPass === "string" ? raw.staPass : "",
      apSsid: typeof raw.apSsid === "string" && raw.apSsid ? raw.apSsid : fallback.apSsid,
      apPass: typeof raw.apPass === "string" && raw.apPass ? raw.apPass : fallback.apPass,
      managed: Array.isArray(raw.managed) ? raw.managed.filter((m) => m && typeof m.ssid === "string").map((m) => ({ ssid: m.ssid, psk: typeof m.psk === "string" ? m.psk : "" })) : []
    };
  } catch {
    return fallback;
  }
}
var saved4 = loadSaved4();
var lastScan = [];
var lastError = "";
var lastNote = "";
function persist6() {
  const tmp = `${jsonPath6()}.${process.pid}.tmp`;
  writeFileSync8(tmp, JSON.stringify(saved4, null, 2), "utf8");
  renameSync8(tmp, jsonPath6());
}
function rememberSsid(ssid, psk) {
  if (!ssid) return;
  const rest = saved4.managed.filter((m) => m.ssid !== ssid);
  saved4.managed = [{ ssid, psk: psk || rest.find((m) => m.ssid === ssid)?.psk }, ...rest].slice(0, 12);
}
function run2(cmd, args, input, timeout = 2e4) {
  return new Promise((resolve, reject) => {
    const child2 = spawn6(cmd, args, { stdio: ["pipe", "pipe", "pipe"], windowsHide: true });
    let stdout = "";
    let stderr = "";
    const timer = setTimeout(() => {
      try {
        child2.kill();
      } catch {
      }
    }, timeout);
    child2.stdout.on("data", (d) => {
      stdout += d.toString("utf8");
    });
    child2.stderr.on("data", (d) => {
      stderr += d.toString("utf8");
    });
    child2.on("error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
    child2.on("close", (code) => {
      clearTimeout(timer);
      resolve({ code: code ?? 1, stdout, stderr });
    });
    if (input !== void 0) {
      child2.stdin.write(input);
      child2.stdin.end();
    } else {
      child2.stdin.end();
    }
  });
}
async function helper3(args, input) {
  if (!existsSync12(HELPER6)) {
    const err = new Error("helper station-net ausente \u2014 use no Raspberry Pi");
    err.code = "NO_HELPER";
    throw err;
  }
  return run2("sudo", ["-n", HELPER6, ...args], input);
}
function pctToRssi(pct) {
  const n = Math.max(0, Math.min(100, pct));
  return Math.round(n / 2 - 100);
}
function signalToRssi(raw) {
  const n = Number(String(raw).replace(/[^\d.-]/g, ""));
  if (!Number.isFinite(n)) return -80;
  if (n <= 0 && n >= -100) return Math.round(n);
  return pctToRssi(n);
}
async function winScan() {
  const { stdout } = await execFileAsync12("netsh", ["wlan", "show", "networks", "mode=bssid"], {
    timeout: 18e3,
    windowsHide: true,
    encoding: "utf8"
  }).catch(async () => {
    const r = await execFileAsync12("cmd.exe", ["/c", "chcp 65001>nul & netsh wlan show networks mode=bssid"], {
      timeout: 18e3,
      windowsHide: true
    });
    return { stdout: r.stdout.toString() };
  });
  const text = String(stdout || "");
  const bySsid = /* @__PURE__ */ new Map();
  let ssid = "";
  let auth = "";
  for (const line of text.split(/\r?\n/)) {
    const s = line.match(/^\s*SSID\s+\d+\s*:\s*(.*)$/i);
    if (s) {
      ssid = s[1].trim();
      auth = "";
      continue;
    }
    const a = line.match(/^\s*Authentication\s*:\s*(.*)$/i) || line.match(/^\s*Autenticação\s*:\s*(.*)$/i);
    if (a) {
      auth = a[1].trim();
      continue;
    }
    const sig = line.match(/^\s*Signal\s*:\s*(\d+)\s*%/i) || line.match(/^\s*Sinal\s*:\s*(\d+)\s*%/i);
    if (sig && ssid) {
      const rssi = pctToRssi(Number(sig[1]));
      const open = !auth || /^open$/i.test(auth) || /abert/i.test(auth);
      const prev = bySsid.get(ssid);
      if (!prev || rssi > prev.rssi) bySsid.set(ssid, { ssid, rssi, open });
    }
  }
  return Array.from(bySsid.values()).sort((a, b) => b.rssi - a.rssi);
}
async function linuxScan() {
  const r = existsSync12(HELPER6) ? await helper3(["scan"]) : await run2("nmcli", ["-t", "-f", "SSID,SIGNAL,SECURITY", "device", "wifi", "list"]);
  const bySsid = /* @__PURE__ */ new Map();
  for (const line of r.stdout.split(/\r?\n/)) {
    const parts = line.split("	");
    const ssid = (parts[0] || "").trim();
    if (!ssid || ssid === "--") continue;
    const rssi = signalToRssi(parts[1] || "40");
    const sec = (parts[2] || "").trim();
    const open = !sec || sec === "--" || /^none$/i.test(sec);
    const prev = bySsid.get(ssid);
    if (!prev || rssi > prev.rssi) bySsid.set(ssid, { ssid, rssi, open });
  }
  return Array.from(bySsid.values()).sort((a, b) => b.rssi - a.rssi);
}
function guessKind(name, hint = "") {
  const n = `${name} ${hint}`.toLowerCase();
  if (/wi-?fi|wlan|wireless|802\.11/.test(n)) return "wifi";
  if (/eth|ethernet|end0|enp|eno|cabo|local area/.test(n)) return "ethernet";
  return "other";
}
function parseIpconfig(text) {
  const blocks = text.split(/\r?\n(?=\S)/);
  const out = [];
  for (const block of blocks) {
    const head = block.split(/\r?\n/)[0] || "";
    if (!/adapter|adaptador/i.test(head)) continue;
    const name = head.replace(/:\s*$/, "").replace(/^(wireless\s+lan\s+adapter|ethernet\s+adapter|adaptador\s+de\s+rede\s+sem\s+fio|adaptador\s+ethernet|adaptador)\s+/i, "").trim();
    const disconnected = /media disconnected|m[ií]dia desconectada|midia desconectada/i.test(block);
    const ip = (block.match(/IPv4[^:\n]*:\s*([\d.]+)/i) || [])[1] || "";
    const mask = (block.match(/Subnet Mask[^:\n]*:\s*([\d.]+)/i) || block.match(/M[aá]scara[^:\n]*:\s*([\d.]+)/i) || [])[1] || "";
    const gw = (block.match(/Default Gateway[^:\n]*:\s*([\d.]+)/i) || block.match(/Gateway Padr[aã]o[^:\n]*:\s*([\d.]+)/i) || block.match(/Gateway[^:\n]*:\s*([\d.]+)/i) || [])[1] || "";
    const dns = [];
    const dnsBlock = block.split(/DNS Servers[^:\n]*:\s*/i)[1] || block.split(/Servidores DNS[^:\n]*:\s*/i)[1] || "";
    for (const line of dnsBlock.split(/\r?\n/)) {
      const m = line.match(/([\d.]+)/);
      if (m && validIp(m[1])) dns.push(m[1]);
      else if (line.trim() && !/^\s*[\d.]+/.test(line) && dns.length) break;
    }
    const ssid = (block.match(/SSID[^:\n]*:\s*(.+)/i) || [])[1]?.trim() || "";
    out.push({
      name,
      kind: guessKind(name, head),
      connected: !disconnected && Boolean(ip),
      ip,
      mask,
      gw: validIp(gw) ? gw : "",
      dns,
      ssid
    });
  }
  return out;
}
async function winLive() {
  const { stdout } = await execFileAsync12("ipconfig", ["/all"], { timeout: 8e3, windowsHide: true }).catch(() => ({ stdout: "" }));
  const ifs = parseIpconfig(String(stdout || ""));
  try {
    const wlan = await execFileAsync12("netsh", ["wlan", "show", "interfaces"], { timeout: 6e3, windowsHide: true });
    const text = String(wlan.stdout || "");
    const ssid = (text.match(/^\s*SSID\s*:\s*(.+)$/im) || [])[1]?.trim() || "";
    const state = (text.match(/^\s*State\s*:\s*(.+)$/im) || text.match(/^\s*Estado\s*:\s*(.+)$/im) || [])[1] || "";
    const connected = /connected|conectado/i.test(state);
    const wifi = ifs.find((i) => i.kind === "wifi");
    if (wifi) {
      wifi.ssid = ssid || wifi.ssid;
      if (connected) wifi.connected = true;
    } else if (ssid) {
      ifs.push({ name: "Wi-Fi", kind: "wifi", connected, ip: "", mask: "", gw: "", dns: [], ssid });
    }
  } catch {
  }
  return ifs;
}
async function linuxLive() {
  const ifs = [];
  try {
    const { stdout } = await execFileAsync12("ip", ["-j", "addr"], { timeout: 5e3 });
    const rows = JSON.parse(String(stdout || "[]"));
    for (const row of rows) {
      const name = row.ifname || "";
      if (!name || name === "lo") continue;
      const v4 = (row.addr_info || []).find((a) => a.family === "inet");
      const prefix = Number(v4?.prefixlen) || 24;
      const mask = prefixToMask(prefix);
      ifs.push({
        name,
        kind: guessKind(name),
        connected: Boolean(v4?.local),
        ip: v4?.local || "",
        mask,
        gw: "",
        dns: [],
        ssid: ""
      });
    }
  } catch {
  }
  try {
    const { stdout } = await execFileAsync12("ip", ["-j", "route"], { timeout: 4e3 });
    const routes = JSON.parse(String(stdout || "[]"));
    const def = routes.find((r) => r.dst === "default");
    if (def?.gateway && def.dev) {
      const hit = ifs.find((i) => i.name === def.dev);
      if (hit) hit.gw = def.gateway;
    }
  } catch {
  }
  try {
    const resolv = readFileSync9("/etc/resolv.conf", "utf8");
    const dns = [];
    const re = /^nameserver\s+([\d.]+)/gm;
    let m;
    while (m = re.exec(resolv)) dns.push(m[1]);
    for (const i of ifs) if (i.connected) i.dns = dns;
  } catch {
  }
  try {
    const { stdout } = await execFileAsync12("iwgetid", ["-r"], { timeout: 3e3 });
    const ssid = String(stdout || "").trim();
    const wifi = ifs.find((i) => i.kind === "wifi") || ifs.find((i) => /^wlan/i.test(i.name));
    if (wifi && ssid) {
      wifi.ssid = ssid;
      wifi.kind = "wifi";
      wifi.connected = true;
    }
  } catch {
  }
  return ifs;
}
function prefixToMask(prefix) {
  const n = Math.max(0, Math.min(32, prefix));
  const bits = n === 0 ? 0 : -1 << 32 - n >>> 0;
  return [24, 16, 8, 0].map((s) => (bits >>> s & 255).toString()).join(".");
}
async function liveIfs() {
  if (process.platform === "win32") return winLive();
  if (process.platform === "linux") return linuxLive();
  return [];
}
function pickLive(ifs, link) {
  if (link === "ethernet") return ifs.find((i) => i.kind === "ethernet" && i.connected) || ifs.find((i) => i.kind === "ethernet");
  return ifs.find((i) => i.kind === "wifi" && i.connected) || ifs.find((i) => i.kind === "wifi");
}
async function netStatus() {
  const ifs = await liveIfs().catch(() => []);
  const wifi = pickLive(ifs, "wifi");
  const eth = pickLive(ifs, "ethernet");
  const chosen = pickLive(ifs, saved4.link) || wifi || eth;
  const liveHost = osHostname().replace(/\.local$/i, "");
  return {
    ok: lastError === "",
    folder: dataDir8(),
    hostname: saved4.hostname,
    liveHostname: liveHost,
    link: saved4.link,
    dhcp: saved4.dhcp,
    ip: saved4.ip || chosen?.ip || "",
    mask: saved4.mask || chosen?.mask || "255.255.255.0",
    gw: saved4.gw || chosen?.gw || "",
    dns1: saved4.dns1 || chosen?.dns[0] || "1.1.1.1",
    dns2: saved4.dns2 || chosen?.dns[1] || "",
    staSsid: wifi?.ssid || saved4.staSsid,
    staConnected: Boolean(wifi?.connected && wifi.ssid),
    staPassSet: Boolean(saved4.staPass),
    apSsid: saved4.apSsid,
    apPassSet: Boolean(saved4.apPass),
    ethConnected: Boolean(eth?.connected),
    ethName: eth?.name || "",
    wlanName: wifi?.name || "",
    liveIp: chosen?.ip || "",
    liveMask: chosen?.mask || "",
    liveGw: chosen?.gw || "",
    scan: lastScan,
    managed: saved4.managed.map((m) => ({ ssid: m.ssid })),
    error: lastError,
    note: lastNote
  };
}
async function netScan() {
  lastError = "";
  lastNote = "";
  try {
    lastScan = process.platform === "win32" ? await winScan() : await linuxScan();
    if (!lastScan.length) lastNote = process.platform === "win32" ? "Nenhuma rede Wi\u2011Fi vis\xEDvel. Ligue o adaptador wireless." : "Nenhuma rede vis\xEDvel. Confira a antena wlan0.";
  } catch (err) {
    lastError = err instanceof Error ? err.message : String(err);
    lastScan = [];
  }
  return netStatus();
}
async function netConnect(body) {
  const ssid = String(body.ssid || saved4.staSsid).trim();
  const pass = typeof body.pass === "string" && body.pass ? body.pass : saved4.staPass;
  lastError = "";
  lastNote = "";
  if (!ssid) {
    lastError = "Escolha uma rede Wi\u2011Fi";
    return netStatus();
  }
  saved4.staSsid = ssid;
  if (typeof body.pass === "string" && body.pass) saved4.staPass = body.pass;
  saved4.link = "wifi";
  rememberSsid(ssid, pass);
  persist6();
  try {
    if (process.platform === "linux") {
      await helper3(["connect", ssid], pass);
      if (!saved4.dhcp) await applyIpv4Linux();
    } else if (process.platform === "win32") {
      await winConnect(ssid, pass);
    } else {
      lastError = "Wi\u2011Fi STA precisa do Raspberry Pi";
    }
  } catch (err) {
    lastError = err instanceof Error ? err.message : String(err);
  }
  return netStatus();
}
async function winConnect(ssid, pass) {
  const profile = join11(dataDir8(), "wlan-profile.xml");
  const open = !pass;
  const xml = open ? `<?xml version="1.0"?><WLANProfile xmlns="http://www.microsoft.com/networking/WLAN/profile/v1"><name>${escXml(ssid)}</name><SSIDConfig><SSID><name>${escXml(ssid)}</name></SSID></SSIDConfig><connectionType>ESS</connectionType><connectionMode>auto</connectionMode><MSM><security><authEncryption><authentication>open</authentication><encryption>none</encryption><useOneX>false</useOneX></authEncryption></security></MSM></WLANProfile>` : `<?xml version="1.0"?><WLANProfile xmlns="http://www.microsoft.com/networking/WLAN/profile/v1"><name>${escXml(ssid)}</name><SSIDConfig><SSID><name>${escXml(ssid)}</name></SSID></SSIDConfig><connectionType>ESS</connectionType><connectionMode>auto</connectionMode><MSM><security><authEncryption><authentication>WPA2PSK</authentication><encryption>AES</encryption><useOneX>false</useOneX></authEncryption><sharedKey><keyType>passPhrase</keyType><protected>false</protected><keyMaterial>${escXml(pass)}</keyMaterial></sharedKey></security></MSM></WLANProfile>`;
  writeFileSync8(profile, xml, "utf8");
  const add = await run2("netsh", ["wlan", "add", "profile", `filename=${profile}`, "user=current"]);
  if (add.code !== 0 && !/already|já existe/i.test(add.stdout + add.stderr)) {
    throw new Error((add.stderr || add.stdout || "falha ao gravar perfil Wi\u2011Fi").trim());
  }
  const con = await run2("netsh", ["wlan", "connect", `name=${ssid}`, `ssid=${ssid}`]);
  if (con.code !== 0) throw new Error((con.stderr || con.stdout || "falha ao conectar").trim());
}
function escXml(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
async function netForget(ssid) {
  const name = ssid.trim();
  saved4.managed = saved4.managed.filter((m) => m.ssid !== name);
  if (saved4.staSsid === name) saved4.staPass = "";
  persist6();
  lastError = "";
  try {
    if (process.platform === "linux") await helper3(["forget", name]);
  } catch (err) {
    lastError = err instanceof Error ? err.message : String(err);
  }
  return netStatus();
}
async function netSetLink(link) {
  saved4.link = link === "ethernet" ? "ethernet" : "wifi";
  persist6();
  lastError = "";
  lastNote = "";
  try {
    if (process.platform === "linux") {
      await helper3(["link", saved4.link]);
      await applyIpv4Linux();
    } else {
      lastNote = saved4.link === "ethernet" ? "Cabo selecionado. No Raspberry Pi a STA Wi\u2011Fi desliga e o Ethernet sobe. Neste Windows s\xF3 salva a prefer\xEAncia." : "Wi\u2011Fi selecionado. No Raspberry Pi o cabo deixa de ser o uplink. Neste Windows s\xF3 salva a prefer\xEAncia.";
    }
  } catch (err) {
    lastError = err instanceof Error ? err.message : String(err);
  }
  return netStatus();
}
async function netSetIp(body) {
  if (typeof body.dhcp === "boolean") saved4.dhcp = body.dhcp;
  if (typeof body.ip === "string") saved4.ip = body.ip.trim();
  if (typeof body.mask === "string") saved4.mask = body.mask.trim() || "255.255.255.0";
  if (typeof body.gw === "string") saved4.gw = body.gw.trim();
  if (typeof body.dns1 === "string") saved4.dns1 = body.dns1.trim();
  if (typeof body.dns2 === "string") saved4.dns2 = body.dns2.trim();
  lastError = "";
  lastNote = "";
  if (!saved4.dhcp) {
    if (!validIp(saved4.ip)) lastError = "IP inv\xE1lido";
    else if (!validIp(saved4.mask)) lastError = "M\xE1scara inv\xE1lida";
    else if (saved4.gw && !validIp(saved4.gw)) lastError = "Gateway inv\xE1lido";
    else if (saved4.dns1 && !validIp(saved4.dns1)) lastError = "DNS prim\xE1rio inv\xE1lido";
    else if (saved4.dns2 && !validIp(saved4.dns2)) lastError = "DNS secund\xE1rio inv\xE1lido";
  }
  persist6();
  if (lastError) return netStatus();
  try {
    if (process.platform === "linux") await applyIpv4Linux();
    else if (process.platform === "win32") lastNote = saved4.dhcp ? "DHCP gravado. No Pi aplica na interface ativa." : "IP fixo gravado. No Raspberry Pi aplica com nmcli; neste Windows n\xE3o altera o adaptador.";
  } catch (err) {
    lastError = err instanceof Error ? err.message : String(err);
  }
  return netStatus();
}
async function applyIpv4Linux() {
  const conn = saved4.link === "ethernet" ? "" : saved4.staSsid;
  if (saved4.dhcp) {
    await helper3(["ipv4", "dhcp", conn]);
    return;
  }
  await helper3(["ipv4", "manual", conn, saved4.ip, saved4.mask, saved4.gw, saved4.dns1, saved4.dns2]);
}
async function netSetHostname(name) {
  const host2 = name.trim().toLowerCase();
  lastError = "";
  lastNote = "";
  if (!HOST_RE.test(host2)) {
    lastError = "Nome inv\xE1lido (letras, n\xFAmeros e h\xEDfen)";
    return netStatus();
  }
  saved4.hostname = host2;
  persist6();
  try {
    if (process.platform === "linux") {
      await helper3(["hostname", host2]);
      lastNote = `Na LAN: http://${host2}.local`;
    } else {
      lastNote = `Nome gravado (${host2}.local no Pi). Neste Windows o nome do PC continua ${osHostname()}.`;
    }
  } catch (err) {
    lastError = err instanceof Error ? err.message : String(err);
  }
  return netStatus();
}
async function netSetAp(body) {
  if (typeof body.ssid === "string" && body.ssid.trim()) saved4.apSsid = body.ssid.trim();
  if (typeof body.pass === "string" && body.pass) saved4.apPass = body.pass;
  persist6();
  lastError = "";
  lastNote = "";
  if (saved4.apPass && saved4.apPass.length < 8) {
    lastError = "Senha do AP precisa de pelo menos 8 caracteres";
    return netStatus();
  }
  try {
    if (process.platform === "linux") await helper3(["ap", saved4.apSsid], saved4.apPass);
    else lastNote = "AP gravado. Sobe no Raspberry Pi (192.168.4.1).";
  } catch (err) {
    lastError = err instanceof Error ? err.message : String(err);
  }
  return netStatus();
}
async function netSave(body) {
  if (typeof body.hostname === "string" && HOST_RE.test(body.hostname.trim())) saved4.hostname = body.hostname.trim().toLowerCase();
  if (body.link === "ethernet" || body.link === "wifi") saved4.link = body.link;
  if (typeof body.dhcp === "boolean") saved4.dhcp = body.dhcp;
  if (typeof body.ip === "string") saved4.ip = body.ip.trim();
  if (typeof body.mask === "string") saved4.mask = body.mask.trim();
  if (typeof body.gw === "string") saved4.gw = body.gw.trim();
  if (typeof body.dns1 === "string") saved4.dns1 = body.dns1.trim();
  if (typeof body.dns2 === "string") saved4.dns2 = body.dns2.trim();
  if (typeof body.staSsid === "string") saved4.staSsid = body.staSsid.trim();
  if (typeof body.pass === "string") saved4.staPass = body.pass;
  if (typeof body.apSsid === "string") saved4.apSsid = body.apSsid.trim();
  persist6();
  return netStatus();
}

// server/index.ts
init_services();

// server/updates.ts
init_brand();
init_const();
init_version();
import { execFile as execFile13, spawn as spawn7 } from "node:child_process";
import { existsSync as existsSync13, readFileSync as readFileSync10 } from "node:fs";
import { dirname as dirname11, join as join12 } from "node:path";
import { fileURLToPath as fileURLToPath11 } from "node:url";
import { promisify as promisify13 } from "node:util";
var execFileAsync13 = promisify13(execFile13);
var ROOT11 = join12(dirname11(fileURLToPath11(import.meta.url)), "..");
var SHIPPED = join12(ROOT11, "deploy", "station", "versions.json");
function helperPath() {
  for (const p of ["/opt/ham-cockpit/bin/station-upd", "/opt/cat-bridge/bin/station-upd"]) {
    if (existsSync13(p)) return p;
  }
  return "/opt/ham-cockpit/bin/station-upd";
}
function appCurrent() {
  const candidates = [
    join12("/opt/ham-cockpit", "VERSION"),
    join12("/opt/cat-bridge", "VERSION"),
    join12(ROOT11, "VERSION")
  ];
  for (const p of candidates) {
    try {
      if (!existsSync13(p)) continue;
      const v = cleanVersion(readFileSync10(p, "utf8"));
      if (v) return v;
    } catch {
    }
  }
  return cleanVersion(APP_VERSION);
}
var jobs = /* @__PURE__ */ new Map();
function loadShipped() {
  const fallback = {
    app: APP_VERSION,
    os: "Ubuntu Server 24.04 LTS",
    osAvailable: "Ubuntu Server 24.04 LTS",
    ser2net: "4.3.13",
    hamlib: "4.5.5",
    wavelog: "1.9.4",
    wlg: "1.0.0"
  };
  try {
    const raw = JSON.parse(readFileSync10(SHIPPED, "utf8"));
    return { ...fallback, ...raw };
  } catch {
    return fallback;
  }
}
function wlgShipped() {
  const p = join12(ROOT11, "deploy", "wavelog-gate", "VERSION");
  try {
    if (existsSync13(p)) return readFileSync10(p, "utf8").trim() || "1.0.0";
  } catch {
  }
  return loadShipped().wlg;
}
function newer(available, current) {
  return isNewerVersion(available, current);
}
function jobOf(id) {
  return jobs.get(id);
}
function item(id, current, available, note = "", error3 = "") {
  const cur = current || "\u2014";
  const avail = available || cur;
  const job = jobOf(id);
  return {
    id,
    current: cur,
    available: avail,
    updatable: newer(avail, cur),
    applying: job?.status === "running",
    error: job?.error || error3,
    note,
    progress: job?.pct ?? 0,
    stage: job?.stage ?? "",
    determinate: job?.determinate ?? false
  };
}
async function githubRawVersion(url, ms = 2800) {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), ms);
    const r = await fetch(url, {
      signal: ctrl.signal,
      headers: { "User-Agent": `Ham-Cockpit/${APP_VERSION}` }
    });
    clearTimeout(t);
    if (!r.ok) return "";
    return cleanVersion(await r.text());
  } catch {
    return "";
  }
}
async function githubTag(repo, ms = 2800) {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), ms);
    const r = await fetch(`https://api.github.com/repos/${repo}/releases/latest`, {
      signal: ctrl.signal,
      headers: { Accept: "application/vnd.github+json", "User-Agent": `Ham-Cockpit/${APP_VERSION}` }
    });
    clearTimeout(t);
    if (!r.ok) return "";
    const j = await r.json();
    return cleanVersion(String(j.tag_name || j.name || ""));
  } catch {
    return "";
  }
}
async function githubAppVersion() {
  const headers = { Accept: "application/vnd.github+json", "User-Agent": `Ham-Cockpit/${APP_VERSION}` };
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 3500);
    const r = await fetch(`https://raw.githubusercontent.com/${UPDATE_REPO}/main/update/version.json`, {
      signal: ctrl.signal,
      headers
    });
    clearTimeout(t);
    if (r.ok) {
      const j = await r.json();
      return cleanVersion(String(j.version || ""));
    }
  } catch {
  }
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 3e3);
    const r = await fetch(`https://api.github.com/repos/${UPDATE_REPO}/contents/update?ref=main`, {
      headers,
      signal: ctrl.signal
    });
    clearTimeout(t);
    if (!r.ok) return "";
    const list = await r.json();
    const vers = list.map(
      (x) => String(x.name || "").replace(/\.(json|tgz|tar\.gz)$/i, "").replace(/^ham-cockpit-?/i, "").replace(/^v/i, "")
    ).filter((n) => /^\d+\.\d+/.test(n));
    vers.sort((a, b) => compareVersion(a, b));
    return vers[vers.length - 1] || "";
  } catch {
    return "";
  }
}
function execError(err) {
  const e = err;
  const stderr = String(e.stderr || "").split(/\r?\n/).filter((l) => l.trim() && !l.includes("HC_PROGRESS ")).join("\n").trim();
  if (e.killed) return stderr || "tempo esgotado ao consultar station-upd";
  if (stderr) return stderr.split(/\r?\n/).filter(Boolean).slice(-6).join("\n");
  const msg = String(e.message || err).split(/\r?\n/).filter((l) => l.trim() && !l.includes("HC_PROGRESS ")).join("\n");
  return msg || String(err);
}
async function helper4(cmd, id = "") {
  const bin = helperPath();
  if (process.platform !== "linux" || !existsSync13(bin)) return null;
  try {
    const args = id ? [cmd, id] : [cmd];
    const timeout = cmd === "apply" ? 3e5 : cmd === "refresh" ? 5e4 : 18e3;
    const { stdout } = await execFileAsync13("sudo", ["-n", bin, ...args], {
      timeout,
      windowsHide: true,
      maxBuffer: 2e6
    });
    return parseHelperOut(String(stdout || "").trim());
  } catch (err) {
    return snapshot(baseline().items, loadShipped().os, false, execError(err));
  }
}
function parseHelperOut(stdout) {
  try {
    const parsed = JSON.parse(lastJsonObject(stdout || "{}"));
    if (!Array.isArray(parsed.items)) return null;
    const byId = new Map(parsed.items.map((row) => [row.id, row]));
    const items = UPDATE_IDS.map((id) => {
      const hit = byId.get(id);
      if (id === "app") {
        const cur = appCurrent() || String(hit?.current || "");
        const avail = String(hit?.available || cur);
        return item("app", cur, avail, String(hit?.note || `github.com/${UPDATE_REPO}/update`), String(hit?.error || ""));
      }
      return item(
        id,
        String(hit?.current || ""),
        String(hit?.available || hit?.current || ""),
        String(hit?.note || ""),
        String(hit?.error || "")
      );
    });
    return snapshot(items, String(parsed.os || ""), parsed.ok !== false, String(parsed.error || ""));
  } catch {
    return null;
  }
}
function snapshot(items, os2, ok = true, error3 = "") {
  const decorated = items.map((row) => {
    const job = jobOf(row.id);
    if (!job) return { ...row, applying: false };
    return {
      ...row,
      applying: job.status === "running",
      error: job.error || row.error,
      progress: job.pct,
      stage: job.stage,
      determinate: job.determinate
    };
  });
  return {
    ok,
    os: os2,
    pending: decorated.filter((row) => row.updatable).length,
    items: decorated,
    jobs: Array.from(jobs.values()),
    error: error3
  };
}
function baseline() {
  const s = loadShipped();
  const wlg = wlgShipped();
  const app = appCurrent() || s.app;
  const items = [
    item("app", app, app, `github.com/${UPDATE_REPO}/update`),
    item("os", s.os, s.osAvailable, "Ubuntu Server"),
    item("ser2net", s.ser2net, s.ser2net, "apt ser2net"),
    item("hamlib", s.hamlib, s.hamlib, "apt libhamlib-utils"),
    item("wavelog", s.wavelog, s.wavelog, "docker ghcr.io/wavelog/wavelog"),
    item("wlg", wlg, wlg, "WaveLogGate headless")
  ];
  return snapshot(items, s.os);
}
function looksVersion(v) {
  return /\d/.test(v) && v !== "\u2014";
}
async function fetchRemotes() {
  const [app, wavelog, wlg] = await Promise.all([
    githubAppVersion(),
    githubTag("wavelog/wavelog"),
    githubRawVersion(`https://raw.githubusercontent.com/${UPDATE_REPO}/main/deploy/wavelog-gate/VERSION`)
  ]);
  return { app, wavelog, wlg };
}
function applyRemotes(base, rem) {
  const next = base.items.map((row) => {
    if (row.id === "app") {
      const installed = appCurrent() || row.current;
      const remote = rem.app || row.available || installed;
      return item("app", installed, remote, row.note, row.error);
    }
    if (row.id === "wavelog" && rem.wavelog && looksVersion(row.current)) {
      return item(row.id, row.current, rem.wavelog, row.note, row.error);
    }
    if (row.id === "wlg" && rem.wlg && looksVersion(row.current)) {
      return item(row.id, row.current, rem.wlg, row.note, row.error);
    }
    return row;
  });
  return snapshot(next, base.os, base.ok, base.error);
}
var cache = null;
function ingestProgress(id, text) {
  const job = jobs.get(id);
  if (!job) return;
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line.startsWith("HC_PROGRESS ")) continue;
    try {
      const j = JSON.parse(line.slice("HC_PROGRESS ".length));
      if (typeof j.pct === "number" && Number.isFinite(j.pct)) job.pct = Math.max(0, Math.min(100, Math.round(j.pct)));
      if (typeof j.stage === "string" && j.stage) job.stage = j.stage;
      if (typeof j.determinate === "boolean") job.determinate = j.determinate;
      if (typeof j.error === "string" && j.error) job.error = j.error;
    } catch {
    }
  }
}
async function updatesStatus(force = false) {
  const running = Array.from(jobs.values()).some((j) => j.status === "running");
  if (running) {
    const base = cache?.snap ?? baseline();
    return snapshot(base.items, base.os, true, "");
  }
  if (!force && cache && Date.now() - cache.at < 6e4) {
    return snapshot(cache.snap.items, cache.snap.os, cache.snap.ok, cache.snap.error);
  }
  const [live3, rem] = await Promise.all([helper4("check"), fetchRemotes()]);
  const snap4 = applyRemotes(live3 ?? baseline(), rem);
  cache = { at: Date.now(), snap: snap4 };
  return snap4;
}
async function updatesRefresh() {
  cache = null;
  const [live3, rem] = await Promise.all([helper4("refresh"), fetchRemotes()]);
  const snap4 = applyRemotes(live3 ?? baseline(), rem);
  cache = { at: Date.now(), snap: snap4 };
  return snap4;
}
function lastJsonObject(text) {
  const start = text.lastIndexOf('{"ok"');
  if (start >= 0) return text.slice(start);
  const alt = text.lastIndexOf("{");
  return alt >= 0 ? text.slice(alt) : text;
}
function spawnApply(sid) {
  const bin = helperPath();
  const job = { id: sid, status: "running", pct: 2, determinate: false, stage: "prepare", error: "" };
  jobs.set(sid, job);
  return new Promise((resolve) => {
    const child2 = spawn7("sudo", ["-n", bin, "apply", sid], {
      windowsHide: true
    });
    let stdout = "";
    let stderr = "";
    const killer = setTimeout(() => child2.kill("SIGTERM"), 3e5);
    child2.stdout?.on("data", (buf) => {
      stdout += String(buf);
    });
    child2.stderr?.on("data", (buf) => {
      const chunk = String(buf);
      stderr += chunk;
      ingestProgress(sid, chunk);
    });
    const finish2 = async (code, errMsg = "") => {
      clearTimeout(killer);
      const parsed = parseHelperOut(lastJsonObject(stdout.trim()));
      const errText = errMsg || stderr.split(/\r?\n/).filter((l) => l.trim() && !l.includes("HC_PROGRESS ")).slice(-8).join("\n");
      if (code === 0 && parsed) {
        job.status = "ok";
        job.pct = 100;
        job.determinate = true;
        job.stage = "done";
        const over = applyRemotes(parsed, await fetchRemotes());
        cache = { at: Date.now(), snap: over };
        jobs.delete(sid);
        resolve(over);
        return;
      }
      job.status = "error";
      job.determinate = true;
      job.stage = "error";
      job.error = errText || `falha ao aplicar ${sid} (c\xF3digo ${code ?? "?"})`;
      const cur = cache?.snap ?? await updatesStatus(true);
      const failed = snapshot(
        cur.items.map((row) => row.id === sid ? { ...row, error: job.error } : row),
        cur.os,
        false,
        job.error
      );
      cache = { at: Date.now(), snap: failed };
      setTimeout(() => {
        if (jobs.get(sid)?.status === "error") jobs.delete(sid);
      }, 2e4);
      resolve(failed);
    };
    child2.on("error", (err) => {
      void finish2(1, String(err.message || err));
    });
    child2.on("close", (code) => {
      void finish2(code);
    });
  });
}
async function updatesApply(id) {
  if (!UPDATE_IDS.includes(id)) {
    const cur = await updatesStatus();
    return { ...cur, ok: false, error: "componente desconhecido" };
  }
  const sid = id;
  const existing = jobs.get(sid);
  if (existing?.status === "running") {
    const cur = cache?.snap ?? await updatesStatus();
    return snapshot(cur.items, cur.os, true, "");
  }
  if (process.platform !== "linux" || !existsSync13(helperPath())) {
    const cur = await updatesStatus();
    return {
      ...cur,
      ok: false,
      error: "O aplicativo roda no Ubuntu Server da esta\xE7\xE3o. Neste host s\xF3 a verifica\xE7\xE3o est\xE1 dispon\xEDvel."
    };
  }
  try {
    return await spawnApply(sid);
  } catch (err) {
    const cur = await updatesStatus(true);
    return { ...cur, ok: false, error: String(err) };
  }
}

// server/layouts.ts
import { existsSync as existsSync14, mkdirSync as mkdirSync9, readFileSync as readFileSync11, renameSync as renameSync9, writeFileSync as writeFileSync9 } from "node:fs";
import { dirname as dirname12, join as join13 } from "node:path";
import { fileURLToPath as fileURLToPath12 } from "node:url";
var ROOT12 = join13(dirname12(fileURLToPath12(import.meta.url)), "..");
var OPT_DIR8 = "/opt/ham-cockpit/layouts";
function dataDir9() {
  if (existsSync14("/opt/ham-cockpit")) {
    mkdirSync9(OPT_DIR8, { recursive: true });
    return OPT_DIR8;
  }
  const local = join13(ROOT12, "data", "layouts");
  mkdirSync9(local, { recursive: true });
  return local;
}
function jsonPath7() {
  return join13(dataDir9(), "panel.json");
}
function writeAtomic5(file, body) {
  const tmp = `${file}.${process.pid}.tmp`;
  writeFileSync9(tmp, body, { encoding: "utf8" });
  renameSync9(tmp, file);
}
function sanitizeUser(name) {
  const n = String(name ?? "").trim().replace(/[^a-zA-Z0-9._-]/g, "").slice(0, 32);
  return n || "admin";
}
function loadStore() {
  try {
    const raw = readFileSync11(jsonPath7(), "utf8");
    const j = JSON.parse(raw);
    if (!j || typeof j !== "object" || Array.isArray(j)) return {};
    return j;
  } catch {
    return {};
  }
}
function asTile(v) {
  if (!v || typeof v !== "object") return null;
  const o = v;
  const id = String(o.id || "");
  if (!id) return null;
  const x = Math.max(0, Math.min(11, Math.round(Number(o.x) || 0)));
  const y = Math.max(0, Math.min(80, Math.round(Number(o.y) || 0)));
  const w = Math.max(2, Math.min(12, Math.round(Number(o.w) || 4)));
  const h = Math.max(3, Math.min(40, Math.round(Number(o.h) || 6)));
  return { id, x, y, w: Math.min(w, 12 - x), h };
}
function layoutGet(user) {
  const name = sanitizeUser(user);
  const store = loadStore();
  if (!Object.prototype.hasOwnProperty.call(store, name)) {
    return { ok: true, user: name, tiles: null };
  }
  const tiles = Array.isArray(store[name]) ? store[name].map(asTile).filter(Boolean) : [];
  return { ok: true, user: name, tiles };
}
function layoutSave(user, tiles) {
  const name = sanitizeUser(user);
  const list = Array.isArray(tiles) ? tiles.map(asTile).filter(Boolean) : [];
  const store = loadStore();
  store[name] = list;
  writeAtomic5(jsonPath7(), `${JSON.stringify(store, null, 2)}
`);
  return { ok: true, user: name, tiles: store[name] };
}

// server/vfo-display.ts
import { execFile as execFile14 } from "node:child_process";
import { promisify as promisify14 } from "node:util";
var execFileAsync14 = promisify14(execFile14);
var HELPER7 = "/opt/ham-cockpit/bin/vfo-display-ctl";
function clientIp(req) {
  const forwarded = String(req.headers["x-forwarded-for"] || "").split(",")[0].trim();
  const real = String(req.headers["x-real-ip"] || "").trim();
  return real || forwarded || req.socket.remoteAddress || "";
}
function isLoopback(req) {
  const ip = clientIp(req);
  return ip === "127.0.0.1" || ip === "::1" || ip === "::ffff:127.0.0.1" || ip.endsWith("127.0.0.1");
}
async function vfoDisplayExit() {
  try {
    await execFileAsync14("sudo", ["-n", HELPER7, "exit"], { timeout: 8e3 });
    return { ok: true };
  } catch (err) {
    return { ok: false, error: String(err) };
  }
}

// server/index.ts
init_ldg();
init_lp100a();

// server/backup.ts
import { execFile as execFile15, spawn as spawn8 } from "node:child_process";
import { randomBytes as randomBytes3 } from "node:crypto";
import {
  accessSync,
  chmodSync as chmodSync2,
  constants,
  cpSync,
  existsSync as existsSync15,
  mkdirSync as mkdirSync10,
  readdirSync as readdirSync3,
  readFileSync as readFileSync12,
  rmSync,
  statSync as statSync2,
  unlinkSync as unlinkSync3,
  writeFileSync as writeFileSync10
} from "node:fs";
import { tmpdir } from "node:os";
import { basename, dirname as dirname13, join as join14 } from "node:path";
import { fileURLToPath as fileURLToPath13 } from "node:url";
import { promisify as promisify15 } from "node:util";
var execFileAsync15 = promisify15(execFile15);
var ROOT13 = join14(dirname13(fileURLToPath13(import.meta.url)), "..");
var ID_RE = /^(?:hamcockpit|catbridge)-\d{8}-\d{6}-[a-f0-9]{8}$/;
var HELPER8 = "/opt/ham-cockpit/bin/station-backup";
var WAVELG_OPT_FILES = [".env", "docker-compose.yml", "wavelog-ctl.sh"];
function linux3() {
  return process.platform === "linux";
}
function backupDir() {
  if (linux3()) {
    for (const dir of ["/backup", "/opt/ham-cockpit/backup"]) {
      try {
        mkdirSync10(dir, { recursive: true });
        const probe2 = join14(dir, ".w");
        writeFileSync10(probe2, "1");
        unlinkSync3(probe2);
        return dir;
      } catch {
      }
    }
  }
  const local = join14(ROOT13, "data", "backup");
  mkdirSync10(local, { recursive: true });
  return local;
}
function stationSources() {
  const local = (name) => join14(ROOT13, "data", name);
  const cat = existsSync15("/opt/ham-cockpit");
  return [
    { key: "ser2net", dir: existsSync15("/opt/ser2net") ? "/opt/ser2net" : local("ser2net") },
    {
      key: "radios",
      dir: cat ? existsSync15("/opt/radios") && !existsSync15("/opt/ham-cockpit/radios") ? "/opt/radios" : "/opt/ham-cockpit/radios" : local("radios")
    },
    { key: "equipment", dir: cat ? "/opt/ham-cockpit/equipment" : local("equipment") },
    { key: "layouts", dir: cat ? "/opt/ham-cockpit/layouts" : local("layouts") },
    { key: "ldg", dir: cat ? "/opt/ham-cockpit/ldg" : local("ldg") },
    { key: "lp100a", dir: cat ? "/opt/ham-cockpit/lp100a" : local("lp100a") },
    { key: "net", dir: cat ? "/opt/ham-cockpit/net" : local("net") },
    { key: "services", dir: cat ? "/opt/ham-cockpit/services" : local("services") },
    { key: "lextel", dir: existsSync15("/opt/lextel") ? "/opt/lextel" : local("lextel") },
    { key: "mmdvm", dir: existsSync15("/opt/ham-cockpit/mmdvm") ? "/opt/ham-cockpit/mmdvm" : local("mmdvm") }
  ];
}
function wlgDir() {
  if (existsSync15("/opt/wavelog-gate")) return "/opt/wavelog-gate";
  return join14(ROOT13, "deploy", "wavelog-gate");
}
function wavelogDir() {
  if (existsSync15("/opt/wavelog")) return "/opt/wavelog";
  return join14(ROOT13, "deploy", "wavelog");
}
function stamp(d = /* @__PURE__ */ new Date()) {
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}
function skipName(base) {
  if (base === "node_modules" || base === "capture.bin") return true;
  if (base.endsWith(".lock")) return true;
  return false;
}
function isEacces(err) {
  return Boolean(err && typeof err === "object" && "code" in err && err.code === "EACCES");
}
function readable(path2) {
  try {
    accessSync(path2, constants.R_OK);
    return true;
  } catch {
    return false;
  }
}
function writableTarget(path2) {
  try {
    if (existsSync15(path2)) {
      accessSync(path2, constants.W_OK);
      return true;
    }
    accessSync(dirname13(path2), constants.W_OK);
    return true;
  } catch {
    return false;
  }
}
function run3(cmd, args, opts) {
  return new Promise((resolve, reject) => {
    const child2 = spawn8(cmd, args, {
      cwd: opts?.cwd,
      windowsHide: true,
      stdio: ["pipe", "pipe", "pipe"]
    });
    let stdout = "";
    let stderr = "";
    const timer = setTimeout(() => {
      child2.kill();
    }, opts?.timeout ?? 12e4);
    child2.stdout.on("data", (d) => {
      stdout += d.toString("utf8");
    });
    child2.stderr.on("data", (d) => {
      stderr += d.toString("utf8");
    });
    child2.on("error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
    child2.on("close", (code) => {
      clearTimeout(timer);
      resolve({ code: code ?? 1, stdout, stderr });
    });
    if (opts?.input !== void 0) child2.stdin.write(opts.input);
    child2.stdin.end();
  });
}
async function helper5(args, timeout = 15e3) {
  if (!linux3() || !existsSync15(HELPER8)) return { ok: false, stdout: "", stderr: "helper ausente" };
  try {
    const r = await run3("sudo", ["-n", HELPER8, ...args], { timeout });
    return { ok: r.code === 0, stdout: r.stdout, stderr: r.stderr };
  } catch (err) {
    return { ok: false, stdout: "", stderr: err instanceof Error ? err.message : String(err) };
  }
}
async function ensureWavelogEnvPerms(warnings) {
  if (!linux3() || !existsSync15(join14(wavelogDir(), ".env"))) return;
  if (readable(join14(wavelogDir(), ".env"))) return;
  const r = await helper5(["ensure-env"]);
  if (!r.ok) {
    warnings.push(`permiss\xF5es do Wavelog .env: ${r.stderr.trim() || "sudo/station-backup indispon\xEDvel"}`);
  }
}
async function copyPrivilegedFile(src, dest, warnings, label) {
  if (!existsSync15(src)) return false;
  mkdirSync10(dirname13(dest), { recursive: true });
  if (readable(src)) {
    try {
      cpSync(src, dest);
      return true;
    } catch (err) {
      if (!isEacces(err)) {
        warnings.push(`${label}: ${err instanceof Error ? err.message : String(err)}`);
        return false;
      }
    }
  }
  const r = await helper5(["copy", src, dest]);
  if (r.ok && existsSync15(dest)) return true;
  warnings.push(`${label}: sem permiss\xE3o para ler ${src}`);
  return false;
}
async function installPrivilegedFile(src, dest, warnings, label) {
  if (!existsSync15(src)) return false;
  mkdirSync10(dirname13(dest), { recursive: true });
  if (writableTarget(dest)) {
    try {
      cpSync(src, dest);
      return true;
    } catch (err) {
      if (!isEacces(err)) {
        warnings.push(`${label}: ${err instanceof Error ? err.message : String(err)}`);
        return false;
      }
    }
  }
  const r = await helper5(["install", src, dest]);
  if (r.ok) return true;
  warnings.push(`${label}: sem permiss\xE3o para gravar ${dest}`);
  return false;
}
function copyTree(src, dest, warnings, label) {
  if (!existsSync15(src)) return false;
  let any = false;
  const walk = (from, to) => {
    let st;
    try {
      st = statSync2(from);
    } catch (err) {
      if (isEacces(err)) warnings.push(`${label}: sem permiss\xE3o para acessar ${from}`);
      else warnings.push(`${label}: ${err instanceof Error ? err.message : String(err)}`);
      return;
    }
    if (st.isFile()) {
      if (skipName(basename(from))) return;
      try {
        mkdirSync10(dirname13(to), { recursive: true });
        cpSync(from, to);
        any = true;
      } catch (err) {
        if (isEacces(err)) warnings.push(`${label}: sem permiss\xE3o para copiar ${from}`);
        else warnings.push(`${label}: ${err instanceof Error ? err.message : String(err)}`);
      }
      return;
    }
    try {
      mkdirSync10(to, { recursive: true });
      for (const name of readdirSync3(from)) {
        if (skipName(name)) continue;
        walk(join14(from, name), join14(to, name));
      }
      any = true;
    } catch (err) {
      if (isEacces(err)) warnings.push(`${label}: sem permiss\xE3o para listar ${from}`);
      else warnings.push(`${label}: ${err instanceof Error ? err.message : String(err)}`);
    }
  };
  walk(src, dest);
  return any;
}
function envValueFromText2(text, key) {
  const line = text.split(/\r?\n/).find((l) => l.startsWith(`${key}=`));
  return line ? line.slice(key.length + 1).trim().replace(/^["']|["']$/g, "") : "";
}
async function readEnvValue(file, key, warnings) {
  if (!existsSync15(file)) return "";
  if (readable(file)) {
    try {
      return envValueFromText2(readFileSync12(file, "utf8"), key);
    } catch (err) {
      if (!isEacces(err)) {
        warnings.push(`.env: ${err instanceof Error ? err.message : String(err)}`);
        return "";
      }
    }
  }
  const r = await helper5(["cat", file]);
  if (r.ok) return envValueFromText2(r.stdout, key);
  warnings.push(`sem permiss\xE3o para ler ${file}`);
  return "";
}
async function dumpWavelog(dest, warnings, parts) {
  mkdirSync10(dest, { recursive: true });
  const home = wavelogDir();
  let copiedOpt = false;
  for (const name of WAVELG_OPT_FILES) {
    const src = join14(home, name);
    if (!existsSync15(src)) continue;
    const ok = await copyPrivilegedFile(src, join14(dest, "opt", name), warnings, `wavelog:${name}`);
    if (ok) copiedOpt = true;
  }
  if (copiedOpt) parts.push("wavelog:opt");
  try {
    const { stdout } = await execFileAsync15("docker", ["volume", "ls", "-q"], { timeout: 15e3, windowsHide: true });
    const vols = stdout.split(/\r?\n/).map((v) => v.trim()).filter((v) => /wavelog/i.test(v) && !/dbdata/i.test(v));
    for (const vol of vols) {
      const out = join14(dest, `${vol}.tgz`);
      const r = await run3("docker", ["run", "--rm", "-v", `${vol}:/from:ro`, "-v", `${dest}:/to`, "alpine:3.20", "tar", "czf", `/to/${basename(out)}`, "-C", "/from", "."], {
        timeout: 18e4
      });
      if (r.code === 0 && existsSync15(out)) parts.push(`wavelog:${vol}`);
      else warnings.push(`volume ${vol}: ${r.stderr.trim() || r.code}`);
    }
  } catch (err) {
    warnings.push(`docker volumes: ${err instanceof Error ? err.message : String(err)}`);
  }
  const pass = await readEnvValue(join14(home, ".env"), "WAVELOG_DB_PASSWORD", warnings);
  if (!pass) {
    warnings.push("WAVELOG_DB_PASSWORD ausente \u2014 dump SQL do Wavelog n\xE3o feito");
    return;
  }
  try {
    const r = await run3("docker", ["exec", "wavelog-db", "mariadb-dump", `-uwavelog`, `-p${pass}`, "--single-transaction", "wavelog"], {
      timeout: 18e4
    });
    if (r.code === 0 && r.stdout.includes("CREATE TABLE")) {
      writeFileSync10(join14(dest, "wavelog.sql"), r.stdout);
      parts.push("wavelog-db");
    } else {
      warnings.push(`mariadb-dump: ${r.stderr.trim() || r.code}`);
    }
  } catch (err) {
    warnings.push(`mariadb-dump: ${err instanceof Error ? err.message : String(err)}`);
  }
}
async function restoreWavelog(src, warnings) {
  const home = wavelogDir();
  const opt = join14(src, "opt");
  if (existsSync15(opt)) {
    mkdirSync10(home, { recursive: true });
    for (const name of readdirSync3(opt)) {
      const from = join14(opt, name);
      const to = join14(home, name);
      if (WAVELG_OPT_FILES.includes(name) || name.endsWith(".env")) {
        await installPrivilegedFile(from, to, warnings, `restore wavelog:${name}`);
      } else {
        try {
          cpSync(from, to);
        } catch (err) {
          warnings.push(
            isEacces(err) ? `restore wavelog:${name}: sem permiss\xE3o` : `restore wavelog:${name}: ${err instanceof Error ? err.message : String(err)}`
          );
        }
      }
    }
  }
  const tgz = existsSync15(src) ? readdirSync3(src).filter((n) => n.endsWith(".tgz")) : [];
  for (const file of tgz) {
    const vol = file.replace(/\.tgz$/, "");
    const r = await run3(
      "docker",
      ["run", "--rm", "-v", `${vol}:/to`, "-v", `${src}:/from:ro`, "alpine:3.20", "sh", "-c", `rm -rf /to/* /to/.[!.]*; tar xzf /from/${file} -C /to`],
      { timeout: 18e4 }
    );
    if (r.code !== 0) warnings.push(`restore ${vol}: ${r.stderr.trim() || r.code}`);
  }
  const sql = join14(src, "wavelog.sql");
  const pass = await readEnvValue(join14(home, ".env"), "WAVELOG_DB_PASSWORD", warnings);
  if (existsSync15(sql) && pass) {
    try {
      const dump = readFileSync12(sql);
      const r = await run3("docker", ["exec", "-i", "wavelog-db", "mariadb", `-uwavelog`, `-p${pass}`, "wavelog"], {
        timeout: 18e4,
        input: dump
      });
      if (r.code !== 0) warnings.push(`mariadb restore: ${r.stderr.trim() || r.code}`);
    } catch (err) {
      warnings.push(`mariadb restore: ${err instanceof Error ? err.message : String(err)}`);
    }
  }
}
function sidecarPath(dir, id) {
  return join14(dir, `${id}.json`);
}
function archivePath(dir, id) {
  return join14(dir, `${id}.tgz`);
}
function readSidecar(dir, id) {
  try {
    const j = JSON.parse(readFileSync12(sidecarPath(dir, id), "utf8"));
    if (j && j.id === id) return j;
  } catch {
  }
  return null;
}
function toItem(dir, id) {
  const file = archivePath(dir, id);
  if (!existsSync15(file)) return null;
  const size = statSync2(file).size;
  const sc = readSidecar(dir, id);
  const st = statSync2(file);
  return {
    id,
    user: sc?.user || "admin",
    createdAt: sc?.createdAt || st.mtime.toISOString(),
    size,
    parts: sc?.parts || [],
    warnings: sc?.warnings || []
  };
}
function backupList() {
  const dir = backupDir();
  const ids = readdirSync3(dir).filter((n) => n.endsWith(".tgz")).map((n) => n.replace(/\.tgz$/, "")).filter((id) => ID_RE.test(id));
  const items = ids.map((id) => toItem(dir, id)).filter((x) => Boolean(x)).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return { ok: true, folder: dir, items };
}
async function backupCreate(user) {
  const who = String(user || "admin").replace(/[^a-zA-Z0-9._-]/g, "").slice(0, 32) || "admin";
  const dir = backupDir();
  const now = /* @__PURE__ */ new Date();
  const id = `hamcockpit-${stamp(now)}-${randomBytes3(4).toString("hex")}`;
  const staging = join14(tmpdir(), id);
  mkdirSync10(join14(staging, "station"), { recursive: true });
  const parts = [];
  const warnings = [];
  try {
    await ensureWavelogEnvPerms(warnings);
    for (const src of stationSources()) {
      if (copyTree(src.dir, join14(staging, "station", src.key), warnings, `station:${src.key}`)) {
        parts.push(`station:${src.key}`);
      }
    }
    try {
      const users = await listUsers();
      writeFileSync10(join14(staging, "station", "linux-users.json"), `${JSON.stringify({ users }, null, 2)}
`);
      parts.push("station:users");
    } catch (err) {
      warnings.push(`users: ${err instanceof Error ? err.message : String(err)}`);
    }
    if (copyTree(wlgDir(), join14(staging, "wlg"), warnings, "wlg")) parts.push("wlg");
    await dumpWavelog(join14(staging, "wavelog"), warnings, parts);
    writeFileSync10(
      join14(staging, "manifest.json"),
      `${JSON.stringify({ version: 1, id, user: who, createdAt: now.toISOString(), parts, warnings }, null, 2)}
`
    );
    const dest = archivePath(dir, id);
    const tar = await run3("tar", ["-czf", dest, "-C", staging, "."], { timeout: 18e4 });
    if (tar.code !== 0 || !existsSync15(dest)) {
      return { ok: false, error: tar.stderr.trim() || "tar" };
    }
    try {
      chmodSync2(dest, 416);
    } catch {
    }
    const sc = { version: 1, id, user: who, createdAt: now.toISOString(), parts, warnings };
    writeFileSync10(sidecarPath(dir, id), `${JSON.stringify(sc, null, 2)}
`);
    const item2 = toItem(dir, id);
    return item2 ? { ok: true, item: item2, folder: dir } : { ok: false, error: "stat" };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : String(err) };
  } finally {
    rmSync(staging, { recursive: true, force: true });
  }
}
function backupDelete(id) {
  if (!ID_RE.test(id)) return { ok: false, error: "id" };
  const dir = backupDir();
  const file = archivePath(dir, id);
  if (!existsSync15(file)) return { ok: false, error: "missing" };
  unlinkSync3(file);
  if (existsSync15(sidecarPath(dir, id))) unlinkSync3(sidecarPath(dir, id));
  return { ok: true };
}
async function backupRestore(id, confirm) {
  if (!confirm) return { ok: false, error: "confirm" };
  if (!ID_RE.test(id)) return { ok: false, error: "id" };
  const dir = backupDir();
  const file = archivePath(dir, id);
  if (!existsSync15(file)) return { ok: false, error: "missing" };
  const staging = join14(tmpdir(), `restore-${id}`);
  mkdirSync10(staging, { recursive: true });
  const warnings = [];
  try {
    const tar = await run3("tar", ["-xzf", file, "-C", staging], { timeout: 18e4 });
    if (tar.code !== 0) return { ok: false, error: tar.stderr.trim() || "tar" };
    const station = join14(staging, "station");
    if (existsSync15(station)) {
      for (const src of stationSources()) {
        const from = join14(station, src.key);
        if (!existsSync15(from)) continue;
        mkdirSync10(src.dir, { recursive: true });
        copyTree(from, src.dir, warnings, `restore station:${src.key}`);
      }
    }
    const wlg = join14(staging, "wlg");
    if (existsSync15(wlg)) {
      const gateEnv = join14(wlg, "wavelog-gate.env");
      const destEnv = join14(wlgDir(), "wavelog-gate.env");
      copyTree(wlg, wlgDir(), warnings, "restore wlg");
      if (existsSync15(gateEnv)) {
        await installPrivilegedFile(gateEnv, destEnv, warnings, "restore wlg:env");
      }
    }
    const wav = join14(staging, "wavelog");
    if (existsSync15(wav)) await restoreWavelog(wav, warnings);
    await ensureWavelogEnvPerms(warnings);
    return { ok: true, warnings };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : String(err) };
  } finally {
    rmSync(staging, { recursive: true, force: true });
  }
}

// server/index.ts
init_host_status();
init_mmdvm();

// server/hamlib-hub.ts
init_equipment();
import { existsSync as existsSync16, mkdirSync as mkdirSync11, readFileSync as readFileSync13, renameSync as renameSync10, writeFileSync as writeFileSync11 } from "node:fs";
import { dirname as dirname14, join as join15 } from "node:path";
import { fileURLToPath as fileURLToPath14 } from "node:url";
import { Socket } from "node:net";
var ROOT14 = join15(dirname14(fileURLToPath14(import.meta.url)), "..");
var OPT_DIR9 = "/opt/ham-cockpit/equipment";
function dataDir10() {
  if (existsSync16("/opt/ham-cockpit")) {
    mkdirSync11(OPT_DIR9, { recursive: true });
    return OPT_DIR9;
  }
  const local = join15(ROOT14, "data", "equipment");
  mkdirSync11(local, { recursive: true });
  return local;
}
function bindingsPath() {
  return join15(dataDir10(), "bindings.json");
}
function writeAtomic6(file, body) {
  const tmp = `${file}.${process.pid}.tmp`;
  writeFileSync11(tmp, body, { encoding: "utf8" });
  renameSync10(tmp, file);
}
var bindings = [];
function load2() {
  try {
    const raw = JSON.parse(readFileSync13(bindingsPath(), "utf8"));
    if (!Array.isArray(raw.bindings)) {
      bindings = [];
      return;
    }
    bindings = raw.bindings.map((b) => sanitizeBinding(b)).filter(Boolean);
  } catch {
    bindings = [];
  }
}
function persist7() {
  writeAtomic6(bindingsPath(), `${JSON.stringify({ bindings }, null, 2)}
`);
}
function newId3() {
  return Math.random().toString(16).slice(2, 10);
}
function sanitizeBinding(raw) {
  const equipmentId = String(raw.equipmentId || "").trim();
  if (!equipmentId || !getEquipment(equipmentId)) return null;
  return {
    id: String(raw.id || newId3()),
    equipmentId,
    connectionKind: raw.connectionKind || "usb-serial",
    host: raw.host ? String(raw.host).trim() : void 0,
    ports: raw.ports,
    ser2netPort: raw.ser2netPort != null ? Number(raw.ser2netPort) : void 0,
    baud: raw.baud != null ? Number(raw.baud) : void 0,
    civAddr: raw.civAddr ? String(raw.civAddr).trim() : void 0,
    username: raw.username ? String(raw.username) : void 0,
    password: raw.password ? String(raw.password) : void 0,
    hamlibListenPort: raw.hamlibListenPort != null ? Number(raw.hamlibListenPort) : void 0,
    label: raw.label ? String(raw.label).trim() : void 0,
    enabled: raw.enabled !== false
  };
}
load2();
function buildPlans() {
  return bindings.filter((b) => b.enabled).map((b) => {
    const plan = planHamlib(b);
    if (!plan) return null;
    return {
      ...plan,
      bindingId: b.id,
      command: formatRigctldCommand(plan)
    };
  }).filter(Boolean);
}
function hubCatalog(maker) {
  const list = maker ? EQUIPMENT_CATALOG.filter((e) => e.maker === maker) : EQUIPMENT_CATALOG;
  return {
    ok: true,
    makers: Array.from(new Set(EQUIPMENT_CATALOG.map((e) => e.maker))),
    hamlibReady: listHamlibReady().map((e) => e.id),
    equipment: list
  };
}
function hubStatus() {
  return {
    ok: true,
    folder: dataDir10(),
    catalogCount: EQUIPMENT_CATALOG.length,
    hamlibReadyCount: listHamlibReady().length,
    bindings,
    plans: buildPlans()
  };
}
function hubSaveBindings(body) {
  if (Array.isArray(body.bindings)) {
    bindings = body.bindings.map((b) => sanitizeBinding(b)).filter(Boolean);
    persist7();
  }
  return hubStatus();
}
function hubUpsertBinding(raw) {
  const next = sanitizeBinding(raw);
  if (!next) {
    const snap4 = hubStatus();
    snap4.ok = false;
    snap4.error = "equipmentId inv\xE1lido ou ausente no cat\xE1logo";
    return snap4;
  }
  const idx = bindings.findIndex((b) => b.id === next.id);
  if (idx >= 0) bindings[idx] = { ...bindings[idx], ...next, id: bindings[idx].id };
  else bindings.push(next);
  persist7();
  return hubStatus();
}
function hubRemoveBinding(id) {
  bindings = bindings.filter((b) => b.id !== id);
  persist7();
  return hubStatus();
}
function hubPlanOne(raw) {
  const equipmentId = String(raw.equipmentId || "").trim();
  if (!equipmentId || !getEquipment(equipmentId)) {
    return { ok: false, plan: null, error: "equipmentId inv\xE1lido" };
  }
  const plan = planHamlib({
    equipmentId,
    connectionKind: raw.connectionKind || "usb-serial",
    host: raw.host,
    ports: raw.ports,
    ser2netPort: raw.ser2netPort,
    baud: raw.baud,
    civAddr: raw.civAddr,
    hamlibListenPort: raw.hamlibListenPort
  });
  if (!plan) return { ok: false, plan: null, error: "falha ao montar plano" };
  return { ok: plan.ready, plan, command: formatRigctldCommand(plan), error: plan.deferReason };
}
async function hubRigctl(listenPort, command, host2 = "127.0.0.1", timeoutMs = 2500) {
  const cmd = command.trim().endsWith("\n") ? command.trim() : `${command.trim()}
`;
  return new Promise((resolve) => {
    const sock2 = new Socket();
    let buf = "";
    let done = false;
    const finish2 = (ok, reply, error3) => {
      if (done) return;
      done = true;
      try {
        sock2.destroy();
      } catch {
      }
      resolve({ ok, reply, error: error3 });
    };
    const timer = setTimeout(() => finish2(false, buf, "timeout"), timeoutMs);
    sock2.connect(listenPort, host2, () => {
      sock2.write(cmd);
    });
    sock2.on("data", (chunk) => {
      buf += chunk.toString("utf8");
      if (buf.includes("\n")) {
        clearTimeout(timer);
        finish2(true, buf.trim());
      }
    });
    sock2.on("error", (err) => {
      clearTimeout(timer);
      finish2(false, "", err.message);
    });
    sock2.on("close", () => {
      clearTimeout(timer);
      if (!done) finish2(buf.length > 0, buf.trim(), buf ? void 0 : "conex\xE3o fechada");
    });
  });
}

// server/index.ts
init_icom_lan();
var __filename = fileURLToPath15(import.meta.url);
var __dirname = path.dirname(__filename);
async function startServer() {
  const app = express();
  const server = createServer2(app);
  app.use(express.json({ limit: "32kb" }));
  attachTerminal(server);
  const staticPath = process.env.NODE_ENV === "production" ? path.resolve(__dirname, "public") : path.resolve(__dirname, "..", "dist", "public");
  app.get("/api/ser2net", async (_req, res) => {
    try {
      res.json(await loadSer2net());
    } catch (err) {
      res.status(500).json({ ok: false, services: [], error: String(err) });
    }
  });
  app.put("/api/ser2net", async (req, res) => {
    try {
      const body = await saveSer2net(req.body ?? {});
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, services: [], error: String(err) });
    }
  });
  app.get("/api/ldg", async (_req, res) => {
    try {
      res.json(await ldgPeek());
    } catch {
      res.json(ldgStatus());
    }
  });
  app.put("/api/ldg", async (req, res) => {
    try {
      res.json(await ldgSave(req.body ?? {}));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/ldg/connect", async (req, res) => {
    try {
      const body = await ldgConnect(req.body ?? {});
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/ldg/disconnect", async (_req, res) => {
    try {
      res.json(await ldgDisconnect());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/ldg/cmd", async (req, res) => {
    try {
      res.json(await ldgCmd(String(req.body?.cmd || "")));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.get("/api/lp100a", async (_req, res) => {
    try {
      res.json(await lp100aPeek());
    } catch {
      res.json(lp100aStatus());
    }
  });
  app.put("/api/lp100a", async (req, res) => {
    try {
      res.json(await lp100aSave(req.body ?? {}));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/lp100a/connect", async (_req, res) => {
    try {
      const body = await lp100aConnect();
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/lp100a/disconnect", async (_req, res) => {
    try {
      res.json(await lp100aDisconnect());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/lp100a/cmd", async (req, res) => {
    try {
      res.json(await lp100aCmd(String(req.body?.cmd || "")));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.get("/api/lextel", (_req, res) => {
    res.json(lextelStatus());
  });
  app.put("/api/lextel", async (req, res) => {
    try {
      res.json(await lextelSave(req.body ?? {}));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/lextel/scan", async (req, res) => {
    try {
      res.json(await lextelScan(Number(req.body?.seconds) || 12));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/lextel/connect", async (req, res) => {
    try {
      const body = await lextelConnect(req.body ?? {});
      res.status(body.ok && body.phase !== "error" ? 200 : 503).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/lextel/disconnect", async (_req, res) => {
    try {
      res.json(await lextelDisconnect());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/lextel/keepalive", async (_req, res) => {
    try {
      res.json(await lextelKeepalive());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/lextel/learn", async (_req, res) => {
    try {
      res.json(await lextelLearn());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/lextel/bluetooth", async (_req, res) => {
    try {
      res.json(await lextelOpenBluetooth());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.get("/api/radios", async (_req, res) => {
    try {
      res.json(await radiosStatus());
    } catch (err) {
      res.status(500).json({ ok: false, radios: [], error: String(err) });
    }
  });
  app.put("/api/radios", async (req, res) => {
    try {
      res.json(await radiosSave(req.body ?? {}));
    } catch (err) {
      res.status(500).json({ ok: false, radios: [], error: String(err) });
    }
  });
  app.post("/api/radios", async (req, res) => {
    try {
      res.json(await radiosUpsert(req.body ?? {}));
    } catch (err) {
      res.status(500).json({ ok: false, radios: [], error: String(err) });
    }
  });
  app.post("/api/radios/connect", async (req, res) => {
    try {
      const body = await radiosConnect(req.body ?? {});
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, radios: [], error: String(err) });
    }
  });
  app.post("/api/radios/primary", async (req, res) => {
    try {
      res.json(await radiosSetPrimary(String(req.body?.id ?? "")));
    } catch (err) {
      res.status(500).json({ ok: false, radios: [], error: String(err) });
    }
  });
  app.post("/api/radios/disconnect", async (req, res) => {
    try {
      res.json(await radiosDisconnect(String(req.body?.id ?? "")));
    } catch (err) {
      res.status(500).json({ ok: false, radios: [], error: String(err) });
    }
  });
  app.post("/api/radios/ble", async (req, res) => {
    try {
      res.json(
        await radiosMarkBle(String(req.body?.id ?? ""), Boolean(req.body?.connected), req.body?.name, req.body?.error)
      );
    } catch (err) {
      res.status(500).json({ ok: false, radios: [], error: String(err) });
    }
  });
  app.get("/api/radios/lan", (_req, res) => {
    try {
      res.json(icomLanStatus());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/radios/civ", async (req, res) => {
    try {
      const cmd = String(req.body?.cmd ?? req.body?.command ?? "");
      if (!cmd.trim()) {
        res.status(400).json({ ok: false, error: "cmd obrigat\xF3rio" });
        return;
      }
      const out = await icomLanCmd(cmd, req.body ?? {});
      res.status(out.ok ? 200 : 502).json(out);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.delete("/api/radios/:id", async (req, res) => {
    try {
      res.json(await radiosRemove(req.params.id));
    } catch (err) {
      res.status(500).json({ ok: false, radios: [], error: String(err) });
    }
  });
  app.get("/api/equipment", (_req, res) => {
    try {
      const maker = typeof _req.query.maker === "string" ? _req.query.maker : void 0;
      res.json(hubCatalog(maker));
    } catch (err) {
      res.status(500).json({ ok: false, equipment: [], error: String(err) });
    }
  });
  app.get("/api/hamlib", (_req, res) => {
    try {
      res.json(hubStatus());
    } catch (err) {
      res.status(500).json({ ok: false, bindings: [], plans: [], error: String(err) });
    }
  });
  app.put("/api/hamlib/bindings", (req, res) => {
    try {
      res.json(hubSaveBindings(req.body ?? {}));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/hamlib/bindings", (req, res) => {
    try {
      const body = hubUpsertBinding(req.body ?? {});
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.delete("/api/hamlib/bindings/:id", (req, res) => {
    try {
      res.json(hubRemoveBinding(req.params.id));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/hamlib/plan", (req, res) => {
    try {
      const body = hubPlanOne(req.body ?? {});
      res.status(body.ok || body.plan ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/hamlib/cmd", async (req, res) => {
    try {
      const port2 = Number(req.body?.port ?? 4532);
      const host2 = String(req.body?.host ?? "127.0.0.1");
      const command = String(req.body?.command ?? "");
      if (!command.trim()) {
        res.status(400).json({ ok: false, error: "command obrigat\xF3rio" });
        return;
      }
      const out = await hubRigctl(port2, command, host2);
      res.status(out.ok ? 200 : 502).json(out);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.get("/api/net", async (_req, res) => {
    try {
      res.json(await netStatus());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.put("/api/net", async (req, res) => {
    try {
      res.json(await netSave(req.body ?? {}));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/net/scan", async (_req, res) => {
    try {
      res.json(await netScan());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/net/connect", async (req, res) => {
    try {
      const body = await netConnect(req.body ?? {});
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/net/forget", async (req, res) => {
    try {
      res.json(await netForget(String(req.body?.ssid ?? "")));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/net/link", async (req, res) => {
    try {
      res.json(await netSetLink(req.body?.link === "ethernet" ? "ethernet" : "wifi"));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/net/ip", async (req, res) => {
    try {
      const body = await netSetIp(req.body ?? {});
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/net/hostname", async (req, res) => {
    try {
      const body = await netSetHostname(String(req.body?.hostname ?? ""));
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/net/ap", async (req, res) => {
    try {
      const body = await netSetAp(req.body ?? {});
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.get("/api/services", async (_req, res) => {
    try {
      res.json(await servicesStatus());
    } catch (err) {
      res.status(500).json({ ok: false, items: [], error: String(err) });
    }
  });
  app.post("/api/services", async (req, res) => {
    try {
      const body = await servicesSetAutostart(String(req.body?.id ?? ""), Boolean(req.body?.autostart));
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, items: [], error: String(err) });
    }
  });
  app.get("/api/updates", async (_req, res) => {
    try {
      res.json(await updatesStatus());
    } catch (err) {
      res.status(500).json({ ok: false, items: [], pending: 0, error: String(err) });
    }
  });
  app.post("/api/updates/check", async (_req, res) => {
    try {
      res.json(await updatesRefresh());
    } catch (err) {
      res.status(500).json({ ok: false, items: [], pending: 0, error: String(err) });
    }
  });
  app.post("/api/updates", async (req, res) => {
    try {
      const body = await updatesApply(String(req.body?.id ?? ""));
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, items: [], pending: 0, error: String(err) });
    }
  });
  app.get("/api/serials", async (_req, res) => {
    try {
      res.json({ devices: await listSerialDevices() });
    } catch (err) {
      res.status(500).json({ devices: [], error: String(err) });
    }
  });
  app.get("/api/wavelog/status", async (_req, res) => {
    try {
      res.json(await wavelogStatus());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/wavelog/up", async (_req, res) => {
    try {
      const body = await wavelogUp();
      res.status(body.ok ? 200 : 503).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/wavelog/down", async (_req, res) => {
    try {
      res.json(await wavelogDown());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.get("/api/wavelog/database", async (_req, res) => {
    try {
      res.json(await wavelogDatabase());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/wavelog/db-update", async (_req, res) => {
    try {
      res.setTimeout(3e5);
      const body = await wavelogDbUpdate();
      res.status(body.updated ? 200 : 503).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.get("/api/wlg/status", async (_req, res) => {
    try {
      res.json(await wlgStatus());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/wlg/up", async (_req, res) => {
    try {
      const body = await wlgUp();
      res.status(body.ok ? 200 : 503).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/wlg/down", async (_req, res) => {
    try {
      res.json(await wlgDown());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.get("/api/mmdvm", async (_req, res) => {
    try {
      res.json(await mmdvmStatus());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.put("/api/mmdvm", async (req, res) => {
    try {
      res.json(await mmdvmSave(req.body ?? {}));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/mmdvm/up", async (_req, res) => {
    try {
      const body = await mmdvmControl("start");
      res.status(body.hostRunning || body.installed ? 200 : 503).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/mmdvm/down", async (_req, res) => {
    try {
      res.json(await mmdvmControl("stop"));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/mmdvm/restart", async (_req, res) => {
    try {
      res.json(await mmdvmControl("restart"));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/mmdvm/remote", async (req, res) => {
    try {
      const body = await mmdvmRemote(String(req.body?.cmd || ""));
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/mmdvm/mode/:mode/pause", async (req, res) => {
    try {
      res.json(await mmdvmModePause(String(req.params.mode || ""), true));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/mmdvm/mode/:mode/resume", async (req, res) => {
    try {
      res.json(await mmdvmModePause(String(req.params.mode || ""), false));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/mmdvm/modes/resume-all", async (_req, res) => {
    try {
      res.json(await mmdvmModeResumeAll());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/mmdvm/network", async (req, res) => {
    try {
      res.json(await mmdvmNetworkSet(req.body ?? {}));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/mmdvm/link", async (req, res) => {
    try {
      res.json(await mmdvmLink(req.body ?? {}));
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.get("/api/layout", (req, res) => {
    try {
      res.json(layoutGet(String(req.query.user || "admin")));
    } catch (err) {
      res.status(500).json({ ok: false, tiles: [], error: String(err) });
    }
  });
  app.put("/api/layout", (req, res) => {
    try {
      res.json(layoutSave(req.body?.user, req.body?.tiles));
    } catch (err) {
      res.status(500).json({ ok: false, tiles: [], error: String(err) });
    }
  });
  app.get("/api/users", async (_req, res) => {
    try {
      const [users, ssh] = await Promise.all([listUsers(), sshStatus()]);
      res.json({ users, ssh });
    } catch (err) {
      res.status(500).json({ users: [], error: String(err) });
    }
  });
  app.post("/api/users", async (req, res) => {
    try {
      const name = String(req.body?.name ?? "");
      const password = String(req.body?.password ?? "");
      const body = await createUser(name, password);
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.delete("/api/users/:name", async (req, res) => {
    try {
      const body = await deleteUser(req.params.name);
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.get("/api/host", async (_req, res) => {
    try {
      res.json(await hostStatus());
    } catch (err) {
      res.status(500).json({
        ok: false,
        cpuTempC: null,
        diskTotalBytes: 0,
        diskFreeBytes: 0,
        diskUsedBytes: 0,
        diskPath: "/",
        error: String(err),
        hardware: "",
        soc: "",
        osPretty: "",
        appVersion: "",
        uptimeSec: 0,
        cpuPct: null,
        ramPct: null,
        ramUsedBytes: 0,
        ramTotalBytes: 0,
        netRxBps: null,
        netTxBps: null,
        sampleMs: 5e3,
        windowMs: 3e5,
        samples: []
      });
    }
  });
  app.get("/api/backup", (_req, res) => {
    try {
      res.json(backupList());
    } catch (err) {
      res.status(500).json({ ok: false, items: [], error: String(err) });
    }
  });
  app.post("/api/backup", async (req, res) => {
    req.setTimeout(3e5);
    res.setTimeout(3e5);
    try {
      const body = await backupCreate(String(req.body?.user ?? "admin"));
      res.status(body.ok ? 200 : 500).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.delete("/api/backup/:id", (req, res) => {
    try {
      const body = backupDelete(req.params.id);
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/backup/:id/restore", async (req, res) => {
    req.setTimeout(3e5);
    res.setTimeout(3e5);
    try {
      const body = await backupRestore(req.params.id, Boolean(req.body?.confirm));
      res.status(body.ok ? 200 : 400).json(body);
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.post("/api/vfo-display/exit", async (req, res) => {
    if (!isLoopback(req)) {
      res.status(403).json({ ok: false, error: "local" });
      return;
    }
    try {
      res.json(await vfoDisplayExit());
    } catch (err) {
      res.status(500).json({ ok: false, error: String(err) });
    }
  });
  app.use(express.static(staticPath));
  app.use("/api", (_req, res) => {
    res.status(404).json({ ok: false, error: "API n\xE3o encontrada" });
  });
  app.get("*", (_req, res) => {
    res.sendFile(path.join(staticPath, "index.html"));
  });
  const port = process.env.PORT || 3e3;
  void radiosResumeIcomLan().catch(() => void 0);
  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
    void servicesApplyBoot();
  });
}
startServer().catch(console.error);
